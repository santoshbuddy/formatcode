import { sweepsConstants } from '../constants/sweeps.constants';
import { sweepsService } from '../services/sweeps.service';

export const sweepsActions = {
    fetchSweepData,
    fetchSweepTableData,
	fetchSweepManualData,
	fetchSweepManualTableData,
    fetchSweepLoansData,
    fetchSweepLoansTableData,
	fetchSweepFailedReviewData,
	fetchSweepFailedReviewTableData,
	fetchSweepFailedPreviewData,
	fetchSweepFailedPreviewTableData,
    fetchSweepRuleDetPopUpData,
    fetchSweepNewruleData,
    fetchMaintainRulesSchedulesViewChangesData,
    fetchSweepRunReportData,
    fetchSweepRunReportTableData,
};


function fetchSweepData() {
    return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepData()
            .then(
                sweepsdata => dispatch(success(sweepsdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPDATA_REQUEST } }
    function success(sweepsdata) {
 		return { type: sweepsConstants.GETSWEEPDATA_SUCCESS, sweepsdata } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPDATA_FAILURE, error } }
}

function fetchSweepTableData(bodyFormData){
	   return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepTableData(bodyFormData)
            .then(
                sweepsdatatable => dispatch(success(sweepsdatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPTBLDATA_REQUEST } }
    function success(sweepsdatatable) { return { type: sweepsConstants.GETSWEEPTBLDATA_SUCCESS, sweepsdatatable } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPTBLDATA_FAILURE, error } }

}
function fetchSweepManualData() {
    return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepManualData()
            .then(
                sweepsmanualdata => dispatch(success(sweepsmanualdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPMANUALDATA_REQUEST } }
    function success(sweepsmanualdata) {
 		return { type: sweepsConstants.GETSWEEPMANUALDATA_SUCCESS, sweepsmanualdata } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPMANUALDATA_FAILURE, error } }
}
function fetchSweepManualTableData(bodyFormData){
	   return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepManualTableData(bodyFormData)
            .then(
                sweepsmanualdatatable => dispatch(success(sweepsmanualdatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPMANUALTBLDATA_REQUEST } }
    function success(sweepsmanualdatatable) { return { type: sweepsConstants.GETSWEEPMANUALTBLDATA_SUCCESS, sweepsmanualdatatable } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPMANUALTBLDATA_FAILURE, error } }

}
function fetchSweepLoansData() {
    return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepLoansData()
            .then(
                sweepsloansdata => dispatch(success(sweepsloansdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPLOANSDATA_REQUEST } }
    function success(sweepsloansdata) {
 		return { type: sweepsConstants.GETSWEEPLOANSDATA_SUCCESS, sweepsloansdata } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPLOANSDATA_FAILURE, error } }
}

function fetchSweepLoansTableData(bodyFormData){
	   return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepLoansTableData(bodyFormData)
            .then(
                sweepsloansdatatable => dispatch(success(sweepsloansdatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPLOANSTBLDATA_REQUEST } }
    function success(sweepsloansdatatable) { return { type: sweepsConstants.GETSWEEPLOANSTBLDATA_SUCCESS, sweepsloansdatatable } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPLOANSTBLDATA_FAILURE, error } }

}
function fetchSweepFailedReviewData() {
    return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepFailedReviewData()
            .then(
               sweepfailedreviewdata => dispatch(success(sweepfailedreviewdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPFAILEDREVIEWDATA_REQUEST } }
    function success(sweepfailedreviewdata) {
 		return { type: sweepsConstants.GETSWEEPFAILEDREVIEWDATA_SUCCESS, sweepfailedreviewdata } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPFAILEDREVIEWDATA_FAILURE, error } }
}

function fetchSweepFailedReviewTableData(bodyFormData){
	   return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepFailedReviewTableData(bodyFormData)
            .then(
                sweepfailedreviewtabledata => dispatch(success(sweepfailedreviewtabledata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPFAILEDREVIEWTBLDATA_REQUEST } }
    function success(sweepfailedreviewtabledata) { return { type: sweepsConstants.GETSWEEPFAILEDREVIEWTBLDATA_SUCCESS,sweepfailedreviewtabledata 	 } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPFAILEDREVIEWTBLDATA_FAILURE, error } }

}
function fetchSweepFailedPreviewData() {
    return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepFailedPreviewData()
            .then(
                sweepfailedpreviewdata => dispatch(success(sweepfailedpreviewdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPFAILEDPREVIEWDATA_REQUEST } }
    function success(sweepfailedpreviewdata) {
 		return { type: sweepsConstants.GETSWEEPFAILEDPREVIEWDATA_SUCCESS, sweepfailedpreviewdata } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPFAILEDPREVIEWDATA_FAILURE, error } }
}

function fetchSweepFailedPreviewTableData(bodyFormData){
	   return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepFailedPreviewTableData(bodyFormData)
            .then(
                sweepfailedpreviewtabledata => dispatch(success(sweepfailedpreviewtabledata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPFAILEDPREVIEWTBLDATA_REQUEST } }
    function success(sweepfailedpreviewtabledata) { return { type: sweepsConstants.GETSWEEPFAILEDPREVIEWTBLDATA_SUCCESS, sweepfailedpreviewtabledata } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPFAILEDPREVIEWTBLDATA_FAILURE, error } }

}
function fetchSweepRuleDetPopUpData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepRuleDetPopUpData(bodyFormData)
            .then(
                sweepspopupdata => dispatch(success(sweepspopupdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPPOPUPDATA_REQUEST } }
    function success(sweepspopupdata) { return { type: sweepsConstants.GETSWEEPPOPUPDATA_SUCCESS, sweepspopupdata } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPPOPUPDATA_FAILURE, error } }
}

function fetchSweepNewruleData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepNewruleData(bodyFormData)
            .then(
                sweepsnewrules => dispatch(success(sweepsnewrules)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPRULEDATA_REQUEST } }
    function success(sweepsnewrules) { return { type: sweepsConstants.GETSWEEPRULEDATA_SUCCESS, sweepsnewrules } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPRULEDATA_FAILURE, error } }
}
function fetchMaintainRulesSchedulesViewChangesData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        sweepsService.fetchMaintainRulesSchedulesViewChangesData(bodyFormData)
            .then(
                sweepsnewrules => dispatch(success(sweepsnewrules)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPRULEDATA_REQUEST } }
    function success(sweepsnewrules) { return { type: sweepsConstants.GETSWEEPRULEDATA_SUCCESS, sweepsnewrules } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPRULEDATA_FAILURE, error } }
}
function fetchSweepRunReportData() {
    return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepRunReportData()
            .then(
                sweepstunreportdata => dispatch(success(sweepstunreportdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPRUNREPORTDATA_REQUEST } }
    function success(sweepstunreportdata) {
 		return { type: sweepsConstants.GETSWEEPRUNREPORTDATA_SUCCESS, sweepstunreportdata } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPRUNREPORTDATA_FAILURE, error } }
}

function fetchSweepRunReportTableData(bodyFormData){
	   return dispatch => {
        dispatch(request());

        sweepsService.fetchSweepRunReportTableData(bodyFormData)
            .then(
                sweepstunreporttabledata => dispatch(success(sweepstunreporttabledata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: sweepsConstants.GETSWEEPRUNREPORTTBLDATA_REQUEST } }
    function success(sweepstunreporttabledata) { return { type: sweepsConstants.GETSWEEPRUNREPORTTBLDATA_SUCCESS, sweepstunreporttabledata } }
    function failure(error) { return { type: sweepsConstants.GETSWEEPRUNREPORTTBLDATA_FAILURE, error } }

}