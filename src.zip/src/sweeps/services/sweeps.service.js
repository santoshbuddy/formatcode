import { authHeader,fetchHelper } from '../../_helpers';
import { alertConstants } from '../../common/constants/alert.constants';
import FromData from 'form-data';
export const sweepsService = {
    fetchSweepData,
    fetchSweepTableData,
	fetchSweepLoansData,
	fetchSweepLoansTableData,
	fetchSweepManualData,
	fetchSweepManualTableData,
	fetchSweepFailedReviewData,
	fetchSweepFailedReviewTableData,
	fetchSweepFailedPreviewData,
	fetchSweepFailedPreviewTableData,
    fetchSweepRuleDetPopUpData,
    fetchSweepNewruleData,
    fetchMaintainRulesSchedulesViewChangesData,
    fetchSweepRunReportData,
    fetchSweepRunReportTableData
};


function fetchSweepData() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
     var pathname = window.location.pathname;
     pathname = pathname.substring(pathname.lastIndexOf('/')+1,pathname.length);
     let _tradeData;
    if(user[0].token !== undefined){
        //filtObj["token"] =user[0].token;
        filtObj.append("token",user[0].token);
        filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
           _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);
    }
    return _tradeData;
}

function fetchSweepTableData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tradeReviewData;
 	var pathname = window.location.pathname;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))


        _tradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _tradeReviewData;
}
function fetchSweepManualData() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
     var pathname = window.location.pathname;
     pathname = pathname.substring(pathname.lastIndexOf('/')+1,pathname.length);
     let _tradeData;
    if(user[0].token !== undefined){
        //filtObj["token"] =user[0].token;
        filtObj.append("token",user[0].token);
        filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
           _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);
    }
    return _tradeData;
}

function fetchSweepManualTableData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tradeReviewData;
 	var pathname = window.location.pathname;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))


        _tradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _tradeReviewData;
}
function fetchSweepLoansData() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
     var pathname = window.location.pathname;
     pathname = pathname.substring(pathname.lastIndexOf('/')+1,pathname.length);
     let _tradeData;
    if(user[0].token !== undefined){
        //filtObj["token"] =user[0].token;
        filtObj.append("token",user[0].token);
        filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
           _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);
    }
    return _tradeData;
}

function fetchSweepLoansTableData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tradeReviewData;
 	var pathname = window.location.pathname;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))


        _tradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _tradeReviewData;
}
function fetchSweepRuleDetPopUpData(bodyFormData) {
     var user = JSON.parse(sessionStorage.getItem('user'));
      var pathname = 'ruleDetPopUp';
     let _tradeData;
    if(user[0].token !== undefined){
        //filtObj["token"] =user[0].token;
        	bodyFormData.append("token",user[0].token);
            bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
         _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _tradeData;
}


function fetchSweepNewruleData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var pathname = window.location.pathname;
     let _tradeData;
    if(user[0].token !== undefined){
        //filtObj["token"] =user[0].token;
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        bodyFormData.append("parentProdId","1700");
        bodyFormData.append("actionFlag", "ADD");
        _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/MNEWRULE.do',bodyFormData);
    }
    return _tradeData;
}
function fetchMaintainRulesSchedulesViewChangesData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var pathname = window.location.pathname;
     let _tradeData;
    if(user[0].token !== undefined){
        //filtObj["token"] =user[0].token;
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        bodyFormData.append("parentProdId","1700");
         _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/PRINTSWPAUDPopUp.do',bodyFormData);
    }
    return _tradeData;
}

function fetchSweepRunReportData() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
     var pathname = window.location.pathname;
     pathname = pathname.substring(pathname.lastIndexOf('/')+1,pathname.length);
     let _tradeData;
    if(user[0].token !== undefined){
        //filtObj["token"] =user[0].token;
        filtObj.append("token",user[0].token);
        filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
           _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);
    }
    return _tradeData;
}

function fetchSweepRunReportTableData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tradeReviewData;
 	var pathname = window.location.pathname;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))


        _tradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _tradeReviewData;
}
function fetchSweepFailedReviewData() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
     var pathname = window.location.pathname;
     pathname = pathname.substring(pathname.lastIndexOf('/')+1,pathname.length);
     let _tradeData;
    if(user[0].token !== undefined){
        //filtObj["token"] =user[0].token;
        filtObj.append("token",user[0].token);
        filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
           _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);
    }
    return _tradeData;
}



function fetchSweepFailedReviewTableData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tradeReviewData;
 	var pathname = window.location.pathname;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))

        _tradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _tradeReviewData;
}
function fetchSweepFailedPreviewData() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
     var pathname = window.location.pathname;
     pathname = pathname.substring(pathname.lastIndexOf('/')+1,pathname.length);
     let _tradeData;
    if(user[0].token !== undefined){
        //filtObj["token"] =user[0].token;
        filtObj.append("token",user[0].token);
        filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
           _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);
    }
    return _tradeData;
}


function fetchSweepFailedPreviewTableData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tradeReviewData;
 	var pathname = window.location.pathname;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))


        _tradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _tradeReviewData;
}