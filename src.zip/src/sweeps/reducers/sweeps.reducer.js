import { sweepsConstants } from '../constants/sweeps.constants';

export function sweepsdata(state = {}, action) {
    switch (action.type) {
      case sweepsConstants.GETSWEEPDATA_REQUEST:
        return {
          loading: true
        };
      case sweepsConstants.GETSWEEPDATA_SUCCESS:
        return {
            sweepsdata: action.sweepsdata
        };
      case sweepsConstants.GETSWEEPDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

  export function sweepsdatatable(state = {}, action) {
    switch (action.type) {
      case sweepsConstants.GETSWEEPTBLDATA_REQUEST:
        return {
          loading: true
        };
      case sweepsConstants.GETSWEEPTBLDATA_SUCCESS:
        return {
            sweepsdatatable: action.sweepsdatatable
        };
      case sweepsConstants.GETSWEEPTBLDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

export function sweepsmanualdata(state = {}, action) {
    switch (action.type) {
      case sweepsConstants.GETSWEEPMANUALDATA_REQUEST:
        return {
          loading: true
        };
      case sweepsConstants.GETSWEEPMANUALDATA_SUCCESS:
        return {
            sweepsmanualdata: action.sweepsmanualdata
        };
      case sweepsConstants.GETSWEEPMANUALDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

  export function sweepsmanualdatatable(state = {}, action) {
    switch (action.type) {
      case sweepsConstants.GETSWEEPMANUALTBLDATA_REQUEST:
        return {
          loading: true
        };
      case sweepsConstants.GETSWEEPMANUALTBLDATA_SUCCESS:
        return {
            sweepsmanualdatatable: action.sweepsmanualdatatable
        };
      case sweepsConstants.GETSWEEPMANUALTBLDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

export function sweepsloansdata(state = {}, action) {
    switch (action.type) {
      case sweepsConstants.GETSWEEPLOANSDATA_REQUEST:
        return {
          loading: true
        };
      case sweepsConstants.GETSWEEPLOANSDATA_SUCCESS:
        return {
            sweepsloansdata: action.sweepsloansdata
        };
      case sweepsConstants.GETSWEEPLOANSDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

  export function sweepsloansdatatable(state = {}, action) {
    switch (action.type) {
      case sweepsConstants.GETSWEEPLOANSTBLDATA_REQUEST:
        return {
          loading: true
        };
      case sweepsConstants.GETSWEEPLOANSTBLDATA_SUCCESS:
        return {
            sweepsloansdatatable: action.sweepsloansdatatable
        };
      case sweepsConstants.GETSWEEPLOANSTBLDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

  export function sweepspopupdata(state = {}, action) {
      switch (action.type) {
        case sweepsConstants.GETSWEEPPOPUPDATA_REQUEST:
          return {
            loading: true
          };
        case sweepsConstants.GETSWEEPPOPUPDATA_SUCCESS:
          return {
              sweepspopupdata: action.sweepspopupdata
          };
        case sweepsConstants.GETSWEEPPOPUPDATA_FAILURE:
          return {
            error: action.error
          };

        default:
          return state
      }
  }
  export function sweepsnewrules(state = {}, action) {
    switch (action.type) {
      case sweepsConstants.GETSWEEPRULEDATA_REQUEST:
        return {
          loading: true
        };
      case sweepsConstants.GETSWEEPRULEDATA_SUCCESS:
        return {
          sweepsnewrules: action.sweepsnewrules
        };
      case sweepsConstants.GETSWEEPRULEDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }
  export function sweepstunreportdata(state = {}, action) {
      switch (action.type) {
        case sweepsConstants.GETSWEEPRUNREPORTDATA_REQUEST:
          return {
            loading: true
          };
        case sweepsConstants.GETSWEEPRUNREPORTDATA_SUCCESS:
          return {
              sweepstunreportdata: action.sweepstunreportdata
          };
        case sweepsConstants.GETSWEEPRUNREPORTDATA_FAILURE:
          return {
            error: action.error
          };

        default:
          return state
      }
    }

    export function sweepstunreporttabledata(state = {}, action) {
      switch (action.type) {
        case sweepsConstants.GETSWEEPRUNREPORTTBLDATA_REQUEST:
          return {
            loading: true
          };
        case sweepsConstants.GETSWEEPRUNREPORTTBLDATA_SUCCESS:
          return {
              sweepstunreporttabledata: action.sweepstunreporttabledata
          };
        case sweepsConstants.GETSWEEPRUNREPORTTBLDATA_FAILURE:
          return {
            error: action.error
          };

        default:
          return state
      }
  }

export function sweepfailedreviewtabledata(state = {}, action) {
          switch (action.type) {
            case sweepsConstants.GETSWEEPFAILEDREVIEWTBLDATA_REQUEST:
              return {
                loading: true
              };
            case sweepsConstants.GETSWEEPFAILEDREVIEWTBLDATA_SUCCESS:
              return {
                  sweepfailedreviewtabledata: action.sweepfailedreviewtabledata
              };
            case sweepsConstants.GETSWEEPFAILEDREVIEWTBLDATA_FAILURE:
              return {
                error: action.error
              };

            default:
              return state
          }
  }

  export function sweepfailedreviewdata(state = {}, action) {
            switch (action.type) {
              case sweepsConstants.GETSWEEPFAILEDREVIEWDATA_REQUEST:
                return {
                  loading: true
                };
              case sweepsConstants.GETSWEEPFAILEDREVIEWDATA_SUCCESS:
                return {
                    sweepfailedreviewdata: action.sweepfailedreviewdata
                };
              case sweepsConstants.GETSWEEPFAILEDREVIEWDATA_FAILURE:
                return {
                  error: action.error
                };

              default:
                return state
            }
  }

    export function sweepfailedpreviewdata(state = {}, action) {
          switch (action.type) {
            case sweepsConstants.GETSWEEPFAILEDPREVIEWDATA_REQUEST:
              return {
                loading: true
              };
            case sweepsConstants.GETSWEEPFAILEDPREVIEWDATA_SUCCESS:
              return {
                  sweepfailedpreviewdata: action.sweepfailedpreviewdata
              };
            case sweepsConstants.GETSWEEPFAILEDPREVIEWDATA_FAILURE:
              return {
                error: action.error
              };

            default:
              return state
          }
  }

  export function sweepfailedpreviewtabledata(state = {}, action) {
        switch (action.type) {
          case sweepsConstants.GETSWEEPFAILEDPREVIEWTBLDATA_REQUEST:
            return {
              loading: true
            };
          case sweepsConstants.GETSWEEPFAILEDPREVIEWTBLDATA_SUCCESS:
            return {
                sweepfailedpreviewtabledata: action.sweepfailedpreviewtabledata
            };
          case sweepsConstants.GETSWEEPFAILEDPREVIEWTBLDATA_FAILURE:
            return {
              error: action.error
            };

          default:
            return state
        }
  }


