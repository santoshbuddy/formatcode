import React from 'react';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import InputLabel from '@material-ui/core/InputLabel';
import Button from '@material-ui/core/Button';
import { createMuiTheme, withStyles} from '@material-ui/core/styles';
import 'react-datepicker/dist/react-datepicker.css';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import NativeSelect from '@material-ui/core/NativeSelect';
var dateFormat = require('dateformat');
let isFilterLoaded=false;
 let    formdata={"companyId":"","clientFirm":"","filStatus":""};
 const styles = theme => ({
			 typography: {
				 useNextVariants: true,
		  },
		form: {
		    display: 'flex',
		    flexDirection: 'column',
		    margin: 'auto',
		    width: 'fit-content',
 		  },
		  formControl: {
		    marginTop: 0,
		    paddingRight:50,
		    minWidth: 300,
 		  },
		  formControlLabel: {
		    marginTop: 0,
   		},
	  button: {
	    margin: theme.spacing.unit,
 	  },
	  input: {
	    display: 'none',
	  },
	  textField: {
	      marginLeft: theme.spacing.unit,
	      marginRight: theme.spacing.unit,
	      width: 150,
  },
});
class SweepsManualFilters extends React.Component {
getMuiTheme = () => createMuiTheme({
					root: {
					    flexGrow: 1,
				  },
 				 typography: {
					    useNextVariants: true,
	 			 },

  })


    constructor () {
        super()
        this.state = {
          fromDate: new Date(),
          toDate: new Date(),
            formdata:{"companyId":"","clientFirm":"","filStatus":""},
        };
        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.handleEndDateChange = this.handleEndDateChange.bind(this);
        this.onFilterChange=this.onFilterChange.bind(this);
       }


	onFilterChange(name, ev) {
	 if(name === 'companyId'){
		  formdata['clientFirm'] = ev.target.value;
	 }
	 console.log('name :: '+name);
	  console.log('ev.target.value :: '+ev.target.value);
	 formdata[name] = ev.target.value;
	 this.setState({formdata:formdata});
     this.props.handleUpdate(formdata);

	}
       handleStartDateChange(e) {

          formdata['fromDate'] =e.target.value;
          this.setState({formdata:formdata});
     		this.props.handleUpdate(formdata);
      }
      handleEndDateChange(e) {

			formdata['toDate'] =e.target.value;
			 this.setState({formdata:formdata});
			 this.props.handleUpdate(formdata);

     }
     doChange(e){
     		this.props.method(formdata);
     }

    render(){

        const { data } = this.props;
         const { classes } = this.props;
        let filetermarkup;

        if(data.sweepsmanualdata !== undefined &&  data.sweepsmanualdata.length>0){

			 if(!isFilterLoaded){
							 isFilterLoaded=true;
							 data.sweepsmanualdata.map((filter,index) => {
 								 formdata[filter.name]=filter.fieldValue;
							 });
							  console.log('isFilterLoaded :'+JSON.stringify( formdata	));
							this.props.handleUpdate(formdata);
			 }
		if(data.sweepsmanualdata && data.sweepsmanualdata.length>0){
        filetermarkup = data.sweepsmanualdata.map((filter,index) => {

             if(filter.type === "Select"){

              return(
                              <Grid item key={filter.id.toString()} xs={index===0?6:3} style={{textAlign: 'left',}}>
			   				 			<InputLabel    style={{fontSize:12,}}>  { filter.label } :</InputLabel>


												<NativeSelect defaultValue={formdata[filter.name]}
												   ref={ filter.name }  name={filter.name}  onChange={this.onFilterChange.bind(this, filter.name)} >
												     {filter.values !== undefined && filter.values.map((obj,index) => {
													     return <option key={index} value={obj.id}>{obj.name}</option>
													 })}
												</NativeSelect>


			   	 			</Grid>


               );
            } else if(filter.type === "datepicker"){
                if(filter.name === "fromDate"){

                 return (
  					  <Grid item key={filter.id.toString()} xs={6} style={{textAlign: 'left',}}>
  					   <InputLabel style={{fontSize:12,}}>
                       { filter.label }:</InputLabel>
  					  <TextField
					          id={filter.name}

					          type="date"
					         value={formdata[filter.name]}  onChange={this.handleStartDateChange}
					          className={classes.textField}
					          InputLabelProps={{
					            shrink: true,
					          }}
     						 />
                                </Grid>
                  );
                }else if(filter.name === "toDate"){

                 return (
					  <Grid item key={filter.id.toString()} xs={3}  >
					   <InputLabel style={{fontSize:12,}}>
                       { filter.label }:</InputLabel>
                        <TextField
					          id={filter.name}

					          type="date"
					         value={formdata[filter.name]}  onChange={this.handleEndDateChange}
					          className={classes.textField}
					          InputLabelProps={{
					            shrink: true,
					          }}
     						 />
     						 </Grid>
                 );
                }
              }else if(filter.type === "Button"){
                return (
				 <Grid item key={filter.id.toString()} xs={3} >

				  <button size="small" style={{width: 30, height: 30, margin: 12}} className="btn btn-primary btn-xs"  title="Go" onClick={(e)=>{this.doChange();}} key={filter.id.toString()}>
				                   { filter.name }
                </button>

 				 </Grid>
               );
              }else if(filter.type === "input"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input ref={filter.name}  defaultValue={filter.name}/>
                  </div>
               );
              }else if(filter.type === "checkbox"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input type="checkbox" ref={filter.name}/>
                  </div>
               );
              }else if(filter.type === "radio"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input type="radio" ref={filter.name}/>
                  </div>
               );
              }else if(filter.type === "textarea"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input type="textarea" className="form-control input-sm" ref={filter.name} />
                  </div>
               );
              }else if(filter.type === "newline"){
                return  <div key="newline" className="clearfix"></div>
              }
        });
    }
}

        return(
            <div className={classes.root}>
     					    <Grid container spacing={24}>
 		               		{filetermarkup}
 		               		</Grid>
		               		</div>
        );
    }
}

 export default withStyles(styles)(SweepsManualFilters);
