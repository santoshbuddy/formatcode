import React from "react";
import { Route ,withRouter} from 'react-router-dom';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import FilterIcon from "@material-ui/icons/FilterList";
import Button from '@material-ui/core/Button';

import { withStyles } from "@material-ui/core/styles";
import { Link } from 'react-router-dom';
import { fetchSweepNewruleInfo } from './reduxforms/sweepUtil.js';
import FormData from 'form-data';

const defaultToolbarSelectStyles = {
  iconButton: {
    marginRight: "24px",
    top: "50%",
    display: "inline-block",
    position: "relative",
    transform: "translateY(-50%)",
  },
  refreshIcon: {
    color: "#000",
  },
   button: {
     	     fontSize: 11,
	  },
};

let companyId='';
let prosId='';
let ruleid='';
let actFlag='';
let newrules=[];
let submitData=[];
class FailedTradeToolbarSelect extends React.Component {
	constructor () {
	super()
        this.state = {
		selectedRows:[],
          };
          this.reexecutewithoverride = this.reexecutewithoverride.bind(this);
        }

	reexecutewithoverride(){
		if (window.confirm('Last updated Available Balance will be taken. Do you want to proceed without entering Available Balance Override Value?')){
			this.props.phistory.push({pathname:'/report/CFLTRDPEW',state: { submitData:submitData,actFlag:'OVERRIDE'}});
		}
	}


 handleClick = () => {
	  let ids=[];
	  let rowData=[];
	  this.props.displayData.map((disdata,index) => {
	  this.props.selectedRows.data.map((row,index) => {
	  if(row.dataIndex === disdata.dataIndex){

  		}
	  })
     })
    console.log("handleEditClick click ruleid !"); // a user can do something with these selectedRow values
   }


  render() {

   		 const { classes } = this.props;


		if(this.props.selectedRows){

		let ids=[];
		let rowData=[];
		submitData=[];
 		this.props.displayData.map((disdata,index) => {
		this.props.selectedRows.data.map((row,index) => {
		if(row.dataIndex === disdata.dataIndex){

			 if(!ids.includes(disdata.data[0])){
				 ids.push(disdata.data[0]);
 						  let arry=disdata.data[1].split('~');
 						  let tradeObj= {
 						  seltrd:disdata.data[0],
						  companyId:arry[0],
						  groupId:arry[1],
						  execDate:arry[2],
						  createdDate:arry[3],
						  ddaNum:arry[4],
						  balover:disdata.data[7].props.placeholder
					  }
					  submitData.push(tradeObj);
		}
		}
		})
		})
	 console.log('submitData :'+JSON.stringify( submitData	));

 	}

     return (
      <div className={"custom-toolbar-select"}>

         <div>
         	<Route render={({ history}) => (
			 <Tooltip title={"Re-Execute with Override Available Balance"}>
				<IconButton onClick={this.reexecutewithoverride} >
					<span className="btn btn-primary btn-xs">Re-Execute with Override Available Balance</span>
				</IconButton>
			 </Tooltip>


 		)} />
 			<Tooltip title={"Re-Execute Manually with  Avaialble Balance Call"}>
				   <Link   to={{ pathname: '/report/CFLTRDPEW', state: {submitData:submitData,actFlag:'MANUAL'} }} className="btn btn-primary btn-xs">
					Re-Execute Manually with  Avaialble Balance Call
				   </Link>
 			 </Tooltip>
        </div>
      </div>
    );
  }

}

export default withStyles(defaultToolbarSelectStyles, { name: "CustomToolbarSelect" })(FailedTradeToolbarSelect);