import React from 'react';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { connect } from 'react-redux';
import MUIDataTable from "mui-datatables";
import FromData from 'form-data';
import { sweepsActions } from '../actions/sweeps.actions';
import { MuiThemeProvider} from '@material-ui/core/styles';
import classnames from 'classnames';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

import TableLoader from '../../common/TableLoader';

 const plancols = [
    {
    name: "From Date",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
    name: "To Date",
    options: {
     filter: true,
     sort: false,
    }
   },{
    name: "Time Before Cut-off(mins)",
    options: {
     filter: true,
     sort: false,
    }
   },{
     name: "Schedule Type",
     options: {
      filter: true,
      sort: false,
     }
   },
   {
    name: "Holiday",
    options: {
     filter: true,
     sort: false,
    }
   }
  ];

   const  cols = [
  	{
      name: "Product Category",
      options: {
       filter: true,
       sort: false,
      }
     },
     {
      name: "Product Name",
      options: {
       filter: true,
       sort: false,
      }
     },{
      name: "Currency",
      options: {
       filter: true,
       sort: false,
      }
     },{
       name: "Maximum Amount",
       options: {
        filter: true,
        sort: false,
       }
     },
     {
      name: "Available Shares",
      options: {
       filter: true,
       sort: false,
      }
     } , {
      name: "NAV",
      options: {
       filter: true,
       sort: false,
      }
     } , {
      name: "Principal Amount",
      options: {
       filter: true,
       sort: false,
      }
     }, {
      name: "Month-to-Date Accured",
      options: {
       filter: true,
       sort: false,
      }
     }, {
    name: "Sweep Account Number",
    options: {
     filter: true,
     sort: false,
    }
   }, {
      name: "Sweep Account Name",
      options: {
       filter: true,
       sort: false,
      }
     }, {
      name: "Account Structure",
      options: {
       filter: true,
       sort: false,
      }
     }, {
      name: "Fund Account Number",
      options: {
       filter: true,
       sort: false,
      }
     } , {
      name: "Type",
      options: {
       filter: true,
       sort: false,
      }
     } , {
      name: "Value",
      options: {
       filter: true,
       sort: false,
      }
     }
  ];
class RuleDetails extends React.Component {
 constructor(props) {
	    super(props);
	    this.state = {
		open: false,
		screenName:'',
		tdVal: null,
    	rule:  null,
    	sweepDet:null,
	}
   };
 componentDidMount() {

   }

  handleClickOpen = () => {

    this.setState({ open: true, rule : this.props.ruleDet });
    var bodyFormData = new FromData();


				if(this.props.ruleDet){
				bodyFormData.append("companyId",this.props.ruleDet[0]);
				bodyFormData.append("ruleid",this.props.ruleDet[1]);
				bodyFormData.append("processId",this.props.ruleDet[2]);
				bodyFormData.append("filStatus",(this.props.filStatus !== undefined)?this.props.filStatus:'N');

				  this.props.dispatch(sweepsActions.fetchSweepRuleDetPopUpData(bodyFormData));
			}
  };

  handleClose = () => {
    this.setState({ open: false });
  };

  render() {
const options = {
      filter: true,
      filterType: 'dropdown',
      responsive: "scroll",
      selectableRows:false,
      setRowProps: (row, rowIndex) => {
        let rem = rowIndex % 2;
          if(rem === 0){
            return {
                style: { backgroundColor: '#fff'}
            };
          }else {
            return {
                style: { backgroundColor: '#f7f8f9'}
            };
          }
      },
       textLabels: {
	              body: {
	                 noMatch: this.props.sweepspopupdata.loading ?
                    <TableLoader /> :
	                      <div key={'1'}  style={{fontSize: 12, color: 'red' ,textAlign: 'center'}}> <b key={'2'}>No data available in table</b></div>,
	              },
        },
    };


// console.log('mapStateToProps : results1'+JSON.stringify( this.props.assProdVec));

//this.state.sweepDet=this.props.sweepDet;

    return (
      <div>
        <a href="javascript:void(0);" onClick={this.handleClickOpen}>
          {this.props.tdVal}
        </a>
        <Dialog  fullWidth={true}
          maxWidth={'md'}
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="form-dialog-title">Rule Details</DialogTitle>
          <DialogContent>
           <Paper>
		<Table>
		<TableHead>
		</TableHead>
			<TableBody>
				<TableRow style={{height:'auto',}}>
					<TableCell>Rule Name:</TableCell>
					<TableCell>{this.props.sweepDet?this.props.sweepDet.RULENAME:''}</TableCell>

					<TableCell align="right">Rule Type:</TableCell>
					<TableCell align="right">{this.props.sweepDet?this.props.sweepDet.RULETYPE:''}</TableCell>
				</TableRow>

				<TableRow style={{height:'auto',}}>
					<TableCell>Approval:</TableCell>
					<TableCell>{this.props.sweepDet?this.props.sweepDet.APPROVALDESC:''}</TableCell>

					<TableCell align="right">Increment Amount:</TableCell>
					<TableCell align="right">{this.props.sweepDet?this.props.sweepDet.INCRAMT:''}</TableCell>
				</TableRow>

				<TableRow style={{height:'auto',}}>
					<TableCell>Target Balance:</TableCell>
					<TableCell>{this.props.sweepDet?this.props.sweepDet.TARGETBAL:''}</TableCell>

					<TableCell align="right">Target Balance CCY:</TableCell>
					<TableCell align="right">{this.props.sweepDet?this.props.sweepDet.TARGETCCY:''}</TableCell>
				</TableRow>

				<TableRow style={{height:'auto',}}>
					<TableCell>Trigger Amount:</TableCell>
					<TableCell>{this.props.sweepDet?this.props.sweepDet.TRIGAMT:''}</TableCell>

					<TableCell align="right">Trigger CCY:</TableCell>
					<TableCell align="right">{this.props.sweepDet?this.props.sweepDet.TRIGCCY:''}</TableCell>
				</TableRow>

				<TableRow style={{height:'auto',}}>
					<TableCell>Rule Mode:</TableCell>
					<TableCell>{this.props.sweepDet?this.props.sweepDet.RULEMODEDESC:''}</TableCell>

					<TableCell align="right">DDA Type:</TableCell>
					<TableCell align="right">{this.props.sweepDet?this.props.sweepDet.DDATYPE:''}</TableCell>
				</TableRow>

				<TableRow style={{height:'auto',}}>
					<TableCell>Loan Sweep:</TableCell>
					<TableCell>Yes</TableCell>
				</TableRow>
			</TableBody>
		</Table>
			{this.props.assProdVec && this.props.assProdVec.length > 0?
			<MUIDataTable title={"Product Details"}
			data={this.props.assProdVec}
			columns={cols} options={options} />:''}

			<MUIDataTable title={"Schedule Details"}
						data={this.props.planDetVec}
			columns={plancols}  options={options} 	/>

 			 </Paper>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>

          </DialogActions>
        </Dialog>
      </div>
    );
  }
}
function mapStateToProps(state) {
    const { sweepspopupdata } = state;


let sweepDet;
let assProdVec =[];
let planDetVec =[];
let results=[];

 			let results1  =  sweepspopupdata.sweepspopupdata;

        //console.log('mapStateToProps : results1'+JSON.stringify( results1));

			let screenName="";
			let from="REFRESH";
	        if( results1 && results1.length>0)
	             results1.map((item,index) => {

		//			 console.log('item.type '+item.type);
    			if(item.type === "Title")
                 screenName = item.name

 //console.log('item.name '+item.name);
				 if(item.name === "sweepDet" && item.values){
	                 	results = item.values
						 results.map(grprecord => {
							 sweepDet=grprecord;
 						})
					}
 					let MainaspVec=[];
	                if(item.name === "assProdVec" && item.values){
	                 	results = item.values
						 results.map(row => {
							 let aspVec=[];
						 aspVec.push(row.PRODCAT);
						 aspVec.push(row.PRODNAME);
						 aspVec.push(row.CURRENCYCODE);
						 aspVec.push(row.MAXAMOUNT);

						 aspVec.push(row.ENDSHARES);
						 aspVec.push(row.NAV);
						 aspVec.push(row.PRAMOUNT);
						 aspVec.push(row.MTD);
						 aspVec.push(row.REFACCTNBR);
						 aspVec.push(row.ACCTNAME);
						 aspVec.push(row.ACCTSTRUCDESCR);

						 aspVec.push(row.FUNDACCTNBR);
						 aspVec.push(row.TYPEDESC);
						 aspVec.push(row.VALUE);
						 MainaspVec.push(aspVec);

						})
					}
					 if(MainaspVec.length>0)
					 assProdVec=MainaspVec;

					//   console.log('mapStateToProps : results1'+JSON.stringify( assProdVec));

					let MainpldVec=[];
					if(item.name === "planDetVec" && item.values){
								results = item.values
 									results.map(row => {
										let pldVec=[];
									pldVec.push(row.FROMDATE);
									pldVec.push(row.TODATE);
									pldVec.push(row.EXECTIME);
									pldVec.push(row.SCHTYPEID);
									pldVec.push(row.HOLIDAY);
									 MainpldVec.push(pldVec);
									})
					}
					 if(MainpldVec.length>0)
					 planDetVec=MainpldVec;
	            })

    return { sweepspopupdata ,sweepDet,assProdVec,planDetVec};
}

 export default connect(mapStateToProps)(RuleDetails)  ;



