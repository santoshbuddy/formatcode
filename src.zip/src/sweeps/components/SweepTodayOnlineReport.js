import React from 'react';
import { Route } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { sweepsActions } from '../actions/sweeps.actions';
import { connect } from 'react-redux';
import SweepTodayOnlineReportFilters from './SweepTodayOnlineReportFilters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import RuleDetails from './RuleDetails';
import MUIDataTable from "mui-datatables";
import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import classnames from 'classnames';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import Grid from '@material-ui/core/Grid';
import PropTypes from 'prop-types';
import FailedTradeToolbarSelect from './FailedTradeToolbarSelect';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import FormData from 'form-data';
import RefreshIcon from "@material-ui/icons/Refresh";
import Loading from '../../common/Loading';
import TableLoader from '../../common/TableLoader';

let formdata ={};
let isFilterLoaded=false;

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });
  const styles = theme => ({
  iconButton: {
    marginRight: "24px",
    top: "50%",
    display: "inline-block",
    position: "relative",
    transform: "translateY(-50%)",
  },
  refreshIcon: {
    color: "#000",
  },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
    },
     formControl: {
    		    marginTop: 0,
    		    minWidth: 120,
    		     fontSize: 11,
    		  },
    		  formControlLabel: {
    		    marginTop: 0,
    		     fontSize: 11,
      		},
    	  button: {
    	    margin: theme.spacing.unit,
    	     fontSize: 11,
  	  },
});

   const cols = [
    {
    name: "Types",
         options: {
          filter: true,
          sort: true,
            customBodyRender: (value, tableMeta, updateValue) => {
  	       	                 return (
  	       	                  <Tooltip title={value} placement="right">
    	        			<a href="#">{value}</a>
  	       	            	</Tooltip>
  	       	                   );
     	 }
      	}
     },
     {
      name: "Deal No",
            options: {
             filter: true,
             sort: true,
               customBodyRender: (value, tableMeta, updateValue) => {
  	          	                 return (
  	          	                  <Tooltip title={value} placement="right">
  	          	                   <a href="#">{value.substring(0,10)}</a>

  	          	            	</Tooltip>
  	          	                   );
     	 }
         	}
     },
     {
      name: "Deal Status",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Investment Business Entity",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Client Name",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "NAV",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "No. of Shares",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Transaction Amount",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Currency",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Maturity Date",
            options: {
             filter: true,
             sort: true,

         	}
     },{

      name: "Rule Name",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Cno",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Trade Date",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Value Date",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Contract No",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Days to Maturity",
            options: {
             filter: true,
             sort: true,

         	}
     },{

      name: "Interest Rate",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Base Rate",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Sales Margin",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Sales Revenue",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Interest Amount",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Maturity Amount",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Yield",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Unit Type",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Comm Usualid",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Settlement A/c",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Settlement A/c",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Maturity A/c",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Account Number",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Account Name",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Booked By",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Product",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Trade Time",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Modified By",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Modified Date/Time",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Trade Reason",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Accepted By",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Approved/Rejected By",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Approved/Rejected Time",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Auto Rollover",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Pledge Name",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Local Tax",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Foreign Tax",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Memo Details",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Pledge Date",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Omnibus Override",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Parent DDA Balance Time",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Parent DDA Balance",
            options: {
             filter: true,
             sort: true,

         	}
     },{
      name: "Child DDA Balance and Time",
            options: {
             filter: true,
             sort: true,

         	}
     },
     ];

class SweepTodayOnlineReport extends React.Component {

getMuiTheme = () => createMuiTheme({
		  typography: {
		 									    useNextVariants: true,
	 			 },
		    overrides: {

				 MuiFormControl: {
						  	        marginNormal: {
						   	           marginTop: '0px',
						   	            marginBottom: '0px',
						   	        }
		      }, MuiIconButton: {
						  	        root: {
						   	           padding: '2px',
						   	        }
		      },
		      MUIDataTableBodyCell: {
		        root: {
	 	           whiteSpace: 'nowrap',
	 	           padding:'0px 56px 0px 24px'
	 	        }
		      },
		      MUIDataTableBodyRow: {
			  	        root: {
			   	           height: '20px',
			   	        }
		      },
		    }
  })

    constructor(){
        super();
        this.state={
            results:[],
            results1:[],
            data:[],
            sweepsdata:[],
            sweepsdatatable:[],
            columns:[],
            screenName:'',
            selected: {},
            selectAll: 0
        }
        this.doChange = this.doChange.bind(this);
        this.handleChildUpdate = this.handleChildUpdate.bind(this);
		this.handleRefresh = this.handleRefresh.bind(this);

    }
    componentDidMount() {
        this.getFilter()
   }
   getFilter(){
    this.props.dispatch(sweepsActions.fetchSweepData());
   }

    handleChildUpdate(formdataObj){
      	 formdata=formdataObj ;
         //console.log('handleChildUpdate :'+JSON.stringify( formdata	));
     }
   doChange(fillObj){
        var bodyFormData = new FormData();
        for (name in fillObj) {
            bodyFormData.append(name, fillObj[name]);
        }
        this.props.dispatch(sweepsActions.fetchSweepTableData(bodyFormData));

   }
	handleRefresh(){
		 var bodyFormData = new FormData();
        for (name in formdata) {
            bodyFormData.append(name, formdata[name]);
        }
		 this.props.dispatch(sweepsActions.fetchSweepTableData(bodyFormData));

     }
    render(){

         const { classes } = this.props;
 	 const { sweepsdata,sweepsdatatable } = this.props;
	 if(sweepsdata.sweepsdata !== undefined){
	           let results1 =[];
	               if(!isFilterLoaded && sweepsdata && sweepsdata.sweepsdata){
	            results1=  sweepsdata.sweepsdata;
	               isFilterLoaded=true;
	             if(sweepsdata.sweepsdata !== undefined){
	             	sweepsdata.sweepsdata.map((filter,index) => { formdata[filter.name]=filter.fieldValue; });
		     }
			 else{
				    return(
					<Loading />
				    )
        	     }
				}else {
				results1=  sweepsdatatable.sweepsdatatable;

				}

				let screenName="";
				let msg="";
				let msgType="success";
				let results = [];
		 		if( results1)
		             results1.map((item,index) => {
		                if(item.type === "Title")
		                  screenName = item.name

						 if(item.type === "Message"){
		                  msg = item.name;
		                  msgType =item.label;
					  	}

		                if(item.name === "data")
		                 results = item.values
		            })

	 console.log('data<>--- :'+sweepsdata.sweepsdata);
		           let data=[];
					if(results && results.length>0){
					 results.map(row => {
					let cdata=[];
					cdata.push('');
					if(row.DealNo !== 'N/A' && row.DealNo !== '0.00'){
					console.log('row.DealNo<>--- :'+row.DealNo);
					cdata.push(row.DealNo);
					cdata.push(row.DealStatus);
					cdata.push(row.InvestmentBusinessEntity);
					cdata.push(row.ClientName);
					cdata.push(row.NAV);
					cdata.push(row.NoofShares);
					cdata.push(row.TransactionAmount);
					cdata.push(row.Currency);
					cdata.push(row.MaturityDate);
					cdata.push(row.RuleName);
					cdata.push(row.Cno);
					cdata.push(row.TradeDate);
					cdata.push(row.ValueDate);
					cdata.push(row.ContractNo);
					cdata.push(row.DaystoMaturity);
					cdata.push(row.InterestRate);
					cdata.push(row.BaseRate);
					cdata.push(row.SalesMargin);
					cdata.push(row.SalesRevenue);
					cdata.push(row.InterestAmount);
					cdata.push(row.MaturityAmount);
					cdata.push(row.Yield);
					cdata.push(row.UnitType);
					cdata.push(row.CommUsualid);
					cdata.push(row.SettlementAc);
					cdata.push(row.SettlementAc);
					cdata.push(row.MaturityAc);
					cdata.push(row.AccountNumber);
					cdata.push(row.AccountName);
					cdata.push(row.BookedBy);
					cdata.push(row.Product);
					cdata.push(row.TradeTime);
					cdata.push(row.ModifiedBy);
					cdata.push(row.ModifiedDateTime);
					cdata.push(row.TradeReason);
					cdata.push(row.AcceptedBy);
					cdata.push(row.ApprovedRejectedBy);
					cdata.push(row.ApprovedRejectedTime);
					cdata.push(row.AutoRollover);
					cdata.push(row.PledgeName);
					cdata.push(row.LocalTax);
					cdata.push(row.ForeignTax);
					cdata.push(row.MemoDetails);
					cdata.push(row.PledgeDate);
					cdata.push(row.OmnibusOverride);
					cdata.push(row.ParentDDABalanceTime);
					cdata.push(row.ParentDDABalance);
					cdata.push(row.ChildDDABalanceandTime);

 					data.push(cdata);
					}
					})
	{data}
	   console.log('data<>-22-- :'+data);

	}
const options = {
	  viewColumns:false,
      filter: true,
      filterType: 'dropdown',
      responsive: 'stacked',
       responsive: 'scroll',selectableRows:false,
      selectableRows: formdata['filStatus']=== 'Y'?true:false,
	   setRowProps: (row) => {

      },
      customToolbarSelect: (selectedRows, displayData, setSelectedRows) =>   <SweepToolbarSelect handleDelete={this.handleDelete} selectedRows={selectedRows} displayData={displayData} setSelectedRows={setSelectedRows} fromPage={this.state.fromPage} />
	,textLabels: {
            body: {
                   noMatch: this.props.sweepsdatatable.loading ?
			                       <TableLoader /> :
                                      <div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'left',paddingLeft:'510px'}}> <b key={'2'}>No data available with selected criteria.</b></div>,
            },
        },
    };

        // const columns1 = ["Name", "Company", "City", "State"];

        // const data1 = [
        //  ["Joe James", "Test Corp", "Yonkers", "NY"],
        //  ["John Walsh", "Test Corp", "Hartford", "CT"],
        //  ["Bob Herm", "Test Corp", "Tampa", "FL"],
        //  ["James Houston", "Test Corp", "Dallas", "TX"],
        // ];
        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">Sweep Today's Online Report</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
                            <SweepTodayOnlineReportFilters handleUpdate={this.handleChildUpdate} method={this.doChange} data={sweepsdata}/>
                            </div>
                        </div>

                        <div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                                </div>
                            </div>
                             <MuiThemeProvider theme={this.getMuiTheme()}>
							<MUIDataTable title={(  <Tooltip title={"Refresh"}><IconButton className={classes.iconButton} onClick={this.handleRefresh}>
 								  </IconButton>
								 </Tooltip>)}
			    					data={data}
			    					columns={cols} options={options} viewColumns={false}/>
			</MuiThemeProvider>



                        </div>
                    </div>
                </div>
            </div>
        );
        }
	    else
	    {
		return(
		    <Loading />
		)
    	    }
    }
}

SweepTodayOnlineReport.propTypes = {
  classes: PropTypes.object.isRequired,
};
function mapStateToProps(state) {
    const { sweepsdata,sweepsdatatable } = state;
    return { sweepsdata,sweepsdatatable };
}

const connectedSweepRunReport = connect(mapStateToProps)((withStyles(styles))(SweepTodayOnlineReport));
export { connectedSweepRunReport as SweepTodayOnlineReport };
