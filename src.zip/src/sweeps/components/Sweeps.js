import React from 'react';
import { Route } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { sweepsActions } from '../actions/sweeps.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';

class Sweeps extends React.Component {

    componentDidMount() {
         console.log("LOGGGG "+window.location.pathname);
                  console.log("LOGGGG "+this.props.location.pathname);

   }



    render(){

        return(
            <div>
                <NavBar/>

            </div>
        );
    }
}

export default  Sweeps;
