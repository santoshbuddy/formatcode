import React from 'react'
import { Field } from 'redux-form'
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

import  Paper from '@material-ui/core/Paper'
import MenuItem from '@material-ui/core/MenuItem';
import TableCell from '@material-ui/core/TableCell';
import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import RadioGroup from '@material-ui/core/RadioGroup';
import Radio from '@material-ui/core/Radio';
import FormLabel from '@material-ui/core/FormLabel';
import ProdMUITable from './ProdMUITable';
import Info from "@material-ui/icons/Info";

import {
  Select
} from "redux-form-material-ui";

const CustomTableCell = withStyles(theme => ({
    head: {
      backgroundColor: theme.palette.background.default,
      color: theme.palette.common.black,
    },
    body: {
      fontSize: 12
    },
  }))(TableCell);
  
  
  
  
  const styles = theme => ({
    root: {
      ...theme.mixins.gutters(),
      paddingTop: theme.spacing.unit * 2,
      paddingBottom: theme.spacing.unit * 2,
      backgroundColor: '#f4f3f3',
      border : '1px solid #ccc'
    },
    paper: {
      padding: theme.spacing.unit * 2,
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    table: {
        minWidth: 1000,
      },
    tableWrapper: {
        overflowX: 'auto',
      },
      row: {
        '&:nth-of-type(odd)': {
          backgroundColor: theme.palette.background.default,
        },
      },

      label: {
        fontSize: '12px',
      },
      margin: {
        marginRight: '0px',
        marginLeft: '0px',
      },
      insrt:{
        fontSize:'10px',
        color: '#666666',
        fontFamily: 'arial,helvetica,sans-serif',
      },
      radio:{padding:'0px 3px 3px 10px !important', 
      height: 20, size: 6}
    

  });
  
  const renderTextField = ({
    label,
    input,
    meta: { touched, invalid, error },
    ...custom
  }) => (
    <TextField
      label={label}
      placeholder={label}
      error={touched && invalid}
      helperText={touched && error}
      variant="outlined" 
      inputProps={{
        style: {textAlign: "left", padding : 0, width: 120,
        height: 20, fontSize: 12}
      }}    
      {...input}
      {...custom}
    />
  )
  
  const renderCheckbox = ({ input, label }) => ( 
      <FormControlLabel
        control={
          <Checkbox
            style={{padding:'0px !important', 
            height: 16}}
            checked={input.value ? true : false}
            onChange={input.onChange}
          />
        }
        label={label}
      />
  )

  const renderRadioGroup = ({ input, ...rest }) => (
    <RadioGroup
      {...input}
      {...rest}
      value={input.value}     
      onChange={(event, value) => input.onChange(value)}
      row 
    />
  )
let sfromPage, sactionFlag;
 class RulesBlock extends React.Component {
    constructor(props) {
    super(props);     
    this.handleKeypress = this.handleKeypress.bind(this)
    }    
    handleKeypress (e) {
        const characterCode = e.key
        if (characterCode === 'Backspace') return
    
        const characterNumber = Number(characterCode)
        if (characterNumber >= 0 && characterNumber <= 9) {
          if (e.currentTarget.value && e.currentTarget.value.length) {
            return
          } else if (characterNumber === 0) {
            e.preventDefault()
          }
        } else {
          e.preventDefault()
        }
  }
    render(){ 
        const {classes} = this.props
        const tblStyle  = {width: "1200px"};
        const grpStyle  = {height: "10px"};  
        const omsTRowStyle  = { height: "14px", width: "60px", padding: "0px", textAlign:"center"};
        const omsTColStyle  = { height: "14px", width: "60px", padding: "2px"};

        sfromPage = this.props.fromPage;
        sactionFlag = this.props.actionFlag;
      
       // console.log(' accountslist::render:'+JSON.stringify( this.props.sweepsnewrules));     
        var menuacct = '';
         if(this.props.sweepsnewrules && this.props.sweepsnewrules.clientAcctList){
          menuacct = 
          this.props.sweepsnewrules.clientAcctList.map((obj,index) => {
            return <MenuItem key={index} value={obj.ACCTNBR} >{obj.REFACCTNBR}-{obj.ACCTNAME}</MenuItem>
            }) 
        }else {
          menuacct = <MenuItem value='none' >'None'</MenuItem>
        }
                        

         var acctGrp = '';
         if(this.props.sweepsnewrules && this.props.sweepsnewrules.acctGrp){
          acctGrp = 
          this.props.sweepsnewrules.acctGrp.map((obj,index) => {
            return <MenuItem key={index} value={obj.ACCTNBR} >{obj.ACCTNAME}</MenuItem>
            }) 
        }else {
          acctGrp = <MenuItem value='none' >'None'</MenuItem>
        }

        //console.log("DDDDDDDDDDDDDDDDDDDDD:::"+rulesProductData);
        /*let parsedData;
        if(this.props.sweepsnewrules.data != undefined){
          parsedData = JSON.parse(this.props.sweepsnewrules.data);
        }*/
        let parsedCols;
        if(this.props.sweepsnewrules.DataColumns != undefined){
          parsedCols = JSON.parse(this.props.sweepsnewrules.DataColumns);
        }     
           
       
    return (	
      <Paper  className={classes.root} >
    <Paper  className={classes.root} elevation={1}>
     <div className="clearfix"></div>    
       <div className="form-group"  >      
      <div className="form-group col-md-2 col-sm-2" >     
      <FormLabel className={classes.label}>Rule Name:</FormLabel>
      </div>
      <div className="form-group col-md-2 col-sm-2" >
      <Field name="ruleName" component={renderTextField} label=""  />
      </div>
      <div className="form-group col-md-2 col-sm-2" >       
      <FormLabel className={classes.label}>DDA Type:</FormLabel> 
      </div>
      <div className="form-group col-md-2 col-sm-2" >  
      <Field name="ddaType" label='Concentration' component={renderCheckbox}/>
      </div> 
      <div className="form-group col-md-4 col-sm-4" >    </div>
      
      </div>
      <div className="clearfix"></div>
      <div className="form-group"  >
      <div className="form-group col-md-2 col-sm-2" >
      <FormLabel  className={classes.label}>Rule Mode:</FormLabel>
      </div>
      <div className="form-group col-md-4 col-sm-4" >
      <Field name="ruleMode" component={renderRadioGroup}>
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="R"
            control={<Radio color="primary"  classes={{root:classes.radio}}/>}
            label="Round Trip"
            labelPlacement="end" />
         <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="N"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Normal"
            labelPlacement="end" />
        </Field>
      
      </div>
      <div className="form-group col-md-6 col-sm-6" ></div>
      </div>
      <div className="clearfix"></div>
      <div className="form-group" >
      <div className="form-group col-md-2 col-sm-2" >
      <FormLabel  className={classes.label}>Accont Rule:</FormLabel>
      </div> 
      <div className="form-group col-md-4 col-sm-4" >
      <Field name="accountRule" component={renderRadioGroup}>
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="S"
            control={<Radio color="primary" classes={{root:classes.radio}} />}
            label="Single"
            labelPlacement="end" />
         <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="M"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Multiple"
            labelPlacement="end" />
        </Field>
      </div> 
      <div className="form-group col-md-6 col-sm-6" > </div>
      </div>
      <div className="clearfix"></div>  

      <div className="form-group" >
      <div className="form-group col-md-2 col-sm-2" >
      <FormLabel  className={classes.label}>Investment A/c:</FormLabel>
      </div>        
      <div className="form-group col-md-4 col-sm-4" >
      <Field           
            component={Select}            
            name="account"
            style = {{fontSize: 12}}           
          >
    	{menuacct}
      
          </Field>
      </div>
      <div className="form-group col-md-2 col-sm-2" >
      <FormLabel  className={classes.label}>Account Group:</FormLabel>       
      </div>        
      <div className="form-group col-md-4 col-sm-4" > 
      <Field           
            component={Select}            
            name="acctGrp"
            style = {{fontSize: 12}}
           
          >
         {acctGrp}
        </Field>
      
      </div>

      </div>
      <div className="clearfix"></div>     
     
      </Paper>
      <Paper className={classes.root}>
      <div className="panel">
            <div className="panel-heading clearfix">
                    <h4 className="panel-title pull-left col-md-1">Amount Details</h4>
             </div>
      </div>
      <div className="clearfix"></div>
      <div className="form-group" >
          <div className="form-group col-md-12 col-sm-12 ">
          <span className= {classes.insrt} > <Info className={classes.info} style={{float:'left'}}/>
         &nbsp; These fields do not accept decimals. </span>
			    </div>
      </div>      
      <div className="clearfix"></div>
      <div className="clearfix"></div>
      <div className="form-group" >

      <div className="form-group col-md-2 col-sm-2" >
      <FormLabel  className={classes.label}>Target Balance CCY:</FormLabel>   
      </div>        
      <div className="form-group col-md-4 col-sm-4" > 
      <Field           
            component={Select}            
            name="targetCcy"
            style = {{fontSize: 12}}
           
          >
          <MenuItem value="EUR" >EUR</MenuItem>
          <MenuItem value="GBP" >GBP</MenuItem>
        </Field>     
      </div>

      <div className="form-group col-md-2 col-sm-2" >
      <FormLabel  className={classes.label}>Target Balance:</FormLabel> 
      </div> 
      <div className="form-group col-md-2 col-sm-2" >
      <Field name="targetBal" onKeyDown={this.handleKeypress} component={renderTextField} label="" />
      </div>      

      </div>
      <div className="clearfix"></div>   
      <div className="form-group" >

      <div className="form-group col-md-2 col-sm-2" >       
        <FormLabel  className={classes.label}>Trigger CCY:</FormLabel>
      </div>        
      <div className="form-group col-md-4 col-sm-4" >      
      <FormLabel  className={classes.label}>EUR</FormLabel>
      </div>

      <div className="form-group col-md-2 col-sm-2" >     
      <FormLabel  className={classes.label}>Trigger Amount:</FormLabel>
      </div> 
      <div className="form-group col-md-2 col-sm-2" >
      <Field name="trigAmt" onKeyDown={this.handleKeypress} component={renderTextField} label="" />
      </div>      

      </div>
      <div className="clearfix"></div>  
      <div className="form-group" >
      <div className="form-group col-md-2 col-sm-2" >      
        <FormLabel  className={classes.label}>Increment Amount:</FormLabel>
      </div>        
      <div className="form-group col-md-2 col-sm-2" > 
      <Field name="incrAmt" onKeyDown={this.handleKeypress} component={renderTextField} label="" />
      </div>

      <div className="form-group col-md-8 col-sm-8" > </div> 

      </div>
      <div className="clearfix"></div>    
      </Paper>

      <Paper className={classes.root}>
      <div className="panel">
            <div className="panel-heading clearfix">
                  <h4 className="panel-title pull-left col-md-1">Balance Details</h4>
             </div>
      </div>
      <div className="clearfix"></div>
      <div className="form-group" >

      <div className="form-group col-md-2 col-sm-2" >      
        <FormLabel className={classes.label}>Balance Type:</FormLabel>
      </div>        
      <div className="form-group col-md-10 col-sm-10" > 
      <Field name="balType" component={renderRadioGroup}>
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="100"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Available Balance"
            labelPlacement="end" />
         <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="101"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Value Dated Balance"
            labelPlacement="end"
           />
          <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="101"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Value Dated Balance"
            labelPlacement="end"
            />
          <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="102"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Ledger Balance"
            labelPlacement="end"
            />
          <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="103"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Projected Balance"
            labelPlacement="end"   />
           <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="104"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Override Balance"
            labelPlacement="end"   />
        </Field>     
      </div>
      </div>
      <div className="clearfix"></div>   
      <div className="form-group" >

      <div className="form-group col-md-2 col-sm-2" >        
        <FormLabel  className={classes.label}>Approval:</FormLabel>
      </div>        
      <div className="form-group col-md-2 col-sm-2" > 
      <Field name="approval" component={renderRadioGroup}>
      {(sfromPage && sfromPage == 'CNEWRULE') ?
         <FormControlLabel
           classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="A"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Automatic"
            labelPlacement="end"    /> : <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="M"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Manual"
            labelPlacement="end" />
          }
       </Field>
      </div>

      <div className="form-group col-md-8 col-sm-8" ></div> 
      </div>
      <div className="clearfix"></div>  
      <div className="form-group" >
      <div className="form-group col-md-2 col-sm-2" >      
        <FormLabel  className={classes.label}>Rule Type:</FormLabel>
      </div>        
      <div className="form-group col-md-10 col-sm-10" > 
      <Field name="ruleType" component={renderRadioGroup}>
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="10"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Re-balance"
            labelPlacement="end"  />
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="20"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Redeem Only"
            labelPlacement="end"  />
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="12"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Invest Only"
            labelPlacement="end" />
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="15"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Invest Net of Debit"
            labelPlacement="end"  />
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="55"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Redeem Net To Debit"
            labelPlacement="end" />
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="35"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Invest Net of Debt And Target"
            labelPlacement="end" />
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="45"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Redeem Net to Debt And Target"
            labelPlacement="end" />
       </Field>     
      </div>
      </div>
      <div className="clearfix"></div>    
      </Paper>      
      <div>
      <ProdMUITable ProdDetCols={parsedCols} ProdDetMap={this.props.sweepsnewrules.assocRuleProd} 
      ruleProdData ={this.props.parsedData} fromPage={sfromPage} actionFlag={sactionFlag}     
      dispatch={this.props.dispatch}
      saveFlag ={this.props.saveFlag}
      resultMsg ={this.props.resultMsg}
      updateProdsMethod={this.props.updateProdsMethod}
      />
      </div>
      </Paper>
        );
    }
}

RulesBlock.propTypes = {
    classes: PropTypes.object.isRequired,
  };
  
  export default withStyles(styles)(RulesBlock);