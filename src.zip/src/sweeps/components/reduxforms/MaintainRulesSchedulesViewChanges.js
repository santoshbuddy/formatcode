import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { connect } from 'react-redux';
import MUIDataTable from "mui-datatables";
import FromData from 'form-data';
import { sweepsActions } from '../../actions/sweeps.actions';
import Paper from '@material-ui/core/Paper';
import Tooltip from "@material-ui/core/Tooltip";

 const cols = [
 {
     name: " ",
     options: {
      filter: true,
      sort: false,
     }
   },
    {
    name: "Client Name",
    options: {
     filter: true,
     sort: false,
    }
   },{
    name: "Investment Business Entiy ",
    options: {
     filter: true,
     sort: false,
    }
   },{
    name: "Sweep Rule",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
    name: "Changes Done At",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
	name: "Changes Done By",
	options: {
	filter: true,
	sort: false,
	}
   },
   {
    name: "Approved At",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
       name: "Approved By",
       options: {
        filter: true,
        sort: false,
       }
   },
   {
    name: "Nature of Change",
          options: {
           filter: true,
           sort: true,
             customBodyRender: (value, tableMeta, updateValue) => {
   	       	                 return (
   	       	                  <Tooltip title={value} placement="right">
     	        			<a href="#">{value.substring(0,8)}</a>
   	       	            	</Tooltip>
   	       	                   );
      	 }
       	}
   },

   {
    name: "Status",
    options: {
     filter: true,
     sort: false,
    }
   }
  ];


class MaintainRulesSchedulesViewChanges extends React.Component {

 getMuiTheme = () => createMuiTheme({
	 		  typography: {
	 							useNextVariants: true,
	 	 			 },
	 	    overrides: {
	 			 MuiFormControl: {
	 					  	        marginNormal: {
	 					   	           marginTop: '0px',
	 					   	            marginBottom: '0px',
	 					   	        }
	 	      }, MuiIconButton: {
	 					  	        root: {
	 					   	           padding: '2px',
	 					   	        }
	 	      }, MuiTableCell: {
	 					  	        root: {
	 					   	           padding: '0px',
	 					   	        }
	 	      }, MuiPrivateSwitchBase: {
	 					  	        root: {
	 					   	           padding: '0px',
	 					   	           minHeight:'100%'
	 					   	        }
	 	      },MuiTableRow:{root: {
				  height:'25px',}
			  },MuiSvgIcon:{root: {
				  height:'0.75em', }
			  },
	 	      MUIDataTableBodyCell: {
	 	        root: {
	  	           whiteSpace: 'nowrap',
	  	           padding:'0px 56px 0px 24px'
	  	        }
	 	      },
	 	      MUIDataTableBodyRow: {
	 		  	        root: {
	 		   	           height: '20px',
	 		   	        }
	 	      },
	 	    }
	   })
 constructor(props) {
	    super(props);
	    this.state = {
		open: this.props?this.props.open:false,
		screenName:'',
		sweepsnewrules:[],
   };
}
 componentWillMount() {
	   console.log('componentDidMount this.props.clientFirm :componentWillMount::::::: '+JSON.parse(sessionStorage.getItem('clientFirm')));
	   console.log('componentDidMount this.props.processId :componentWillMount::::::: '+JSON.parse(sessionStorage.getItem('processId')));
	   console.log('componentDidMount this.props.companyId	 :: '+this.props.companyId);
	   console.log('componentDidMount this.props.ruleId	 :: '+this.props.ruleId);
	   console.log('componentDidMount this.props.fromDate	 :: '+this.props.fromDate);

  			 var bodyFormData = new FromData();

				bodyFormData.append("clientFirm",this.props.clientFirm);
				bodyFormData.append("processId",this.props.processId);
				bodyFormData.append("companyId",this.props.companyId);
				bodyFormData.append("ruleId",this.props.ruleId);
				bodyFormData.append("fromDate",this.props.fromDate);
				bodyFormData.append("selpopUpFlag","POPUP");

				//bodyFormData.append("selLoginId",this.props.selLoginId);
				bodyFormData.append("fromPage","ViewChanges");
				bodyFormData.append("viewPage","ViewChanges");

  				 this.props.dispatch(sweepsActions.fetchMaintainRulesSchedulesViewChangesData(bodyFormData));

   }

 componentDidUpdate(prevProps) {
    if (this.props.selLinkGrpId &&  (prevProps == null) || (prevProps && this.props.selLinkGrpId !== prevProps.selLinkGrpId)) {


    var bodyFormData = new FromData();

				bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
				bodyFormData.append("processId",this.props.processId);
				bodyFormData.append("companyId",this.props.companyId);
				bodyFormData.append("ruleId",this.props.ruleId);
				bodyFormData.append("fromDate",this.props.fromDate);
				bodyFormData.append("selpopUpFlag","POPUP");
				//bodyFormData.append("selLinkGrpId",this.props.selLinkGrpId);
				bodyFormData.append("fromPage","ViewChanges");
				bodyFormData.append("viewPage","ViewChanges");

 				 this.props.dispatch(sweepsActions.fetchMaintainRulesSchedulesViewChangesData(bodyFormData));

  };
}
  handleClose = () => {
    this.setState({ open: false });
     this.props.doClose();
  };

  render(){
	  console.log('this.props.clientFirm :: '+JSON.parse(sessionStorage.getItem('clientFirm')));
	  console.log('this.props.processId :: '+JSON.parse(sessionStorage.getItem('processId')));
	  console.log('this.props.open :: '+this.props.open);
	  console.log('componentDidMount this.props.companyId	 :: '+this.props.companyId);

	const options = {
		filter: true,
		filterType: 'dropdown',
		responsive: 'scroll',
		selectableRows:false,
    };

 	let {changesVec} = this.props;

 return (
      <div>

        <Dialog  fullWidth={true}
          maxWidth={'md'}
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="form-dialog-title"> Sweeps View Changes </DialogTitle>
          <DialogContent>
           <Paper>

			<MUIDataTable
			data={changesVec}
			columns={cols} options={options} />



 			 </Paper>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>

          </DialogActions>
        </Dialog>
      </div>
    );
  }
}
function mapStateToProps(state) {
    const { sweepsnewrules } = state;

let changesVec =[];

			let results=[];
 			let results1  =  sweepsnewrules.sweepsnewrules;

 				    console.log('mapStateToProps : results1'+JSON.stringify( results1));

			let screenName="";
			let from="REFRESH";
	        if( results1&& results1.length>0)
	             results1.map((item,index) => {

		//			 console.log('item.type '+item.type);
    			if(item.type === "Title")
                 screenName = item.name

 //console.log('item.name '+item.name);

 					let MainaspVec=[];
	                if(item.name === "dispList" && item.values){
	                 	results = item.values
						 results.map(row => {
							 let aspVec=[];
 						 aspVec.push('');
						 aspVec.push(row.COMPANYNAME);
 						 aspVec.push(row.BRANCHID);
						 aspVec.push(row.RULENAME);
						 aspVec.push(row.MODIFIEDDATE);
						 aspVec.push(row.MODIFIEDBY);
						 aspVec.push(row.ACCEPTEDDATE);
						 aspVec.push(row.ACCEPTEDBY);
						 aspVec.push(row.NAVTYPE);
						 aspVec.push(row.STATUS);
						 MainaspVec.push(aspVec);

						})
					}
					 if(MainaspVec.length>0)
					 changesVec=MainaspVec;


	            })


    return { sweepsnewrules ,changesVec};
}

 export default connect(mapStateToProps)(MaintainRulesSchedulesViewChanges)  ;



