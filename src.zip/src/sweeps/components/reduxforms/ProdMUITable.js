import React from 'react'; 
import { Field } from 'redux-form'
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import { Select } from "redux-form-material-ui";
import { Route } from 'react-router-dom';  
import MenuItem from '@material-ui/core/MenuItem';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Typography from '@material-ui/core/Typography';
import  Grid from '@material-ui/core/Grid';
import {change } from 'redux-form';


let rowdata=[], saveLable;
const styles = theme => ({
    selectWidth: {
        fontSize: '12px',
        width: 99,
        height: 20
      },      
      root: {
        ...theme.mixins.gutters(),
        paddingTop: theme.spacing.unit * 2,
        paddingBottom: theme.spacing.unit * 2,
        overflow:'auto',
        backgroundColor: '#f4f3f3',
        border : '1px solid #ccc'
      },
      paper: {
              ...theme.mixins.gutters(),
              paddingTop: theme.spacing.unit * 2,
              paddingBottom: theme.spacing.unit * 2,
              overflow:'auto',             
              border : '1px solid #ccc'
      }
});

const renderTextField = ({
    label,
    input,
    meta: { touched, invalid, error },
    ...custom
  }) => (
    <TextField
      label={label}
      placeholder={label}
      error={touched && invalid}
      helperText={touched && error}
      variant="outlined" 
      inputProps={{
        style: {textAlign: "left", padding : 0, width: 120,
        height: 20, fontSize: 12}
      }}    
      {...input}
      {...custom}
    />
  )

  const renderCheckbox = ({ input, label }) => ( 
    <FormControlLabel
      control={
        <Checkbox
          checked={input.value ? true : false}
          onChange={input.onChange}
        />
      }
      label={label}
    />
)
let redirectPath,sfromPage, sactionFlag;

class ProdMUITable extends React.Component {
    
    constructor(props){
        super(props);
        this.state={
            result1:'',
            ck:''
        }
        
    }
    componentWillMount(){         
        rowdata = [];
        if(this.props.ruleProdData !== undefined){            
            this.props.ruleProdData.map((item,index) =>{              
                rowdata.push(item) 
            });
        }
    }
       
    handleChange(e,index,name) {         
        if(document.getElementById("rowNumber"+index).checked===false){  
            rowdata[index].chktype="true";
        } 
        
            var singlerow = rowdata[index];
            singlerow[name]=e.target.value; 
            rowdata[index] = singlerow;           
      }
   
    
    checkClick(index){         
        if(index !== undefined && index === "all"){ 
            rowdata.map((item,index) =>{
                if(this.state.ck === "all"){  
                    item.chktype="false";                   
                }else {
                    item.chktype="true";  
                }
            }) 
            if(this.state.ck === "all"){ 
                this.state.ck = "none"; 
                this.setState({ck:"none"}) 
            }else {
                this.state.ck = "all";     
                this.setState({ck:"all"})   
            }
                 
        }else {
            if(rowdata[index].chktype==="false"){  
                rowdata[index].chktype="true";
                document.getElementById("rowNumber"+index).checked===true
            } else{
                rowdata[index].chktype="false";
                document.getElementById("rowNumber"+index).checked===false
            }
            this.setState({ck:"none"}) 
        }            
    }

    doAddRow(){ 
        var len = rowdata.length;
        const tempObj = Object.assign({}, rowdata[rowdata.length-1]); 
        rowdata.push(tempObj) 
        
        rowdata.map((item,index) =>{
            if(index === len){
                item.rowNumber = len.toString(); 
               // item.rowCount = (len+1).toString();                
            }
        })        
        
        rowdata.map((item,index) =>{
            var rows=[];
            
            if(index === len)
             {
                var rows=[];
                var m = 0;
                for(var k in item) {                   
                    if(k === "rowNumber"){
                        item[k] = len;
                    }else {rows.push(k); }
                }

                        rows.map((item1,index1) =>{                            
                            /* if(index1 === 4 || index1 === 5 || index1 === 6 ||  index1 === 12 || index1 === 13
                                || index1 === 14 || index1 === 15 || index1 === 16 || index1 === 17){
                                item[item1]="";
                            }*/
                            if(index1 === 12){
                                item[item1]="";
                            }
                            if(index1 === 9 && item[item1] === ''){
                                item[item1]="N";
                            }
                        })
                rowdata[len]=item;
             }
        })
        this.setState({ck:"none"})       
        this.setNewRecord();  
        this.props.updateProdsMethod(rowdata);
    }
    setNewRecord(){        
        var len = rowdata.length;
        var item = rowdata[len-1];
        for(var k in item) {                   
            if(k === "rowNumber"){               
            }else {                
                this.props.dispatch(change('SweepSetupForm', k+(len-1), item[k]));   
             }
        }
    }

    doDelete(){
    if(window.confirm('Deleting the product will terminate Sweep MMMF Account. If the same product is defined in another rule then it will also get deleted.')){
        var len = rowdata.length;          
        for(var i = 0; i < len; i++) {                      
            if(rowdata[i].chktype == "true"){ 
                var rows=[];       
                for(var k in rowdata[i]) {                   
                    if(k === "rowNumber"){
                        rowdata[i][k] = len;
                    }else {rows.push(k); }
                }

                rows.map((item1,index1) =>{ 
                    rowdata[i][item1]="";
                })

                rowdata.splice(i, 1);

               // this.props.dispatch(change('SweepSetupForm', 'product'+i, ''));
            
            }
        } 
        this.setState({ck:"none"}) 
        this.props.updateProdsMethod(rowdata);
    }
  }
    doDeleteLastRow(){
        var len = rowdata.length;        
        if(len > 0){
            rowdata.splice((len -1), 1);
        }
        this.setState({ck:"none"}) 
        this.props.updateProdsMethod(rowdata);
    }    
   
    render(){  
        const {classes} = this.props
        var columns=[]; 

        sactionFlag = this.props.actionFlag;
        if(this.props.ProdDetMap !== undefined){
            var temp = this.props.ProdDetCols[0];
            for(var k in temp){ 
                if(k !== "rowNumber"){
                    if(k === "chktype" && sactionFlag == "MODIFY")
                    columns.push( <Field  name={"rowNumber"} onClick={(e)=>this.checkClick("all")} component={Checkbox}/>);                  
                    else if(k === "chktype"){
                        
                    }else
                        columns.push(temp[k]);
                }
            }
        }
        let prodcatTypeSelect = ''        
        if(this.props.ProdDetMap !== undefined){ 
            this.props.ProdDetMap.map((obj,index) => { 
      
            if(obj.PRODCATVEC){
            prodcatTypeSelect = 
            obj.PRODCATVEC.map((objc,index) => {               
              return <MenuItem key={index} value={objc.PRODID}>{objc.PRODNAME}</MenuItem>
              }) 
            }
          })
         }else {
            prodcatTypeSelect = <MenuItem value='none' >None</MenuItem>
         }

        // console.log('prodcatTypeSelect:'+JSON.stringify(prodcatTypeSelect)); 

         let prodTypeSelect = ''        
         if(this.props.ProdDetMap !== undefined){ 
             this.props.ProdDetMap.map((obj,index) => {          
             if(obj.PRODVEC){
                prodTypeSelect = 
             obj.PRODVEC.map((objc,index) => {               
               return  <MenuItem key={index} value={objc.PRODID}>{objc.PRODNAME}</MenuItem>
               }) 
             }
           })
          }else {
            prodTypeSelect = <MenuItem value='none' >None</MenuItem>
          }

          let CurrencySelect = <MenuItem value='EUR' >EUR</MenuItem>

          let invAcctTypeSelect = ''        
          if(this.props.ProdDetMap !== undefined){ 
              this.props.ProdDetMap.map((obj,index) => {          
              if(obj.PDDAACCTVEC){
                invAcctTypeSelect = 
              obj.PDDAACCTVEC.map((objc,index) => {               
                return <MenuItem key={index} value={objc.ACCTNBR} >{objc.SETTLEMENTACCTNBR}-{objc.SETTLEMENTTYPE}</MenuItem>
                }) 
              }
            })
           }else {
            invAcctTypeSelect = <MenuItem value='none' >None</MenuItem>
           }           
         
       
        let tableheadermarkup = columns.map((item,index) =>{           
             return   <TableCell style={{border: "1px solid #ccc",
                      textAlign : 'center', fontSize: '12px', fontWeight: 'bold', color: "black"}} key={index}>{item}</TableCell>
        })

        let tablebodymarkup;
        if(this.props.ruleProdData !== undefined){
            tablebodymarkup = rowdata.map((item1,index1) =>{
             if(item1 && item1 !== undefined && item1 !== ''){
                var rows=[];
                var cols=[];
                var tempRow = [];
               
                for(var k in item1){
                    if(k !== "rowNumber"){
                        rows.push(item1[k]);
                        cols.push(k); 
                    }
                }                                       
                   let row = rows.map((item,index) =>{   
                        tempRow = [];                              
                       if(sactionFlag === "MODIFY"){                            
                                if(index === 0 && item1.value !== '' && item1.value !== undefined ){                                   
                                    tempRow[0] = <TableCell key={index}>                                    
                                        <Field  id={"rowNumber"+index1.toString()} name={"rowNumber"+index1.toString()} checked={item==="true"?true:false} onClick={(e)=>this.checkClick(index1)} component={Checkbox}/>
                                        </TableCell>
                                }else if(index === 0){
                                    tempRow[0] = <TableCell key={index}>                                    
                                    &nbsp;
                                    </TableCell> 
                                }else if(index === 1 ){                                    
                                    tempRow[0] = <TableCell key={index}><Field           
                                    component={Select}            
                                    name={cols[index]+index1.toString()}                                 
                                    style = {{fontSize: 12}} >
                                    
                                  {prodcatTypeSelect}</Field>                                                
                                            </TableCell>
                                }
                                else if(index === 2 ){                                     
                                    tempRow[0] = <TableCell key={index}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                  {prodTypeSelect}</Field>                                                
                                        </TableCell>
                                }else if(index === 3 ){                                     
                                    tempRow[0] =  <TableCell key={index}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                  {CurrencySelect}</Field>                                                
                                        </TableCell>
                                }
                                else if(index === 7 ){                                     
                                    tempRow[0] = <TableCell key={index}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                  {invAcctTypeSelect}</Field>                                                
                                        </TableCell>
                                }else if(index === 8 ){                                     
                                    tempRow[0] = <TableCell key={index}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                    <MenuItem value="100" >Sweep A/C</MenuItem>      
                                    <MenuItem value="101" >DDA A/C</MenuItem></Field>                                                
                                        </TableCell>
                                }else if(index === 9 ){                                     
                                    tempRow[0] =  <TableCell key={index}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index]+index1.toString()}
                                    style = {{fontSize: 12}}
                                    disabled >
                                 <MenuItem value='Y' >Yes</MenuItem>           
                                <MenuItem value='N' >No</MenuItem></Field>                                                
                                        </TableCell>
                                }else if(index === 10 ){                                     
                                    tempRow[0] = <TableCell key={index}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index]+index1.toString()}
                                    style = {{fontSize: 12}} 
                                    disabled >
                                  <MenuItem value='100' >RECAPITALIZE</MenuItem>           
                                  <MenuItem value='101' >CASH PAYOUT</MenuItem></Field>                                                
                                        </TableCell>
                                }else if(index === 11 ){                                     
                                    tempRow[0] = <TableCell key={index}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                   <MenuItem value='1' >Amount</MenuItem>           
                                   <MenuItem value='2' >Percentage</MenuItem></Field>                                                
                                        </TableCell>
                                }else if(index === 12 || index === 13){
                                    tempRow[0] = <TableCell key={index}>
                                    <Field name={cols[index]+index1.toString()}  component={renderTextField} label="" />
                                    </TableCell>
                                }else {
                                    tempRow[0] = <TableCell key={index}>
                                    <Field name={cols[index]+index1.toString()} disabled component={renderTextField} label="" />
                                    </TableCell>
                                }
                            }else {                               
                                if(index === 0 ){                                    
                                    tempRow[0] = <TableCell key={index+1}><Field           
                                    component={Select}            
                                    name={cols[index+1]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                  {prodcatTypeSelect}</Field>                                                
                                            </TableCell>
                                }
                                else if(index === 1 ){                                     
                                    tempRow[0] = <TableCell key={index+1}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index+1]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                  {prodTypeSelect}</Field>                                                
                                        </TableCell>
                                }else if(index === 2 ){                                     
                                    tempRow[0] = <TableCell key={index+1}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index+1]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                  {CurrencySelect}</Field>                                                
                                        </TableCell>
                                }
                                else if(index === 6 ){                                     
                                    tempRow[0] = <TableCell key={index+1}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index+1]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                  {invAcctTypeSelect}</Field>                                                
                                        </TableCell>
                                }else if(index === 7 ){                                     
                                    tempRow[0] = <TableCell key={index+1}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index+1]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                    <MenuItem value="100" >Sweep A/C</MenuItem>      
                                    <MenuItem value="101" >DDA A/C</MenuItem></Field>                                                
                                        </TableCell>
                                }else if(index === 8 ){                                     
                                    tempRow[0] = <TableCell key={index+1}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index+1]+index1.toString()}
                                    style = {{fontSize: 12}}
                                    disabled >
                                 <MenuItem value='Y' >Yes</MenuItem>           
                                <MenuItem value='N' >No</MenuItem></Field>                                                
                                        </TableCell>
                                }else if(index === 9 ){                                     
                                    tempRow[0] = <TableCell key={index+1}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index+1]+index1.toString()}
                                    style = {{fontSize: 12}} 
                                    disabled >
                                  <MenuItem value='100' >RECAPITALIZE</MenuItem>           
                                  <MenuItem value='101' >CASH PAYOUT</MenuItem></Field>                                                
                                        </TableCell>
                                }else if(index === 10 ){                                     
                                    tempRow[0] = <TableCell key={index+1}>
                                    <Field           
                                    component={Select}            
                                    name={cols[index+1]+index1.toString()}
                                    style = {{fontSize: 12}} >
                                   <MenuItem value='1' >Amount</MenuItem>           
                                   <MenuItem value='2' >Percentage</MenuItem></Field>                                                
                                        </TableCell>
                                }else if(index === 11 || index === 12){
                                    tempRow[0] = <TableCell key={index+1}>
                                    <Field name={cols[index+1]+index1.toString()} component={renderTextField} label="" />
                                    </TableCell>
                                }else if(index === 17){
                                    tempRow[0] = null;
                                }else {
                                    tempRow[0] = <TableCell key={index+1}>
                                    <Field name={cols[index+1]+index1.toString()} disabled component={renderTextField} label="" />
                                    </TableCell>
                                }
                            }                            
                            if((index1+1) === rowdata.length && (index+1) === rows.length && (item1.value === '' || item1.value === undefined)){
                                tempRow[1] = <TableCell key={index+2}>
                                <button  className="btn btn-primary btn-xs"
                                    type='button'
                                    onClick={() => {this.doDeleteLastRow();}}
                                     >Cancel Product</button> 
                                </TableCell>
                            }                            
                            return tempRow;
                    })
                    return (
                        
                            <TableRow key={index1}>
                                {row}
                            </TableRow>
                    )
                }
            });
        }
        
        
  //if(!sfromPage)
  sfromPage = this.props.fromPage;  

  if(sfromPage && sfromPage == "CNEWRULE"){
        redirectPath = '/report/CMNTRULE';
        if(this.props.saveFlag === "start"){
            saveLable ="Processing...";
        }else {
            saveLable = "Save";	
        }        
	 } else if(sfromPage && sfromPage == "MNEWRULE"){
        redirectPath = '/report/MSWEEP';
        if(this.props.saveFlag === "start"){
            saveLable ="Processing...";
        }else {
            saveLable = "Run";	
        } 
       
	 } else {
        redirectPath = '/report/LSWEEP';
        if(this.props.saveFlag === "start"){
            saveLable ="Processing...";
        }else {
            saveLable = "Run";	
        } 
	 }
 
  let backtotradebtn; 
  let tradesubmitbtn;
  tradesubmitbtn =
        <Route render={({ history}) => (
            <button  className="btn btn-primary btn-xs"
                type='submit'               
            >
            {saveLable}
          </button> 
        )} />
  backtotradebtn =
        <Route render={({ history}) => (
            <button  className="btn btn-primary btn-xs"
                type='button'
                onClick={() => { history.push({pathname : redirectPath}) }}
            >Back</button> 
        )} />

        return(
            <div>
               <Paper className={classes.root}>
                   <div className="panel">
                      <div className="panel-heading clearfix">
                            <h4 className="panel-title pull-left col-md-1">Product Details</h4>
                      </div>
                   </div>
                <Paper className={classes.paper} > 
                    <Table>
                    {(rowdata !== undefined && rowdata.length > 0) &&
                        <TableHead>
                            <TableRow style={{backgroundColor: "#f4f3f3", border: "1px solid #ccc",
                      textAlign : 'center', color: "blue", height: '16px !important'}}>
                                {tableheadermarkup}
                            </TableRow>
                        </TableHead>}
                        {(rowdata !== undefined && rowdata.length > 0) ?                        
                        <TableBody>
                                {tablebodymarkup}
                        </TableBody>:<TableBody>
                             <TableRow key="0"><TableCell colSpan={3}> 
                                <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>No Products Associated to This Rule</div>
                            </TableCell></TableRow> 
                        </TableBody>}
                    </Table>
                </Paper> 
                <Grid container spacing={8} direction="row"
			  justify="flex-start"
			  alignItems="flex-start" item xs={12}><Grid item xs={2}>
                <Typography component="p" gutterBottom style= {{paddingTop: "12px"} } >Footnote:</Typography>
                </Grid>
                <Grid item xs={10}>
                <Typography component="p" gutterBottom style= {{paddingTop: "12px"} } >MMMF Account Lookup should be used for updating and setting up different Dividend and redemption settlement Account other than the Investment Account.</Typography>
                
            </Grid></Grid> 
            </Paper>
            
      <div className="clearfix"></div>      
                <div style= {{textAlign: "center", paddingTop: "12px", }}>
                    {(rowdata !== undefined && rowdata.length > 0) ? 
                         <a title="Add Product" onClick={(e)=>{this.doAddRow();}} className="btn btn-primary btn-xs">Add Product</a> 
                    :""}                    
                    {((rowdata !== undefined && rowdata.length > 0) && (sactionFlag === "MODIFY"))?
		         <a title="Delete Product" onClick={(e)=>{this.doDelete();}} className="btn btn-primary btn-xs">Delete Product</a> 
                    :""}
                    {tradesubmitbtn}
                    {backtotradebtn}                     
                </div>
                <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>
                {this.props.resultMsg}</div>
            </div>
 
        );
    }
}

export default withStyles(styles)(ProdMUITable);