import React from 'react';
import { reduxForm } from 'redux-form';
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import  Paper from '@material-ui/core/Paper';
import validate from './validate';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';

import RulesBlock from './rules';
import ScheduleBlock from './schedules';
import WithLoading  from '../../../_helpers/WithLoading';

const RulesBlockWithLoading = WithLoading(RulesBlock);

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

const styles = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
  },
  
     tabsRoot: {
        borderBottom: '1px solid #e8e8e8',
      },
      tabsIndicator: {
        backgroundColor: '#1890ff',
      },
      tabRoot: {
        textTransform: 'initial',
        minWidth: 72,
        fontWeight: theme.typography.fontWeightRegular,
        marginRight: theme.spacing.unit * 4,
        // fontFamily: [
        //   '-apple-system',
        //   'BlinkMacSystemFont',
        //   '"Segoe UI"',
        //   'Roboto',
        //   '"Helvetica Neue"',
        //   'Arial',
        //   'sans-serif',
        //   '"Apple Color Emoji"',
        //   '"Segoe UI Emoji"',
        //   '"Segoe UI Symbol"',
        // ].join(','),
        '&:hover': {
          color: '#40a9ff',
          opacity: 1,
        },
        '&$tabSelected': {
          color: '#1890ff',
          fontWeight: theme.typography.fontWeightMedium,
        },
        '&:focus': {
          color: '#40a9ff',
        },
      },
      tabSelected: {},
      typography: {
        padding: theme.spacing.unit * 3,
      },
      
        paper: {
          padding: theme.spacing.unit * 2,
          textAlign: 'center',
          color: theme.palette.text.secondary,
      },
        priorityIcon: {
      	      color: "#000",
      	},
      	iconButton: {
    	    marginRight: "24px",
    	    top: "50%",
    	    display: "inline-block",
    	    position: "relative",
    	    transform: "translateY(-50%)",
  },
});
let sfromPage, actionFlag,companyId,ruleid,fromDate;
let sweepsnewrules = [];
let rulesnewdata = [];
let sweepProds;
class SweepSetupForm extends React.Component {  
  constructor(){
    super();
    this.state={ 
        tabIndex: 0,
        loading: false        
    } 
    this.doProdsMethod = this.doProdsMethod.bind(this);
}
componentWillMount () {
  sweepProds = 'null';
   this.getInit(); 
}
getInit(){
  this.setState({ loading: true });
    sweepsnewrules = this.props.sweepsnewrules; 
     rulesnewdata = this.props.rulesnewdata;    
       this.props.initialize(rulesnewdata);
       this.setState({ loading: false});     
}


handleChange = (event, value) => {
  this.setState({tabIndex : value });
};
doProdsMethod(newParsedData){
  sweepProds = newParsedData;
  this.props.updateProdsMethod(sweepProds);
}

  
  render () {
  const { handleSubmit, pristine, reset, submitting, classes } = this.props
  const tblStyle  = {width: "1200px"};

  if(!sweepProds || sweepProds === undefined || sweepProds === 'null'){
    sweepProds = this.props.parsedData;
  }
  
  //if(!sfromPage)
  sfromPage = this.props.fromPage;  
	companyId = this.props.companyId;  
	ruleid 	  = this.props.ruleid;
	fromDate  = this.props.fromDate;
	
  console.log("SETUP FORM companyId:::"+companyId+"::ruleid::"+ruleid+"::fromDate::"+fromDate); 
       
  return (
    <form style={tblStyle} onSubmit={handleSubmit}  >

     
      <Tabs value={this.state.tabIndex} onChange={this.handleChange} style={{minHeight:'auto'}}
      classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}>
            
            
            <Tab
			disableRipple
			classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
			label="Rules"
 		  />
		  <Tab
			disableRipple
			classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
			label="Schedules"
 	  />
   
      </Tabs>      
        {this.state.tabIndex === 0 && <TabContainer>  <RulesBlockWithLoading  isLoading={this.state.loading} 
          sweepsnewrules={sweepsnewrules} fromPage ={sfromPage}
          parsedData = {sweepProds}
          actionFlag={this.props.actionFlag} 
          dispatch={this.props.dispatch}
          saveFlag ={this.props.saveFlag}
          resultMsg ={this.props.resultMsg}
          updateProdsMethod={this.doProdsMethod}
          />       
        </TabContainer>}
        {this.state.tabIndex === 1 && <TabContainer><ScheduleBlock fromPage ={sfromPage} 
        actionFlag={this.props.actionFlag}        
        companyId={this.props.companyId} 
        ruleid={this.props.ruleid} 
        fromDate={this.props.fromDate}
        saveFlag ={this.props.saveFlag}
        resultMsg ={this.props.resultMsg} /></TabContainer>}       
       
    </form>
  );
};
};

SweepSetupForm =  reduxForm({
  form: "SweepSetupForm", // a unique identifier for this form   
  classes: PropTypes.object.isRequired 
})(SweepSetupForm);

export default ((withStyles(styles))(SweepSetupForm));