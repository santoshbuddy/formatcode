
import { fetchHelper } from '../../../_helpers';
import { alertConstants } from '../../../common/constants/alert.constants';

export function fetchSweepNewruleInfo(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

     var pathname = window.location.pathname;
     let _tradeData;
    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        bodyFormData.append("parentProdId","1700");
        //_tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/MNEWRULE.do',bodyFormData);
        _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);


        //console.log("_tradeData:11111111111:"+_tradeData);
        //console.log(' response%%%%%%%%%%%%%%%%%%%%%%%%:::'+JSON.stringify( _tradeData));
    }
    return _tradeData;
}
export function submitRuleData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tradeReviewData;

     var pathname = window.location.pathname;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
         bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        bodyFormData.append("parentProdId","1700");
        //bodyFormData.append("actionFlag", "SAVE");
        bodyFormData.append("modifyFlag", "MODIFY");

        _tradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _tradeReviewData;
}

