import { reportConstants } from '../constants/report.constants';
import { reportService } from '../services/report.service';

export const reportActions = {
    fetchReportData,
    fetchReportTableData,
    fetchReporComptData,
    fetchClientReportData
};

function fetchReportData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        reportService.fetchReport(bodyFormData)
            .then(
                reportdata => dispatch(success(reportdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: reportConstants.GETREPORTDATA_REQUEST } }
    function success(reportdata) { return { type: reportConstants.GETREPORTDATA_SUCCESS, reportdata } }
    function failure(error) { return { type: reportConstants.GETREPORTDATA_FAILURE, error } }
}
function fetchClientReportData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        reportService.fetchClientReport(bodyFormData)
            .then(
                reportdata => dispatch(success(reportdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: reportConstants.GETREPORTDATA_REQUEST } }
    function success(reportdata) { return { type: reportConstants.GETREPORTDATA_SUCCESS, reportdata } }
    function failure(error) { return { type: reportConstants.GETREPORTDATA_FAILURE, error } }
}
function fetchReporComptData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        reportService.fetchCompReport(bodyFormData)
            .then(
                reportcdata => dispatch(success(reportcdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: reportConstants.GETREPORTCOMPDATA_REQUEST } }
    function success(reportcdata) { return { type: reportConstants.GETREPORTCOMPDATA_SUCCESS, reportcdata } }
    function failure(error) { return { type: reportConstants.GETREPORTCOMPDATA_FAILURE, error } }
}

function fetchReportTableData(bodyFormData){  
    return dispatch => {
        dispatch(request());

        reportService.fetchReportTable(bodyFormData)
            .then(
                reportdatatable => dispatch(success(reportdatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: reportConstants.GETREPORTTBLDATA_REQUEST } }
    function success(reportdatatable) { return { type: reportConstants.GETREPORTTBLDATA_SUCCESS, reportdatatable } }
    function failure(error) { return { type: reportConstants.GETREPORTTBLDATA_FAILURE, error } }
 
}