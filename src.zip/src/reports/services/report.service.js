import { authHeader,fetchHelper } from '../../_helpers';
import { alertConstants } from '../../common/constants/alert.constants';
import FromData from 'form-data';
export const reportService = {
    fetchReport,
    fetchReportTable,
    fetchCompReport,
    fetchClientReport
};
function fetchReport(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    let _reportData;
    console.log("window.location.pathname==>",window.location.pathname)
     var pathname
     if(window.location.pathname === "/client/CLLSTREP" ){
        pathname= window.location.pathname.replace("/client/","")
     }
     else if(window.location.pathname === "/reportC/COMPART" || window.location.pathname === "/reportC/INDICAT"){
        pathname= window.location.pathname.replace("/reportC/","")
     }
     else
        pathname = window.location.pathname.replace("/report/","")

    //    console.log("pathname==>",pathname)
     if(pathname === "COMPART"){
         bodyFormData.append("subSrc","COMPART");
         bodyFormData.append("rateType","Comparative");
     }
     if(pathname === "INDICAT"){
         bodyFormData.append("subSrc","INDICAT");
         bodyFormData.append("rateType","Indicative");

     }

    if (pathname == "/reportCheck/EDTDLACK")
	pathname = "editDealAck";

	if (pathname == "/reportCheck/MMFMTDRA")
	pathname = "productBalances";


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)

        if (pathname != "/reportCheck/EDTDLACK"){
          bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        }

        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _reportData;
 }
 function fetchClientReport(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    let _reportData;
    console.log("window.location.pathname==>",window.location.pathname)
     var pathname
     if(window.location.pathname === "/client/CLLSTREP" ){
        pathname= window.location.pathname.replace("/client/","")
     }

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _reportData;
 }
 function fetchCompReport(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    let _reportData;
    // console.log("window.location.pathname==>",window.location.pathname)
     var pathname
     pathname = "InvRatesResult";
         for (var pair of bodyFormData.entries()) {
             if(pair[0] === "reactJSActionFlag" && pair[1] === "GO"){

                 console.log(pair[0]+ ', ' + pair[1]);
                 bodyFormData.append("actionFlag","SHOWRATES");
                 if(window.location.pathname === "/reportC/COMPART"){
                    bodyFormData.append("subSrc","COMPART");
                    bodyFormData.append("rateType","Comparative");
                 }
                 if(window.location.pathname === "/reportC/INDICAT"){
                    bodyFormData.append("subSrc","INDICAT");
                    bodyFormData.append("rateType","Indicative");
                 }
                 bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

             }
        }


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _reportData;
 }
function fetchReportTable(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _reportTableData;

    var pathname = window.location.pathname.replace("/report/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("reactJSActionFlag","GO")
        _reportTableData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _reportTableData;
}