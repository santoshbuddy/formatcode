import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import { MuiThemeProvider } from '@material-ui/core/styles';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import Grid from '@material-ui/core/Grid';
import Select from '@material-ui/core/Select';
import MenuItem from "@material-ui/core/MenuItem";
import keyboard_arrow_down from "@material-ui/icons/KeyboardArrowDown";
var selectOptions=[5,10,20,50,100];
class CustomPagination extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
       selectopt: 10,
      inputValue: props.page
    }
    // this.handleInputValue = this.handleInputValue.bind(this);
  }
  handleFirstPageButtonClick = event => {
    this.props.onChangePage(event, 0);
  };

  handleBackButtonClick = event => {
    this.props.onChangePage(event, this.props.page- 1);
  };

  handleNextButtonClick = event => {
    this.props.onChangePage(event, this.props.page + 1);
  };

  handleLastPageButtonClick = event => {
    this.props.onChangePage(
      event,
      Math.max(0, Math.ceil(this.props.count / this.props.rowsPerPage) - 1),
    );
  };
  changeInputValue = event => {
    let value = event.target.value;
    if(value > Math.ceil(this.props.count / this.props.rowsPerPage)) value = Math.ceil(this.props.count / this.props.rowsPerPage);
    if(value < 0) value = 0;
    console.log(value)
    this.setState({inputValue: value},()=>{
      this.props.onChangePage(
        event, this.state.inputValue-1
      );
    });
  }
  onSelectChange = event => {
    this.props.changeRowsPerPage(event.target.value);
    this.setState({selectopt:event.target.value})
  }
  render() {
    console.log("this.props",this.props)
    const { classes, count, page, rowsPerPage, theme, selectedCount, type } = this.props;

    return (
      <div className={classes.root}>
        
        <Grid className={classes.paginationDiv}>
        { type === 'senario2' &&
          <Grid className={classes.itemLeft} item xs>
            {/* { type === 'senario1' &&
              <div>
                <span className={classes.selectedTextColor}>{selectedCount} </span>
                <span className={classes.normaltextColor}>of {count} selected</span>
              </div>
            } */}
          
              <div>
                {count > rowsPerPage ?
                  <div>
                    <span className={classes.normaltextColor}>({rowsPerPage*(page)+1} - {rowsPerPage*(page+1)> count ? count:rowsPerPage*(page+1)}) </span>
                    <span className={classes.normaltextColor}>of {count} Listed</span>
                  </div>:
                  <div>
                    <span className={classes.normaltextColor}>{count} Listed</span>
                  </div>
                }
              </div>
          </Grid>
            }
  <MuiThemeProvider  theme={muiTableStyles.getMuiTheme()}>
          <Grid className={classes.itemLeft} item xs> 
                  <label className="LabelText" style={{marginTop:'4px'}}> Sort : </label>
                  <Select onChange={this.onSelectChange} value={this.state.selectopt} IconComponent = {keyboard_arrow_down}  className={classes.select} className={"w15"}>
                    {
                      selectOptions && selectOptions.map((item) => {                  
                        return <MenuItem value={item}>{item}</MenuItem>
                      })
                    }
                  </Select>
          </Grid>
          </MuiThemeProvider>
          <Grid className={classes.itemCenter} item xs>
          { type === 'senario1' &&
              <div className={classes.itemsDiv}>
                <IconButton
                  onClick={this.handleBackButtonClick}
                  aria-label="Previous Page"
                  className={classes.itemAorrow}
                  className={page === 0 ?classes.buttonDisable:classes.itemAorrow}
                >
                  {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
                </IconButton>
                <input type="text" className={classes.inputWidth} value={count===0?0:page+1} onChange={this.changeInputValue}/>
                <span className={classes.normaltextColor}>  of {Math.ceil(count / rowsPerPage)}</span>
                <IconButton
                  onClick={this.handleNextButtonClick}
                  aria-label="Next Page"
                  className={(page >= Math.ceil(count / rowsPerPage) - 1)?classes.buttonDisable:classes.itemAorrow}
                >
                  {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
                </IconButton>
              </div>
            }
            { type === 'senario2' &&
              <div>
                {count > rowsPerPage ?
                  <div className={classes.itemsDiv}>
                    <IconButton
                      onClick={this.handleBackButtonClick}
                      aria-label="Previous Page"
                      className={classes.itemAorrow}
                      className={page === 0 ?classes.buttonDisable:classes.itemAorrow}
                    >
                      {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
                    </IconButton>
                    <input type="text" className={classes.inputWidth} value={page+1} onChange={this.changeInputValue}/>
                    <span className={classes.normaltextColor}>  of {Math.ceil(count / rowsPerPage)}</span>
                    <IconButton
                      onClick={this.handleNextButtonClick}
                      aria-label="Next Page"
                      className={(page >= Math.ceil(count / rowsPerPage) - 1)?classes.buttonDisable:classes.itemAorrow}
                    >
                      {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
                    </IconButton>
                  </div>:
                  <div></div>
                }
              </div>
            }
          </Grid>
          <Grid className={classes.itemRight} item xs>
            <button className={classes.buttonOutline} onClick={this.handleFirstPageButtonClick}>
              First Page
            </button>
            <button className={classes.buttonOutline} onClick={this.handleLastPageButtonClick}>
              Last Page
            </button>
          </Grid>
        </Grid>
      </div>
    );
  }
}

CustomPagination.propTypes = {
  classes: PropTypes.object.isRequired,
  count: PropTypes.number.isRequired,
  onChangePage: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
  theme: PropTypes.object.isRequired,
};

const styles = theme => ({
  root: {
    background: '#ffffff',
    width: '100%'
  },
  toolBarDiv: {
    marginTop: '18px',
    textAlign:'right',
    fontSize: '16px',
    padding: '0px !important'
  },
  itemsDiv: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  paginationDiv: {
    textAlign:'center',
    marginBottom: '12px',
    border: '1px solid #d5d5d6',
    borderTop: '0',
    background: 'linear-gradient(#FFFFFF, #F6F7F7)',
    fontSize: '16px',
    padding: '9px 12px',
    color: theme.palette.text.secondary,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  itemCenter:{
    textAlign:'center',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '16px',
    padding: '0px !important'
  },
  itemLeft: {
    textAlign:'left',
    fontSize: '16px',
    padding: '0px !important'
  },
  itemRight: {
    textAlign:'right',
    fontSize: '16px',
    padding: '0px !important',
    justifyContent: 'flex-end',
  },
  selectedTextColor: {
    color: '#0074A6'
  },
  normaltextColor: {
    color: '#666666'
  },
  itemAorrow: {
    padding: '0',
    background:'transparent',
    color: '#0074A6',
    '&:hover': {
      color: "#00395d",
      background: 'transparent'
    },
    '&:active': {
      color: "#666666",
      background: 'transparent'
    },
  },
  buttonDisable: {
    color: '#0074A6',
    opacity: '0.6',
    pointerEvents: 'none',
    padding: '0'
  },
  inputWidth: {
    width: '33px',
    height: '30px',
    fontSize: '16px',
    lineHeight: '1.42857143',
    color: '#555',
    padding: '2px 6px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    textAlign:'right',
    marginRight: '9px'
  },
  buttonFill: {
    color: '#fff',
    backgroundColor: '#0074A6',
    border: '1px solid #0074A6',
    padding: '4px 12px',
    fontSize: '14px',
    borderRadius: '5px',
  },
  buttonOutline: {
    color: '#0074A6',
    fontSize: '14px',
    border: '1px solid #0074A6',
    padding: '4px 12px',
    borderRadius: '5px',
    marginRight: '10px',
    backgroundColor: 'transparent'
  },
  select: {
    width: '175px',
    height: '30px',
    padding: '6px 12px',
    fontSize: '16px',
    lineHeight: '1.42857143',
    color: '#555',
    backgroundColor: '#fff',
    border: '1px solid #ccc',
    borderRadius: '4px',
    margin: '18px 0px 12px 12px',
  }
});
export default withStyles(styles, { withTheme: true })(CustomPagination);
