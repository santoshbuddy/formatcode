import { messageUS } from '../../common/javascript/i18N/en_US/alerts'
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts'
import {addCommasAmt} from '../../tradeentry/components/amountValidations';

export const IsCharsInBag =  function (s,bag) {
	var i;
	var c;

	for(i=0;i<s.length;i++)
	{
		c = s.charAt(i);
		if(bag.indexOf(c) == -1)
		return false;
	}
	return true;
  }

export const onChangeAmount =  function (e,i) {

        let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

        var amtLmt=e.target.value;
        //alert("apr 10, 2019 amtLmt::"+amtLmt);
        var errMsg;

    	if(amtLmt == "") {
    	  alert(message["ENAMOUNT"]);
    	  document.getElementById("amount"+i).value="0.00";
    	  window.document.getElementById("amount"+i).focus();
    	  return false;
    	}
    	if(IsCharsInBag(amtLmt,"0123456789.,MMmmKKkk") == false)
    	{
    		alert(message["ENVLDAMT"]);
    		document.getElementById("amount"+i).value="0.00";
    		window.document.getElementById("amount"+i).focus();
    		return false;
    	}

	if(amtLmt!="" && amtLmt!="0.00" && amtLmt != undefined && amtLmt.length>0 && parseFloat(amtLmt) > 0){
	  addCommasAmt(e,userLocale,true);
	}
   return true;
  }

 export const onSharesAmt =  function (e,i) {

       let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

         var numberOfShares=e.target.value;
         //alert("apr 10, 2019 amtLmt::"+numberOfShares);
         var errMsg;

     	if(numberOfShares == "") {
    	  alert(message["ENTRSHARES"]);
     	  document.getElementById("numberOfShares"+i).value="0.00";
     	  window.document.getElementById("numberOfShares"+i).focus();
     	  return false;
     	}
     	if(IsCharsInBag(numberOfShares,"0123456789.,MMmmKKkk") == false)
     	{
    		alert(message["ENVLDSHARES"]);
     		document.getElementById("numberOfShares"+i).value="0.00";
     		window.document.getElementById("numberOfShares"+i).focus();
     		return false;
     	}

 	if(numberOfShares!="" && numberOfShares!="0.00" && numberOfShares != undefined && numberOfShares.length>0 && parseFloat(numberOfShares) > 0){
 	  addCommasAmt(e,userLocale,true);
 	}
    return true;
  }

export const onNavAmt =  function (e,i) {
   let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
        var nav=e.target.value;
        var errMsg;

    	if(nav == "") {
    	  alert(message["ENTNAV"]);
    	  document.getElementById("nav"+i).value="0.00";
    	  window.document.getElementById("nav"+i).focus();
    	  return false;
    	}
    	if(IsCharsInBag(nav,"0123456789.,") == false)
    	{
    		alert(message["NAVCNT"]);
    		document.getElementById("nav"+i).value="0.00";
    		window.document.getElementById("nav"+i).focus();
    		return false;
    	}
   return true;
}
