import React from 'react';
import { history } from '../../_helpers';
import ReactTable from "react-table";

class MultiTable extends React.Component {
	constructor(props) {
        super(props);
        this.doView = this.doView.bind(this);
    }
    doView(rownum,original,data1){ 
        //console.log("may 02, 2019 ::companyname:"+data1['COMPANYNAME']+",productid::"+original.ProductId+",curencycode::"+original.CurrencyCode+",fromdate::"+original.FromDate+",productname"+original.ProductName+",view_none:"+original.PolicyTrades);
        if(original.PolicyTrades == 'View')
        {
        history.push({
            pathname: '/report/TRDINQR',
            state: {
                clientFirmName: data1['COMPANYNAME'],
                productName: original.ProductName,
                prodId: original.ProductId,
                currencyCode: original.CurrencyCode,
                fromDate:original.FromDate,
                product: '1700',
                pageCount: '',
                rowsByPage:'',
                from:'INVPOLICY',
            }
        })
       }
	} 
    render(){
        const data1 = this.props.data1;
        const data2 = this.props.data2;
        var columns=[];
        if(data2 !== undefined) {
            data2.map((item,index) => {
                let View='';
                if(index === 0){
                    var s =  item;
                    View='';
                    for(var k in s) {
                        if(k === 'Out of Policy Trades'){
                            View = 'None';
                            if(item[k] == 'View') {
                                View = 'View Link';
                            }
                                columns.push({
                                    id: "link",
                                    accessor: "Out of Policy Trades",
                                    Cell: ({ original }) => {
                                        if(original.PolicyTrades === "View") 
                                        {
                                        return (
                                            <div>
                                              <a  onClick={this.doView.bind(this,original.rowNumber,original,data1)}>{original.PolicyTrades}</a>
                                            </div>
                                          );
                                        }else{
                                            return (
                                                <div>
                                                  {original.PolicyTrades}
                                                </div>
                                              );
                                        }
                                    },                                   
                                    Header: x => {
                                        return (
                                                "Out of Policy Trades"
                                        );
                                    }
                                })
                        }else if(k === 'CompanyId'){
                            columns.push({
                                id: "",
                                accessor: "",
                                show:false
                            })
                        }else if(k === 'Total Net Assets(MM)'){
                            columns.push({
                                Header:k,
							    accessor: k,
								width:150
                            })
                        }else if(k === 'Fund Product'){
							columns.push({
								Header:k,
							    accessor: k,
								width:250
							})
                        }else if(k === 'Fund Type'){
							columns.push({
								Header:k,
							    accessor: k,
								width:80
							})
                        }else if(k === 'Total Balance in Cash'){
							columns.push({
								Header:k,
							    accessor: k,
								width:150
							})
                        }
                        else if(k === 'ProductId'){
                            columns.push({
                                id: "",
                                accessor: "",
                                show:false
                            })
                        }else if(k === 'CurrencyCode'){
                            columns.push({
                                id: "",
                                accessor: "",
                                show:false
                            })
                        }else if(k === 'FromDate'){
                            columns.push({
                                id: "",
                                accessor: "",
                                show:false
                            })
                        }else if(k === 'ProductName'){
                            columns.push({
                                id: "",
                                accessor: "",
                                show:false
                            })
                        }else if(k === 'PolicyTrades'){
                            columns.push({
                                id: "",
                                accessor: "",
                                show:false
                            })
                        }else{
                            columns.push({
                            Header: k,
                            accessor: k
                            });
                        }
                    }
                }
            });

        }
         var arr=[];
         for(var k in data1){
             arr.push({name:k,value:data1[k]})
         }


        let tbody = arr && arr.map((item,index)=>{
            if(item.name !== "rowNumber")
                 return(
                    <div  className="col-md-4 col-sm-4" key={index}>
                        <label> { item.name } :</label>
                        <label className="TxtNrml"> { item.value } </label>
                    </div>
                );
         });

        return(
            <div className="col-md-12 col-sm-12 head-cls backwhite">
                <div className="panel">
                    <div className="panel-heading clearfix">
                        <h4 className="panel-title pull-left col-md-1">Client Firm:{data1.ClientFirm}</h4>
                    </div>
                </div>

                    {tbody}

                <div className="col-md-12 col-sm-12 head-cls backwhite">
                    <div className="panel">
                        <div className="panel-heading clearfix">
                            <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                        </div>
                    </div>
                    <ReactTable showPagination={true} resizable={false} noDataText="No Data Found" data={this.props.data2} columns={columns}  className="table table-striped" />
                </div>
            </div>
        );
    }
}

export default MultiTable;
