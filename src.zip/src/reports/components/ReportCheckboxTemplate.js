import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { reportActions } from '../actions/report.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import 'react-tabs/style/react-tabs.css';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import DialogTitle from '@material-ui/core/DialogTitle';
import Paper from '@material-ui/core/Paper';
import { Link } from 'react-router-dom';
import Loading from '../../common/Loading'
import MUIDataTable from "mui-datatables";
import Card from "./Card";
import ScrollDialog from "./ScrollDialog";
import PopUpDataTable  from "./PopUpDataTable";
import ScrollDialogPopUp  from "./ScrollDialogPopUp";
import {muiTableStyles} from '../../styles/muidatatableCss';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import axios from 'axios';
import FormData from 'form-data';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import DialogContentText from "@material-ui/core/DialogContentText";
import { alertConstants } from '../../common/constants/alert.constants';
import TextField from '@material-ui/core/TextField';
import CustomToolbarSelect from "../../navbar/components/CustomToolbarSelect";
import TableLoader from '../../common/TableLoader';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import Checkbox from '@material-ui/core/Checkbox';
import { resultConstants } from '../../common/constants/result.constants'
import {onChangeAmount} from './editDealAck';
import {onSharesAmt} from './editDealAck';
import {onNavAmt} from './editDealAck';
import ViewChanges from './ViewChanges';
import AcctPositions from './AcctPositions';
import { showConfirm, showAlert } from '../../common/components/showConfirmLayer';
import { Typography } from '@material-ui/core';
import Formatter from '../../formats/Formatters';

import CustomPagination from './CustomPagination';

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });
  let popUpColumns1;
  let popUpMsg;
  let optionsPopUp;
  let buttonFlag=true;
  var popUpData,fileds,title;
  let popUpData1;
  let pageName='';
  let filterFlag=true;
  let msg="";
  var data1 = [];
  var columns1 = [];
  var data2 = [];
  var columns2 = [];
  var data3 = [];
  var columns3 = [],savemessage='',savemessageapprove='';
  var mcprocessflag='',runId='', deskGroupId='';
  let fromDate,toDate;
  let selRowsIndex;
  let checkerFlag="false";
    let tradeApprovalMsg='empty';
  let messageTxt = 'empty';
let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
let changedbodyFormData =  new FormData();
class ReportCheckboxTemplate extends React.Component {
    getMuiTheme = () =>
        createMuiTheme({
          overrides: {
            MUIDataTableHeadCell: {
              root: {
                background: '#eaeaea !important',
                color: '#0066b2 !important',
                textTransform: 'uppercase',
                whiteSpace: 'nowrap',
                fontWeight:'bold',
                borderRight: '1px solid #b3b3b3 !important',
                borderTop: '1px solid #b3b3b3',
                borderBottom: '1px solid #b3b3b3',
                '&:first-child':{
                  borderLeft: '1px solid #b3b3b3'
                },
                '&:last-child':{
                  paddingRight: '4px'
                }
              }
            },
            MUIDataTableBodyRow: {
              root: {
                '&:nth-child(odd)': {
                  backgroundColor: '#f7f8f9'
                }
              }
             },
             MuiTableCell: {
               root: {
                whiteSpace: 'nowrap',
                padding: '7px 5px',
                borderRight: '1px solid #f3ebeb',
                borderTop: '1px solid #c3c3c3',
                borderBottom: '1px solid #f3ebeb',
                '&:last-child':{
                  borderRight:'0px'
                },
                '&:first-child':{
                  borderLeft: '1px solid #f3ebeb'
                }
               }
             },
             MuiTableRow: {
               root:{
                 height:'auto'
               },
               head: {
                 height:'auto',
               }
             }
            }
          });


    constructor(){
        super();
        this.state={
            flag:true,
            results:[],
            results1:[],
            reportdata:[],
            columns:[],
            screenName:'',
            open: false,
            openPopUp: false,
            message:'',
            TradeType:'',
            allRows:[],
            allRows1:[],
            fixflag:false,
            ck:1,
            allRateReason:'',
			allRate:'',
			rateTxtObj: {
							allRateTxt:'',
							allRateTxt2:'',
							allRateReasonTxt2:''
						},
        }
        this.coldata=[];
        this.doChange = this.doChange.bind(this);
        this.routeChange = this.routeChange.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.submit = this.submit.bind(this);
        this.doSubmit = this.doSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.doSave = this.doSave.bind(this);
        this.doRefresh = this.doRefresh.bind(this);
        this.doNSave = this.doNSave.bind(this);
        this.doViewChanges = this.doViewChanges.bind(this);
        this.doMMMFMTDASave = this.doMMMFMTDASave.bind(this);
        this.doAllRateCheck= this.doAllRateCheck.bind(this);
        this.doAllRateReasonCheck= this.doAllRateReasonCheck.bind(this);
		this.rateChangeValues= this.rateChangeValues.bind(this);
		this.doRevoke = this.doRevoke.bind(this);
		this.doApproveMtd = this.doApproveMtd.bind(this);
		this.doRejectMtd = this.doRejectMtd.bind(this);


      }

    componentDidMount() {
        console.log("Report Template componentDidMount")
        pageName=this.props.location.pathname;
        this.coldata=[];
        this.getFilter()
        this.state.fixflag=false;
        changedbodyFormData =  new FormData();
   }
   componentDidUpdate(){
     savemessage='';
     // alert("componentDidUpdate")
      console.log("page name",pageName)
      console.log("this.props.location.pathname",this.props.location.pathname)
      if(pageName.length!==0 && pageName!==this.props.location.pathname)
       {
	filterFlag=true;
        pageName=this.props.location.pathname;
        console.log("Report Template componentDidUpdate",pageName)
        this.coldata=[];
        //this.setState({results:[]})
        this.getFilter()
       }
       else{
         pageName=this.props.location.pathname;
       }
   }

   getFilter(){
		changedbodyFormData =  new FormData();
		console.log("Report Template getFilter")
		//this.setState({message:""})
		var bodyFormData = new FormData();
		bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
		if(pageName === "/reportCheck/EDTDLACK"){
		bodyFormData.append("company","All");
		bodyFormData.append("branchId","All");
		bodyFormData.append("companyId","All");
		}
		bodyFormData.append("reactJSActionFlag","")
		// if(this.props.reportdata.reportdata === undefined ){
		this.props.dispatch(reportActions.fetchReportData(bodyFormData));
		// }
   }

   doChange(bodyFormData){
 	   changedbodyFormData = bodyFormData;
        //bodyFormData.append("reactJSActionFlag","GO")
        //var bodyFormData = new FormData();
        //for (name in fillObj) {
            //bodyFormData.append(name, fillObj[name]);
        //}
        //alert(bodyFormData.get("clientFirm"));
        bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
         if(pageName === "/reportCheck/MMFMTDRA"){
			  filterFlag=true;
		}else {
       	 filterFlag=false;
		}
        savemessageapprove='';
        this.props.dispatch(reportActions.fetchReportData(bodyFormData));
   }
   routeChange(){
        let path = `/admincreate/CREATEACCT`;
        this.props.history.push(path);
    }

    handleClose () {
        this.setState({flag:false})
        this.setState({ open: false });
      }
handlePopUpClose = () => {
       popUpMsg="";
     //alert("111popup close popup ...");
      this.setState({ openPopUp: false });
      this.getFilter();
 };

 doSubmit(e){
   //alert("e.target.name::"+e.target.name);
   if(e.target.name === "APPROVE"){
     this.doApprove("paper");
   }
   else if(e.target.name === "REJECT"){
        this.doReject("paper");
   }
 }
 handleChange(e,name,index){
  data2[index][columns2.findIndex(e => e.name === name)] = e.target.value
  console.log("handle Change==>",data2[index][columns2.findIndex(e => e.name === name)])
  this.setState({fixflag:true})
 }
      submit(e){
         var jsonBody = new FormData();
         var checkin = false;
  //       var selectedCount = 0;

        var url;
        var user = JSON.parse(sessionStorage.getItem('user'));
        jsonBody.append("token",user[0].token);
        jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        if(e.target.name === "Submit trades"){


			// alert("Please select at least one trade transaction.")
		   if(this.state.allRows.length === 0)
		   	showAlert(this,message["CHECKATLONE"]);
		   else{

			  /*
				  data1.map((item,index)=>{
					  if(this.state.allRows.find(e => e.index.toString() === index.toString()) !== undefined){
						if(data1[index][columns1.findIndex(e => e.name === "Upload Status")] === "Upload Success"){
						  jsonBody.append("tradeCheck"+index,index);
						  jsonBody.append("transid"+index,data1[index][columns1.findIndex(e => e.name === "TRANSID")]);
						}
						else {
						  alert("Only successful trade(s) will be  submitted from all selected trade(s).")
						}
					  }
				  });

				  */

					this.state.allRows.forEach((row,index) => {

						  if(data1[row.dataIndex][columns1.findIndex(e => e.name === "Upload Status")] === "Upload Success"){
 								jsonBody.append("tradeCheck"+index,row.dataIndex);
								jsonBody.append("transid"+index,data1[row.dataIndex][columns1.findIndex(e => e.name === "TRANSID")]);
 						  }else{
							   checkin = true;
						  }

					});

					// alert("Only successful trade(s) will be  submitted from all selected trade(s).")
        	  	if(checkin==true){
					showAlert(this,message["TRDSUB"]);
 				}else{

					jsonBody.append("vecSize",data1.length);
					jsonBody.append("mcProcessFlag",mcprocessflag);
					jsonBody.append("actionFlag","RELEASEFORAPPROVAL");
					url=alertConstants.URL+"/REVTRDUP.do";
					axios({
					  method: 'post',
					  url:url,
					  data: jsonBody,
					  config: { headers: {'Content-Type': 'multipart/form-data' }}
					}).then((response)=>{
					  data1 = response.data;
					  this.getFilter();
					});

				}

				}

        }
        else if(e.target.name === "Fix Errors Online"){
			//    alert("Please select at least one trade transaction.")
		   if(this.state.allRows.length === 0)
		   showAlert(this,message["CHECKATLONE"]);
          else{

            jsonBody.append("mcprocessflag",mcprocessflag);
            jsonBody.append("toDate",toDate);
            jsonBody.append("fromDate",fromDate);
            jsonBody.append("actionFlag","RESUBMIT");
            // jsonBody.append("vecSize",this.state.allRows.length);
            jsonBody.append("vecSize",data1.length);
            jsonBody.append("deskGroupId",deskGroupId);
/*
            data1.map((item,index)=>{
              if(this.state.allRows.find(e => e.index.toString() === index.toString()) !== undefined){
                // console.log("ddddddddddddddd",columns1.findIndex(e => e.name === "Run Id"))
                // console.log("sssssssssssssss",data1[index][columns1.findIndex(e => e.name === "Run Id")])
                console.log("sssssss",data1[index][columns1.findIndex(e => e.name === "Upload Status")])
                if(data1[index][columns1.findIndex(e => e.name === "Upload Status")] === "Upload Failed"){

                  jsonBody.append("tradeCheck"+index,index);
                  jsonBody.append("transactionId"+index,data1[index][columns1.findIndex(e => e.name === "Transaction Id")]);
                  jsonBody.append("runId"+index,data1[index][columns1.findIndex(e => e.name === "Run Id")]);
                  selectedCount++;
                }else{
                  selectedCount--;
                  checkin=true;
                }
              }
          });
*/
//          if(checkin==true){
                   			this.state.allRows.forEach((row,index) => {
//				  			console.log("---row data----1:" , row);
//								for(var k=0;k<18;k++){
//									console.log(" ,data value:index:"+data1[row.index][k]+", k value::"+k);
//									console.log(" ,data value:dataIndex:"+data1[row.dataIndex][k]+", k value::"+k);

								  if(data1[row.dataIndex][columns1.findIndex(e => e.name === "Upload Status")] === "Upload Failed"){

										jsonBody.append("tradeCheck"+index,row.dataIndex);
										jsonBody.append("transactionId"+index,data1[row.dataIndex][columns1.findIndex(e => e.name === "Transaction Id")]);
										jsonBody.append("runId"+index,data1[row.dataIndex][columns1.findIndex(e => e.name === "Run Id")]);

										console.log("tradeCheck"+index,row.dataIndex);
										console.log("transactionId"+index,data1[row.dataIndex][columns1.findIndex(e => e.name === "Transaction Id")]);
										console.log("runId"+index,data1[row.dataIndex][columns1.findIndex(e => e.name === "Run Id")]);

								  }else{
									   checkin = true;
 								  }

///                  jsonBody.append("tradeCheck"+index,index);
//                  jsonBody.append("transactionId"+index,data1[index][columns1.findIndex(e => e.name === "Transaction Id")]);
//                  jsonBody.append("runId"+index,data1[index][columns1.findIndex(e => e.name === "Run Id")]);

				//  				}
			});

// 		  }

//   alert("Only failed trade(s) will be allowed to  fix errors from all selected trade(s).");
          if(checkin==true){
			showAlert(this,message["TRDRESUB"])
 			}



          url=alertConstants.URL+"/RESUBUPLD.do";
var data;
data2=[];
if(checkin === false){
  this.setState({fixflag:true})
            axios({
              method: 'post',
              url:url,
              data: jsonBody,
              config: { headers: {'Content-Type': 'multipart/form-data' }}
            }).then((response)=>{
              data = response.data;
              columns2 = data.find(item =>item.name ==="columns").COLUMNS;
              data2 = data.find(item =>item.name ==="DATA").DATA;
              columns2 && columns2.map((item,index)=>{
                if(item.name !== "Error Message / Reason"){
                  item.options["customBodyRender"] = (value, tableMeta, updateValue) => <input type='text' name={item.name+tableMeta.rowIndex} onChange={e=>this.handleChange(e,item.name,tableMeta.rowIndex)} defaultValue={value}/>;
                }
              })
              this.setState({ck:0})
              this.state.fixflag=false;
              // this.state.allRows=[];
              // console.log("11111111111===>",columns2)
              // console.log("22222222222===>",data2)
            });
          }

          }

        }else if(e.target.name === "Save"){
			// alert("Please select at least one trade transaction.")
		  if(this.state.allRows1.length === 0)
		  showAlert(this,message["CHECKATLONE"]);
         else{
          if(confirm("Are you sure, you want to save the data?")){
          jsonBody.append("mcprocessflag",mcprocessflag);
          jsonBody.append("actionFlag","UPLOAD");
         jsonBody.append("vecSize",this.state.allRows.length);
        //  jsonBody.append("vecSize",data2.length);
          data2 && data2.map((item,index)=>{
            if(this.state.allRows1.find(e => e.index.toString() === index.toString()) !== undefined){
              // console.log("ddddddddddddddd",columns1.findIndex(e => e.name === "Run Id"))
              // console.log("sssssssssssssss",data1[index][columns1.findIndex(e => e.name === "Run Id")])
              jsonBody.append("tradeCheck"+index,index);
              jsonBody.append("transactionId"+index,data2[index][columns2.findIndex(e => e.name === "transactionId")]);
              jsonBody.append("escrowacctnbr"+index,data2[index][columns2.findIndex(e => e.name === "GIP Account Number")]);
              jsonBody.append("dollaramount"+index,data2[index][columns2.findIndex(e => e.name === "Amount")]);
              jsonBody.append("transtype"+index,data2[index][columns2.findIndex(e => e.name === "Transtype")]);
              jsonBody.append("accountnumber"+index,data2[index][columns2.findIndex(e => e.name === "Client Identifier")]);
              jsonBody.append("notes"+index,data2[index][columns2.findIndex(e => e.name === "Notes")]);
              jsonBody.append("accountidflag"+index,data2[index][columns2.findIndex(e => e.name === "Accountidflag")]);
              jsonBody.append("recordno"+index,data2[index][columns2.findIndex(e => e.name === "recordNo")]);
              jsonBody.append("runId"+index,data2[index][columns2.findIndex(e => e.name === "Run Id")]);
            }
        });
        url=alertConstants.URL+"/RESUBUPLD.do";
var data;
          axios({
            method: 'post',
            url:url,
            data: jsonBody,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
          }).then((response)=>{
            data = response.data;
            // console.log("dataaaaaaaaaaaa===>",data.find(item =>item.name ==="saveStatus").value)
            savemessage = data.find(item =>item.name ==="saveStatus").value;
            columns3 = data.find(item =>item.name ==="columns").COLUMNS;
            data3 = data.find(item =>item.name ==="DATA").DATA;
            this.setState({fixflag:false})
            this.state.allRows1=[];
          });
        }
      }
    }else if(e.target.name === "Back"){
      this.setState({fixflag:false})
    }else if(e.target.name === "Approve Selected Trade(s)"){
      var ckflag = true,sb='',crsflag=false;
      if(this.state.allRows.length === 0)
	  	showAlert(this,message["CHECKATLONE"]);
          else{
            if(confirm("Are you sure, you want to approve the data?")){

              jsonBody.append("vecSize",data1.length);
              jsonBody.append("actionFlag","APPROVE");

//         data1.map((item,index)=>{
			  this.state.allRows.forEach((row,index) => {
           //   if(this.state.allRows.find(e => e.index.toString() === index.toString()) !== undefined){
                var mcpr = data1[row.dataIndex][columns1.findIndex(e => e.name === "MCPR")];
                if((mcprocessflag === "Y" && mcpr === "N") || (mcprocessflag === "N" && mcpr === "Y")){
                //   alert("Cannot approve as Maker/Checker role is changed or MakerChecker process is disabled.");
				showAlert(this,"Cannot approve as Maker/Checker role is changed or MakerChecker process is disabled.");
                  ckflag=false;
                }
                if(data1[row.dataIndex][columns1.findIndex(e => e.name === "CRSFLAG")] === "N"){
                  sb += data1[row.dataIndex][columns1.findIndex(e => e.name === "TransId")]+", ";
                  crsflag = true;
                }
                jsonBody.append("tradeCheck"+index,index);
                jsonBody.append("transid"+index,data1[row.dataIndex][columns1.findIndex(e => e.name === "TransId")]);
           //    }
          });


          if(crsflag){
            // alert("The Trade "+sb+" No Trading Permissible\n\nOur records indicate that this Customer does not have a Self-Certification on file in order to comply with the Common Reporting Standards. Please contact your Fo Representative and access\nhttps://www.fo.com/tts/sa/taxinitiatives/crs.html for forms and/or more information.")
            showAlert(this,"The Trade "+sb+" No Trading Permissible\n\nOur records indicate that this Customer does not have a Self-Certification on file in order to comply with the Common Reporting Standards. Please contact your Fo Representative and access\nhttps://www.fo.com/tts/sa/taxinitiatives/crs.html for forms and/or more information.")
          }else{
          url=alertConstants.URL+"/APRTRDUP.do";
          var data;
          if(ckflag){
            axios({
              method: 'post',
              url:url,
              data: jsonBody,
              config: { headers: {'Content-Type': 'multipart/form-data' }}
            }).then((response)=>{
              data = response.data;
              savemessageapprove = data.find(item =>item.name ==="saveStatus").value;
              this.setState({allRows:[]})
              // console.log("savemessageapprove--->",savemessageapprove)
            });
          }
        }
          }
        }
    }else if(e.target.name === "Reject Trade(s)"){
      var ckflag = true;
      if(this.state.allRows.length === 0)
	  showAlert(this,message["CHECKATLONE"]);
          else{
            if(confirm("Are you sure, you want to reject these data?")){

              jsonBody.append("vecSize",data1.length);
              jsonBody.append("actionFlag","REJECT");
           // data1.map((item,index)=>{
			   this.state.allRows.forEach((row,index) => {
 //             if(this.state.allRows.find(e => e.index.toString() === index.toString()) !== undefined){
                var mcpr = data1[row.dataIndex][columns1.findIndex(e => e.name === "MCPR")];
                if((mcprocessflag === "Y" && mcpr === "N") || (mcprocessflag === "N" && mcpr === "Y")){
                //   alert("Cannot reject the trade(s) as Maker/Checker role is changed or MakerChecker process is disabled.");
				showAlert(this,"Cannot reject the trade(s) as Maker/Checker role is changed or MakerChecker process is disabled.");
                  ckflag=false;
                }

                jsonBody.append("tradeCheck"+index,index);
                jsonBody.append("transid"+index,data1[row.dataIndex][columns1.findIndex(e => e.name === "TransId")]);
//               }
          });

          url=alertConstants.URL+"/APRTRDUP.do";
          var data;
          if(ckflag){
            axios({
              method: 'post',
              url:url,
              data: jsonBody,
              config: { headers: {'Content-Type': 'multipart/form-data' }}
            }).then((response)=>{
              data = response.data;
              savemessageapprove = data.find(item =>item.name ==="saveStatus").value;
              this.setState({allRows:[]})
              // console.log("savemessageapprove--->",savemessageapprove)
            });

        }
          }
        }
    }
    }
selectedRows(selRows)
{
	console.log("selected rws ", selRows);
	selRowsIndex=selRows;
}
 doApprove(scroll){
        //alert("begin approve  ")
        var jsonBody = new FormData();
        var cnt=0;
        var url;
        if(selRowsIndex != undefined && pageName != undefined && pageName === "/reportCheck/FUDEAPRL"){
          url=alertConstants.URL+"/FUDEAPRL.do";
          jsonBody.append("totsize",selRowsIndex.length);
	     selRowsIndex.forEach((row,index) => {
			 console.log("row data" , row);

	     /*for(var k=0;k<15;k++){
	       alert(" ,data value::"+data1[row.index][k]+", k value::"+k);
	     }*/
	     jsonBody.append("selwebreferenceid"+cnt,data1[row.dataIndex][0]);//WEBREFERENCE
	     jsonBody.append("seltransid"+cnt,data1[row.dataIndex][12]);//TRANSID
	     jsonBody.append("selgroupid"+cnt,data1[row.dataIndex][13]);//GROUPID
	     jsonBody.append("tickteStatus"+cnt,data1[row.dataIndex][9]);//TICKETSTATUS
	     jsonBody.append("check"+cnt,"on");
	     cnt++;
	     //alert("catid futuredate trade approval block webreference::"+data1[row.index][0]+"::seltransid::"+data1[row.index][12]+"::selgroupid"+data1[row.index][13]+"::ticket status:"+data1[row.index][9]);
	 })
         }

	if(selRowsIndex != undefined && pageName != undefined && pageName === "/reportCheck/WATFRAPP"){
	  url=alertConstants.URL+"/WATFRAPP.do";
	  jsonBody.append("MCtradesSize",data1.length);
	  selRowsIndex.forEach((row,index) => {

	   //for(var k=0;k<16;k++){
		//alert(" ,data value::"+data1[row.index][k]+", k value::"+k);
	   //}
	   jsonBody.append("transid"+cnt,data1[row.dataIndex][11]);//TRANSID
	   jsonBody.append("version"+cnt,data1[row.dataIndex][13]);//VERSION
	   jsonBody.append("chk"+cnt,"on");
	   cnt++;
	   //alert("catid todays trade approve block transid::"+data1[row.index][9]+"::version::"+data1[row.index][11]);
	  })
          }

	  if(cnt > 0){
	    if(window.confirm('Are you sure, you want to approve the trade(s)?')){
    	     var user = JSON.parse(sessionStorage.getItem('user'));
    	     jsonBody.append("clientFirm",sessionStorage.getItem('clientFirm'));
    	     jsonBody.append("token",user[0].token);
    	     jsonBody.append("actionFlag","APPROVE");
		    axios({
		     method: 'post',
		     url:url,
		     data: jsonBody,
		     config: { headers: {'Content-Type': 'multipart/form-data' }}
		   }).then((response)=>{
		     popUpData = response.data;
		     this.setState({ openPopUp: true, scroll });
		});
    	      //alert("after submit ")
	    }
	  }else{
            // alert("Please check atleast one check box");
			showAlert(this,message["PLSELECT"])
		}
     }

 doReject(scroll){
       //alert("begin reject block");
         var jsonBody = new FormData();
         var cnt=0;
         var url;
         if(selRowsIndex != undefined && pageName != undefined && pageName === "/reportCheck/FUDEAPRL"){
          url=alertConstants.URL+"/FUDEAPRL.do";
          jsonBody.append("totsize",data1.length);
 	  selRowsIndex.forEach((row,index) => {


 	  jsonBody.append("selwebreferenceid"+cnt,data1[row.dataIndex][0]);//WEBREFERENCE
 	  jsonBody.append("seltransid"+cnt,data1[row.dataIndex][12]);//TRANSID
 	  jsonBody.append("selgroupid"+cnt,data1[row.dataIndex][13]);//GROUPID
 	  jsonBody.append("tickteStatus"+cnt,data1[row.dataIndex][9]);//TICKETSTATUS
 	   jsonBody.append("check"+cnt,"on");

 	   cnt++;
	     //alert("catid futuredate trade reject block webreference::"+data1[[row.dataIndex][0]+"::seltransid::"+data1[[row.dataIndex][12]+"::selgroupid"+data1[[row.dataIndex][13]+"::ticket status:"+data1[[row.dataIndex][9]);
 	  })
 	  }

 	  if(selRowsIndex != undefined && pageName != undefined && pageName === "/reportCheck/WATFRAPP"){
  	       url=alertConstants.URL+"/WATFRAPP.do";
	  	  jsonBody.append("MCtradesSize",data1.length);
	  	  selRowsIndex.forEach((row,index) => {

	  	  jsonBody.append("transid"+cnt,data1[row.dataIndex][11]);//TRANSID
	  	  jsonBody.append("version"+cnt,data1[row.dataIndex][13]);//VERSION
	  	   jsonBody.append("chk"+cnt,"on");
	  	     cnt++;
	       //alert("catid todays trade reject block transid::"+data1[row.index][9]+"::version::"+data1[row.index][11]);
	  	  })
	  }

 	  if(cnt > 0){
 	    if(window.confirm('Are you sure, you want to reject the trade(s)?')){
     	     var user = JSON.parse(sessionStorage.getItem('user'));
     	     jsonBody.append("clientFirm",sessionStorage.getItem('clientFirm'));
     	     jsonBody.append("token",user[0].token);
    	     jsonBody.append("actionFlag","REJECT");
		axios({
		     method: 'post',
		     url:url,
		     data: jsonBody,
		     config: { headers: {'Content-Type': 'multipart/form-data' }}
		   }).then((response)=>{
		     popUpData = response.data;
		     this.setState({ openPopUp: true, scroll });
		     //this.getFilter();
		});
	      //alert("submit rejected")
 	    }
 	  }else{
			//  alert("Please check atleast one check box");
			showAlert(this,message["PLSELECT"])
           }
   }
   doRefresh(){
     this.getFilter();
   }


	 doAllRateCheck(e){
	 	if(this.state.allRate === 'Y')
	 	{
			this.setState({allRate:''});
		}else if(this.state.allRate === '') {
			this.setState({allRate:'Y'});
		}

   }

   doAllRateReasonCheck(e){

  		if(this.state.allRateReason === 'Y')
  	 	{
  			this.setState({allRateReason:''});
  		}else if(this.state.allRateReason === '') {
  			this.setState({allRateReason:'Y'});
		}

  }
    rateChangeValues(e,name){
		showAlert(this,name +'<<>>'+e.target.value)
		// alert(name +'<<>>'+e.target.value)
 		let value =e.target.value;
 		let rateTxtObj = this.state.rateTxtObj;
   		this.setState({name:value});
   		if(name ==='allRateTxt'){
			rateTxtObj.allRateTxt = value;
		}else if(name ==='allRateTxt2'){
			rateTxtObj.allRateTxt2 = value;
		}else if(name ==='allRateReasonTxt2'){
			rateTxtObj.allRateReasonTxt2 = value;
		}
		this.setState({rateTxtObj:rateTxtObj});

		console.log('rateTxtObj >>>'+JSON.stringify(rateTxtObj))

   }

    doViewChanges(){



  }
  doRevoke(){
	  var jsonBody =  new FormData(); ;

			for (var pair of changedbodyFormData.entries())
			{
			jsonBody.append(pair[0], pair[1]);
			}
 			var company;
	       	var clientFirm;
	       	var user = JSON.parse(sessionStorage.getItem('user'));
	       	jsonBody.append("token",user[0].token);
	       	jsonBody.append("actionFlag",'REVOKE');
	       	jsonBody.append("totsize",data1.length);
	       	jsonBody.append("processId",data1[0][21]);

			if(document.getElementById("clientFirm")!=null){
				clientFirm=document.getElementById("clientFirm").value;
			}


			if(confirm('Are you sure, you want to revoke the changes?'))
			{
				this.props.dispatch(reportActions.fetchReportData(jsonBody));
			}
			 filterFlag=false;
			 this.state.allRows = [];
  }
    doApproveMtd(){
  	doMMMFMTDASave('APPROVE');
  }
    doRejectMtd(){
			var jsonBody =  new FormData(); ;

			for (var pair of changedbodyFormData.entries())
			{
			jsonBody.append(pair[0], pair[1]);
			}

 			var company;
	       	var clientFirm;
	       	var user = JSON.parse(sessionStorage.getItem('user'));
	       	jsonBody.append("token",user[0].token);
	       	jsonBody.append("actionFlag",'REJECT');
	       	jsonBody.append("totsize",data1.length);
	       	jsonBody.append("processId",data1[0][21]);



			if(document.getElementById("clientFirm")!=null){
				clientFirm=document.getElementById("clientFirm").value;
			}


			if(confirm('Are you sure, you want to reject the changes?'))
			{
				this.props.dispatch(reportActions.fetchReportData(jsonBody));
			}
			 filterFlag=false;
			  this.state.allRows = [];
  }

  doMMMFMTDASave(actionFlag){


        //alert("doSave block clicked save button:::"+selRowsIndex);
        var jsonBody =  new FormData(); ;

        for (var pair of changedbodyFormData.entries())
		{
		 jsonBody.append(pair[0],pair[1]);
		}

   	var cnt=0;
   	//console.log("apr 04, 2019 data1222::",columns1);
  // 	 console.log("apr 04, 2019 data1222::"+JSON.stringify(data1));

   	//alert("selRowsIndex::"+selRowsIndex);

	if(this.state.allRate === 'Y'){
	cnt++;
	jsonBody.append("allRate" ,'Y');
	jsonBody.append("allRateTxt" ,this.state.rateTxtObj.allRateTxt);
	} else if(this.state.allRateReason === 'Y'){
	cnt++;
	jsonBody.append("allRateReason" ,"Y");
	jsonBody.append("allRateTxt2" ,this.state.rateTxtObj.allRateTxt2);
	jsonBody.append("allRateReasonTxt2" ,this.state.rateTxtObj.allRateReasonTxt2);
	}

	//if(selRowsIndex != undefined && selRowsIndex.length!=0)
	//{
   	     var adjRate="";
   	     var adjBal="";
   	      var comments="";
	     var amount="";
	     var numberOfShares="";
	     var nav="";
	     var parentProdId="";


   	     data1.forEach((row,index) => {
   		jsonBody.append("check"+index,"on");
   		if(document.getElementById("adjRate"+index)!=null)
   		   adjRate=document.getElementById("adjRate"+index).value;
   		   jsonBody.append("adjRate"+index,adjRate);

   		    adjBal=document.getElementById("adjBal"+index).value;
   		   jsonBody.append("adjBal"+index,adjBal);

   		     comments=document.getElementById("comments"+index).value;
		      jsonBody.append("comments"+index,comments);

   		  	  jsonBody.append("acctNbr"+index,data1[index][20]);
   		  	  jsonBody.append("rate"+index,data1[index][8]);
   		  	  jsonBody.append("endbalance"+index,data1[index][5]);
   		  	  jsonBody.append("oldmtdValue"+index,data1[index][10]);
   		  	  jsonBody.append("selgroupid"+index,data1[index][17]);
   		  	  jsonBody.append("selcreateddate"+index,data1[index][6	]);
   		  	  jsonBody.append("selentrytypeid"+index,'');
   		  	  jsonBody.append("selecompanyid"+index,data1[index][16]);
   		  	  jsonBody.append("selacctbalentryId"+index,'');
   		  	  jsonBody.append("selacctnbr"+index,data1[index][14]);
   		  	  jsonBody.append("processId"+index,data1[index][21]);


   		   //alert("transid::"+jsonBody.get("trId"+row.index));
   		   cnt++;
   	    });

		//}
      //  alert("save block cnt::"+cnt);
       if(cnt>0)
       {

   		var company;
       	var clientFirm;
       	var user = JSON.parse(sessionStorage.getItem('user'));
       	jsonBody.append("token",user[0].token);
       	jsonBody.append("actionFlag",actionFlag);
       	jsonBody.append("totsize",data1.length);



		if(document.getElementById("clientFirm")!=null){
			clientFirm=document.getElementById("clientFirm").value;
		}


		if(actionFlag == 'APPROVE'&& confirm('Are you sure, you want to appove the changes?'))
		{
			 this.props.dispatch(reportActions.fetchReportData(jsonBody));
		}else  if(confirm('Are you sure, you want to save the changes?'))
		{
			 this.props.dispatch(reportActions.fetchReportData(jsonBody));
		}
	  }else{
		// alert(message["PLSELECT"]);
		showAlert(this,message["PLSELECT"]);
	  }

 filterFlag=false;

  }
   doSave() {
        //alert("doSave block clicked save button:::"+selRowsIndex);
        var jsonBody = new FormData();
   	var cnt=0;
   	//console.log("apr 04, 2019 data1222::",columns1);
   	//console.log("apr 04, 2019 data1222::",data1);

   	//alert("selRowsIndex::"+selRowsIndex);
   	if(selRowsIndex != undefined && selRowsIndex.length!=0)
   	{
   	     var contractNo="";
	     var amount="";
	     var numberOfShares="";
	     var nav="";
	     var parentProdId="";
   	     selRowsIndex.forEach((row,index) => {
   		jsonBody.append("chk"+cnt,"on");
   		if(document.getElementById("contractNo"+row.dataIndex)!=null)
   		   contractNo=document.getElementById("contractNo"+row.dataIndex).value;

   		   jsonBody.append("contractNo"+cnt,contractNo);
   		   jsonBody.append("trId"+cnt,data1[row.dataIndex][columns1.findIndex(e => e.name === "Deal No")]);//TRANSID
   		   parentProdId=data1[row.dataIndex][columns1.findIndex(e => e.name === "Parent Product Id")]

   		   jsonBody.append("parentProdId"+cnt,parentProdId);

   		   if(parentProdId == resultConstants.MMFPRODID)
   		   {
   		   //alert("in block ...");
   		   jsonBody.append("accountNumber"+cnt,data1[row.dataIndex][columns1.findIndex(e => e.name === "Account Number")]);
   		   if(document.getElementById("amount"+row.dataIndex)!=null)
   		     amount=document.getElementById("amount"+row.dataIndex).value;


   		   if(document.getElementById("numberOfShares"+row.dataIndex)!=null){
   		     numberOfShares=document.getElementById("numberOfShares"+row.dataIndex).value;
   		     }

   		   if(document.getElementById("nav"+row.dataIndex)!=null)
   		     nav=document.getElementById("nav"+row.dataIndex).value;

   		   jsonBody.append("transType"+cnt,data1[row.dataIndex][columns1.findIndex(e => e.name === "Transtype")]);
   		   jsonBody.append("amount"+cnt,amount);
   		   jsonBody.append("shares"+cnt,numberOfShares);
   		   jsonBody.append("nav"+cnt,nav);

   		   jsonBody.append("feeAmt"+cnt,"0");//12060D
   		   }
   		   //alert("transid::"+jsonBody.get("transType"+cnt));
   		   cnt++;
   	    });

       //alert("save block cnt::"+cnt);
       if(cnt>0)
       {

   	var company;
       	var clientFirm;
       	var user = JSON.parse(sessionStorage.getItem('user'));
       	jsonBody.append("token",user[0].token);
       	jsonBody.append("actionFlag","SAVE");
       	jsonBody.append("chkSize",data1.length);

       	if(document.getElementById("company")!=null){
   	    company=document.getElementById("company").value;
   	}

	if(document.getElementById("fromDate")!=null){
   	    fromDate=document.getElementById("fromDate").value;
   	}

	if(document.getElementById("toDate")!=null){
   	    toDate=document.getElementById("toDate").value;
   	}

   	//alert("apr 16, 2019 ACK fromDate::"+fromDate+",toDate::"+toDate+",company:"+company);

	jsonBody.append("company",company);
	jsonBody.append("companyId","ALL");
	jsonBody.append("fromDate",fromDate);
	jsonBody.append("toDate",toDate);
	if(confirm(message["ACKCNFRM"]))
        {
	 this.props.dispatch(reportActions.fetchReportData(jsonBody));
	//alert("submited success");
       }
  }else{
    // alert(message["PLSELECT"]);
    showAlert(this,message["PLSELECT"]);
  }
      }else{
			// alert(message["PLSELECT"]);
			showAlert(this,message["PLSELECT"]);
          }
     }
 doNSave() {
        //alert("doSave block clicked save button:::"+selRowsIndex);
        var jsonBody = new FormData();
   	var cnt=0;
   	//console.log("apr 04, 2019 data1222::",columns1);
   	//console.log("apr 04, 2019 data1222::",data1);

   	//alert("selRowsIndex::"+selRowsIndex);
   	if(selRowsIndex != undefined && selRowsIndex.length!=0)
   	{
   	     var contractNo="";
   	     selRowsIndex.forEach((row,index) => {
   		jsonBody.append("chk"+cnt,"on");
   		if(document.getElementById("contractNo"+row.dataIndex)!=null)
   		   contractNo=document.getElementById("contractNo"+row.dataIndex).value;
   		   jsonBody.append("trId"+cnt,data1[row.dataIndex][columns1.findIndex(e => e.name === "Deal No")]);//TRANSID
   		   jsonBody.append("contractNo"+cnt,contractNo);
   		   //alert("transid::"+jsonBody.get("trId"+cnt));
   		   cnt++;
   	    });

       //alert("save block cnt::"+cnt);
       if(cnt>0)
       {

   	var company;
       	var clientFirm;
       	var user = JSON.parse(sessionStorage.getItem('user'));
       	jsonBody.append("token",user[0].token);
       	jsonBody.append("actionFlag","NACK");
       	jsonBody.append("chkSize",data1.length);

       	if(document.getElementById("company")!=null){
   	    company=document.getElementById("company").value;
   	}

	if(document.getElementById("fromDate")!=null){
   	    fromDate=document.getElementById("fromDate").value;
   	}

	if(document.getElementById("toDate")!=null){
   	    toDate=document.getElementById("toDate").value;
   	}
   	//alert("apr 16, 2019 NACK fromDate::"+fromDate+",toDate::"+toDate).
	jsonBody.append("company",company);
	jsonBody.append("companyId","ALL");
	jsonBody.append("fromDate",fromDate);
	jsonBody.append("toDate",toDate);

	if(confirm(message["CANCELTRADE"]))
        {
	 this.props.dispatch(reportActions.fetchReportData(jsonBody));
	//alert("NACK submited success");
       }
  }else{
	// alert(message["PLSELECT"]);
	showAlert(this,message["PLSELECT"])
  }
      }else{
			// alert(message["PLSELECT"]);
			showAlert(this,message["PLSELECT"])
          }
     }

    render() {
    	popUpMsg="";
    let dataFlag=true;
		let approveBtn="";
		let rejectBtn="";
		let tradeMsg="";

            var newdata ;
            var popuptitle,popupvalue;
            //const { reportdata } = this.props;
             //this.props[3].COLUMNS;
	 //this.props[3].DATA;
		var actions = [] //this.props[3].DATA;
		var actionsTrdFut = []
            var data,columns,screenName,saveMsg,saveMsgTxt,showBtnFlag,results1=[],paginationFlag=true,checkPosition,checkboxFlag=false;
            // console.log(" this.props.reportdata--->", this.props.reportdata.reportdata)
//            console.log(" this.props.reportdata[3]--->", this.props.reportdata.reportdata[3])

             //this.props.reportdata.reportdata.find(


            this.state.reportdata = this.props.reportdata.reportdata;
            if(this.state.reportdata!==undefined)
            results1  = Array.from(this.state.reportdata);
            //columns = this.props.reportdata.reportdata.COLUMNS;
            //data = this.props.reportdata.reportdata.DATA;


            //if(mmmfdata.mmmfdata !== undefined){
            //   columns = mmmfdata.mmmfdata.COLUMNS;

            // console.log("results1 block :::",results1)
            //console.log("columns block::",columns)

             //var mainList=results1.find(item =>item.name ==="columns")// === listName)
             //console.log("mainlist", mainList)


         if(this.props.reportdata.reportdata !== undefined){
                if(this.props.reportdata.reportdata.length>0){
                    newdata="";
                    newdata = this.props.reportdata.reportdata.find(item =>item.name==="newTradeData")
                    //  console.log("newdata::",newdata)
                     if(newdata !== undefined && newdata.length!==0)
                     {
                        //console.log("insode newdata::",newdata)
                        popuptitle = newdata.label;
                        popupvalue = newdata.value;
                    }else
                    this.state.open=false;
            }
        }
        else{
            return(
                <Loading />
            )
        }


var popuptradedata;
        var popupcolumns1=[],popupdata1=[];
        if(this.state.flag && newdata !== undefined){
                newdata.values.map((item,index)=>{
                popuptradedata = item;
                popupdata1.push(popuptradedata)
            })
        console.log("popuptradedata-->",popuptradedata)
        if(popuptradedata !== undefined){
            var s =  popuptradedata;
            for(var k in s) {

                if(k !== "TradeType"){
                    popupcolumns1.push({
                        Header: k,
                        accessor: k
                        });
                }else{
                    this.state.TradeType = s[k]
                }

            }
            this.state.open = true;
        }
    }
    console.log("popupcolumns1::",popupcolumns1);
    //console.log("popupdata1::",popupdata1);
    // console.log("result1 " , results1);
    let screenLinkImage;
    let actionsmarkup='';
    let actionsTdayFutMarkup='';

	let allchecked='';
	let checkDisabled='';
	let rateTxt='';
	let rateTxt2='';
	let reasonTxt2='';
	let displayButtons='';
	let tempStatusFlag='';
	let displayMessage='';
	let createFlag='';

    if(this.props.location.pathname!== undefined && this.props.location.pathname.length!==0){
         let pos=this.props.location.pathname.lastIndexOf('/');
         //console.log("position value::",pos);
         screenLinkImage=this.props.location.pathname;
         screenLinkImage=screenLinkImage.substring(pos+1,screenLinkImage.length)
         //alert("screenLinkImage::"+screenLinkImage)
         //console.log("screenLinkImage value::",screenLinkImage);
    }
		if( results1 !== undefined && results1.toString().trim().length!==0)
		{
			displayButtons=undefined;
			tempStatusFlag=undefined;
			displayMessage=undefined;
			createFlag=undefined;


			 results1.map((item,index) => {
			    if(item.type === "Title"){
			       screenName = item.name
			    }

			     if(pageName === "/reportCheck/MMFMTDRA"){


						if(item.name === "allchecked"){
						allchecked = item.value
						}

						if(item.name === "checkDisabled"){
							 checkDisabled = item.value
						}
						if(item.name === "rateTxt"){
						rateTxt = item.value
						}
						if(item.name === "rateTxt2"){
							 rateTxt2 = item.value
						}
						if(item.name === "reasonTxt2"){
						 reasonTxt2 = item.value
						}

						if(item.name === "tempStatusFlag"){
							 	 tempStatusFlag = item.value
						}

						if(item.name === "displayButtons"){
							  displayButtons = item.value
						}

						if(item.name === "displayMessage"){
							   displayMessage = item.value
						}
						if(item.name === "createFlag"){
							createFlag = item.value
						}
						if(item.name === "checkerFlag"){
							checkerFlag = item.value
						}

					}



			    if(item.type === "SaveMessage"){
			         saveMsg = item.name;
			         saveMsgTxt = <div style={{ paddingTop:'10px', color: 'red', textAlignVertical: "left",textAlign: "left", }}>{saveMsg === "empty"?"":saveMsg}</div>;
			    }
			    if(item.type === "showButton")
			    {
			           showBtnFlag = item.name
			    }
			    if(item.paginationFlag === "false"){
			          paginationFlag = false;
			    }
			 if(item.type === "RoleType")
                    		checkerFlag = item.name
			if(item.type === "TradeApprovalMsg")
				tradeApprovalMsg = item.name

			mainList=results1.find(item =>item.name ==="TFACTIONS")// === listName)
		           if(mainList!==undefined && mainList.TFACTIONS!==undefined)
		              actionsTrdFut = mainList.TFACTIONS;

			actionsTdayFutMarkup = actionsTrdFut.map((item,index)=>{
				return <button className="btn btn-xs btn-primary" name={item.label} onClick={this.doSubmit}>{item.label}</button>
			})
			if(item.type === "Message"){
				messageTxt = item.name
				this.state.message=item.name
			}


			if(item.type === "datepicker"){
			   if(item.name === "fromDate"){
			     fromDate=item.value;
			   }
			   if(item.name === "toDate"){
			        toDate=item.value;
			   }
			}
		    //if(item.name === "data")
		      //results = item.values
		})
    var mainList=results1.find(item =>item.name ==="columns")// === listName)

    // console.log("results1==>",results1)
		if(mainList!==undefined && mainList.COLUMNS!==undefined)
 	     	 columns1 = mainList.COLUMNS;


	     	mainList=results1.find(item =>item.name ==="DATA")// === listName)
	     	if(mainList!==undefined && mainList.DATA!==undefined)
              data1 = mainList.DATA;

		if(data1!== undefined && data1.length!==0){

			console.log("mar07, 2019 checkerFlag::"+checkerFlag+",pageName::"+pageName);
			//alert("111 checkerFlag::"+checkerFlag+",pageName::"+pageName);
			if(pageName === "/reportCheck/FUDEAPRL" || pageName === "/reportCheck/WATFRAPP"){
			       if(checkerFlag === "true"){
				  checkboxFlag=true;
				  tradeMsg = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "left", }}>{tradeApprovalMsg==="empty"?"":tradeApprovalMsg}</div>
			       }
			}else{
			  checkboxFlag=false;
		  }
		}
       		 mainList=results1.find(item =>item.name ==="ACTIONS")// === listName)
           if(mainList!==undefined && mainList.ACTIONS!==undefined)
              actions = mainList.ACTIONS;

        mainList=results1.find(item =>item.name ==="commonData")// === listName)
        if(mainList!==undefined && mainList.commonData!==undefined){
            mcprocessflag = mainList.commonData.mcProcessFlag;
            runId = mainList.commonData.runId;
            deskGroupId = mainList.commonData.deskGroupId;
        }

        mainList=results1.find(item =>item.name ==="checkPosition")// === listName)
           if(mainList!==undefined && mainList.value!==undefined){
              checkPosition = parseInt(mainList.value);
           }

        actionsmarkup = actions && actions.map((item,index)=>{
          return <button className="btn btn-xs btn-primary" name={item.label} onClick={this.submit}>{item.label}</button>
        })


         columns1 && columns1.map((item,index)=>{

			if(item.name === "Instruction Date"){
				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
					return (
						   <Formatter datetime={value}/>
					);
				  }
			 }
    if(item.options.hyperlink === "true" && (pageName === "/report/ACCPOREP" || pageName === "/report/MMDAACC"))
    {
	     //alert("before ScrollDialogPopUp");
             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
               return (
		  <ScrollDialogPopUp
                  onClick={e => this.openPopUp(e, tableMeta)}
                  rowData={tableMeta}
                  linkName={value}
                  screenLinkImage={screenLinkImage}
                  fromDate={fromDate}
                  toDate={toDate}
                />
              );
            }
	   }else if(item.options.hyperlink === "true" && pageName === "/report/AUDTRREP"){
 				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
					 return (
					  <PopUpDataTable
						onClick={e => this.openPopUp(e, tableMeta)}
						rowData={tableMeta}
						linkName={value}
						screenLinkImage={screenLinkImage}
						fromDate={fromDate}
						toDate={toDate}
					  />
					);
            }
	   }else if(item.options.hyperlink === "true"){
             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
               return (
                <ScrollDialog
                  onClick={e => this.openPopUp(e, tableMeta)}
                  rowData={tableMeta}
                  linkName={value}
                  screenLinkImage={screenLinkImage}
                  fromDate={fromDate}
                  toDate={toDate}
                />
              );
            }
		  }

         })

		}

let subBlk;
if(buttonFlag){
if(this.props.reportdata.reportdata !== undefined){
                if(this.props.reportdata.reportdata.length>0){
    //alert("target report pageName::"+pageName);
    subBlk = <Filters method={this.doChange} data={this.props.reportdata} filterFlag={filterFlag} pageName={pageName} />
    }
  }
}else{
    subBlk = <button className="btn btn-xs btn-primary" onClick={this.routeChange} >Create New account</button>
   }


msg = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "left", }}  >{this.state.message==="empty"?"":this.state.message}</div>

              const options = {
                filterType: "dropdown",
                selectableRows: data1.length >0 ?true:false,
                search: data1.length >0 ?true:false,
                sort: data1.length >0 ?true:false,
                filter:data1.length >0 ?true:false,
				print:data1.length >0 ?true:false,
				download:data1.length >0 ?true:false,
				viewColumns:data1.length >0 ?true:false,
                responsive: data1.length >0 ?"scroll":'',
                pagination: data1.length >0 ?paginationFlag:false,
                rowsPerPage:(paginationFlag===false)?data1.length:10,
                fixedHeader: false     ,
                downloadOptions:(screenName !== undefined && screenName !== "")?{filename: screenName+'.csv', separator: ','}:{filename: 'Report.csv', separator: ','},
                textLabels: {
				                body: {
				                     noMatch: this.props.reportdata.loading ?<TableLoader />:'Sorry, there is no matching data to display',
				                },
            	},
                isRowSelectable: (dataIndex) => {
									console.log("checkPosition .....", checkPosition);
									if(pageName === "/reportCheck/MMFMTDRA"){

										if(this.state.allRate === 'Y' || this.state.allRateReason === 'Y' || checkDisabled){
											return false;
										}else {
 				                 	return data1[dataIndex][checkPosition] !== "disabled";
										}
									}else {
 				                 		return data1[dataIndex][checkPosition] !== "disabled";
									}
                  },
                  onRowsSelect: (rowsSelected, allRows) => {
					  if(pageName === "/reportCheck/MMFMTDRA"){
						filterFlag=false;
					  }
                    this.selectedRows(allRows);
                    this.setState({allRows})

                  },
                  	customToolbarSelect: (selectedRows, displayData, setSelectedRows) => (
				  		<CustomToolbarSelect selectedRows={selectedRows} displayData={displayData} setSelectedRows={setSelectedRows} />
				  ),
				  customFooter: (
					  count,
					  page,
					  rowsPerPage,
					  changeRowsPerPage,
					  changePage
				  ) => {

					  return data1.length >0 ?<CustomPagination
										  count={count}
										  page={page}
										  rowsPerPage={rowsPerPage}
										  changeRowsPerPage={changeRowsPerPage}
										  // changePage={changePage}
										  onChangePage={(_, page) => changePage(page)}
										  onChangeRowsPerPage={event => changeRowsPerPage(event.target.value)}
										  type={"senario1"}
								  />:<div></div>;
				  }

              };
              const options1 = {
                filterType: "dropdown",
                selectableRows: data1.length >0 ?true:false,
                responsive: "scroll",
                pagination:paginationFlag,
                rowsPerPage:(paginationFlag===false)?data1.length:10,
                 downloadOptions:(screenName !== undefined && screenName !== "")?{filename: screenName+'.csv', separator: ','}:{filename: 'Report.csv', separator: ','},
                fixedHeader: false     ,
                  onRowsSelect: (rowsSelected, allRows1) => {
                    this.state.allRows1 = allRows1
                  }
              };
              const options2 = {
                filterType: "dropdown",
                selectableRows: false,
                responsive: "scroll",
                pagination:paginationFlag

              };

if( popUpData !== undefined && popUpData.toString().trim().length!==0){
   var commonPopUpData = [];
   console.log("view changes popup  popUpData::",popUpData);

	var popUpList=popUpData.find(item =>item.name ==="commonData")// === listName)

	if(popUpList!==undefined && popUpList.commonData!==undefined)
	  commonPopUpData = popUpList.commonData;
 	  title=commonPopUpData.screenName;
 	  messageTxt=commonPopUpData.Message;

	popUpMsg = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "left", }}  >{messageTxt === "empty"?"":messageTxt}</div>


	var popUpList=popUpData.find(item =>item.name ==="columns")// === listName)
	popUpColumns1 = popUpList.COLUMNS;

	popUpList=popUpData.find(item =>item.name ==="DATA")// === listName)
	popUpData1 = popUpList.DATA;

	optionsPopUp = {
		filterType: "dropdown",
		selectableRows: false,
		pagination: false,
        	rowsPerPage: 10,
		responsive: "scroll",
		fixedHeader: false,
		downloadOptions:(screenName !== undefined && screenName !== "")?{filename: screenName+'.csv', separator: ','}:{filename: 'Report.csv', separator: ','},
 		filter:false,
		search:false,
		print:false,
		download:false,
		viewColumns:false,
	};
    console.log("view changes popup  field values::",commonPopUpData);
  }
  let ackBtn,refreshBtn,nackBtn;
   let saveBtn='',viewChangesBtn='',rateDiv='',revokeBtn='';

  if(pageName!== undefined && pageName === "/reportCheck/EDTDLACK"){

     if(data1 !== undefined && data1.toString().trim().length!==0){
           refreshBtn = <button className="btn btn-xs btn-primary" onClick={this.doRefresh.bind()}> Refresh</button>
           ackBtn = <button className="btn btn-xs btn-primary" onClick={this.doSave.bind()}> ACK</button>
           if(showBtnFlag!==undefined && showBtnFlag === 'true'){
             nackBtn = <button className="btn btn-xs btn-primary" onClick={this.doNSave.bind()}> Cancel</button>
           }
      }

      if(columns1!== undefined && columns1.length !==0){
           columns1.map((item,index)=>{
  	 	       console.log("mar02,2019  item.name:::::",item.name)
  	 		if(item.name === "Contract No"){
  	 			item.options["sort"]=false;
      				item.options["searchable"]=false;
  	 			item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
  	 			//console.log("tableMeta",tableMeta);
  	 			 return (
  	 			  <div>
  	 			    <input type="text" name={"contractNo"+tableMeta.rowIndex} id={"contractNo"+tableMeta.rowIndex} maxlength="100" onChange={e => updateValue(e.target.value, tableMeta.rowIndex)} value={value} />
  	 			  </div>
  	 			  );
  	 			 }
  	 		}
			if(item.name === "No. of Shares"){
				item.options["sort"]=false;
      				item.options["searchable"]=false;
				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
				 return (
				  <div>
				    {((data1[tableMeta.rowIndex][columns1.findIndex(e => e.name === "Parent Product Id")]===resultConstants.MMFPRODID)?<input type="text" name={"numberOfShares"+tableMeta.rowIndex} id={"numberOfShares"+tableMeta.rowIndex} maxlength="20" onChange={e => {onSharesAmt(e,tableMeta.rowIndex);updateValue(e.target.value, tableMeta.rowIndex)}} value={value} />:<label className='TxtNrml'>{value}</label>)}
				  </div>
				  );
				 }
			}
			if(item.name === "NAV"){
				item.options["sort"]=false;
      				item.options["searchable"]=false;
				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
				 return (
				  <div>
				    {((data1[tableMeta.rowIndex][columns1.findIndex(e => e.name === "Parent Product Id")]===resultConstants.MMFPRODID)?<input type="text" name={"nav"+tableMeta.rowIndex} id={"nav"+tableMeta.rowIndex} maxlength="20" onChange={e => {onNavAmt(e,tableMeta.rowIndex);updateValue(e.target.value, tableMeta.rowIndex)}} value={value} />:<label className='TxtNrml'>{value}</label>)}
				  </div>
				  );
				 }
			 }
			if(item.name === "Transaction Amount"){
				item.options["sort"]=false;
				item.options["searchable"]=false;
				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
				 return (
				  <div>
				    {((data1[tableMeta.rowIndex][columns1.findIndex(e => e.name === "Parent Product Id")]===resultConstants.MMFPRODID)?<input type="text" name={"amount"+tableMeta.rowIndex} id={"amount"+tableMeta.rowIndex} maxlength="20" onChange={e => {onChangeAmount(e,tableMeta.rowIndex);updateValue(e.target.value, tableMeta.rowIndex)}}  value={value} />:<label className='TxtNrml'>{value}</label>)}
				  </div>
				  );
			      }
			}

             })
           }
         }

          if(pageName!== undefined &&pageName === "/reportCheck/MMFMTDRA"){

		       if(columns1!== undefined && columns1.length !==0){

				   rateDiv = <div>
				   			  				<div className="clearfix"></div>
				                           <div >
				                           	<table>
				                           	<tr><th></th><th>Rate</th><th>&nbsp;</th><th>Reason Description</th></tr>
				   			  				<tr><td><Checkbox name="allRate"  onChange={(e)=>{this.doAllRateCheck(e)}}
				   			  				 disabled={(this.state.allRows.length>0 || this.state.allRateReason === 'Y' || checkDisabled === 'true' ||  checkDisabled === 'disabled' )?true:false}  />

				   			  				Apply Rate change to all accounts in the same fund</td>
				   			  				<td><TextField refs="rateTxt"  id="rateTxt"  defaultValue={rateTxt}  onChange={(e)=>{this.rateChangeValues(e,'allRateTxt')}}/></td>
				    			  				<td></td><td></td>
				   			  				</tr>
				   			  				<tr><td><Checkbox name="allRateReason"
				   										 disabled={(this.state.allRows.length>0 || this.state.allRate === 'Y' || checkDisabled === 'true' ||  checkDisabled === 'disabled')?true:false} onChange={(e)=>{this.doAllRateReasonCheck(e)}}
				   											  />
				   										 Apply Rate and Reason Description change to all accounts in the same fund</td>
				   										<td><TextField refs="allRateTxt2"  id="allRateTxt2"  defaultValue={rateTxt2}  onChange={(e)=>{this.rateChangeValues(e,'allRateTxt2')}} /> </td>
				   										<td></td><td><TextField refs="allRateReasonTxt2"  id="allRateReasonTxt2"  defaultValue={reasonTxt2}  onChange={(e)=>{this.rateChangeValues(e,'allRateReasonTxt2')}} /> </td>
				   			  				</tr>
				   							</table>
				   			  			</div>
				   			  			<div className="clearfix"></div>

				   			  			 <div className="clearfix"></div>
				   			  			</div>


 				   			  if(displayButtons === 'false' && tempStatusFlag !== 'YES'){
				   		      saveBtn = <button className="btn btn-xs btn-primary" onClick={(e)=>{this.doMMMFMTDASave('SAVE')}}> SAVE</button>
								 viewChangesBtn = <ViewChanges changedbodyFormData={changedbodyFormData} />
							  revokeBtn='';
							  approveBtn='';rejectBtn='';
							 }else  if(displayButtons === 'true'){
								 if(createFlag === 'Y'){

									 if(displayMessage === undefined || displayMessage === ''){
									  saveBtn = <button className="btn btn-xs btn-primary" onClick={(e)=>{this.doMMMFMTDASave('SAVE')}}> SAVE</button>
									  revokeBtn = <button className="btn btn-xs btn-primary" onClick={this.doRevoke.bind()}> Revoke Chages</button>
									}
									}
								 viewChangesBtn = <ViewChanges changedbodyFormData={changedbodyFormData} />

								 approveBtn='';rejectBtn='';


							  if(checkerFlag === "true"){
								  	saveBtn='';viewChangesBtn='';revokeBtn='';
									  approveBtn = <button className="btn btn-xs btn-primary" onClick={this.doApproveMtd.bind()}> Approve</button>
								  	  rejectBtn = <button className="btn btn-xs btn-primary" onClick={this.doRejectMtd.bind()}> Reject</button>


							  }
							   }

		            columns1 && columns1.map((item,index)=>{
		   	 	       //console.log("mar02,2019  item.name:::::",item.name)
		   	 		if(item.name === "Adjusted New Rate"){
		   	 			item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
		   	 			 return (
		   	 			  <div>
		   	 			    <input type="text" name={"adjRate"+tableMeta.rowIndex} id={"adjRate"+tableMeta.rowIndex} defaultValue={value}  disabled={(this.state.allRate === 'Y' || this.state.allRateReason === 'Y' || checkDisabled === 'true' ||  checkDisabled === 'disabled')?true:false}/>
		   	 			  </div>
		   	 			  );
		   	 			 }
		   	 		}
					if(item.name === "Adjusted New MTDA"){
		   	 			item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
		   	 			 return (
		   	 			  <div>
		   	 			    <input type="text" name={"adjBal"+tableMeta.rowIndex} id={"adjBal"+tableMeta.rowIndex} defaultValue={value}  disabled={(this.state.allRate === 'Y' || this.state.allRateReason === 'Y' || checkDisabled === 'true' ||  checkDisabled === 'disabled')?true:false} />
		   	 			  </div>
		   	 			  );
		   	 			 }
		   	 		}

					if(item.name === "Reason Description"){
						item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
						 return (
						  <div>
							<input type="text" name={"comments"+tableMeta.rowIndex} id={"comments"+tableMeta.rowIndex} defaultValue={value}  disabled={(this.state.allRate === 'Y' || this.state.allRateReason === 'Y' || checkDisabled === 'true' ||  checkDisabled === 'disabled')?true:false} />
						  </div>
						  );
						 }
					}


		 			 if(item.name === "Account Position Link"){
							item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
								 if(pageName === "/reportCheck/MMFMTDRA"){
														filterFlag=false;
					 			 }
							 return (
							  <div> <AcctPositions changedbodyFormData={changedbodyFormData} rowData={tableMeta.rowData} />
 							  </div>
							  );
							 }
					}

		              })
		            }
         }

            return (
                <div>

                    <NavBar/>

					<div className="mainContent">
						<Typography variant="h5" component="h3" className="screenTitle">{screenName}</Typography>

						<div className="filter_div" id="filter_div" >
							{subBlk}
							{ subBlk !== undefined &&
							<br/>
							}
						</div>
        {savemessageapprove !== '' &&
          <div className="alert alert-success text-center">{savemessageapprove}</div>}
			<div className="clearfix"></div>
			<div>
			  {msg}
			</div>
			<div className="clearfix"></div>
                        <div >
                        {

                          this.state.fixflag!==true ?
                          data1 !== undefined ?
                          <div>
                          {(pageName === "/reportCheck/MMFMTDRA")?rateDiv:''}
                        <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                            <MUIDataTable
                            title=''
                            data={data1}
                            columns={columns1}
                            options={options}
                            />
                        </MuiThemeProvider>
                          {actionsmarkup}
                          </div>
                        :
                        <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
                        :
                          savemessage === ''?
                          <div>
                          <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                              <MUIDataTable
                              title=''
                              data={data2}
                              columns={columns2}
                              options={options1}
                              />
                          </MuiThemeProvider>
                          <button className="btn btn-xs btn-primary" name="Save" onClick={this.submit}>Save</button>
                          <button className="btn btn-xs btn-primary" name="Back" onClick={this.submit}>Back</button>
                          </div>
                          :
                          <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                              <MUIDataTable
                              title=''
                              data={data3}
                              columns={columns3}
                              options={options2}
                              />
                          </MuiThemeProvider>

                      }


				{(pageName === "/reportCheck/MMFMTDRA")?
				<div className="mt10">
				{saveBtn}{revokeBtn}
				{viewChangesBtn}
				{approveBtn}{rejectBtn}{saveMsgTxt}
				</div>:
				<div className="mt10">{saveMsgTxt}
                      {ackBtn}
                      {nackBtn}
                      {refreshBtn}
					  {actionsTdayFutMarkup}</div>}

			<div>
			  {tradeMsg}
			</div>

			<div>
		            <Dialog
		              open={this.state.openPopUp}
		              onClose={this.handlePopUpClose}
		              scroll={this.state.scroll}
		              aria-labelledby="scroll-dialog-title"
		              fullWidth={true}
		              maxWidth = {'md'}
		            >
		              <DialogTitle id="scroll-dialog-title"> {title}

		              </DialogTitle>
		              <DialogContent>
		               <DialogContentText>
				<div className="clearfix"></div>
				<div>
				{popUpMsg}
				</div>
				<div className="clearfix"></div>
		    	       {
		    		dataFlag === true ?
		    		(
		    		popUpData1 !== undefined ?
		    		<MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
		    		  <MUIDataTable
		    		  data={popUpData1}
		    		  columns={popUpColumns1}
		    		  options={optionsPopUp}
		    		  />
		    		</MuiThemeProvider>
		    		:
		    		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
		    		)
		    		:
		    		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div></div>
		    		}
		                </DialogContentText>

		              </DialogContent>
		              <DialogActions>
		                <Button onClick={this.handlePopUpClose} color="primary">
		                  Ok
		                </Button>
		              </DialogActions>
		            </Dialog>
		          </div>
                <Dialog  fullWidth={true}
                            maxWidth={'md'}
                            open={this.state.open}
                            onClose={this.handleClose}
                            aria-labelledby="form-dialog-title"
                        >
                            <DialogTitle id="form-dialog-title">{popuptitle}</DialogTitle>
                             <DialogContent>
                            <Paper>
                                {popupvalue}
                                <div id="popup">
                                 <ReactTable columns={popupcolumns1}  data={popupdata1} className="table table-striped" />
                                </div>
                                <div className="col-md-2"><a className="btn btn-primary btn-xs" id="ok" onClick={this.handleClose}>OK</a></div>
                                <div className="col-md-2"><Link to={{ pathname: '/DEALENT', state: { flag: 'newtrade', TradeType:this.state.TradeType} }} id="palceanot" className="btn btn-primary btn-xs">Place Another Trade</Link></div>
                            </Paper>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={this.handleClose} id="close" color="primary">
                                Close
                                </Button>

                            </DialogActions>
                            </Dialog>
                        </div>
                    </div>
                </div>
            );
        }
}
function mapStateToProps(state) {
    const { reportdata } = state;
    return { reportdata };
}

const connectedReportCheckboxTemplate = connect(mapStateToProps)(ReportCheckboxTemplate);
export { connectedReportCheckboxTemplate as ReportCheckboxTemplate };