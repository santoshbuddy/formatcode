import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { reportActions } from '../actions/report.actions';
import { connect } from 'react-redux';
import AdmFilters from './AdmFilters';
import Filters from './Filters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import 'react-tabs/style/react-tabs.css';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import DialogTitle from '@material-ui/core/DialogTitle';
import Paper from '@material-ui/core/Paper';
import { Link } from 'react-router-dom';
import Loading from '../../common/Loading'
import MUIDataTable from "mui-datatables";
import Card from "./Card";
import ScrollDialog from "./ScrollDialog";
import PopUpDataTable  from "./PopUpDataTable";
import ScrollDialogPopUp  from "./ScrollDialogPopUp";
 import {muiTableStyles} from '../../styles/muidatatableCss';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { history } from '../../_helpers';
import Checkbox from '@material-ui/core/Checkbox';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import TableLoader from '../../common/TableLoader';
import { alertConstants } from '../../common/constants/alert.constants';
import axios from 'axios';
 import DrillDown from './DrillDown.js';
import DialogContentText from "@material-ui/core/DialogContentText";
import { Typography } from '@material-ui/core';
import { showConfirm, showAlert } from '../../common/components/showConfirmLayer';

import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import CustomPagination from './CustomPagination';
import Formatter from '../../formats/Formatters';

let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

 function arrayRemove(arr, value) {

	   return arr.filter(function(ele){
	       return ele != value;
	   });

}

 Object.assign(ReactTableDefaults, {
		showPagination: false,
    defaultPageSize: 5,
    minRows: 1
  });
  let buttonFlag=true;
  let pageName='';
  let filterFlag=true;
  let msg="";
  let messageTxt = 'empty';
  let fromDate,toDate;
  var data1 = [] //this.props[3].DATA;
  var popupdata2=[];
  var popUpVData,fileds,title;
  let dataFlag=false;
  let popUpVColumns1;
    let popUpVData1;
  let optionsVPopUp;
  var HiddenFields = [];
 let fillObjLocal=[];
class ReportTemplate extends React.Component {
    getMuiTheme = () =>
        createMuiTheme({
          overrides: {
            MUIDataTableHeadCell: {
              root: {
                background: '#eaeaea !important',
                color: '#0066b2 !important',
                textTransform: 'uppercase',
                whiteSpace: 'nowrap',
                fontWeight:'bold',
                borderRight: '1px solid #b3b3b3 !important',
                borderTop: '1px solid #b3b3b3',
                borderBottom: '1px solid #b3b3b3',
                '&:first-child':{
                  borderLeft: '1px solid #b3b3b3'
                },
                '&:last-child':{
                  paddingRight: '4px'
                }
              }
            },
            MUIDataTableBodyRow: {
              root: {
                '&:nth-child(odd)': {
                  backgroundColor: '#f7f8f9'
                }
              }
             },
             MuiTableCell: {
               root: {
                whiteSpace: 'nowrap',
                padding: '7px 5px',
                borderRight: '1px solid #f3ebeb',
                borderTop: '1px solid #c3c3c3',
                borderBottom: '1px solid #f3ebeb',
                '&:last-child':{
                  borderRight:'0px'
                },
                '&:first-child':{
                  borderLeft: '1px solid #f3ebeb'
                }
               }
             },
             MuiTableRow: {
               root:{
                 height:'auto'
               },
               head: {
                 height:'auto',
               }
             },
            }
          });


    constructor(){
        super();
        	this.state={
		flag:true,
		selectAll:false,
		selected:[],
		emailOpen: false,
		open: false,
		TradeType:'',
		message:'',
		resData:[],
		emailid:'',
		recordcount:'',
		openView:false,
		scroll: "paper"
        }
        this.coldata=[];
        this.doChange = this.doChange.bind(this);
        this.doAdmChange = this.doAdmChange.bind(this);
        this.routeChange = this.routeChange.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.fundNameClick = this.fundNameClick.bind(this);
        this.doCheck = this.doCheck.bind(this);
        // this.doEmail = this.doEmail.bind(this);
        this.doFututeDealCancel = this.doFututeDealCancel.bind(this);
        this.doApprove = this.doApprove.bind(this);
        this.doFutureSubmit = this.doFutureSubmit.bind(this);
        this.doReject = this.doReject.bind(this);
        this.doEdit = this.doEdit.bind(this);
        this.doPilotEdit = this.doPilotEdit.bind(this);
        this.doDelete = this.doDelete.bind(this);
        this.doViewChange = this.doViewChange.bind(this);
        this.doActApprove = this.doActApprove.bind(this);

	 }

 doCheck(){
         var openAcct1 = '';
        const selectAll =this.state.selectAll === true ?false:true;
	if(selectAll){
	    this.setState({ selectAll:selectAll})
	    openAcct1 = "on";
	}else {
	    this.setState({ selectAll:selectAll})
        }

        console.log(selectAll);

        var jsonBody = new FormData();
	var user = JSON.parse(sessionStorage.getItem('user'));
	jsonBody.append("fromDate",fromDate);
	jsonBody.append("toDate",toDate);
	jsonBody.append("clientFirm",sessionStorage.getItem('clientFirm'));
	jsonBody.append("token",user[0].token);
	jsonBody.append("openAcct",openAcct1);
	this.props.dispatch(reportActions.fetchReportData(jsonBody));
    }

     componentDidMount() {
        console.log("Report Template componentDidMount");
        pageName=this.props.location.pathname;
        this.coldata=[];
        filterFlag=true;
        this.getFilter();
   }
   componentDidUpdate(){
	console.log("Report Template componentDidUpdate::");
    // alert("componentDidUpdate")
      console.log("page name",pageName)
      console.log("this.props.location.pathname",this.props.location.pathname)
      if(pageName.length!==0 && pageName!==this.props.location.pathname)
       {
	filterFlag=true;
        pageName=this.props.location.pathname;
        console.log("Report Template componentDidUpdate",pageName)
        this.coldata=[];
        this.getFilter()
       }
       else
       pageName=this.props.location.pathname;
   }
   	fundNameClick(rowDatax, screenLink)
   	{
		if(screenLink == 'CLFBHREP')
		{
			history.push({
				pathname: '/report/CLFBHREPD',
				state: {
					issueChild: rowDatax[7],
					catId: 'CFBHREPO',
					selClient: 'All',
					prodName: rowDatax[0],
					currency: rowDatax[3],
					chkStatus: 'ALL',
					acctnature: 'All',
					selectedAcct: '',
				}
			});
    }
		else
		{
			history.push({
				pathname: '/administration/REVIEWPROS',
				state: {
					tabIndex: 1,
					activeStep: 0,
					fromWhere:this.props.location.pathname,
					product: rowDatax[14],
					productname: rowDatax[0],
					currency: rowDatax[2],
					fundTypeId: rowDatax[13],
					fundFamilyId: rowDatax[14]
				}
			});
		}
  }
doFututeDealCancel(rowData){

	if(confirm('Are you sure, you want to delete this trade?')){
		//console.log('tableData<<<<<<>>>>'+JSON.stringify(rowData))
		var bodyFormData = new FormData();
			var user = JSON.parse(sessionStorage.getItem('user'));

				bodyFormData.append("token",user[0].token);
				bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
					bodyFormData.append("transId",rowData[0]);
					bodyFormData.append("webreference",rowData[2]);
					bodyFormData.append("trdStatus",rowData[1]);
					bodyFormData.append("statuss",rowData[25]);
					bodyFormData.append("reason",rowData[22]);
				    bodyFormData.append("actionFlag","CANCEL");
				    this.props.dispatch(reportActions.fetchReportData(bodyFormData));

	}
}
doFutureSubmit(e,transId){

	if(!this.state.selected.includes(transId)){
		this.state.selected.push(transId);

 	}else {
		let	selection=arrayRemove(this.state.selected,transId);
 		this.setState({selected:selection});
	}

 }
doApprove(){


	var tempFlag = false;
		var showFlag = true;
		var addstr = "";
		var chkFlag = false;
	 	var checkFlag = false;
	 	var fnavflag = "";

 	var size =  this.state.selected.length;

 	var rejultData = this.props.reportdata.reportdata.find(item =>item.name==="DATA")

 	 this.state.selected && this.state.selected.map((selitem,index) => {
		 	console.log('selitem[2]>>>>'+JSON.stringify(selitem));
		 		console.log('rejultData>>>>'+JSON.stringify(rejultData));
						 	let rowData = rejultData.DATA.find(item =>item[2]===selitem)
						 	console.log('doApprove>>>>'+JSON.stringify(rowData));
							 if((rowData[27] === "F" ||
							 rowData[27] === "V") &&
							 rowData[31] == "10"){
										fnavflag = "true";
										checkFlag = true;
							 }
					});

		if(!checkFlag){
			showAlert(this,message["CHECKATLONE"]);
				// alert(message["CHECKATLONE"]);
 		return;
 		}

	this.state.selected && this.state.selected.map((selitem,index) => {
		let rowData = rejultData.DATA.find(item =>item[2]===selitem)
					if(rowData[29].value=="false"){
							if(chkFlag) {
								addstr += "," +rowData[2];
								tempFlag = true;
							} else {
								addstr += rowData[2];
								chkFlag = true
								tempFlag = true;
							}
					}

	});

	if(tempFlag) {
		showAlert(this,message["CURRGATEIMP1"]+" ["+addstr+"] "+message["CURRGATEIMP2"]);
		// alert(message["CURRGATEIMP1"]+" ["+addstr+"] "+message["CURRGATEIMP2"]);
			return;
	}


		this.state.selected && this.state.selected.map((selitem,index) => {
				let rowData = rejultData.DATA.find(item =>item[2]===selitem)
							if(rowData[28]!== null) {
									if(rowData[28] === "Y") {
										if(chkFlag) {
											addstr += "," +rowData[2];
											tempFlag = true;
										} else {
											addstr += rowData[2];
											chkFlag = true
											tempFlag = true;
										}
									}
							}

	});


	if(tempFlag) {
			if(confirm('The Trade '+"["+addstr+"]"+' being approved is allowed investment policy override. Do you want to Approve the trade?'))
				showFlag = true;
			else {
				showFlag = false;
			}
	}

 if(showFlag == true){
 		if(fnavflag == "true")
 			showAlert(this,message["NAVDELMSG"]);
 			// alert(message["NAVDELMSG"]);
 		if(confirm('Are you sure, you want to approve the data?')) {

 				 var bodyFormData = new FormData();
  				var user = JSON.parse(sessionStorage.getItem('user'));


  					    bodyFormData.append("token",user[0].token);
  					    bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
  					    bodyFormData.append("totsize",this.state.selected.length);

  					    this.state.selected && this.state.selected.map((selitem,index) => {
  					 	let rowData = rejultData.DATA.find(item =>item[2]===selitem)
  						bodyFormData.append("Apprchk"+index,'Y');
  						if(rowData[0] !== 'Y')
						 bodyFormData.append("seltransid"+index,rowData[0]);
						else bodyFormData.append("seltransid"+index,"");
  						bodyFormData.append("selwebreferenceid"+index,rowData[2]);
  						bodyFormData.append("tickteStatus"+index,rowData[1]);
  						bodyFormData.append("dealAggregation"+index,rowData[25]);
  						bodyFormData.append("selgroupid"+index,rowData[30]);
  					});
  					    bodyFormData.append("actionFlag","APPROVE");
					    this.props.dispatch(reportActions.fetchReportData(bodyFormData));
 	}
}


}

doReject(){

	if(!this.state.selected){
		showAlert(this,message["CHECKATLONE"]);
			// alert('Please select at least one trade transaction.');
			return;
	}

	if(confirm("Are you sure, you want to reject these data?")){
 	var rejultData = this.props.reportdata.reportdata.find(item =>item.name==="DATA")

		var bodyFormData = new FormData();
			var user = JSON.parse(sessionStorage.getItem('user'));


				    bodyFormData.append("token",user[0].token);
				    bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
				      bodyFormData.append("totsize",this.state.selected.length);

				    this.state.selected && this.state.selected.map((selitem,index) => {
				 	let rowData = rejultData.DATA.find(item =>item[2]===selitem)
					bodyFormData.append("Apprchk"+index,'Y');
					if(rowData[0] !== 'Y')
					bodyFormData.append("seltransid"+index,rowData[0]);
					else bodyFormData.append("seltransid"+index,"");
					bodyFormData.append("selwebreferenceid"+index,rowData[2]);
					bodyFormData.append("tickteStatus"+index,rowData[1]);
					bodyFormData.append("dealAggregation"+index,rowData[25]);
					bodyFormData.append("selgroupid"+index,rowData[30]);
				});
				    bodyFormData.append("actionFlag","REJECT");
				    this.props.dispatch(reportActions.fetchReportData(bodyFormData));

	}
}


  // doEmail(){
	// 	var newdata1 = this.props.reportdata.reportdata.find(item =>item.name==="newTradeData")
	// 	var bodyFormData = new FormData();
	// 	var data;
	// 	var user = JSON.parse(sessionStorage.getItem('user'));

	// 	bodyFormData.append("token",user[0].token)
	// 	bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
	// 	bodyFormData.append("fileName",'TABLEDATA.pdf')
	// 	bodyFormData.append("reportName",'SUCCESS_TRADESTATUS')
	// 	bodyFormData.append("count",newdata1.values.length)
	// 	axios({
	// 		method: 'POST',
	// 		url:alertConstants.URL+"/EXCELEMAILPopUp.do",
	// 		data: bodyFormData,
	// 		config: { headers: {'Content-Type': 'application/x-www-form-urlencoded' }}
	// 	  }).then((response)=>{
	// 	    popupdata2 = response.data;
	// 	    this.setState({recordcount:popupdata2[0].recordcount});
	// 	    this.setState({emailid:popupdata2[0].emailid});

	// 	    let xml = new DOMParser().parseFromString(response.data.msg, 'application/xml');
	// 		var emailFlag = "";
	// 		var emailid = "";
	// 		var recordcount = "";
	// 	});

	// 	this.handleClose();
	// 	this.state.emailOpen = true;
  // }

//    doCreate(){
//      //alert("clicked created button");
//    }
//    doTradeAllo(){
//    }
//    doSelectAll(){
//    }
//    doUnSelectAll(){
//    }
//    doShowTradeDetailsPopUp(){
//    }
   getFilter(){
    // console.log("Report Template getFilter")

    var bodyFormData = new FormData();

    if(this.props.location.state != undefined && this.props.location.state.fromPage != undefined && this.props.location.state.fromPage == 'ViewChanges') {
      bodyFormData.append("product",this.props.location.state.product);
      bodyFormData.append("issueChild",this.props.location.state.issueChild);
      bodyFormData.append("from", 'INVPOLICY');
      bodyFormData.append("productName",this.props.location.state.productName);
      bodyFormData.append("currencyCode",this.props.location.state.currencyCode);
      bodyFormData.append("clientFirmName",this.props.location.state.clientFirmName);
    }
    else if(this.props.location.state != undefined && this.props.location.state.from == 'INVPOLICY'){
	 	bodyFormData.append("clientFirmName",this.props.location.state.clientFirmName);
	 	bodyFormData.append("productName",this.props.location.state.productName);
//	  	bodyFormData.append("prodId",this.props.location.state.prodId);
	  	bodyFormData.append("currencyCode",this.props.location.state.currencyCode);
 	  	bodyFormData.append("fromDate",this.props.location.state.fromDate);
	  	// bodyFormData.append("product",this.props.location.state.product);
//	  	bodyFormData.append("product","All");
 //	  	bodyFormData.append("issueChild",this.props.location.state.issueChild);
      	bodyFormData.append("from",this.props.location.state.from);
	}
    bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
    bodyFormData.append("reactJSActionFlag","")
    // if(this.props.reportdata.reportdata === undefined ){
	if(pageName === "/report/DESETST"){
		if(fillObjLocal!=undefined && fillObjLocal.length>0)
		{
			let obj=fillObjLocal.find(e=>e.id === "companyCategory") && fillObjLocal.find(e=>e.id === "companyCategory")
			if(obj!= undefined){
			  bodyFormData.append("companyCategory",obj.value);
			}
		}
	}
        //alert("may 03 in getFilter :fillObjLocal:"+fillObjLocal);
    this.props.dispatch(reportActions.fetchReportData(bodyFormData));
    // }
   }

doAdmChange(bodyFormData,fromPage,fillObj){
	//alert("may 03 in doAdmChange :fillObjLocal:"+fillObjLocal);
        //console.log("may 03, 2019 ::fillObj:::",fillObj);
         this.setState({ resData: [] });
         this.setState({ message: '' });
 	 msg = "";
        fillObjLocal=fillObj;
        //alert("fromPage::"+fromPage);
        if(pageName === "/report/FUDTDRAC"){
	   			  filterFlag=true;
	   		}else {
	          	 filterFlag=false;
		}
	if(fromPage === "companyCategory")
	{
	  this.props.dispatch(reportActions.fetchReportData(bodyFormData));
	}
	else if(pageName === "/report/DESETST")
	{
		var companyCategory;

		if(document.getElementById("companyCategory")!=null){
		  companyCategory=document.getElementById("companyCategory").value;
		}
		//alert("clicked new method::"+companyCategory);
		this.props.history.push({
		pathname: '/DESETST',
			state: {
				companyCategory:companyCategory,
				fromPage:'New',
			}
		});
	}else{
          this.props.dispatch(reportActions.fetchReportData(bodyFormData));
       }
   }
   doChange(bodyFormData){
        //bodyFormData.append("reactJSActionFlag","GO")
        //var bodyFormData = new FormData();
        //for (name in fillObj) {
            //bodyFormData.append(name, fillObj[name]);
        //}
        //alert(bodyFormData.get("clientFirm"));
        if(pageName === "/report/FUDTDRAC" || pageName === "/report/ACCTINQU"){
	   			  filterFlag=true;
	   		}else {
	          	 filterFlag=false;
		}
        this.props.dispatch(reportActions.fetchReportData(bodyFormData));
   }
   routeChange(){
        let path = '/admincreate/CREATEACCT';
        this.props.history.push(path);
    }

	checkClick(cData, paramVal) {
		if(paramVal == 'TRADEENTRY' || paramVal == 'CLOSEACCOUNT') {
			history.push({
				pathname: '/DEALENT',
				state: {
					tabIndex: 1,
					activeStep: 1,
					paramVal: paramVal,
					fromPage:'ViewChanges',
					bformdata: cData
				}
			});
		} else if(paramVal == 'TRADEHISTORY') {
			history.push({
				pathname: '/report/TRDINQR',
				state: {
					fromPage:'ViewChanges',
					product: 'ALL',
					issueChild: 'ALL',
					productName: cData.subprodname==undefined?"":cData.subprodname,
					clientFirmName: cData.clientName==undefined?"":cData.clientName,
					currencyCode: cData.currency==undefined?"":cData.currency
				}
			});
		} else if(paramVal == 'EDITACCOUNT') {
			history.push({
				pathname: '/administration/MMFEDITACCT',
				state: {
					fromPage:'ViewChanges',
					mmmfAcct: cData.escrowacctnbr,
					clientFirm: cData.clientFirm,
					product: cData.subprodname,
					currency: cData.currency,
				}
			});
		}
	}

    handleClose () {
        this.setState({flag:false})
        this.setState({ open: false });
      }
      handlePopUpClose = () => {
            this.setState({ emailOpen: false });
  };

  handleViewClose = () => {
       this.setState({ openView: false });
  };

  doPilotEdit(cData) {
	this.props.history.push({
		pathname: '/report/PILOSTP',
		state: {
			clientFirm:cData[10],
			customerName:cData[4],
			businessEntity:cData[8],
			company:cData[17],
			businessInvestEntity:cData[9],
			csId:cData[3],
			isPopup: "EDIT",
		}
	});

  }

	doEdit(cData){
	if(window.confirm("Are you sure, you want to Edit a company?")){
	    // console.log("apr 24, 2019 :::edit block  cData::",cData);
	   //alert("companyname ::"+cData[1]);
	   this.props.history.push({
	      pathname: '/DESETST',
		state: {
			companyCategory:cData[9],
			company: cData[0],
			companyCategoryTxt:cData[13],
			fromPage:'Edit',
		}
	    });

	}
	}


		doActApprove(cData,actionFlag){
 		console.log("apr 25, 2019 ::cData::",cData);
		var bodyFormData=new FormData();
		var user = JSON.parse(sessionStorage.getItem('user'));
		bodyFormData.append("token",user[0].token);
		bodyFormData.append("saveFlag", actionFlag);

		bodyFormData.append("processId", cData[13]);
		bodyFormData.append("companyId", cData[10]);
		HiddenFields && HiddenFields.map((item,index)=>{
			if(item.value === undefined) item.value='';
		  	bodyFormData.append(item.name, item.value);
		});
			let msg='Are you sure, you want to approve the data?'
			if(actionFlag === 'REJECT')
			msg='Are you sure, you want to reject the data?'
     	     if(confirm(msg))
     	     {
     	     var url;
     	     url=alertConstants.URL+"/PILOSTP.do";

		axios({
		     method: 'post',
		     url:url,
		     data: bodyFormData,
		     config: { headers: {'Content-Type': 'multipart/form-data' }}
		   }).then((res)=>{
		   dataFlag=true;
		   //console.log("apr 25, 2019  res.data--res.data--",res.data)
		   this.getFilter();
		   this.setState({ resData: res.data });
		});
	    }
	}
	doDelete(cData){
 		console.log("apr 25, 2019 ::cData::",cData);
		var bodyFormData=new FormData();
		var user = JSON.parse(sessionStorage.getItem('user'));
		bodyFormData.append("token",user[0].token);
		bodyFormData.append("actionFlag", "DELETE");
		bodyFormData.append("companyCategory", cData[9]);
		bodyFormData.append("companyCategoryTxt", cData[13]);
		bodyFormData.append("company", cData[0]);
		bodyFormData.append("tradingDeskId", cData[0]);
		bodyFormData.append("companyId", cData[0]);
		bodyFormData.append("routingNumber", cData[2]);
		bodyFormData.append("taxIdTxt", cData[3]);
		bodyFormData.append("address1", cData[4]);
		bodyFormData.append("cityTxt", cData[5]);
		bodyFormData.append("firstTxt", cData[6]);
		bodyFormData.append("phoneTxt", cData[7]);
		bodyFormData.append("mailTxt", cData[8]);
		bodyFormData.append("selectedCompanyId", cData[0]);
		if(cData[11] !== undefined)
		bodyFormData.append("taxPayerTypeTxt", cData[11]);
		if(cData[12] !== undefined)
		bodyFormData.append("taxStatusCodeTxt", cData[12]);
		HiddenFields && HiddenFields.map((item,index)=>{
			if(item.value === undefined) item.value='';
		  	bodyFormData.append(item.name, item.value);
		});

     	     if(confirm(message["DELTECOMP"]))
     	     {
     	     var url;
     	     url=alertConstants.URL+"/DESKNEWSAVE.do";

		axios({
		     method: 'post',
		     url:url,
		     data: bodyFormData,
		     config: { headers: {'Content-Type': 'multipart/form-data' }}
		   }).then((res)=>{
		   dataFlag=true;
		   //console.log("apr 25, 2019  res.data--res.data--",res.data)
		   this.getFilter();
		   this.setState({ resData: res.data });
		});
	    }
	}

	doViewChange(scroll,cData){
	     //console.log("apr 24, 2019 cData::",cData);
	     var bodyFormData=new FormData();
	     var user = JSON.parse(sessionStorage.getItem('user'));
	     bodyFormData.append("token",user[0].token);
	     bodyFormData.append("companyCategory", cData[9]);
	     bodyFormData.append("selectedCompanyCatId", cData[9]);
	     bodyFormData.append("company", cData[0]);
	     bodyFormData.append("tradingDeskId", cData[0]);
	     bodyFormData.append("companyId", cData[0]);
	     bodyFormData.append("selectedCompanyName", cData[1]);
	     //alert("companyname ::"+cData[1]);
     	     var url;
     	     url=alertConstants.URL+"/printMcDeskEntityPopUp.do";

     		axios({
     	             method: 'post',
     	             url:url,
     	             data: bodyFormData,
     	             config: { headers: {'Content-Type': 'multipart/form-data' }}
     	           }).then((response)=>{
     	             popUpVData = response.data;
     	             dataFlag=true;
		     this.setState({ openView: true, scroll });
            });
	};
    render() {
    	     //console.log("may 03, 2019 ::fillObjLocal::",fillObjLocal);
            let DDAAccount,AccountName,opened,CurrentBal,CurrencyCode,AsOf,CurrDet,AsDatOf;
            var newdata ;
            var popuptitle,popupvalue;
            const { reportdata } = this.props;
            var columns1 = [] //this.props[3].COLUMNS;
            var reportdataLoc=[];
            fromDate = '';
            toDate	= '';
            var data,columns,screenName,fullName,ssoId,appRefCode,todaysdate,results1=[],paginationFlag=true,checkboxFlag=false;
            console.log(" this.props.reportdata--->", this.props.reportdata.reportdata)
//            console.log(" this.props.reportdata[3]--->", this.props.reportdata.reportdata[3])

            reportdataLoc = this.props.reportdata.reportdata;
            if(reportdataLoc!==undefined)
            results1  = Array.from(reportdataLoc);

		let approveBtn=<a title="Approve" onClick={(e)=>{this.doApprove();}} className="btn btn-primary btn-xs" style={{marginTop:'10px'}}>Approve</a>
		let rejectBtn=<a title="Reject" onClick={(e)=>{this.doReject();}} className="btn btn-primary btn-xs" style={{marginTop:'10px'}}>Reject</a>

         if(this.props.reportdata.reportdata !== undefined){
                if(this.props.reportdata.reportdata.length>0){
                    newdata="";
                    newdata = this.props.reportdata.reportdata.find(item =>item.name==="newTradeData")
                     console.log("newdata::",newdata)
                      if(newdata !== undefined && newdata.length!==0)
                     {
                        //console.log("insode newdata::",newdata)
                        popuptitle = newdata.label;
                        popupvalue = newdata.value;
                    }else
                    this.state.open=false;
            }
        }
        else{
            return(
                <Loading />
            )
        }

    //console.log("popupcolumns1::",popupcolumns1);
    //console.log("popupdata1::",popupdata1);
    //console.log("result1 " , results1);
    let screenLinkImage;
    let approveFlag ='false';

    if(this.props.location.pathname!== undefined && this.props.location.pathname.length!==0){
         let pos=this.props.location.pathname.lastIndexOf('/');
         //console.log("position value::",pos);
         screenLinkImage=this.props.location.pathname;
         screenLinkImage=screenLinkImage.substring(pos+1,screenLinkImage.length)
         //alert("screenLinkImage::"+screenLinkImage)
         //console.log("screenLinkImage value::",screenLinkImage);
    }
    if( results1 !== undefined && results1.toString().trim().length!==0)
		{
			 results1.map((item,index) => {
			    if(item.type === "Title"){
				   screenName = item.name
				}
				if(item.name === "HiddenFields"){
				  HiddenFields = item.value;
				}
			    if(item.type === "Fullname"){
			          fullName = item.name
			    }

			    if(item.type === "SSOId"){
			    	ssoId = item.name
			    }

			    if(item.type === "ApplicationID"){
			    	appRefCode = item.name
			    }


				if(item.type === "approveFlag"){
				if(item.name === "approveFlag"){
				approveFlag=item.value;
				}
				}
				if(item.type === "TodaysDate"){
			       todaysdate = item.value
			    }
			    if(item.type === "Message")
                    		messageTxt = item.name

			    if(item.paginationFlag === "false"){
			          paginationFlag = false;
			    }
			if(item.type === "datepicker"){
			   if(item.name === "fromDate"){
			     fromDate=item.value;
			   }
			   if(item.name === "toDate"){
			        toDate=item.value;
			   }
			}

		      if(screenName === "Client list report"){

			if(item.type === "subTitle1"){
				   if(item.name === "DDA Account Number:"){
				     DDAAccount=item.label;
				    }
			}
			if(item.type === "subTitle2"){
				   if(item.name === "Account Name:"){
				     AccountName=item.label;
				    }
			}
			if(item.type === "subTitle3"){
				   if(item.name === "Opened:"){
				     opened=item.label;
				    }
			}
			if(item.type === "subTitle4"){
				   if(item.name === "Current Balance:"){
				     CurrentBal=item.label;
				    }
			}
			if(item.type === "subTitle5"){
				   if(item.name === "CURRENCYCODE:"){
				     CurrencyCode=item.label;
				    }
			}

			if(item.type === "subTitle6"){
				   if(item.name === "As of"){
				     AsOf=item.label;
				  //    AsOf = "DDA Account Number:"+DDAAccount+" - "+"Account Name:"+AccountName+" - "+"Opened:"+opened+" - "+"Current Balance:"+CurrentBal+" "+CurrencyCode+" "+"As of"+" "+AsOf;

				      AsDatOf = "DDA Account Number:"+DDAAccount+" - "+"Account Name:"+AccountName+" - "+"Opened:"+opened;
 				     CurrDet="Current Balance:"+CurrentBal+" "+CurrencyCode+" "+"As of"+" "+AsOf;
				    }
			}
 		      }
		})

		console.log('approveFlag >sss>>>'+approveFlag);
		var mainList=results1.find(item =>item.name ==="columns")// === listName)
		if(mainList!==undefined && mainList.COLUMNS!==undefined)
 	     	 columns1 = mainList.COLUMNS;

	     	mainList=results1.find(item =>item.name ==="DATA")// === listName)
	     	if(mainList!==undefined && mainList.DATA!==undefined)
          		data1 = mainList.DATA;


         columns1 && columns1.map((item,index)=>{

	//  console.log("::may 01, 2019 ::name::"+item.name+",pagename::"+pageName);
	 if(item.name === "Instruction Date"){
		item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
			return (
				   <Formatter date={value}/>
			);
		  }
	 }
	 if(item.name === "Amount"){
		item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
			return (
				   <Formatter currency={value}/>
			);
		  }
	 }
	if(item.name === "Currency Code" && pageName === "/report/CLPRFREP"){
	      item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
			  return (
	    		     <label className='bold'>{value}</label>
			  );
		    }
	}else if(item.name==="Actions" && pageName === "/report/DESETST"){
	      item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
			  return (
				<div>
				<button className="btn btn-xs btn-primary" onClick={this.doEdit.bind(this,tableMeta.rowData)}> Edit</button>
				<button className="btn btn-xs btn-primary" onClick={this.doDelete.bind(this,tableMeta.rowData)}> Delete</button>
				<button className="btn btn-xs btn-primary" onClick={this.doViewChange.bind(this,"paper",tableMeta.rowData)}> View Changes</button>
				</div>
			  );
		    }

	}else if(item.name==="Tax ID" && pageName === "/report/DESETST"){

				if(HiddenFields !== undefined && HiddenFields.find(e=>e.name === "selectedCompanyCatId")
				&& HiddenFields.find(e=>e.name === "selectedCompanyCatId").value   === '400')
				item.options["display"] =  false;

 	}
    else if(item.name==="Cancel" && pageName === "/report/FUDTDRAC"){

             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {

				if(value === 'P'){
 					  return (
						<button onClick={(e)=>{this.doFututeDealCancel(tableMeta.rowData);}}
						  className="btn btn-primary btn-xs mt pull-center">Cancel</button>
					  );
		 		 }else if((value === 'C' || value === 'W' )&&  tableMeta.rowData[0] === 'Y'){

  					  return (
						<div><Checkbox value={tableMeta.rowData[2]} onChange={(e)=>{this.doFutureSubmit(e,tableMeta.rowData[2]);}} /></div>
					  );
		 		 }else {
					  return (<div> </div>);
				 }
            }
	  }
	  else if(item.name==="Types" && pageName === "/report/FUDTDRAC"){

             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
  				  return (<div> </div>);
            }
	  }else if(item.options.hyperlink === "true" && pageName === "/report/ACCTINQU")
      {
			item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
				return (
					<AccountInqiryPopup onClick={e => this.openPopUp(e, tableMeta)} rowData={tableMeta} linkName={value} screenLinkImage={screenLinkImage} fromDate={fromDate} func ={this.checkClick } toDate={toDate} />
				);
			}
	   }else if(item.name==="Status" && pageName === "/report/ACCTINQU"){
	      item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
			  		if(tableMeta.rowData[12] !== undefined && tableMeta.rowData[12] === 'P'){
			  						value='Pending'
					}else  if(tableMeta.rowData[12] !== undefined && tableMeta.rowData[12] === 'R'){
			  						value='Rejected'
					}if(tableMeta.rowData[12] !== undefined && tableMeta.rowData[12] === 'Y'){
			  						value='Approved'
					}
					return (<div>{value} </div>);
		  }

		}else if(item.name==="Action" && pageName === "/report/ACCTINQU"){
	      item.options["customBodyRender"] = (value, tableMeta, updateValue) => {


			  if( HiddenFields !== undefined && HiddenFields[0].checkerLogin   === 'true' 	 &&
				tableMeta.rowData[16] !== undefined && tableMeta.rowData[16] === 'P'){
					item.name ='Action'
					  return (
						<div>
						<button className="btn btn-xs btn-primary" onClick={this.doActApprove.bind(this,tableMeta.rowData,'APPROVE')}> Approve</button>
						<button className="btn btn-xs btn-primary" onClick={this.doActApprove.bind(this,tableMeta.rowData,'REJECT')}> Reject</button>
						</div>
					  );
		  		}else  if( HiddenFields !== undefined && HiddenFields[0].checkerLogin   !== 'true') {
					if(HiddenFields !== undefined && HiddenFields[0].makerLogin   === 'true'
					&& tableMeta.rowData[16] !== undefined &&  tableMeta.rowData[16] === 'R'){
						return (<div>
						<button className="btn btn-xs btn-primary" onClick={this.doActApprove.bind(this,tableMeta.rowData,'REVOKE')}> Revoke</button>
						</div>);

				}else if(HiddenFields !== undefined && HiddenFields[0].loginid !== undefined
					&& tableMeta.rowData[15] !== undefined &&  tableMeta.rowData[15] === HiddenFields[0].loginid && tableMeta.rowData[16] === 'P' ){
						return (<div>
						<button className="btn btn-xs btn-primary" onClick={this.doPilotEdit.bind(this,tableMeta.rowData)}> Edit</button>
						</div>);
					}
				}
				return (<div> </div>);


		    }

	}else if(item.options.hyperlink === "true" && (pageName === "/report/ACCPOREP" || pageName === "/report/MMDAACC"))
      {
	     //alert("before ScrollDialogPopUp");
             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
               return (
		          <ScrollDialogPopUp
                  onClick={e => this.openPopUp(e, tableMeta)}
                  rowData={tableMeta}
                  linkName={value}
                  screenLinkImage={screenLinkImage}
                  fromDate={fromDate}
                  func ={this.checkClick }
                  toDate={toDate}
                />
              );
            }
	   }else if(item.options.hyperlink === "true" && pageName === "/report/AUDTRREP"){
			item.options["sort"]=false;
			item.options["searchable"]=false;
 				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
					 return (
					  <PopUpDataTable
						onClick={e => this.openPopUp(e, tableMeta)}
						rowData={tableMeta}
						linkName={value}
						screenLinkImage={screenLinkImage}
						fromDate={fromDate}
						toDate={toDate}
					  />
					);
            }
	   }else if(item.options.hyperlink === "true" && pageName === "/report/FUDTDRAC"){
             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
              return (

                <DealDetails
					onClick={e => this.openPopUp(e, tableMeta)}
					dealVal={value}
					itemName={item.name}
					fromPage={'FUDTDRAC'}
					dealDet={tableMeta.rowData} />
              );
            }
           }
	   else if(item.options.hyperlink === "true"){

             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
              return (
                <ScrollDialog
                  onClick={e => this.openPopUp(e, tableMeta)}
                  rowData={tableMeta}
                  linkName={value}
                  screenLinkImage={screenLinkImage}
                  fromDate={fromDate}
                  func ={this.fundNameClick }
                  toDate={toDate}
                />
              );
            }
		  }
	   else if(item.options.hyperlink === "true" && pageName === "/report/FUNDINFO"){
             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
              return (
                <ScrollDialog
                  onClick={e => this.openPopUp(e, tableMeta)}
                  rowData={tableMeta}
                  linkName={value}
                  screenLinkImage={screenLinkImage}
                  fromDate={fromDate}
                  func ={this.fundNameClick }
                  toDate={toDate}
                />
              );
            }
		  }

         })

		}

    var popuptradedata,dealtype;
    var popupcolumns1=[],popupdata1=[];
    if(this.state.flag && newdata !== undefined){
            newdata.values.map((item,index)=>{
            popuptradedata = item;
            dealtype = item.DealType;
            popupdata1.push(popuptradedata)
        })
   console.log("popuptradedata-->",popuptradedata)
    if(popuptradedata !== undefined){
        var s =  popuptradedata;
        for(var k in s) {
          if(k === "Trans ID"){
            popupcolumns1.push({
              Header: k,
		accessor: k,
		width: 150,
		maxWidth: 300,
		sortable:false,
		filterable:false,
            });
          }else if(k === "Product"){
            popupcolumns1.push({
              Header: k,
		accessor: k,
		width: 255,
		maxWidth: 300,
		sortable:false,
		filterable:false,
            });
          }else if(k === "Portfolio Number"){
            popupcolumns1.push({
              Header: k,
		accessor: k,
		width: 150,
		maxWidth: 300,
		sortable:false,
		filterable:false,
            });
          }else if(k === "Currency"){
            popupcolumns1.push({
              Header: k,
              accessor: k,
		maxWidth: 300,
		sortable:false,
		filterable:false,
            });
          }else if(k === "Amount/Units"){
            popupcolumns1.push({
              Header: k,
              accessor: k,
		maxWidth: 300,
		sortable:false,
		filterable:false,
            });
          }else if(k === "Transaction Type"){
            popupcolumns1.push({
              Header: k,
              accessor: k,
            width: 150,
		maxWidth: 300,
		sortable:false,
		filterable:false,
            });
          }else if(k === "Type"){
            popupcolumns1.push({
              Header: k,
              accessor: k,
			  maxWidth: 300,
		sortable:false,
		filterable:false,
            });
          }else if(k === "Reference ID"){
              popupcolumns1.push({
                Header: k,
		accessor: k,
		width: 150,
		maxWidth: 300,
		sortable:false,
		filterable:false,
                Cell: ({ original }) => {
                 if(dealtype === "CURRENT"){
                    return (
                         <ScrollDialog
                        onClick={e => this.openPopUp(e, original)}
                        rowData={original}
                        linkName={original["Reference ID"]}
                        screenLinkImage={screenLinkImage}
                        samepage={"true"}
                      />
                    );
                 }else{
                    return (
                         <ScrollDialog
                        onClick={e => this.openPopUp(e, original)}
                        rowData={original}
                        linkName={original["Reference ID"]}
                        screenLinkImage={screenLinkImage}
                        samepage={"true"}
                        />
                    );
                 }
                }
            })
            }else{
                this.state.TradeType = s[k]
            }

        }
     //   this.state.open = true;
    }
}
let subBlk;
if(buttonFlag){
if(this.props.reportdata.reportdata !== undefined){
                if(this.props.reportdata.reportdata.length>0){
  console.log("ReportTemplate ::target report filterFlag::"+filterFlag+",pageName:"+pageName);
    if(pageName === "/report/AUDLOORT" || pageName === "/report/DESETST")
    {
      subBlk = <AdmFilters method1={this.doAdmChange} data={this.props.reportdata} filterFlag={filterFlag} fullName={fullName} ssoId={ssoId} appRefCode={appRefCode} pageName={pageName}/>
    }else{
      subBlk = <Filters method={this.doChange} data={this.props.reportdata} filterFlag={filterFlag} pageName={pageName}/>
     }
    }
  }
}else{
    subBlk = <button className="btn btn-xs btn-primary" onClick={this.routeChange} >Create New account</button>
   }


msg = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">{this.state.message}</div>


              const options = {
								filter: pageName === "/report/DESETST"?false:true,
                filterType: "dropdown",
                selectableRows: false,
                responsive: "scroll",
                pagination:paginationFlag,
                rowsPerPage:(paginationFlag===false)?data1.length:10,
                fixedHeader: false,
                 downloadOptions:(screenName !== undefined && screenName !== "")?{filename: screenName+'.csv', separator: ','}:{filename: 'Report.csv', separator: ','},
 				  textLabels: {
									body: {
										noMatch: this.props.reportdata.loading ?<TableLoader />:<div key={'1'} style={{fontSize: 14, textAlign: 'center',}}>Sorry, there is no matching data to display</div>,
									},
            		},
                isRowSelectable: (dataIndex) => {
                  return data1[dataIndex][13] !== "disabled";

								},
								customFooter: (
									count,
									page,
									rowsPerPage,
									changeRowsPerPage,
									changePage
								) => {

									return <CustomPagination
														count={count}
														page={page}
														rowsPerPage={rowsPerPage}
														changeRowsPerPage={changeRowsPerPage}
														// changePage={changePage}
														onChangePage={(_, page) => changePage(page)}
														onChangeRowsPerPage={event => changeRowsPerPage(event.target.value)}
														type={"senario1"}
												/>;
								}
/*,
                expandableRows:true,
                 renderExpandableRow: (rowData, rowMeta) => {
				           const colSpan = rowData.length + 1;
				           return (
				             <TableRow>
				               <TableCell colspan={colSpan}>
				                <DrillDown rowData={data1[rowMeta.dataIndex]}/>
				               </TableCell>
				             </TableRow>

				           );
     			}*/
              };

 		 let user = JSON.parse(sessionStorage.getItem('user'));
		 		console.log('Member CATID >>>'+user[0].memberCatId	);

//console.log("apr 24, 2019 pagename::"+pageName);
let tbody="";

if(dataFlag === true && pageName === "/report/DESETST" && this.state.resData!== undefined && this.state.resData!=='' && this.state.resData.length>0)
{
    this.state.resData.map((item,index) => {
	if(item.type === "Message"){
	  this.state.message = item.name
	}
    })
   if(this.state.message!==undefined && this.state.message!== '')
      msg = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">{this.state.message}</div>
}

if(pageName!== undefined && pageName === "/report/DESETST")
{
 if( popUpVData !== undefined && popUpVData.toString().trim().length!==0)
 {
   var commonPopUpData = [];
   console.log("view changes popup  popUpVData::",popUpVData);

	var popUpList=popUpVData.find(item =>item.name ==="commonData")// === listName)

	if(popUpList!==undefined && popUpList.commonData!==undefined)
	  commonPopUpData = popUpList.commonData;
 	  title=commonPopUpData.screenName;

	var popUpList=popUpVData.find(item =>item.name ==="columns")// === listName)
	popUpVColumns1 = popUpList.COLUMNS;

	popUpList=popUpVData.find(item =>item.name ==="DATA")// === listName)
	popUpVData1 = popUpList.DATA;

	optionsVPopUp = {
		pagination: true,
        	selectableRows: false,
        	rowsPerPage: 10,
		responsive: "scroll",
		fixedHeader: true,
	   downloadOptions:(title !== undefined && title !== "")?{filename: title+'.csv', separator: ','}:{filename: 'Report.csv', separator: ','},
 		filter:true,
		search:true,
		print:true,
		download:true,
	};
	if(commonPopUpData !== undefined && commonPopUpData.length !== 0 )
	{
	tbody = <table className="table table-striped table-bordered" width="100%">
		<tbody>
		   <tr>
			<td>
			  <label> Company Category  : </label>
			  <label className="TxtNrml"> {commonPopUpData['Company Category']} </label>
			</td>
			<td>
			  <label> Trading Desk  : </label>
			  <label className="TxtNrml"> {commonPopUpData['Trading Desk']} </label>
			</td>
	    	</tr>
	  </tbody>
	</table>
	}
    console.log("view changes popup  field values::",commonPopUpData);
    }
  }

            return (
                <div>

                    <NavBar/>
			<div className="clearfix"></div>
                    <div className="mainContent">
			<div>
			<Typography variant="h5" component="h3" className="screenTitle">{screenName}</Typography>
			</div>
			<div className="clearfix"></div>
			{AsOf !== undefined ? <table style={{width:'98%',align:'center'}}><tr><td><div style={{fontSize:'13px' ,textAlign:'left'}}>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{AsDatOf}</div></td><td><div style={{fontSize:'13px' ,textAlign:'right'}}>{CurrDet}</div></td></tr></table>:''}

			<br/>
			<div className="filter_div" id="filter_div" >
			    {subBlk}
			    { subBlk !== undefined &&
			     <br/>
			    }
			{
				this.props.location.pathname === "/report/FNAVREPC" &&
				<div><Checkbox defaultChecked={false}  checked={this.state.selectAll?true:false} name="openAcct" ref="openAcct" onChange={this.doCheck}/>Only show funds with opened account</div>
			}

			{
							this.props.location.pathname === "/report/FUNDINFO" &&
							<div><Checkbox defaultChecked={false}  checked={this.state.selectAll?true:false} name="openAcct" ref="openAcct" onChange={this.doCheck}/>Only show funds with opened account</div>
			}

			{
							this.props.location.pathname === "/report/FNAVFDST" &&
							<div><Checkbox defaultChecked={false}  checked={this.state.selectAll?true:false} name="openAcct" ref="openAcct" onChange={this.doCheck}/>Only show funds with opened account</div>
			}

			</div>
			<div className="clearfix"></div>
			<div>
			  {msg}
			</div>
			<div className="clearfix" style={{marginBottom:'10px'}}>
			{(this.props.location.pathname === "/report/FUDTDRAC" && data1 != undefined && data1.length > 0)
 				&&<div>
			<div style={{float:'left', marginLeft:'20px'}}><img src={require('../../images/icon_instruction.gif')}/> <b>Click on the 'Cancel' button to cancel the Trade</b></div>
			<div style={{float:'right', marginRight:'20px'}}><b>Today's Date/Time:{todaysdate}</b></div></div>}
			</div>
                        <div>
                        {
                          data1 !== undefined ?
                        <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                            <MUIDataTable
                            data={data1}
                            columns={columns1}
                            options={options}
                            />
                        </MuiThemeProvider>
                        :
                        <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
                      }
 				{(this.props.location.pathname === "/report/FUDTDRAC" && data1 != undefined && data1.length > 0)
 				&&<div style={{textAlign:'center'}}>

 				<div className="ltGrayBg" style={{backgroundColor:'#e6e6ff',marginTop:'10px'}}>
				 	<table style={{width:'100%', border:"0",  valign:"bottom", cellspacing:'0', cellpadding:'0'}}>
					<tr height='25'>
						<td className="lgndBldTxt" style={{width:"6%",textAlign:'left'}}>&nbsp;&nbsp;<b>Legend:</b></td>

						<td className="lgndBldTxt" style={{width:'10%', textAlign:'left'}}><b>Deal Status:</b></td>

						<td className="lgndBldTxt" style={{width:'10%', textAlign:'left'}}><b>WC:</b>Confirmed(Pending Cash Receipt) <b>WA:</b>Waiting for Ack  <b>M:</b>Matured</td>

					</tr>
					<tr>
						<td>&nbsp;</td>
						<td className="lgndBldTxt" style={{width:'10%',textAlign:'left'}}><b>Account Trades:</b></td>
						<td className="lgndBldTxt" style={{width:'10%',textAlign:'left'}}><img src={require('../../images/icon_multiaccount.gif')}/>Click to view <b>Multiple Account Trades</b></td>
					</tr>

				      </table>
				</div>
				{( approveFlag === 'true')?<div>
				{approveBtn}
				{rejectBtn}</div>:''}
				</div>}
                       	<Dialog  fullWidth={true}
			    maxWidth={'md'}
			    open={this.state.open}
			    onClose={this.handleClose}
                            aria-labelledby="form-dialog-title"
                        >
			    <DialogTitle id="form-dialog-title">{popuptitle}</DialogTitle>
			     <DialogContent>
			    {/* <Paper> */}
				<span style={{fontSize:'14px'}}>{popupvalue}</span>
				{/* <a href="javascript:void(0);" onClick={this.doEmail} className="pull-right">
				  <svg width="24" height="24" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8l8 5 8-5v10zm-8-7L4 6h16l-8 5z"/></svg>
				</a> */}

				<div id="popup" className="clearfix">
				 <ReactTable resizable={false} columns={popupcolumns1}  data={popupdata1} className="table table-striped" style={{marginBottom:'0'}} />
				</div>
				<div className="clearfix"></div>
				<div style={{float:'left',padding:'10px 0'}} className='clearfix'>
					<label style={{fontWeight: 'normal',width:'100%',whiteSpace: 'normal',fontSize:'11px'}}>Your instruction has been submitted. This will be processed by the Corporate Investment Services Managers. You may be contacted in the case of any problems. You will be able to view the status of your trade on the "Trade History" screen</label>
				</div>
				<div className="pull-right">
				{  (user[0].memberCatId==='3')?
						<Link to={{ pathname: '/BRORDENT', state: { flag: 'newtrade', TradeType:this.state.TradeType} }} id="palceanot" className="btn btn-default btn-xs">Place Another Trade</Link>
						:
						<Link to={{ pathname: '/DEALENT', state: { flag: 'newtrade', TradeType:this.state.TradeType} }} id="palceanot" className="btn btn-default btn-xs">Place Another Trade</Link>
 				}
					<a className="btn btn-primary btn-xs" id="Close" onClick={this.handleClose} style={{marginLeft: '10px'}}>Close</a>
				</div>
			    {/* </Paper> */}
			    </DialogContent>
			    {/* <DialogActions>
				<Button onClick={this.handleClose} id="close" color="primary">
				Close
				</Button>

			    </DialogActions> */}
                         </Dialog>
                         {
				this.state.emailid !== '' &&
				 <Dialog  fullWidth={true}
				    maxWidth={'sm'}
				    open={this.state.emailOpen}
				    onClose={this.handlePopUpClose}
				    aria-labelledby="form-dialog-title">
				    <DialogTitle id="form-dialog-title">Export Trade Entry Confirmation for {this.state.recordcount} selected records</DialogTitle>
				     <DialogContent>
				     <h5>
				     		<span style={{float:'left'}}><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm5 16H7v-2h10v2zm-6.7-4L7 10.7l1.4-1.4 1.9 1.9 5.3-5.3L17 7.3 10.3 14z"/></svg>
						</span><span style={{float:'left',marginTop:'12px'}}>PDF of Trade Entry Confirmation has been sent to your email 	<span>{this.state.emailid}</span></span>

					</h5>

					<br/>
					<div className="pull-left" style={{paddingTop:'10px'}}><a className="btn btn-primary btn-xs" id="ok" onClick={this.handlePopUpClose}>OK</a></div>
					<div className="pull-left" style={{ paddingTop:'20px', marginLeft: '10px'}}><Link to='/MySettings' >Set up reports to be automatically sent to my email address </Link></div>
				    </DialogContent>
				    <DialogActions>
					<button onClick={this.handlePopUpClose} id="close" className="btn btn-primary btn-xs">
					Close
					</button>

				    </DialogActions>
				 </Dialog>
			 }
                        </div>
                        <div>
		    <Dialog
		      open={this.state.openView}
		      onClose={this.handleViewClose}
		      scroll={this.state.scroll}
		      aria-labelledby="scroll-dialog-title"
		      fullWidth={true}
		      maxWidth = {'md'}
		    >
		      <DialogTitle id="scroll-dialog-title"> {title}

		      </DialogTitle>
		      <DialogContent>
			<DialogContentText>
			{tbody}
		       {
			dataFlag === true ?
			(
			popUpVData !== undefined ?
			<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
			  <MUIDataTable
			  data={popUpVData1}
			  columns={popUpVColumns1}
			  options={optionsVPopUp}
			  />
			</MuiThemeProvider>
			:
			<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
			)
			:
			<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div></div>
			}
			</DialogContentText>
		      </DialogContent>
		      <DialogActions>
			<button onClick={this.handleViewClose} className="btn btn-primary btn-xs">
			  Close
			</button>
		      </DialogActions>
		    </Dialog>
</div>

                    </div>
                </div>
            );
        }
}
function mapStateToProps(state) {
    const { reportdata } = state;
    return { reportdata };
}

const connectedReportTemplate = connect(mapStateToProps)(ReportTemplate);
export { connectedReportTemplate as ReportTemplate };