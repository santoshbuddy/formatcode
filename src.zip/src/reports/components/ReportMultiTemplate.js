import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { reportActions } from '../actions/report.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import FormData from 'form-data';
import MultiTable from './MultiTable';
import Loading from '../../common/Loading'

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });
let pageName='';
let filterFlag=true;
class ReportMultiTemplates extends React.Component {
    constructor(){
        super();
        this.state={
            results:[],
            results1:[],
            reportdata:[],
            columns:[],
            screenName:'',
            message:''
        }
        this.doChange = this.doChange.bind(this);
    }
    componentDidMount() {
		pageName = '';
		filterFlag=true;
        this.getFilter()
   }
   getFilter(){
    var bodyFormData = new FormData();
    bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
    this.props.dispatch(reportActions.fetchReportData(bodyFormData));
   }
componentDidUpdate(){

      console.log("page name",pageName)
      if(pageName.length !== 0 && pageName !== this.props.location.pathname)
       {
        filterFlag=true;
        //alert("if block navigate .filterFlag::"+filterFlag);
        pageName=this.props.location.pathname;
        this.coldata=[];
        //this.setState({results:[]})
        this.getFilter()
       }
       else{
       //alert("else block navigate ... ");
        pageName=this.props.location.pathname;
       }
   }
  /* shouldComponentUpdate(nextProps,nextState) {
        const update = this.props.reportdata !== nextProps.reportdata;
        if(!update){
           this.getFilter()
           this.setState({results:[]})
           this.setState({columns:[]})
        }
            return true;
    }*/
   doChange(bodyFormData){
        //var bodyFormData = new FormData();
        //for (name in fillObj) {
            //bodyFormData.append(name, fillObj[name]);
        //}
        bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
        bodyFormData.append("reactJSActionFlag","GO")
        filterFlag=false;
        this.props.dispatch(reportActions.fetchReportData(bodyFormData));
   }
    render(){
      var results;
       let filtermarup;
       let tableMarkup;
       if(this.props.reportdata.reportdata !== undefined){
         filtermarup = <Filters method={this.doChange} data={this.props.reportdata.reportdata} filterFlag={filterFlag}/>

            if(this.props.reportdata.reportdata.title!== undefined && this.props.reportdata.reportdata.title.type!== undefined && this.props.reportdata.reportdata.title.type === "Title")
                this.state.screenName = this.props.reportdata.reportdata.title.name

	   if(this.props.reportdata.reportdata.message!== undefined && this.props.reportdata.reportdata.message.type!== undefined && this.props.reportdata.reportdata.message.type === "message")
                this.state.message = this.props.reportdata.reportdata.message.name
             results = this.props.reportdata.reportdata.tabledata;

        if(results !== undefined){
            let item = results.find(item => item.name==="data")
                if(item.name === "data"){
                    tableMarkup = item.values && item.values.map((val,ind) => {
                         return( <MultiTable data1={val.data1} data2={val.data2} key={ind}/>)
                })
            }
        }
       }else{
            return(
                <Loading />
            )
        }

	let msg="";
        msg = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">{this.state.message}</div>
        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{this.state.screenName}</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
                              {filtermarup}
                            </div>
                        </div>
                        <div className="clearfix"></div>
                        {msg}
                        <div className="clearfix"></div>
                            {tableMarkup}
                    </div>
                </div>
            </div>
        );
    }
}
function mapStateToProps(state) {
    const { reportdata} = state;
    return { reportdata};
}

const connectedReportMultiTemplates = connect(mapStateToProps)(ReportMultiTemplates);
export { connectedReportMultiTemplates as ReportMultiTemplates };

