import React from 'react';
import { Route } from 'react-router-dom';
import MUIDataTable from "mui-datatables";
import TableLoader from '../../common/TableLoader';
import { Link } from 'react-router-dom';
import Typography from '@material-ui/core/Typography';
import ScrollDialog from "../../reports/components/ScrollDialog";
import axios from 'axios';
import { alertConstants } from '../../common/constants/alert.constants';
import Dialog from "@material-ui/core/Dialog";
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';

import { muiTableStyles } from '../../styles/muidatatableCss';

import { MuiThemeProvider } from '@material-ui/core/styles';

import Filters from './Filters';
import Grid from '@material-ui/core/Grid';
import InputLabel from '@material-ui/core/InputLabel';

import { MuiStyles } from '../../styles/MuiStyles';
import { withStyles } from '@material-ui/core/styles';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
 import CustomDatePickerInput from '../../styles/CustomDatePickerInput';
import { ReactDatePicker } from '../../styles/ReactDatePicker';

import DatePicker from 'react-datepicker';
 import 'react-datepicker/dist/react-datepicker.css';

const styles = theme => ({
  margin: {
    margin: theme.spacing.unit,
  },
});

let loading=true
let filterDataObj={eventHistory:'ALL' , fromDate:'',toDate:''}
class AcctPositions extends React.Component {
 constructor(props) {
	    super(props);
	    this.state = {
	    	AcctPositionsData:[],
	    	openExpand:false,
	    	filterDataObj:{eventHistory:'ALL' , fromDate:'',toDate:''},
 		open: false,
   };
   	    	 this.handleAcctPositions=this.handleAcctPositions.bind(this);
   	    	 this.handleDateChange=this.handleDateChange.bind(this);
   	    	 this.handleEventHistory=this.handleEventHistory.bind(this);
			 this.handleExpandCollapse=this.handleExpandCollapse.bind(this);


}
handleEventHistory(e){
	filterDataObj.eventHistory =e.target.value;
	this.setState({filterDataObj: filterDataObj});
			console.log('filterDataObj handleEventHistory >>.'+JSON.stringify(filterDataObj))
	this.handleAcctPositions();
}
handleDateChange(name,value) {
	if(name === 'fromDate' ){
		filterDataObj.fromDate = new Date(value) ;
	}else if(name === 'toDate' ){
		filterDataObj.toDate = new Date(value);
	}
this.setState({filterDataObj: filterDataObj});
		console.log('filterDataObj >>.'+JSON.stringify(filterDataObj))

 }



handleExpandCollapse(){
	if(this.state.openExpand === true){
		this.setState({openExpand:false});
	}else {
		this.setState({openExpand:true});
	}

}

  handleOpen = () => {
     this.handleAcctPositions();
   };
  handleClose = () => {
    this.setState({ open: false });
   };

  handleAcctPositions() {
    var data;
    var url;

     let changedbodyFormData = this.props.changedbodyFormData;
     let rowData =this.props.rowData;
     var bodyFormData = new FormData();
		bodyFormData.append("deskId",changedbodyFormData.get('parentCompany'))
		bodyFormData.append("selectedDeskName",changedbodyFormData.get('selectedDeskName'))

		bodyFormData.append("branchId",changedbodyFormData.get('branchId'))
		bodyFormData.append("selectedBranch",changedbodyFormData.get('selectedBranchName'))

		bodyFormData.append("selectedClientName",changedbodyFormData.get('selectedClientName'))
		bodyFormData.append("companyId",changedbodyFormData.get('companyId'))
		bodyFormData.append("prodCatName",changedbodyFormData.get('prodCatName'))
		bodyFormData.append("prodName",changedbodyFormData.get('prodName'))
		bodyFormData.append("refAcct",rowData[4])
		bodyFormData.append("accountList",rowData[20])
		bodyFormData.append("accountListTxt",rowData[4])

				bodyFormData.append("greenFlag",'GREEN')


     	bodyFormData.append("fromDate",this.state.filterDataObj.fromDate)
     	bodyFormData.append("toDate",this.state.filterDataObj.toDate)
     	     	bodyFormData.append("eventHistory",this.state.filterDataObj.eventHistory)

     	bodyFormData.append("product",changedbodyFormData.get('product'))
     	bodyFormData.append("issueChild",rowData[22])
		bodyFormData.append("currency",changedbodyFormData.get('currency'))
		bodyFormData.append("refAcctNbr",'All')
		bodyFormData.append("acctnature",rowData[18])
		bodyFormData.append("chkStatus",rowData[19])
				bodyFormData.append("popUpFlag",'POPUP')


     var user = JSON.parse(sessionStorage.getItem('user'));

    	 bodyFormData.append("token",user[0].token)
    	bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
    	axios({
  		method: 'POST',
  		url:alertConstants.URL+"/acctPosPopUp.do",
  		data: bodyFormData,
  		config: { headers: {'Content-Type': 'application/x-www-form-urlencoded' }}
  					  }).then((response)=>{
  					  data = response.data;
   					 //  console.log('<<data wwwew>>>>'+JSON.stringify(data));
  					   this.setState({ open:true, AcctPositionsData:data});
  					//   console.log('<<data22222dfdfd>>>>'+JSON.stringify(this.state.AcctPositionsData));
  					   loading=false;
   					  });


 }

  render(){
	    const { classes } = this.props;
   const options = {
            filter: false,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:false,
            rowsPerPage: 5,
			responsive: "scroll",
			fixedHeader: false,
			filter:false,
			search:false,
			print:false,
			download:false,
      		viewColumns:false,
      		pagination: false,
			  textLabels: {
                body: {
                     noMatch:  loading ?<TableLoader />:'',
                },
            }
        };


          const options1 = {
		            filter: false,
		            filterType: 'dropdown',
		            responsive: 'scroll',
		            selectableRows:false,
		            rowsPerPage: 5,
					responsive: "scroll",
					fixedHeader: false,
					filter:false,
					search:false,
					print:false,
					download:false,
		      		viewColumns:false,
		      		pagination: false,
		            textLabels: {
		                body: {
		                     noMatch:  loading ?<TableLoader />:'',
		                },
		            }
        };

		let columns =[];
		let data =[];

		let columns1 =[];
		let data1 =[];
		let screenName='';
		let eventsVect =[];
		if(this.state.AcctPositionsData !== undefined ){
 					 this.state.AcctPositionsData.map((item,index) => {
						    if(item.type === "Title"){
						       screenName = item.name
			   			 }
						if(filterDataObj.fromDate  === ''){
						if(item.name === "fromDate"){
							filterDataObj.fromDate = item.fromDate
						}

						if(item.type === "toDate"){
							filterDataObj.toDate = item.value
						}
						this.state.filterDataObj =filterDataObj;
					}


			});


		var mainList=this.state.AcctPositionsData.find(item =>item.name ==="columns")// === listName)

 		if(mainList!==undefined && mainList.COLUMNS!==undefined)
		columns = mainList.COLUMNS;


		 columns.map((item,index)=>{
						   //console.log("mar02,2019  item.name:::::",item.name)
						if(item.name === "Balance Change"){
							item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
							  if(this.state.openExpand){
								 return ( <a onClick={this.handleExpandCollapse.bind()} ><img src='/src/images/icon_settleinst_hide.gif' style={{    position: 'absolute'}} /> </a>  );

							  }else {
							 	return ( <a onClick={this.handleExpandCollapse.bind()} ><img src='/src/images/icon_settleinst_view.gif' style={{    position: 'absolute'}}  /> </a> );
								}
							 }
						}
			});


		mainList=this.state.AcctPositionsData.find(item =>item.name ==="DATA")// === listName)
		if(mainList!==undefined && mainList.DATA!==undefined)
		data = mainList.DATA;


		mainList=this.state.AcctPositionsData.find(item =>item.name ==="columns1")// === listName)


 		if(mainList!==undefined && mainList.COLUMNS1!==undefined)
		columns1 = mainList.COLUMNS1;


		mainList=this.state.AcctPositionsData.find(item =>item.name ==="DATA1")// === listName)
		if(mainList!==undefined && mainList.DATA1!==undefined)
		data1 = mainList.DATA1;


		mainList=this.state.AcctPositionsData.find(item =>item.name ==="eventsVect")// === listName)
		if(mainList!==undefined && mainList.values!==undefined)
		eventsVect = mainList.values;

		if(mainList!==undefined && mainList.fieldValue!==undefined)
		filterDataObj.eventHistory = mainList.fieldValue;



		}
		let filetermarkup;
		if(this.state.AcctPositionsData !== undefined && this.state.AcctPositionsData.length>0){
		           filetermarkup = this.state.AcctPositionsData.map((filter,index) => {
		            if(filter.type === "label"){
		               return (
		                  <Grid item  key={filter.id.toString()}>
		                      <InputLabel className={classes.labelStyle} shrink htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
		                      <InputLabel> { filter.value }</InputLabel>
		                  </Grid>
		               );
		               }

		        });

        }

          var selectList="";

        selectList=  <NativeSelect className={classes.select}
		  				   ref={'eventHistory'}  id={'eventHistory'} name={'eventHistory'}  onChange={this.handleEventHistory.bind()} value={this.state.filterDataObj.eventHistory}>
		   				 	{eventsVect !== undefined && eventsVect.map((obj,index) => {
		  								     return <option key={index} value={obj.id}>{obj.name}</option>
		  					 })}
		</NativeSelect>


		var		selectionFields=<div><Grid item  key={'toId'}>
				  <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
				{'Event History From' } : </InputLabel>{selectList}
			</Grid>
 		{(this.state.filterDataObj.eventHistory === 'ALL')?<Grid item  key={'fromId'}>
		                       <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
		                       {  'From' }:</InputLabel>
													 <ReactDatePicker>
		                      		<DatePicker dateFormat="MMM dd, YYYY" ref={'fromDate'} autoOk={true} name={'fromDate'} className="form-control"    selected={this.state.filterDataObj.fromDate}  onChange={this.handleDateChange.bind(this, 'fromDate')}  customInput={(<CustomDatePickerInput/>)}/>
														</ReactDatePicker>
                   </Grid>:''}
 		{(this.state.filterDataObj.eventHistory === 'ALL')?<Grid item  key={'toId'}>
		                       <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
		                       { 'To' }:</InputLabel>
													 <ReactDatePicker>
		                      		<DatePicker dateFormat="MMM dd, YYYY" ref={'toDate'} autoOk={true} name={'toDate'} className="form-control"  selected={this.state.filterDataObj.toDate}   onChange={this.handleDateChange.bind(this, 'toDate')}   customInput={(<CustomDatePickerInput/>)}/>
														</ReactDatePicker>
                   </Grid>:''}

                    <button size="small" style={{height: 30, margin: 12}} className="btn btn-primary btn-xs" title="Refresh" onClick={this.handleAcctPositions.bind()}  >
				   						{ 'Refresh' }
					  </button>
		</div>





 return (


      <div>

		<a href="#" onClick={this.handleAcctPositions.bind()}> View Account Position</a>
        <Dialog  fullWidth={true}
          maxWidth={'md'}
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >


          <DialogContent>
			<div>
				<h4>{screenName}</h4>
			</div>
			<div className="clearfix"></div>
			<br/>
          <div className="filter_div" id="filter_div" >
			{filetermarkup}

			</div>
          <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>

		 	<MUIDataTable
		 		  title=''
		 		  data={data}
		 		  columns={columns}
		 		  options={options}
		  />
		{(this.state.openExpand)?
			<div>{selectionFields}

		   <MUIDataTable
		  		 		  title={''}
		  		 		  data={data1}
		  		 		  columns={columns1}
		  		 		  options={options1}
		  /></div>:''}

 			</MuiThemeProvider>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

 export default withStyles(MuiStyles)(AcctPositions);

