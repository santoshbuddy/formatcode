import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { MuiThemeProvider } from '@material-ui/core/styles';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';

let listChange=false;
const styles = theme => ({
  margin: {
    margin: theme.spacing.unit,
  },
});

let filterNameValueArray=[];
let filterData=[];
let pageName="";
let inputChange=false;
class AdmFilters extends React.Component {
    constructor () {
        super(),
        this.state = {
		newChangeList:[],
		inputValue:'',
		lastName:'',
		SSOId:''
        },
        this.doChange = this.doChange.bind(this);
        this.inputLastNameHandle = this.inputLastNameHandle.bind(this);
        this.inputSSOIdHandle = this.inputSSOIdHandle.bind(this);
        this.inputHandle = this.inputHandle.bind(this);
        //this.handleChange = this.handleChange.bind(this);
      }
      componentWillMount(){
        // this.doChange();
      }
      componentDidUpdate(){
        //listChange=false;
      }

inputLastNameHandle(e){
	var listName=e.target.name;
	var listValue=e.target.value;
	if(filterNameValueArray!== undefined && filterNameValueArray.length>0){
	let obj=filterNameValueArray.find(namevalue => namevalue.id === listName);
	if(obj!== undefined){
	  obj.value=listValue;
	}
	}
	listChange=true;
  	this.setState({lastName:e.target.value})
}

inputSSOIdHandle(e){
	var listName=e.target.name;
	var listValue=e.target.value;
	if(filterNameValueArray!== undefined && filterNameValueArray.length>0){
		let obj=filterNameValueArray.find(namevalue => namevalue.id === listName);
		if(obj!== undefined){
		  obj.value=listValue;
		}
	}
	listChange=true;
  this.setState({SSOId:e.target.value})
}

inputHandle(e){

	var listName=e.target.name;
	var listValue=e.target.value;

	if(filterNameValueArray!== undefined && filterNameValueArray.length>0){
	let obj=filterNameValueArray.find(namevalue => namevalue.id === listName);
		if(obj!== undefined){
		  obj.value=listValue;
		}
	}
	listChange=true;
  this.setState({inputValue:e.target.value})
}

handleChange(e)
      {
	      	var listName=e.target.name;
	      	var listValue=e.target.value;
	      	//alert("listName::"+listName+",listValue:"+listValue)
	      	listChange=true;

		if(filterNameValueArray!== undefined && filterNameValueArray.length>0){
			let obj=filterNameValueArray.find(namevalue => namevalue.id === listName);
			if(obj!== undefined){
			  obj.value=listValue;
			}
		}
		console.log("after onchange filterNameValueArray::",filterNameValueArray);
		//this.setState({ newChangeList: "" });
		this.doChange(e.target.name);
     }

	doChange(e){
	if(event.target.name==="New"){
		if(window.confirm("Are you sure, you want to create a company?")){
		//console.log("apr 05, 2019 filternamevaluearray values::"+filterNameValueArray)
				var bodyFormData 	= new FormData();

				//alert(" pagename:::"+pageName);

				  if(filterNameValueArray !== undefined)
				  {
				    for(var i =0; i<filterNameValueArray.length; i++)
				    {
					var temp = filterNameValueArray[i];
					//alert(" apr2019 apr 05, 2019 ... temp id:"+temp.id+", value::"+temp.value);
					bodyFormData.append(temp.id, temp.value);
				     }
				 }
				//bodyFormData.append("reactJSActionFlag","")
				//alert(" apr2019 before submit...");
		this.props.method1(bodyFormData,e,filterNameValueArray);
	}
	}else{
      		//console.log("apr 05, 2019 filternamevaluearray values::"+filterNameValueArray)
		var bodyFormData 	= new FormData();

		//alert(" pagename:::"+pageName);

		  if(filterNameValueArray !== undefined)
		  {
		    for(var i =0; i<filterNameValueArray.length; i++)
		    {
			var temp = filterNameValueArray[i];
			//alert(" apr2019 apr 05, 2019 ... temp id:"+temp.id+", value::"+temp.value);
			bodyFormData.append(temp.id, temp.value);
		     }
		 }
		//bodyFormData.append("reactJSActionFlag","")
		//alert(" apr2019 before submit...");
		this.props.method1(bodyFormData,e,filterNameValueArray);
		}
	}

    render(){
	//alert(" apr2019 lastName:::"+this.state.lastName);
      //console.log("filter filterFlag::"+this.props.filterFlag);
      //console.log("filterData::"+filterData+",filterFlag:"+this.props.filterFlag);
      //console.log("filterFlag:::"+this.props.filterFlag)
      const { classes } = this.props;
        const { data } = this.props;

        let fullName,ssoId,appRefCode;

        if(this.props.fullName !== undefined){
	   fullName = this.props.fullName;
	}

	if(this.props.ssoId !== undefined){
	   ssoId = this.props.ssoId;
	}

	if(this.props.appRefCode !== undefined){
	  appRefCode = this.props.appRefCode;
	}

        if(this.props.pageName !== undefined){
          pageName=this.props.pageName;
        }
        let filetermarkup;

        if(data.reportdata !== undefined && this.props.filterFlag === true){
          filterData=data.reportdata;
        }
        console.log("after filterData::",filterData);
        //if(this.props.filterFlag == true)
        	//listChange = false;
        if(filterData !== undefined && filterData.length>0 ){
           filetermarkup = filterData.map((filter,index) => {
            if(filter.type === "Select"){
		if(filter.values !== undefined && filter.values.length>0 && this.props.filterFlag === true && listChange === false)
                	filterNameValueArray.push({id:filter.name,value:filter.values[0].id})

                //alert(filterNameValueArray.find(namevalue => namevalue.id === filter.name).value);
                //alert(filterData.find(namevalue => namevalue.name === filter.name).values[index].id)
             var listValue="";
             if(listChange === true){
               if(filterNameValueArray!== undefined && filterNameValueArray.length>0){
		let obj=filterNameValueArray.find(namevalue => namevalue.id === filter.name);
		    //console.log(obj);
			if(obj!== undefined){
			  listValue=obj.value;
		        }
		}
             }else{
               listValue=filterNameValueArray.find(namevalue => namevalue.id === filter.name)!== undefined && filterNameValueArray.find(namevalue => namevalue.id === filter.name).value
              }
             //alert("list value ::"+listValue+",index:"+index+",listChange:"+listChange);

             var selectList="";
		selectList=<NativeSelect className={classes.select}
		   ref={ filter.name }  id={filter.name} name={filter.name}  onChange={(e)=>{this.handleChange(e,filter.onChangeFlag,filter.subListName)}} value={listValue}>
		     {filter.values !== undefined && filter.values.map((obj,index) => {
			     return <option key={index} value={obj.id}>{obj.name}</option>
			 })}
		</NativeSelect>
             return(
                <Grid item  key={filter.id.toString()}>
                  <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
                    { filter.label } :
                  </InputLabel>
                    {selectList}
                </Grid>
               );
            }else if(filter.type === "Button"){
                return (
                <span>
					  <button size="small" name="New" style={{height: 30, margin: 12}} className="btn btn-primary btn-xs" title={ filter.name } onClick={(e)=>{this.doChange();}} key={filter.id.toString()}>
						{ filter.name }
					  </button>
					  {
						(pageName === "/report/DESETST") &&
						<span className="displayTxt">To create New Desk/Entity </span>
					  }
                </span>
               );
              }else if(filter.type === "input" && filter.name === "lastName"){
			if(this.state.lastName === '' && listChange === false){
			  filterNameValueArray.push({id:filter.name,value:filter.value})
			}
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label }:</InputLabel>
                     <TextField className={classes.inputStyle} refs={filter.name} name={filter.name} defaultValue={this.state.lastName===''?fullName:this.state.lastName} onChange={this.inputLastNameHandle}/>
                  </Grid>
               );
              }
              else if(filter.type === "input" && filter.name === "ssoId"){
		if(this.state.SSOId === '' && listChange === false){
		  filterNameValueArray.push({id:filter.name,value:filter.value})
		}
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label }:</InputLabel>
                     <TextField className={classes.inputStyle} refs={filter.name} name={filter.name}  defaultValue={this.state.SSOId===''?ssoId:this.state.SSOId} onChange={this.inputSSOIdHandle}/>
                  </Grid>
               );
              }else if(filter.type === "input"){
                  if(this.state.inputValue === '' && listChange === false){
                    filterNameValueArray.push({id:filter.name,value:filter.value})
                   }
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label }:</InputLabel>
                     <TextField className={classes.inputStyle} refs={filter.name} name={filter.name} defaultValue={this.state.inputValue===''?appRefCode:this.state.inputValue} onChange={this.inputHandle}/>
                  </Grid>
               );
              }else if(filter.type === "label"){
               return (
                  <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
                      <InputLabel className={classes.inputStyle}> { filter.value }</InputLabel>
                  </Grid>
               );
              }else if(filter.type === "newline"){
                return  <div key="newline" className="clearfix"></div>
              }
        });

        console.log("after filter block called ... filterNameValueArray::",filterNameValueArray);
        //console.log("after filter block called ... filterFlag::",this.props.filterFlag);

       }

        return(
					<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
            <Grid container spacing={24} >
                {filetermarkup}
            </Grid>
					</MuiThemeProvider>
        );
    }
}

export default withStyles(MuiStyles)(AdmFilters);