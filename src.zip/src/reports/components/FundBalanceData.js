import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { reportActions } from '../actions/report.actions';
import ReactTable, { ReactTableDefaults } from "react-table";
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import 'react-tabs/style/react-tabs.css';
import { withStyles } from '@material-ui/core/styles';
import Loading from '../../common/Loading'
import MUIDataTable from "mui-datatables";
import {muiTableStyles} from '../../styles/muidatatableCss';
import { history } from '../../_helpers';
import ReportFilter from './ReportFilter';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";

Object.assign(ReactTableDefaults, {
	defaultPageSize: 5,
	minRows: 1
});

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
      marginTop:'0px',
    }
});

let backButton;
var data1 = [] //this.props[3].DATA;
let gissueChild = '';
let gprodName 	= '';
let gcurrency	= '';
let dipObj;

class FundBalanceData extends React.Component {
	getMuiTheme = () =>
	createMuiTheme({
		overrides: {
			MUIDataTableHeadCell: {
				root: {
					background: '#eaeaea !important',
					color: '#0066b2 !important',
					textTransform: 'uppercase',
					whiteSpace: 'nowrap',
					fontWeight:'bold',
					borderRight: '1px solid #b3b3b3 !important',
					borderTop: '1px solid #b3b3b3',
					borderBottom: '1px solid #b3b3b3',
					'&:first-child':{
						borderLeft: '1px solid #b3b3b3'
					},
					'&:last-child':{
						paddingRight: '4px'
					}
				}
			},
			MUIDataTableBodyRow: {
				root: {
					'&:nth-child(odd)': {
						backgroundColor: '#f7f8f9'
					}
				}
			},
			MuiTableCell: {
				root: {
					whiteSpace: 'nowrap',
					padding: '7px 5px',
					borderRight: '1px solid #f3ebeb',
					borderTop: '1px solid #c3c3c3',
					borderBottom: '1px solid #f3ebeb',
					'&:last-child':{
						borderRight:'0px'
					},
					'&:first-child':{
						borderLeft: '1px solid #f3ebeb'
					}
				}
			},
			MuiTableRow: {
				root:{
					height:'auto'
				},
				head: {
					height:'auto',
				}
			}
		}
	});

    constructor(){
        super();
        this.state={
			flag:true,
			results:[],
			results1:[],
			reportdata:[],
			columns:[],
			screenName:'',
			open: false,
			message:'',
			TradeType:'',
			selectAll:false,
        }
	}

	componentWillMount() {
		this.getFilter()
	}

	doFilterChange(fillObj) {

		fillObj.append("clientFirm",sessionStorage.getItem('clientFirm'));
		fillObj.append("reactJSActionFlag","")
		fillObj.append("issueChild",gissueChild);
		fillObj.append("catId","CFBHREPO");
		fillObj.append("prodName",gprodName);
		fillObj.append("currency",gcurrency);
		fillObj.append("selectedAcct","");

		dipObj.dispatch(reportActions.fetchReportData(fillObj));
	}

	getFilter()
	{
		var bodyFormData = new FormData();

		bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
		bodyFormData.append("reactJSActionFlag","")
		bodyFormData.append("issueChild",this.props.location.state.issueChild);
		bodyFormData.append("catId","CFBHREPO");
		bodyFormData.append("selClient","All");
		bodyFormData.append("prodName",this.props.location.state.prodName);
		bodyFormData.append("currency",this.props.location.state.currency);
		bodyFormData.append("chkStatus","ALL");
		bodyFormData.append("acctnature","All");
		bodyFormData.append("selectedAcct","");

		this.props.dispatch(reportActions.fetchReportData(bodyFormData));
	}

	doBackConfirm() {
		history.push("/report/CLFBHREP");
	}

	render() {

		var newdata ;
		var columns1 = [] //this.props[3].COLUMNS;
		var data,columns,screenName,results1=[],paginationFlag=true,checkboxFlag=false;

		console.log(" this.props.reportdata--->", this.props.reportdata.reportdata)

		this.state.reportdata = this.props.reportdata.reportdata;
		if(this.state.reportdata !== undefined) {
			results1  = Array.from(this.state.reportdata);
		}

		if(this.props.location.state.prodName != undefined)
			screenName = this.props.location.state.prodName;

		if(this.props.location.state.issueChild != undefined)
			gissueChild = this.props.location.state.issueChild;

		if(this.props.location.state.prodName != undefined)
			gprodName = this.props.location.state.prodName;

		if(this.props.location.state.currency != undefined)
			gcurrency = this.props.location.state.currency;

		dipObj	=	this.props;

		console.log("result1 " , results1);

		if( results1 !== undefined && results1.toString().trim().length!==0)
		{
			var mainList=results1.find(item =>item.name ==="columns")// === listName)
			if(mainList!==undefined && mainList.COLUMNS!==undefined)
				columns1 = mainList.COLUMNS;

			mainList=results1.find(item =>item.name ==="DATA")// === listName)
			if(mainList!==undefined && mainList.DATA!==undefined)
				data1 = mainList.DATA;
		}
		else{
            return(
                <Loading />
            )
        }

		const options = {
			filterType: "dropdown",
			selectableRows: false,
			responsive: "scroll",
			pagination:paginationFlag,
			rowsPerPage:(paginationFlag===false)?data1.length:10,
			fixedHeader: false,
			isRowSelectable: (dataIndex) => {
				return data1[dataIndex][13] !== "disabled";
			}
		};

		backButton = <button className="btn btn-primary btn-xs mt" id="back"  style={{marginTop:'10px'}} onClick={this.doBackConfirm.bind(this)}>Back</button>

		return (
			<div>
				<NavBar/>
				<div className="clearfix"></div>
				<div className="col-md-12 col-sm-12">
					<div className="clearfix"></div>
					<div><h4>{screenName}</h4></div>
					<div className="clearfix"></div>
					<br/>
					<div className="clearfix"></div>
					<ReportFilter method={this.doFilterChange} data={this.state.reportdata} />
					<div className="clearfix"></div>
					<div className="col-md-12 col-sm-12">
						{
							data1 !== undefined ?
							<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
								<MUIDataTable
									data={data1}
									columns={columns1}
									options={options}
								/>
							</MuiThemeProvider>
							:
							<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
						}
						{ backButton }
					</div>
				</div>
			</div>
		);
	}
}

FundBalanceData.propTypes = {
    classes: PropTypes.object.isRequired,
};

function mapStateToProps(state) {
	const { reportdata } = state;
	return { reportdata };
}

const connectedFundBalanceData = connect(mapStateToProps)((withStyles(styles))(FundBalanceData));
export { connectedFundBalanceData as FundBalanceData };