import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { reportActions } from '../actions/report.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import 'react-tabs/style/react-tabs.css';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import DialogTitle from '@material-ui/core/DialogTitle';
import Paper from '@material-ui/core/Paper';
import { Link } from 'react-router-dom';
import Loading from '../../common/Loading'
import MUIDataTable from "mui-datatables";
import Card from "./Card";
import ScrollDialog from "./ScrollDialog";
import PopUpDataTable  from "./PopUpDataTable";
import ScrollDialogPopUp  from "./ScrollDialogPopUp";
import {muiTableStyles} from '../../styles/muidatatableCss';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });
  // let buttonFlag=true;
  let pageName='';
  let filterFlag=true;
  let msg="",results2=[];
  let prodid = '';
class ReportCompTemplate extends React.Component {
    getMuiTheme = () =>
        createMuiTheme({
          overrides: {
            MUIDataTableHeadCell: {
              root: {
                background: '#eaeaea !important',
                color: '#0066b2 !important',
                textTransform: 'uppercase',
                whiteSpace: 'nowrap',
                fontWeight:'bold',
                borderRight: '1px solid #b3b3b3 !important',
                borderTop: '1px solid #b3b3b3',
                borderBottom: '1px solid #b3b3b3',
                '&:first-child':{
                  borderLeft: '1px solid #b3b3b3'
                },
                '&:last-child':{
                  paddingRight: '4px'
                }
              }
            },
            MUIDataTableBodyRow: {
              root: {
                '&:nth-child(odd)': {
                  backgroundColor: '#f7f8f9'
                }
              }
             },
             MuiTableCell: {
               root: {
                whiteSpace: 'nowrap',
                padding: '7px 5px',
                borderRight: '1px solid #f3ebeb',
                borderTop: '1px solid #c3c3c3',
                borderBottom: '1px solid #f3ebeb',
                '&:last-child':{
                  borderRight:'0px'
                },
                '&:first-child':{
                  borderLeft: '1px solid #f3ebeb'
                }
               }
             },
             MuiTableRow: {
               root:{
                 height:'auto'
               },
               head: {
                 height:'auto',
               }
             }
            }
          });


    constructor(){
        super();
        this.state={
            flag:true,
            results:[],
            results1:[],
            reportdata:[],
            reportcdata:[],
            columns:[],
            screenName:'',
            open: false,
            message:'',
            TradeType:''
        }
        this.coldata=[];
        this.doChange = this.doChange.bind(this);
        this.routeChange = this.routeChange.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.goToTradeScreen = this.goToTradeScreen.bind(this);
     }

        //constructor() {
            //super()
            //this.state = { loading:true,tabIndex: 0, enterdata: '',fixed:'' };
        //}

        //componentDidMount() {
          // if(this.props.reportdata === undefined || this.props.reportdata === "")
            // this.props.dispatch(userActions.getMMMFData());
        //}

    componentDidMount() {
        console.log("Report Template componentDidMount")
        pageName=this.props.location.pathname;
        this.coldata=[];
        this.getFilter()
   }
   componentDidUpdate(){
    // alert("componentDidUpdate")
      console.log("page name",pageName)
      console.log("this.props.location.pathname",this.props.location.pathname)
      if(pageName.length!==0 && pageName!==this.props.location.pathname)
       {
	filterFlag=true;
        pageName=this.props.location.pathname;
        console.log("Report Template componentDidUpdate",pageName)
        this.coldata=[];
        //this.setState({results:[]})
        this.getFilter()
        this.props.dispatch(reportActions.fetchReporComptData(new FormData()));
       }
       else
       pageName=this.props.location.pathname;
   }
   doEdit(){
     alert("clicked edit button");
   }
   doCreate(){
     alert("clicked created button");
   }
   doTradeAllo(){
   }
   doSelectAll(){
   }
   doUnSelectAll(){
   }
   doShowTradeDetailsPopUp(){
   }
   getFilter(){
    console.log("Report Template getFilter")
         //this.setState({message:""})
    var bodyFormData = new FormData();
    bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
    bodyFormData.append("reactJSActionFlag","")
    // if(this.props.reportdata.reportdata === undefined ){
    this.props.dispatch(reportActions.fetchReportData(bodyFormData));
    // }
   }

   doChange(bodyFormData, selprodId, xe){
        //bodyFormData.append("reactJSActionFlag","GO")
        //var bodyFormData = new FormData();
        //for (name in fillObj) {
            //bodyFormData.append(name, fillObj[name]);
        //}
        //alert(bodyFormData.get("clientFirm"));
        filterFlag=false;
        prodid = selprodId;

        if(xe === 'investAccount') {
	   filterFlag=true;
			bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
			bodyFormData.append("reactJSActionFlag","")
			this.props.dispatch(reportActions.fetchReportData(bodyFormData));

		} else {
        this.props.dispatch(reportActions.fetchReporComptData(bodyFormData));
   }
   }
   routeChange(){
        let path = `/admincreate/CREATEACCT`;
        this.props.history.push(path);
    }

    goToTradeScreen() {
		console.log('refs--',this.refs);
		console.log('ref--',this.refs['product']);
		this.props.history.push({
			pathname: '/DEALENT',
			state: {
				prodId: prodid,
				fromPage:'INDICATIVERATES'
			}
		});
	}

    handleClose () {
        this.setState({flag:false})
        this.setState({ open: false });
      }
    render() {
            let fromDate,toDate;
            var newdata ;
            var popuptitle,popupvalue;
            //const { reportdata } = this.props;
            var columns1 = [] //this.props[3].COLUMNS;
		var data1 = [] //this.props[3].DATA;
            var data,columns,screenName,results1=[],paginationFlag=true;
            console.log(" this.props.reportdata--->", this.props.reportdata.reportdata)
//            console.log(" this.props.reportdata[3]--->", this.props.reportdata.reportdata[3])

             //this.props.reportdata.reportdata.find(


            this.state.reportdata = this.props.reportdata.reportdata;
            if(this.state.reportdata!==undefined)
            results1  = Array.from(this.state.reportdata);
            //columns = this.props.reportdata.reportdata.COLUMNS;
            //data = this.props.reportdata.reportdata.DATA;


            //if(mmmfdata.mmmfdata !== undefined){
            //   columns = mmmfdata.mmmfdata.COLUMNS;

            console.log("results1 block :::",results1)
            //console.log("columns block::",columns)

             //var mainList=results1.find(item =>item.name ==="columns")// === listName)
             //console.log("mainlist", mainList)


         if(this.props.reportdata.reportdata !== undefined){
                if(this.props.reportdata.reportdata.length>0){
                    newdata="";
                    newdata = this.props.reportdata.reportdata.find(item =>item.name==="newTradeData")
                     console.log("newdata::",newdata)
                     if(newdata !== undefined && newdata.length!==0)
                     {
                        //console.log("insode newdata::",newdata)
                        popuptitle = newdata.label;
                        popupvalue = newdata.value;
                    }else
                    this.state.open=false;
            }
        }
        else{
            return(
                <Loading />
            )
        }


var popuptradedata;
        var popupcolumns1=[],popupdata1=[];
        if(this.state.flag && newdata !== undefined){
                newdata.values.map((item,index)=>{
                popuptradedata = item;
                popupdata1.push(popuptradedata)
            })
       console.log("popuptradedata-->",popuptradedata)
        if(popuptradedata !== undefined){
            var s =  popuptradedata;
            for(var k in s) {

                if(k !== "TradeType"){
                    popupcolumns1.push({
                        Header: k,
                        accessor: k
                        });
                }else{
                    this.state.TradeType = s[k]
                }

            }
            this.state.open = true;
        }
    }
    //console.log("popupcolumns1::",popupcolumns1);
    //console.log("popupdata1::",popupdata1);
    console.log("result1 " , results1);
    let screenLinkImage;
    if(this.props.location.pathname!== undefined && this.props.location.pathname.length!==0){
         let pos=this.props.location.pathname.lastIndexOf('/');
         //console.log("position value::",pos);
         screenLinkImage=this.props.location.pathname;
         screenLinkImage=screenLinkImage.substring(pos+1,screenLinkImage.length)
         //alert("screenLinkImage::"+screenLinkImage)
         //console.log("screenLinkImage value::",screenLinkImage);
    }
		if( results1 !== undefined && results1.toString().trim().length!==0)
		{
			 results1.map((item,index) => {
			    if(item.type === "Title"){
			       screenName = item.name
			    }
			    if(item.paginationFlag === "false"){
			          paginationFlag = false;
			    }
			if(item.type === "datepicker"){
			   if(item.name === "fromDate"){
			     fromDate=item.value;
			   }
			   if(item.name === "toDate"){
			        toDate=item.value;
			   }
			}
		    //if(item.name === "data")
		      //results = item.values
		})
		var mainList=results1.find(item =>item.name ==="columns")// === listName)
		if(mainList!==undefined && mainList.COLUMNS!==undefined)
 	     	 columns1 = mainList.COLUMNS;

	     	mainList=results1.find(item =>item.name ==="DATA")// === listName)
	     	if(mainList!==undefined && mainList.DATA!==undefined)
          		data1 = mainList.DATA;

         columns1 && columns1.map((item,index)=>{
    if(item.options.hyperlink === "true" && (pageName === "/report/ACCPOREP" || pageName === "/report/MMDAACC"))
    {
	     //alert("before ScrollDialogPopUp");
             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
               return (
		  <ScrollDialogPopUp
                  onClick={e => this.openPopUp(e, tableMeta)}
                  rowData={tableMeta}
                  linkName={value}
                  screenLinkImage={screenLinkImage}
                  fromDate={fromDate}
                  toDate={toDate}
                />
              );
            }
	   }else if(item.options.hyperlink === "true" && pageName === "/report/AUDTRREP"){
 				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
					 return (
					  <PopUpDataTable
						onClick={e => this.openPopUp(e, tableMeta)}
						rowData={tableMeta}
						linkName={value}
						screenLinkImage={screenLinkImage}
						fromDate={fromDate}
						toDate={toDate}
					  />
					);
            }
	   }else if(item.options.hyperlink === "true"){
             item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
               return (
                <ScrollDialog
                  onClick={e => this.openPopUp(e, tableMeta)}
                  rowData={tableMeta}
                  linkName={value}
                  screenLinkImage={screenLinkImage}
                  fromDate={fromDate}
                  toDate={toDate}
                />
              );
            }
		  }

         })

		}

let subBlk;
// if(buttonFlag){
if(this.props.reportdata.reportdata !== undefined){
                if(this.props.reportdata.reportdata.length>0){
//console.log("target report filterFlag::"+filterFlag);
    subBlk = <Filters method={this.doChange} data={this.props.reportdata} PageName={pageName} filterFlag={filterFlag}/>
    }}
// }else{
    // subBlk = <button className="btn btn-xs btn-primary" onClick={this.routeChange} >Create New account</button>
  //  }


msg = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">{this.state.message}</div>

              const options = {
                filterType: "dropdown",
                selectableRows: false,
                responsive: "scroll",
                pagination:paginationFlag,
                rowsPerPage:(paginationFlag===false)?data1.length:10,
                fixedHeader: false,
                downloadOptions:(screenName !== undefined && screenName !== "")?{filename: screenName+'.csv', separator: ','}:{filename: 'Report.csv', separator: ','},

              };


            let muidatatable=[];
            if( this.props.reportcdata !== undefined){
                this.state.reportcdata = this.props.reportcdata.reportcdata;
                if(this.state.reportcdata!==undefined)
                    results2  = Array.from(this.state.reportcdata);
            }

            return (
                <div>
                    <NavBar/>
			<div className="clearfix"></div>
                    <div className="col-md-12 col-sm-12">
                        <div className="clearfix"></div>
			<div>
				<h4>{screenName}</h4>
			</div>
			<div className="clearfix"></div>
			<br/>
			<div className="filter_div" id="filter_div" >
			    {subBlk}
			    { subBlk !== undefined &&
			     <br/>
			    }
			</div>
			<div className="clearfix"></div>
			<div>
			  {msg}
			</div>
			<div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12">
                        {
                          results2 !== undefined ?
                          results2.map((item,index) =>{
                            item.COLUMNS && item.COLUMNS.map((item,index)=> {
                              if(item.options.hyperlink === "true")
                              {
                                //alert("before ScrollDialogPopUp");
                                item.options["customBodyRender"] = (value) => {
                                  return (
									 <a onClick={this.goToTradeScreen} href="javascript:void(0)">{value}</a>
                                  );
                                }
                              }
                            })
                            return <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                                <MUIDataTable
                                    title={item.TABLEHEADING}
                                    data={item.DATA}
                                    columns={item.COLUMNS}
                                    options={options}
                                />
                            </MuiThemeProvider>
                        })
                        :
                        <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
                      }

                <Dialog  fullWidth={true}
                            maxWidth={'md'}
                            open={this.state.open}
                            onClose={this.handleClose}
                            aria-labelledby="form-dialog-title"
                        >
                            <DialogTitle id="form-dialog-title">{popuptitle}</DialogTitle>
                             <DialogContent>
                            <Paper>
                                {popupvalue}
                                <div id="popup">
                                 <ReactTable columns={popupcolumns1}  data={popupdata1} className="table table-striped" />
                                </div>
                                <div className="col-md-2"><a className="btn btn-primary btn-xs" id="ok" onClick={this.handleClose}>OK</a></div>
                                <div className="col-md-2"><Link to={{ pathname: '/DEALENT', state: { flag: 'newtrade', TradeType:this.state.TradeType} }} id="palceanot" className="btn btn-primary btn-xs">Place Another Trade</Link></div>
                            </Paper>
                            </DialogContent>
                            <DialogActions>
                                <Button onClick={this.handleClose} id="close" color="primary">
                                Close
                                </Button>

                            </DialogActions>
                            </Dialog>
                        </div>

                    </div>
                </div>
            );
        }
}
function mapStateToProps(state) {
    const { reportdata,reportcdata } = state;
    return { reportdata,reportcdata };
}

const connectedReportCompTemplate = connect(mapStateToProps)(ReportCompTemplate);
export { connectedReportCompTemplate as ReportCompTemplate };