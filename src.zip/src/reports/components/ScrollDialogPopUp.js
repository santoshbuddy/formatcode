import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import axios from 'axios';
import FormData from 'form-data';
import Loading from '../../common/Loading';
import { alertConstants } from '../../common/constants/alert.constants';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import FiltersPopUp from './FiltersPopUp';
import {addCommaDV} from '../../tradeentry/components/amountValidations';
import {muiTableStyles} from '../../styles/muidatatableCss';

var data,fileds,title;
let screenLinkImage;
let fromDate;
let toDate;
let data1;
let columns1;
let options;
let filterFlag=true;
let acctLocalNbr;
let policyName;
let statusTxt;
var commonData = [];
var actionsList = [];
var editbtnList = [];
var actionbtns = [];
var editbtn = [];
class ScrollDialogPopUp extends React.Component {
getMuiTheme = () =>
	        createMuiTheme({
	          overrides: {
	            MUIDataTableHeadCell: {
	              root: {
	                background: '#eaeaea !important',
	                color: '#0066b2 !important',
	                textTransform: 'uppercase',
	                whiteSpace: 'nowrap',
	                fontWeight:'bold',
	                borderRight: '1px solid #b3b3b3',
	                borderTop: '1px solid #b3b3b3',
	                borderBottom: '1px solid #b3b3b3',
	                '&:first-child':{
	                  borderLeft: '1px solid #b3b3b3'
	                },
	                '&:last-child':{
	                  paddingRight: '4px'
	                }
	              }
	            },
	            MUIDataTableBodyRow: {
	              root: {
	                '&:nth-child(odd)': {
	                  backgroundColor: '#f7f8f9'
	                }
	              }
	             },
	             MuiTableCell: {
	               root: {
	                whiteSpace: 'nowrap',
	                padding: '7px 5px',
	                borderRight: '1px solid #f3ebeb',
	                // borderTop: '1px solid #c3c3c3',
	                borderBottom: '1px solid #f3ebeb',
	                '&:last-child':{
	                  borderRight:'0px'
	                },
	                '&:first-child':{
	                  borderLeft: '1px solid #f3ebeb'
	                }
	               }
	             },
	             MuiTableRow: {
	               root:{
	                 height:'auto'
	               },
	               head: {
	                 height:'auto',
	               }
	             }
	            }
	          });

  constructor(props){
    super(props);
    this.state = {
    open: false,
    scroll: "paper",
    alertmsg:false,
		updateFlag: false,
		ck:0
  };
  this.handleClickOpen = this.handleClickOpen.bind(this);
  this.doChange = this.doChange.bind(this);
  this.enterTrade = this.enterTrade.bind(this);
}

 doChange(filterNameValueArray) {
      //alert("begin do change method ");
	 var jsonBody = new FormData();
	 if(filterNameValueArray !== undefined){
      for(var i =0; i<filterNameValueArray.length; i++){
		  var temp = filterNameValueArray[i];
		  jsonBody.append(temp.id, temp.value);
		  //alert(temp.id+" ,value:"+temp.value);
	  }}
	 filterFlag=false;
	 //alert("in dochange block .acctLocalNbr.."+acctLocalNbr);

    var url;
    var user = JSON.parse(sessionStorage.getItem('user'));
    jsonBody.append("token",user[0].token);
    jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
    console.log('screenLinkImage:'+screenLinkImage);
//console.log("fromdate ::"+JSON.parse(sessionStorage.getItem('fromDate')));
//console.log("todate ::"+JSON.parse(sessionStorage.getItem('toDate')));
jsonBody.append("actionFlag","GO");

     if(screenLinkImage === "ACCPOREP"){
		//alert("ACCPOREP::acctnbr:"+rowData.rowData[17]);
		jsonBody.append("chkStatus","ALL");
		jsonBody.append("subSource","ACCPOREP");
		jsonBody.append("acctNbr",acctLocalNbr);
		//jsonBody.append("acctNbr","1686536897283335");//acctLocalNbr
		jsonBody.append("issueChild","ALL");
		jsonBody.append("eventHistory","ALL");
		jsonBody.append("accountList","ALL");
		jsonBody.append("acctnature","All");
		//jsonBody.append("fromDate",JSON.parse(sessionStorage.getItem('fromDate')));
    	//jsonBody.append("toDate",JSON.parse(sessionStorage.getItem('toDate')));
		url=alertConstants.URL+"/MMMFACCNOPOS.do";
	}else if(screenLinkImage === "MMDAACC"){
		//alert("MMDAACC::acctnbr:"+rowData.rowData[6]);
		jsonBody.append("chkStatus","ALL");
		jsonBody.append("subSource","MMDAACC");
		jsonBody.append("acctNbr",acctLocalNbr);
		//jsonBody.append("acctNbr","1686536897283335");//acctLocalNbr
		jsonBody.append("issueChild","ALL");
		jsonBody.append("eventHistory","ALL");
		jsonBody.append("accountList","ALL");
		jsonBody.append("acctnature","All");
		//jsonBody.append("fromDate",JSON.parse(sessionStorage.getItem('fromDate')));
    	//jsonBody.append("toDate",JSON.parse(sessionStorage.getItem('toDate')));
		url=alertConstants.URL+"/MMDAACCNOPOS.do";
	}
	console.log("scrolldialog .... url info::"+url+",jsonBody:"+jsonBody);

    //jsonBody.append("transId",rowData.rowData[9]);
    axios({
      method: 'post',
      url:url,
      data: jsonBody,
      config: { headers: {'Content-Type': 'multipart/form-data' }}
    }).then((response)=>{
      data = response.data;
      this.setState({ updateFlag: true });
      //this.setState({ open: true, scroll });
      });
    };

	enterTrade(e) {
		var paramVal = e.target.id;
		if(paramVal == 'CLOSEACCOUNT') {
			if(commonData.terminateFlag == 'true') {
				this.setState({ alertmsg: true });
			} else {
				this.props.func(commonData, paramVal);
			}

		}
		else {
			this.props.func(commonData, paramVal);
		}
	}

  handleClickOpen (scroll,rowData) {
    var jsonBody = new FormData();
    var url;
    var user = JSON.parse(sessionStorage.getItem('user'));
    jsonBody.append("token",user[0].token);


   //alert("screenLinkImage:"+screenLinkImage);
	if(screenLinkImage === "ACCPOREP"){
	        jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
		//alert("ACCPOREP::acctnbr:"+rowData.rowData[17]);
		jsonBody.append("chkStatus","ALL");
		jsonBody.append("subSource","ACCPOREP");
		jsonBody.append("acctNbr",rowData.rowData[17]);
		acctLocalNbr=rowData.rowData[17];
		//jsonBody.append("acctNbr","1686536897283335");
		jsonBody.append("issueChild","ALL");
		jsonBody.append("accountList","ALL");
		jsonBody.append("acctnature","All");
		jsonBody.append("fromDate",fromDate);
		jsonBody.append("toDate",toDate);
		url=alertConstants.URL+"/MMMFACCNOPOS.do";
	}else if(screenLinkImage === "MMDAACC"){
		jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
		//alert("MMDAACC::acctnbr:"+rowData.rowData[6]);
		jsonBody.append("chkStatus","ALL");
		jsonBody.append("subSource","MMDAACC");
		jsonBody.append("acctNbr",rowData.rowData[6]);
		acctLocalNbr=rowData.rowData[6];
		//jsonBody.append("acctNbr","1686536897283335");
		jsonBody.append("issueChild","ALL");
		jsonBody.append("accountList","ALL");
		jsonBody.append("acctnature","All");
		jsonBody.append("fromDate",fromDate);
		jsonBody.append("toDate",toDate);
		url=alertConstants.URL+"/MMDAACCNOPOS.do";
	}

    //jsonBody.append("transId",rowData.rowData[9]);
    axios({
      method: 'post',
      url:url,
      data: jsonBody,
      config: { headers: {'Content-Type': 'multipart/form-data' }}
    }).then((response)=>{
      data = response.data;
      this.setState({ open: true, scroll });
      });
    };

  handleClose = () => {
    this.setState({ open: false });
  };

  render() {
    let linkName;
    let dataFlag=true;

    if (this.props.linkName !== undefined)
      linkName = this.props.linkName;

    if (this.props.screenLinkImage !== undefined){
			screenLinkImage = this.props.screenLinkImage;
      console.log("feb2019 screenLinkImage",screenLinkImage);
		}

		if (this.props.open !== undefined && this.state.ck === 0){
			this.state.open =  this.props.open;
			data = this.props.data;
			this.state.ck=1;
		}

    let userLocale="";
	var user = JSON.parse(sessionStorage.getItem('user'));
	if(user[0].localeLang !== undefined){
		userLocale=user[0].localeLang;
	}
    if (this.props.fromDate !== undefined){
      fromDate = this.props.fromDate;
    //  console.log("feb2019 fromDate",fromDate);
    }

    if (this.props.toDate !== undefined){
      toDate = this.props.toDate;
    //  console.log("feb2019 toDate",toDate);
    }

  let tbody="";
  let subBlk;
   if( data !== undefined && data.toString().trim().length!==0){
   console.log("Money Fund Account Position data::",data);

	var mainList=data.find(item =>item.name ==="commonData")// === listName)
	if(mainList!==undefined && mainList.commonData!==undefined)
	commonData = mainList.commonData;
 	 title=commonData.screenName;

 	actionsList =  data[1].ACTIONS;
    editbtnList =  data[2].EDITBTN;
	var mainList=data.find(item =>item.name ==="columns")// === listName)
	columns1 = mainList.COLUMNS;

	mainList=data.find(item =>item.name ==="DATA")// === listName)
	data1 = mainList.DATA;

	options = {
		filterType: "dropdown",
		textLabels: {
			body: {
				noMatch: this.props.isLoading ?
				<Loader /> :
				'No data found',
			},
		},
		selectableRows: false,
		pagination: true,
        rowsPerPage: 10,
		responsive: "scroll",
		fixedHeader: false
	};
    console.log("Money Fund Account Position field values::",commonData);

    if(commonData !== undefined && commonData.length !== 0 )
    {
		if(actionsList != undefined)
		{
			actionbtns = [];
			actionsList.map((item, index) => {
				actionbtns.push(<button id={item.JSFUNCTION} onClick={e => this.enterTrade(event)} className="btn btn-primary btn-xs mt pull-right">{item.label}</button>);
			});
		}
		if(editbtnList != undefined)
		{
			editbtn = [];
			editbtnList.map((item, index) => {
				//console.log("editbtnList--->", editbtnList)
				editbtn.push(<button id={item.JSFUNCTION} onClick={e => this.enterTrade(event)} className="btn btn-primary btn-xs mt">{item.label}</button>);
			});
		}


		subBlk = <FiltersPopUp method={this.doChange} data={data} filterFlag={filterFlag}/>
if(screenLinkImage!== undefined && screenLinkImage === "MMDAACC")
{
   tbody = <table className="table table-striped table-bordered" width="100%">
    <tbody>
          <tr>
            <td>
                <label> Client Name: </label>
                <label className="TxtNrml"> {commonData.clientName} </label>
            </td>
            <td>
                <label> Product: </label>
                <label className="TxtNrml"> {commonData.product} </label>
            </td>
			<td>
				<label> Account: </label>
				<label className="TxtNrml"> {commonData.account} </label>
			</td>
          </tr>
          <tr>
				<td>
				  <label> Currency : </label>
				  <label className="TxtNrml"> {commonData.currency} </label>
				</td>
	              <td>
	                  <label> Balance: </label>
	                  <label className="TxtNrml">{commonData.balance === "Pending"?commonData.balance:addCommaDV(commonData.balance,userLocale,"2","2")} </label>

	              </td>
	              <td>
	                  <label> &nbsp; </label>
	                  <label className="TxtNrml"> &nbsp; </label>
	              </td>
            </tr>

            <tr>
	    	              <td>
	    	                  <label> Rate : </label>
	    	                  <label className="TxtNrml"> {commonData.rate} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Posted Date: </label>
	    	                  <label className="TxtNrml"> {commonData.postedDate} </label>
	    	              </td>
	    	              <td>
	    	                  <label> &nbsp; </label>
	    	                  <label className="TxtNrml"> &nbsp; </label>
	    	              </td>
            </tr>
     </tbody>
  </table>
}else{

    tbody =<table className="table table-striped table-bordered" width="100%">

    <tbody>
          <tr>
            <td>
                <label> Client Name: </label>
                <label className="TxtNrml"> {commonData.clientName} </label>
            </td>
            <td>
                <label> Account: </label>
                <label className="TxtNrml"> {commonData.account} </label>
            </td>
            <td>
                <label> Product: </label>
                <label className="TxtNrml"> {commonData.product} </label>
            </td>
          </tr>
          <tr>
	              <td>
	                  <label> Nav : </label>
	                  <label className="TxtNrml"> {commonData.nav} </label>
	              </td>
	              <td>
	                  <label> Balance: </label>
	                  <label className="TxtNrml"> {commonData.balance === "Pending"?commonData.balance:addCommaDV(commonData.balance,userLocale,"2","2")} </label>
	              </td>
	              <td>
	                  <label> Shares: </label>
	                  <label className="TxtNrml"> {commonData.shares} </label>
	              </td>
            </tr>
            <tr>
	              <td>
	                  <label> Currency : </label>
	                  <label className="TxtNrml"> {commonData.currency} </label>
	              </td>
	              <td>
	                  <label> Dividend Payment: </label>
	                  <label className="TxtNrml"> {commonData.dividendPayment} </label>
	              </td>
	              <td>
	                  <label> Daily Factor: </label>
	                  <label className="TxtNrml"> {commonData.dailyFactor} </label>
	              </td>
            </tr>
            <tr>
	    	              <td>
	    	                  <label> Rate : </label>
	    	                  <label className="TxtNrml"> {commonData.rate} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Posted Date: </label>
	    	                  <label className="TxtNrml"> {commonData.postedDate} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Fund Type: </label>
	    	                  <label className="TxtNrml"> {commonData.fundType} </label>
	    	              </td>
            </tr>
     </tbody>
  </table>


    }
    }else{
		dataFlag=false;
		tbody = <table className="table table-striped table-bordered" width="100%">
		    <tbody>
		          <tr>
		            <td style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">No Data Found
		            </td>
            </tr>
           </tbody>
           </table>
	}
  }
    return (
      <div>
        <a href="#" onClick={this.handleClickOpen.bind(this,"paper",this.props.rowData)}>
          {linkName}
        </a>
        <Dialog
          open={this.state.open}
          onClose={this.handleClose}
          scroll={this.state.scroll}
          aria-labelledby="scroll-dialog-title"
          fullWidth={true}
          maxWidth = {'md'}
        >
          <DialogTitle id="scroll-dialog-title"> {title}
                {editbtn}
				{actionbtns}
					{/* <button onClick={e => this.enterTrade('TRADEENTRY')} className="btn btn-primary btn-xs mt pull-right">
					Enter Trade
          </button>
					<button onClick={e => this.enterTrade('CLOSEACCOUNT')} className="btn btn-primary btn-xs mt pull-right">
					Close this account
          </button>
					<button onClick={e => this.enterTrade('TRADEHISTORY')} className="btn btn-primary btn-xs mt pull-right">
					Trade History
          </button>
					<button onClick={e => this.enterTrade('EDITACCOUNT')} className="btn btn-primary btn-xs mt pull-right">
					Edit Account Details
          </button> */}
				</DialogTitle>
          <DialogContent>
            <DialogContentText>
              {tbody}
              {subBlk}
	      {
		dataFlag === true ?
		(
		data1 !== undefined ?
		<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
		  <MUIDataTable
		  title=''
		  data={data1}
		  columns={columns1}
		  options={options}
		  />
		</MuiThemeProvider>
		:
		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
		)
		:
		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div></div>
		}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>

          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

export default ScrollDialogPopUp;
