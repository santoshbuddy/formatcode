import React from 'react';
import { Route } from 'react-router-dom';
import MUIDataTable from "mui-datatables";
import TableLoader from '../../common/TableLoader';
import { Link } from 'react-router-dom';
import Typography from '@material-ui/core/Typography';
import ScrollDialog from "../../reports/components/ScrollDialog";
import axios from 'axios';
import { alertConstants } from '../../common/constants/alert.constants';
import Dialog from "@material-ui/core/Dialog";
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';

import { muiTableStyles } from '../../styles/muidatatableCss';

import { MuiThemeProvider } from '@material-ui/core/styles';

import Filters from './Filters';
import Grid from '@material-ui/core/Grid';
import InputLabel from '@material-ui/core/InputLabel';

import { MuiStyles } from '../../styles/MuiStyles';
import { withStyles } from '@material-ui/core/styles';


const styles = theme => ({
  margin: {
    margin: theme.spacing.unit,
  },
});

let loading=true

class ViewChanges extends React.Component {
 constructor(props) {
	    super(props);
	    this.state = {
	    	viewchangesData:[],
 		open: false,
   };
   	    	 this.handleViewChanges=this.handleViewChanges.bind(this);

}

  handleOpen = () => {
     this.handleViewChanges();
   };
  handleClose = () => {
    this.setState({ open: false });
   };

  handleViewChanges() {
    var data;
    var url;

     let changedbodyFormData = this.props.changedbodyFormData;
     var bodyFormData = new FormData();
			bodyFormData.append("selectedCompanyId",changedbodyFormData.get('parentCompany'))
			bodyFormData.append("selectedDeskName",changedbodyFormData.get('selectedDeskName'))

     	bodyFormData.append("selectedBranchId",changedbodyFormData.get('branchId'))
     	bodyFormData.append("selectedBranchName",changedbodyFormData.get('selectedBranchName'))

     	     	bodyFormData.append("selectedClientName",changedbodyFormData.get('selectedClientName'))
     	bodyFormData.append("selectedClient",changedbodyFormData.get('companyId'))
     	bodyFormData.append("prodCatName",changedbodyFormData.get('prodCatName'))
     	bodyFormData.append("prodName",changedbodyFormData.get('prodName'))



     	bodyFormData.append("fromDate",'')
     	bodyFormData.append("toDate",'')
     	bodyFormData.append("product",changedbodyFormData.get('issueChild'))
		bodyFormData.append("curStatus",changedbodyFormData.get('currency'))
		bodyFormData.append("refAcctNbr",'All')
		bodyFormData.append("selectedAcctNature",'ALL')
		bodyFormData.append("chkStatus",'ALL')
				bodyFormData.append("popUpFlag",'POPUP')


     var user = JSON.parse(sessionStorage.getItem('user'));

    	 bodyFormData.append("token",user[0].token)
    	bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
    	axios({
  		method: 'POST',
  		url:alertConstants.URL+"/PRINTADMNMTDAADJPopUp.do",
  		data: bodyFormData,
  		config: { headers: {'Content-Type': 'application/x-www-form-urlencoded' }}
  					  }).then((response)=>{
  					  data = response.data;
   					   console.log('<<data wwwew>>>>'+JSON.stringify(data));
  					   this.setState({ open:true, viewchangesData:data});
  					   console.log('<<data22222dfdfd>>>>'+JSON.stringify(this.state.viewchangesData));
  					   loading=false;
   					  });


 }

  render(){
	    const { classes } = this.props;
   const options = {
            filter: false,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:false,
            rowsPerPage: 5,
			responsive: "scroll",
			fixedHeader: false,
			filter:false,
			search:false,
			print:false,
			download:false,
      		viewColumns:false,
      		pagination: false,
            textLabels: {
                body: {
                     noMatch:  loading ?<TableLoader />:'',
                },
            }
        };
		let columns =[];
		let data =[];
		let screenName='';
		if(this.state.viewchangesData !== undefined ){
 					 this.state.viewchangesData.map((item,index) => {
						    if(item.type === "Title"){
						       screenName = item.name
			   			 }

			});

		var mainList=this.state.viewchangesData.find(item =>item.name ==="columns")// === listName)

 		if(mainList!==undefined && mainList.COLUMNS!==undefined)
		columns = mainList.COLUMNS;


		mainList=this.state.viewchangesData.find(item =>item.name ==="DATA")// === listName)
		if(mainList!==undefined && mainList.DATA!==undefined)
		data = mainList.DATA;


		}
		let filetermarkup;
		if(this.state.viewchangesData !== undefined && this.state.viewchangesData.length>0){
		           filetermarkup = this.state.viewchangesData.map((filter,index) => {
		            if(filter.type === "label"){
		               return (
		                  <Grid item  key={filter.id.toString()}>
		                      <InputLabel className={classes.labelStyle} shrink htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
		                      <InputLabel> { filter.value }</InputLabel>
		                  </Grid>
		               );
		               }

		        });

        }

 return (


      <div style={{float:'right'}}>

		<button className="btn btn-xs btn-primary" onClick={this.handleViewChanges.bind()}> View Changes</button>
        <Dialog  fullWidth={true}
          maxWidth={'md'}
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >


          <DialogContent>
			<div>
				<h4>{screenName}</h4>
			</div>
			<div className="clearfix"></div>
			<br/>
          <div className="filter_div" id="filter_div" >
			{filetermarkup}

			</div>
          <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>

		 <MUIDataTable
		 		  title='ViewChanges'
		 		  data={data}
		 		  columns={columns}
		 		  options={options}
		  />
 			</MuiThemeProvider>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

 export default withStyles(MuiStyles)(ViewChanges);

