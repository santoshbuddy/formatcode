import React from 'react';
import { FormattedMessage, FormattedDate, FormattedNumber, FormattedTime } from 'react-intl';

class Formtters extends React.Component {
    constructor() {
        super()
    }
    render() {
      
        if (this.props.date !== undefined)
            return (
                <FormattedMessage
                    id={"date"}
                    defaultMessage="{day}/{month}/{year}"
                    values={{
                        day: <FormattedDate value={this.props.date} day="2-digit" />,
                        month: <FormattedDate value={this.props.date} month="2-digit" />,
                        year: <FormattedDate value={this.props.date} year="numeric" />
                    }}
                />
            );
        else if(this.props.currency !== undefined){
            console.log("currencyy ==>",this.props.currency)
            return (
                <FormattedNumber
                    value={this.props.currency}
                    style="currency"
                    currency="USD" />
            );
        }
        else if(this.props.datetime !== undefined){
            console.log("datetime ==>",this.props.datetime)
            return (
                <FormattedMessage
                    id={"datetime"}
                    defaultMessage="{day}/{month}/{year} {time}"
                    values={{
                        day: <FormattedDate value={this.props.datetime} day="2-digit" />,
                        month: <FormattedDate value={this.props.datetime} month="2-digit" />,
                        year: <FormattedDate value={this.props.datetime} year="numeric" />,
                        time: <FormattedTime value={this.props.datetime} format="24hour" />                       

                    }}
                />
            );
        }
    }
}

export default Formtters;