import React from 'react';
import { confirmAlert } from 'react-confirm-alert';
import blueAlert from '../../images/blue-alert.png';
import bluealertclose from '../../images/blue-alert-close.png';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';

let message = (sessionStorage.getItem('userLocaleTxt') === null || sessionStorage.getItem('userLocaleTxt')==="en_US")?messageUS:messageTr;


export function showConfirm(myprop, msgs, btype, bodyFormData) {
	confirmAlert({
		closeOnEscape: true,
		customUI: ({ onClose }) => {
			return (
				<div className='custom-ui'>
					<div className="overlay"  id={"overlay"} onClick={(e)=>{clickOverlay(myprop);}} ></div>
					<div className="confirmAlert" id="confirmAlert">
						<div  className="alertTitle">
							<div className="alertHeader">
								<img src={blueAlert} className="Alert"/>
								<h4 className="AlertText">Confirm</h4>
							</div>
							<img src={bluealertclose} onClick={(e)=>{onClose();}} className="alert-close"/>
						</div>
						<div  className="alertContent">{message[msgs]}</div>
						<div className="btn-cls">
							<button className="btn btn-primary btn-xs"
								onClick={(e)=>{
									myprop.confirmAccept(btype, bodyFormData);
									onClose();
								}}>Ok
							</button>
							<button onClick={(e)=>{onClose();}} className="btn btn-primary btn-xs">Cancel</button>
						</div>
					</div>
				</div>
			);
		}
	})
}

export function showAlert(myprop, msgs, eid) {
	confirmAlert({
		closeOnEscape: true,
		customUI: ({ onClose }) => {
			return (
				<div className='custom-ui'>
					<div className="overlay" id={"overlay"} onClick={clickOverlay}></div>
					<div className="confirmAlert" id="alert">
						<div  className="alertTitle">
							<div className="alertHeader">
								<img src={blueAlert} className="Alert"/>
								<h4 className="AlertText">Alert</h4>
							</div>
							<img src={bluealertclose} onClick={(e)=>{onClose();}} className="alert-close"/>
						</div>
						<div className="alertContent">{message[msgs]}</div>
						<div className="btn-cls">
							<button className="btn btn-primary btn-xs"
								onClick={(e)=>{
									if(eid != '' && document.getElementById(eid) != null) {
										document.getElementById(eid).focus();
									}
									//myprop.hideAlert(eid);
									onClose();
								}}>Ok
							</button>
						</div>
					</div>
				</div>
			);
		}
	})
}

export function clickOverlay() {

}