import React from 'react';
import blueAlert from '../../images/blue-alert.png';
import bluealertclose from '../../images/blue-alert-close.png';

class ConfirmLayer extends React.Component {
    constructor(props) {
        super(props);
        this.clickOk = this.clickOk.bind(this);
    }
    clickOk(e){
        document.getElementById("overlay").style.display="none";
        document.getElementById("confirmAlert").style.display="none";
        if(this.props.method !== undefined)
            this.props.method();
    }
    render(){        
        return(
            <div>
            <div className="overlay"  id={"overlay"} onClick={this.clickOverlay}></div>
               <div className="confirmAlert" id="confirmAlert">
                        <div  className="alertTitle">
                            <div className="alertHeader"> 
                                <img src={blueAlert} className="Alert"/>                        
                                <h4 className="AlertText">Confirm</h4>
                            </div>
                            <img src={bluealertclose} onClick={this.handleClose} className="alert-close"/>
                        </div>
                        <div  className="alertContent">
                       {this.props.text}
                        </div>
                    <div className="btn-cls">
                        <button className="btn btn-primary btn-xs" onClick={this.clickOk}>
                            Ok
                        </button>
                        <button onClick={this.handleClose} className="btn btn-primary btn-xs">
                            Cancel
                        </button>
                    </div>
            </div>
            </div>
        )
    }
}

export default ConfirmLayer;