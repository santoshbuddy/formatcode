import React from 'react';
import blueAlert from '../../images/blue-alert.png';
import bluealertclose from '../../images/blue-alert-close.png';

class AlertLayer extends React.Component {
    constructor(props) {
        super(props);
        this.clickOk = this.clickOk.bind(this);
    }
    clickOk(e){
        document.getElementById("overlay").style.display="none";
        document.getElementById("alert").style.display="none";
        if(this.props.method !== undefined)
            this.props.method();
    }
    render(){        
        return(
            <div>
            <div className="overlay"  id={"overlay"} onClick={this.clickOverlay}></div>
               <div className="confirmAlert" id="alert">
                        <div  className="alertTitle">
                            <div className="alertHeader"> 
                                <img src={blueAlert} className="Alert"/>                        
                                <h4 className="AlertText">Alert</h4>
                            </div>
                            <img src={bluealertclose} onClick={this.clickOk} className="alert-close"/>
                        </div>
                        <div  className="alertContent">
                       {this.props.text}
                        </div>
                    <div className="btn-cls">
                        <button className="btn btn-primary btn-xs" onClick={this.clickOk}>
                            Ok
                        </button> 
                    </div>
            </div>
            </div>
        )
    }
}

export default AlertLayer;