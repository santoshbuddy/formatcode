import React from 'react';
// import Button from '@material-ui/core/Button';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';

class LPMButton extends React.Component {
    constructor(props) {
        super(props);

    }
    render(){
		const { classes } = this.props;
		var operFlag = false;
		 //console.log("operVal------------------",JSON.stringify(this.props.operVal));
		if(this.props.operval !== undefined && this.props.operval === '7') {
			operFlag = true;
			//alert("operFlag----------"+operFlag);
		}

        return(
			<span>
			{operFlag===true &&
				<button className="btn btn-primary btn-xs"  
				   {...this.props}
				/>
			}
			</span>
        )
    }
}

const styles = {
	btnFill: {
		color: '#fff',
		backgroundColor: '#0074A6',
		padding: '6px 12px',
		fontSize: '12px',
		marginRight: '10px',
		borderRadius: '6px',
		textTransform: 'capitalize',
		'&:hover':{
			backgroundColor: '#00618C',
		},
		'&:active':{
			backgroundColor: '#00395D',
		}
	}
}

LPMButton.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(LPMButton);