export const alertConstants = {
    SUCCESS: 'ALERT_SUCCESS',
    ERROR: 'ALERT_ERROR',
    CLEAR: 'ALERT_CLEAR',
      //  URL: 'https://sit.privateoxygen.com/fotrd',
      URL: 'https://192.168.21.25:8445/fotrd',
    homePage:'',
    timeOut:30,
    apiTimeOut:30000
};
