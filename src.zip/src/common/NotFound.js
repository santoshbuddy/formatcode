import React from 'react';
import { Link } from 'react-router-dom';
import { NavBar } from '../navbar/components/navbar';
import 'react-datepicker/dist/react-datepicker.css';
import { MuiThemeProvider } from "@material-ui/core/styles";


class NotFound extends React.Component {
    constructor(props) {
        super(props);

        // reset login status
        this.homeAgain = this.homeAgain.bind(this);
     }

	homeAgain() {
		this.props.history.push({
			pathname: '/',
		});
	}



    render() {

        return (
			<div >
				<NavBar/>
				<div className="col-md-12 col-sm-12" style={{textAlign:'center',paddingTop:'100px',paddingBottom:'10px',fontSize:'18px',fontFamily:'sans-serif',fontWeight:'bold'}}>
					There was some error while processing your request..
				</div>
				<div className="clearfix"></div>
				<div className="col-md-12 col-sm-12" style={{textAlign:'center',fontSize:'14px',fontFamily:'sans-serif',fontWeight:'bold'}}>
					Please contact System Administrator.
				</div>
				<div className="clearfix"></div>
				<div style={{textAlign:'center'}}>
					<button className="btn btn-primary btn-xs mt" id="reviewTrade" onClick={this.homeAgain.bind(this)}>Home</button>
				</div>
			</div>
        );
    }
}


 export default NotFound;