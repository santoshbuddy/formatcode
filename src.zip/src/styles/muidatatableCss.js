import { createMuiTheme } from '@material-ui/core/styles';

export const muiTableStyles = {
    getMuiTheme,
 getMuiThemeNoToolBar,
 getMuiThemeNoHeight,
  getstepper
};
function getMuiTheme() {
  return createMuiTheme({
    typography: {
      useNextVariants: true,
      root:{
        fontFamily: 'MyFirstFont',
        src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
      }
    },
    overrides: {
      MuiFormControl: {
        marginNormal: {
          marginTop: '0px',
          marginBottom: '0px',
        }
      },
      MuiFormLabel:{
        root: {          
        fontFamily: 'MyFirstFont',
        src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
        }
      },
      MuiIconButton: {
        root: {
          padding: '2px',
        }
      },
      MuiTable: {
        root: {
          fontFamily: 'MyFirstFont',
          src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
        }
      },
		MuiFilledInput: {
			input: {
					  padding:'4px'
			}
		},	MuiOutlinedInput: {
			input: {
					  padding:'4px'
			}
		},
      //       MuiTableCell: {
      //   root:{
      //     padding: '0px !important',
      //   },
      //   head: {
      //     fontSize: '12px',
      //     font
      //     // fontWeight: '600',
      //     padding: '0px !important'
      //   }
      // },
      MuiTableRow:{
        root: {
          height: 'auto !important',
        },
        hover: {
          '&:hover': {
            backgroundColor: '#E5F1F6 !important',
          }
        }
      },
      MUIDataTableSelectCell:{
        headerCell: {
          border: "1px solid #ccc",
          align : 'center',
          height: '16px !important',
          padding: '0px !important',
          backgroundColor: "#f4f3f3",
        }
      },
      MUIDataTableHeadCell: {
        root: {
          background: '#E4EAED', /* Old browsers */
          background: '-moz-linear-gradient(top, #E4EAED 0%, #F7F9FA 100%)', /* FF3.6-15 */
          background: '-webkit-linear-gradient(top, #E4EAED 0%,#F7F9FA 100%)', /* Chrome10-25,Safari5.1-6 */
          background: 'linear-gradient(to bottom, #E4EAED 0%,#F7F9FA 100%)', /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: 'progid:DXImageTransform.Microsoft.gradient( startColorstr="#E4EAED", endColorstr="#F7F9FA",GradientType=0 )', /* IE6-9 */
          color: '#00395D',
          fontSize: '12px',
          textTransform: 'uppercase',
          textAlign: 'center',
          whiteSpace: 'nowrap',
          verticalAlign: 'bottom',
          height: '48px !important',
          borderRight: '1px solid #d5d5d6',
          borderTop: '1px solid #d5d5d6',
          padding: '0px 15px 9px !important',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6'
          },
        },
        sortActive: {
          color: '#00395D',
        },
        fixedHeader :{
          backgroundColor: "#f4f3f3",
        }
      },
      MuiTableSortLabel:{
        active:{
          color: '#00395D',
        }
      },
      MUIDataTableSelectCell: {
        headerCell: {
          display: 'flex',
          justifyContent: 'center',
          background: '#E4EAED', /* Old browsers */
          background: '-moz-linear-gradient(top, #E4EAED 0%, #F7F9FA 100%)', /* FF3.6-15 */
          background: '-webkit-linear-gradient(top, #E4EAED 0%,#F7F9FA 100%)', /* Chrome10-25,Safari5.1-6 */
          background: 'linear-gradient(to bottom, #E4EAED 0%,#F7F9FA 100%)', /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: 'progid:DXImageTransform.Microsoft.gradient( startColorstr="#E4EAED", endColorstr="#F7F9FA",GradientType=0 )', /* IE6-9 */
          color: '#00395D',
          fontSize: '12px',
          whiteSpace: 'nowrap',
          verticalAlign: 'middle',
          height: '48px !important',
          borderRight: '1px solid #d5d5d6',
          borderTop: '1px solid #d5d5d6',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6',
            borderBottom: '1px solid #d5d5d6'
          },
        },
        root: {
          display: 'flex',
          justifyContent: 'center',
          whiteSpace: 'nowrap',
          padding:'6px',
          textAlign: 'center',
          borderBottom:'0px',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6'
          },
        }
      },

      MUIDataTableBodyCell: {
        root: {
          whiteSpace: 'nowrap',
          fontSize: '14px',
          padding:'6px 9px',
          borderBottom:'0px',
          textAlign: 'left',
          borderRight: '1px solid #d5d5d6',
          borderLeft: '1px solid #d5d5d6',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6'
          },
        }
      },
      MuiTableCell:{
        body:{
          fontSize: '14px',
        },
        head:{
          color: '#00395D',
          fontSize: '12px',
          textTransform: 'uppercase',
        }
      },
      MUIDataTableBodyRow: {
        root: {
          '&:nth-child(even)': {
            backgroundColor: '#F6F7F7'
          },
          '&:last-child':{
            borderBottom: '1px solid #d5d5d6'
          },
        }
      },
      // MUIDataTableToolbar: {
      //   root: {
      //      display: 'block'
      //  }
      // },
      MuiInput:{
        underline:{
          '&:after':{
            border: '0px !important'
          },
          '&:before':{
            border: '0px !important'
          },
        }
      },
      MuiTypography: {
        subtitle1:{
          color: '#ff0000',
          fontFamily: 'MyFirstFont',
          src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
        },
        h6: {
          fontFamily: 'MyFirstFont',
          src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
        }
      },
      MuiGrid: {
        item: {
          display:'inline-flex !important'
        }
      },
      MUIDataTable:{
        responsiveScroll:{
          height: 'auto !important',
          minHeight: 'auto !important',
          maxHeight: '300px !important'
        }
      },
      MUIDataTableSearch: {
        searchText: {
          border: '1px solid #d5d5d6',
          fontSize: '12px',
          paddingLeft: '9px',
          borderRadius: '6px',
        }
      },
      MuiSelect:{
        root: {
          borderRadius: 6,
          background: 'linear-gradient(to bottom, #f2f2f2 0%,#ffffff 100%)',
          border: '1px solid #ced4da',
          height: '30px',
          padding: '0px 9px',
          fontSize: 14,
          '&:hover':{
              background: 'linear-gradient(to bottom, #f5f7fa 0%,#e2e9f0 100%)',
          },
          '&:active': {
              background: 'linear-gradient(to bottom, #99cbe1 0%,#eff6fa 100%)',
          }
        },
        icon: {
          right: '2px'
        },
        select: {
          '&:focus': {
            background: 'rgba(0,0,0,0) !important'
          }
        }
      },
      MuiInputBase:{
        root:{
          fontFamily: 'MyFirstFont',
          src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
        }
      },
      MuiToolbar:{
        regular:{
          minHeight:'48px !important',
          // border: '1px solid #d5d5d6',
          // borderBottom: '0',
        }
      },
      MUIDataTableToolbar:{
        actions:{
          padding:'10px 0'
        }
      },
      MUIDataTableBody:{
        emptyTitle:{
          position: 'absolute',
          marginTop: '-12px',
          // bottom: '15px !important',
          right: '0',
          left: '0',
        }
      },
      MUIDataTable:{
        responsiveScroll:{
          position: 'inherit !important'
        }
      },
      MuiMenu:{
        paper: {
          // top: '51px !important',
          marginTop: '35px !important',
          marginLeft: '-9px !important',
          transform: 'scale(1) !important'
        }
      },
      MuiList: {
        padding:{
          paddingTop: '3px !important',
          paddingBottom: '3px !important' 
        }
      },
      MuiMenuItem: {
        root: {
          fontSize: '14px',
          fontFamily: 'MyFirstFont',
          src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
          height: '30px !important',
        },
        gutters: {
          padding: '0px 9px !important',
          borderTop: '1px solid transparent',
          borderBottom: '1px solid transparent',
        }
      },
      MuiPaper: {
        elevation4:{
          boxShadow: '0 0 0 !important',
        },
        elevation8: {
          border: '1px solid #d5d5d6 !important',
          boxShadow: '0px 1px 2px rgba(88,89,91,0.15) !important',
          maxHeight: '320px !important',
        }
      },
      MuiListItem: {
        root:{
        '&$selected': {
          backgroundColor: '#bfdfed !important',
          borderTop: '1px solid #d5d5d6 !important',
          borderBottom: '1px solid #d5d5d6 !important',
          }
        },
        button:{
          '&:hover':{
            background: '#e5f2f8 !important',
            borderTop: '1px solid #d5d5d6 !important',
            borderBottom: '1px solid #d5d5d6 !important',
          },
        },
      }
    }
  });
};

function getMuiThemeNoToolBar() {
  return createMuiTheme({
    typography: {
      useNextVariants: true,
    },
    overrides: {
      MuiFormControl: {
        marginNormal: {
        marginTop: '0px',
        marginBottom: '0px',
      }
      },
      MuiIconButton: {
        root: {
          padding: '2px',
        }
      },
      MuiTable: {
        root: {
          fontFamily: 'sans-serif',
        }
      },
      // MuiTableCell: {
      //   root:{
      //     padding: '0px !important',
      //   },
      //   head: {
      //     fontSize: '0.8rem',
      //     fontWeight: '600',
      //   }
      // },
      MuiTableRow:{
        root: {
          height: 'auto !important',
        },
        hover: {
          '&:hover': {
            backgroundColor: '#E5F1F6 !important',
          }
        }
      },
      MUIDataTableSelectCell:{
        headerCell: {
          border: "1px solid #ccc",
          align : 'center',
          height: '16px !important',
          padding: '0px 12px !important',
          backgroundColor: "#f4f3f3",
        }
      },
      MUIDataTableHeadCell: {
        root: {
          background: '#E4EAED', /* Old browsers */
          background: '-moz-linear-gradient(top, #E4EAED 0%, #F7F9FA 100%)', /* FF3.6-15 */
          background: '-webkit-linear-gradient(top, #E4EAED 0%,#F7F9FA 100%)', /* Chrome10-25,Safari5.1-6 */
          background: 'linear-gradient(to bottom, #E4EAED 0%,#F7F9FA 100%)', /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: 'progid:DXImageTransform.Microsoft.gradient( startColorstr="#E4EAED", endColorstr="#F7F9FA",GradientType=0 )', /* IE6-9 */
          color: '#00395D',
          fontSize: '12px',
          textAlign: 'center',
          whiteSpace: 'nowrap',
          verticalAlign: 'bottom',
          height: '48px !important',
          padding: '0px 9px 6px !important',
          borderRight: '1px solid #d5d5d6',
          borderTop: '1px solid #d5d5d6',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6'
          },
        },
        sortActive: {
          color: '#00395D',
        },
        fixedHeader :{
          backgroundColor: "#f4f3f3",
        }
      },
      MuiTableSortLabel:{
        active:{
          color: '#00395D',
        }
      },
      MUIDataTableBodyCell: {
        root: {
          whiteSpace: 'nowrap',
          padding:'6px',
          borderBottom:'0px',
          borderRight: '1px solid #d5d5d6',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6'
          },
        }
      },
      MuiTableCell:{
        body:{
          fontSize: '14px'
        },
        head:{
          color: '#00395D',
          fontSize: '12px',
          textTransform: 'uppercase',
        }
      },
      MUIDataTableBodyRow: {
        root: {
          '&:nth-child(even)': {
            backgroundColor: '#F6F7F7'
          },
          '&:last-child':{
            borderBottom: '1px solid #d5d5d6'
          },
        }
      },
      // MUIDataTableToolbar: {
      //   root: {
      //      display: 'block'
      //  }
      // },
      MuiInput:{
        underline:{
          '&:after':{
            border: '0px !important'
          },
          '&:before':{
            border: '0px !important'
          },
        }
      },
      MuiTypography: {
        subtitle1:{
          color: '#ff0000'
        }
      },
      MuiGrid: {
        item: {
          display:'inline-flex !important'
        }
      },
      MUIDataTable:{
        responsiveScroll:{
          height: 'auto !important',
          minHeight: 'auto !important',
          // maxHeight: '300px !important'
        }
      },
      MUIDataTableToolbar: {
        root: {
           display: 'none',
       }
      }
    }
  });
};
function getMuiThemeNoHeight() {
  
  return createMuiTheme({
    typography: {
      useNextVariants: true,
    },
    overrides: {
      MuiFormControl: {
        marginNormal: {
        marginTop: '0px',
        marginBottom: '0px',
      }
      },
      MuiIconButton: {
        root: {
          padding: '2px',
        }
      },
      MuiTable: {
        root: {
          fontFamily: 'sans-serif',
        }
      },
		MuiFilledInput: {
			input: {
					  padding:'4px'
			}
		},	MuiOutlinedInput: {
			input: {
					  padding:'4px'
			}
		},
      MuiTableCell: {
        root:{
          padding: '0px !important',
          color: '#383838',
        },
        head: {
          fontSize: '0.8rem',
          fontWeight: '600',
          padding: '0px !important'
        }
      },
      MuiTableRow:{
        root: {
          height: 'auto !important',
        },
        hover: {
          '&:hover': {
            backgroundColor: '#E5F1F6 !important',
          }
        }
      },
      MUIDataTableSelectCell:{
        headerCell: {
          border: "1px solid #ccc",
          align : 'center',
          height: '16px !important',
          padding: '0px !important',
          backgroundColor: "#f4f3f3",
        }
      },
      MUIDataTableHeadCell: {
        root: {
          background: '#E4EAED', /* Old browsers */
          background: '-moz-linear-gradient(top, #E4EAED 0%, #F7F9FA 100%)', /* FF3.6-15 */
          background: '-webkit-linear-gradient(top, #E4EAED 0%,#F7F9FA 100%)', /* Chrome10-25,Safari5.1-6 */
          background: 'linear-gradient(to bottom, #E4EAED 0%,#F7F9FA 100%)', /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: 'progid:DXImageTransform.Microsoft.gradient( startColorstr="#E4EAED", endColorstr="#F7F9FA",GradientType=0 )', /* IE6-9 */
          color: '#00395D',
          fontSize: '12px',
          textAlign: 'center',
          whiteSpace: 'nowrap',
          verticalAlign: 'middle',
          height: '48px !important',
          borderRight: '1px solid #d5d5d6',
          borderTop: '1px solid #d5d5d6',
          padding: '0px 15px !important',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6'
          },
        },
        sortActive: {
          color: '#00395D',
        },
        fixedHeader :{
          backgroundColor: "#f4f3f3",
        }
      },
      MuiTableSortLabel:{
        active:{
          color: '#00395D',
        }
      },
      MUIDataTableSelectCell: {
        headerCell: {
          display: 'flex',
          justifyContent: 'center',
          background: '#E4EAED', /* Old browsers */
          background: '-moz-linear-gradient(top, #E4EAED 0%, #F7F9FA 100%)', /* FF3.6-15 */
          background: '-webkit-linear-gradient(top, #E4EAED 0%,#F7F9FA 100%)', /* Chrome10-25,Safari5.1-6 */
          background: 'linear-gradient(to bottom, #E4EAED 0%,#F7F9FA 100%)', /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
          filter: 'progid:DXImageTransform.Microsoft.gradient( startColorstr="#E4EAED", endColorstr="#F7F9FA",GradientType=0 )', /* IE6-9 */
          color: '#00395D',
          fontSize: '12px',
          whiteSpace: 'nowrap',
          verticalAlign: 'middle',
          height: '48px !important',
          borderRight: '1px solid #d5d5d6',
          borderTop: '1px solid #d5d5d6',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6',
            borderBottom: '1px solid #d5d5d6'
          },
        },
        root: {
          display: 'flex',
          justifyContent: 'center',
          whiteSpace: 'nowrap',
          padding:'6px',
          textAlign: 'center',
          borderBottom:'0px',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6'
          },
        }
      },

      MUIDataTableBodyCell: {
        root: {
          whiteSpace: 'nowrap',
          padding:'6px',
          borderBottom:'0px',
          textAlign: 'left',
          borderRight: '1px solid #d5d5d6',
          '&:first-child':{
            borderLeft: '1px solid #d5d5d6'
          },
        }
      },
      // MuiTableCell:{
      //   body:{
      //     fontSize: '12px'
      //   },
      //   head:{
      //     color: '#00395D',
      //     fontSize: '12px',
      //   }
      // },
      MUIDataTableBodyRow: {
        root: {
          '&:nth-child(even)': {
            backgroundColor: '#F6F7F7'
          },
          '&:last-child':{
            borderBottom: '1px solid #d5d5d6'
          },
        }
      },
      // MUIDataTableToolbar: {
      //   root: {
      //      display: 'block'
      //  }
      // },
      MuiInput:{
        underline:{
          '&:after':{
            border: '0px !important'
          },
          '&:before':{
            border: '0px !important'
          },
        }
      },
      MuiTypography: {
        subtitle1:{
          color: '#ff0000'
        }
      },
      MuiGrid: {
        item: {
          display:'inline-flex !important'
        }
      },
      MUIDataTable:{
        responsiveScroll:{
          height: 'auto !important',
          minHeight: 'auto !important',
          position:'inherit !important',
        }
      },
      MUIDataTableSearch: {
        searchText: {
          border: '1px solid #d5d5d6',
          fontSize: '12px',
          paddingLeft: '9px',
          borderRadius: '6px',
        }
      },
      MuiSelect:{
        root: {
          borderRadius: 6,
          background: 'linear-gradient(to bottom, #f2f2f2 0%,#ffffff 100%)',
          border: '1px solid #ced4da',
          height: '30px',
          padding: '0px 9px',
          fontSize: 12,
          '&:hover':{
              background: 'linear-gradient(to bottom, #f5f7fa 0%,#e2e9f0 100%)',
          },
          '&:active': {
              background: 'linear-gradient(to bottom, #99cbe1 0%,#eff6fa 100%)',
          }
        }
      },
      MUIDataTableToolbar: {
        root: {
           display: 'none',
        }
      }
    }
  });
};
function getstepper() {
  return createMuiTheme({
    typography: {
      useNextVariants: true,
      fontFamily: 'MyFirstFont',
      src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
    },
    overrides: {
      MuiStepLabel:{
        active:{
          marginTop: '9px !important'
        }
      },
      MuiTypography: {
        body2: {
          fontSize: '14px'
        }
      }
    }
  });
};