import styled from "styled-components";

const CustomCheckBoxOutlined = styled.div`
  display: inherit;
  svg {
    color: #abacad;
  }
  path:last-child {
    color: #007eb6;
  }
`;
export default CustomCheckBoxOutlined;