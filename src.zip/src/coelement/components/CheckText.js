//import DatePicker from 'react-datepicker';
//import 'react-datepicker/dist/react-datepicker.css'
import styled from "styled-components";

export const CheckText = styled.div.attrs({ className: 'CheckText' })`
  .CheckText{
  color:#f00;}
  
  .check_sample{
  width:14px;
  height:14px;
  padding:0px;
  border-color:#D5D5D6
  color:#0074A6
  backgroundColor:#ffffff:
  
  }
  
  
  .MuiSvgIcon-root- {
  width:14px;
  height:14px;
  }
  
  .MuiSvgIcon {
  width:14px;
  height:14px;
  }
  
  .check_sample_label{
  padding: 'codebase' !important;
  label:'codebase' !important;
  margin-left:6px;
  margin-top:3px;
  }
  
   .radio_sample{
  width:14px;
  height:14px;
  margin-left:0px;
  border-color:#D5D5D6
  color:#0074A6
  backgroundColor:#ffffff:
 
  }
  
  .radio_sample_label{
  padding: 'codebase' !important;
  label:'codebase' !important;
  margin-left:6px;
  margin-top:7px;
  }
  
  .MuiInput-inputType-182{
  margin:0px;}
  
  .checkPlanTop{
  width:100%;
 
  }
  .checkPlanBottom{
  width:100%;
  }
  
  
`;
