import { authHeader,fetchHelper } from '../../_helpers';
import { alertConstants } from '../../common/constants/alert.constants';
import FromData from 'form-data';
export const poolService = {
    fetchPool,
    fetchPoolTable,
    submitPoolData
};


function fetchPool() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
    let _poolData;
     var pathname = window.location.pathname.replace("/pool/","")

    if(user[0].token !== undefined){
        filtObj.append("token",user[0].token);
       // filtObj["token"] =user[0].token;
        _poolData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);

    }
    return _poolData;
}
function fetchPoolTable(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _poolTableData;

    var pathname = window.location.pathname.replace("/pool/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("reactJSActionFlag","GO")
        _poolTableData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _poolTableData;
}

function submitPoolData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));
     let _poolData;
     var pathname = window.location.pathname.replace("/pool/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
          bodyFormData.append("reactJSActionFlag","GO")

        _poolData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _poolData;
}