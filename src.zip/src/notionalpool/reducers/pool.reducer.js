import { poolConstants } from '../constants/pool.constants';

export function pooldata(state = {}, action) {
    switch (action.type) {
      case poolConstants.GETPOOLDATA_REQUEST:
        return {
          loading: true
        };
      case poolConstants.GETPOOLDATA_SUCCESS:
        return {
            pooldata: action.pooldata
        };
      case poolConstants.GETPOOLDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

  export function pooldatatable(state = {}, action) {
    switch (action.type) {
      case poolConstants.GETPOOLTBLDATA_REQUEST:
        return {
          loading: true
        };
      case poolConstants.GETPOOLTBLDATA_SUCCESS:
        return {
          pooldatatable: action.pooldatatable
        };
      case poolConstants.GETPOOLTBLDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }