import React from 'react';  
class ConfirmTrade extends React.Component {
     
    render(){
        return(
            <div className="col-md-12">
                <label>Confirm Trade </label>
            </div>
        );
    }
}

export default ConfirmTrade;