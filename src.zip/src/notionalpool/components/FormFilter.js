import React from 'react';
import DatePicker from 'react-datepicker';
import moment from 'moment';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import InputLabel from '@material-ui/core/InputLabel';
import { withStyles } from '@material-ui/core/styles';
 import Button from '@material-ui/core/Button';


import 'react-datepicker/dist/react-datepicker.css';
var dateFormat = require('dateformat');
let formdata={"selectedRegion":"All","countryCode":"All","entiySel":"ALL"}

 const styles = theme => ({
		form: {
		    display: 'flex',
		    flexDirection: 'column',
		    margin: 'auto',
		    width: 'fit-content',
 		  },
		  formControl: {
		    marginTop: 0,
		    paddingRight:50,
		    minWidth: 300,
 		  },
		  formControlLabel: {
		    marginTop: 0,
   		},
	  button: {
	    margin: theme.spacing.unit,
 	  },
	  input: {
	    display: 'none',
	  },
});


class FormFilters extends React.Component {
    constructor () {
        super()
        this.state = {
          startDate: new Date(),
          endDate: new Date(),
          ck : false,
          formdata:{"selectedRegion":"All","countryCode":"All","entiySel":"ALL"}
        };
        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.handleEndDateChange = this.handleEndDateChange.bind(this);
		this.onFilterChange= this.onFilterChange.bind(this);

      }
      componentWillMount(){
		   console.log( 'componentWillMount onFilterChange <><> ');
        this.doChange();
      }
      componentWillReceiveProps(){
        if(this.props.data.pooldata !== undefined){
         this.props.data.pooldata.map((filter,index) => {
          if(filter.type === "datepicker"){
            if(filter.name === "fromDate")
                this.state.startDate=new Date(filter.value)
          }
         });
        }

      }
      onFilterChange(name, ev) {

  			 formdata[name] = ev.target.value;
  			 this.setState({formdata:formdata});
 	 }
      handleStartDateChange(date) {
         this.setState({startDate:date});
      }
      handleEndDateChange(date) {
        this.setState({endDate:date});
     }
     doChange(e){
     		this.props.method(this.state.formdata);
     }

    render(){
          const { data } = this.props;
         const { classes } = this.props;
        let filetermarkup;

        if(data.pooldata !== undefined){
        filetermarkup = data.pooldata.map((filter,index) => {
            if(filter.type === "Select"){
             return(
				 <FormControl    className={classes.formControl} key={'FormControl'+index}>
				 			<InputLabel htmlFor="max-width" key={'input'+index} style={{fontSize:12,}}>  { filter.label } :</InputLabel>
				 			<Select required={false}  id={filter.name} key={'select'+index}
				 				style={{fontSize:12,}}
				 				value={this.state.formdata[filter.name]}
								onChange={this.onFilterChange.bind(this, filter.name)}
								inputProps={{
								name: 'max-width',
								id: 'max-width',
								}}
								>
								{
								filter.values.map((obj,index) => {
								return <MenuItem value={obj.id} key={'option'+obj.id.toString()} >{obj.name}</MenuItem>
								})
								}

				 			</Select>
	 			</FormControl>


               );
            }else if(filter.type === "datepicker"){
                if(filter.name === "fromDate"){


                 return (
                   <div className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                       <label> { filter.label }:</label>
                       {/* <input readOnly ref={ filter.name } name={filter.name} className="form-control" value="Dec 01, 2018" /> */}
                     <DatePicker dateFormat="MMM dd, YYYY" ref={ filter.name } name={filter.name} className="form-control"   selected={this.state.startDate}  onChange={this.handleStartDateChange} />
                   </div>
                 );
                }else if(filter.name === "toDate"){

                 return (
                   <div className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                       <label> { filter.label }:</label>
                       {/* <input readOnly ref={ filter.name } name={filter.name} className="form-control" value="Dec 13, 2018" /> */}
                     <DatePicker dateFormat="MMM dd, YYYY" ref={ filter.name } name={filter.name} className="form-control"  selected={this.state.endDate}   onChange={this.handleEndDateChange} />
                   </div>
                 );
                }
              }else if(filter.type === "Button"){
                return (

                 <Button style={{maxWidth: '25px', maxHeight: '25px', minWidth: '25px', minHeight: '25px'}}  variant="outlined" className={classes.button} color="primary"  onClick={(e)=>{this.doChange();}}> { filter.name } </Button>

               );
              }else if(filter.type === "input"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input ref={filter.name}  defaultValue={filter.name}/>
                  </div>
               );
              }else if(filter.type === "checkbox"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input type="checkbox" ref={filter.name}/>
                  </div>
               );
              }else if(filter.type === "radio"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input type="radio" ref={filter.name}/>
                  </div>
               );
              }else if(filter.type === "textarea"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input type="textarea" className="form-control input-sm" ref={filter.name} />
                  </div>
               );
              }else if(filter.type === "newline"){
                return  <div key="newline" className="clearfix"></div>
              }
        });
    }

        return(
            <div>  <form className={classes.form} noValidate onSubmit={(e) => { e.preventDefault(); alert('Submitted form!');
            		console.log('FROM SUBMISSION :'+JSON.stringify(e.target));
            		} }>
           		 <FormGroup row>
                 {filetermarkup}
                 </FormGroup>
                </form>
            </div>
        );
    }
}
export default withStyles(styles)(FormFilters);

