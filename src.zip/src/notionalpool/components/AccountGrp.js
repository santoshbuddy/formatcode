import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { poolActions } from '../actions/pool.actions';
import { connect } from 'react-redux';
import FormFilter from './FormFilter';
import AccountGrpData from './AccountGrpData';

import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import FormData from 'form-data';

import classNames from 'classnames';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import IconButton from '@material-ui/core/IconButton';
import Tooltip from '@material-ui/core/Tooltip';
import DeleteIcon from '@material-ui/icons/Delete';
import FilterListIcon from '@material-ui/icons/FilterList';
import { lighten } from '@material-ui/core/styles/colorManipulator';
 import Button from '@material-ui/core/Button';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import {error,success,handleMsgClose} from '../../messages/Message';


let formData = {};
  function createData(id,companyId, companyName,acctGrpName, statusTxtId, createdDate, createddBy,modifiedDate,modifiedBy) {
   return { id: id, companyId,companyName, acctGrpName, statusTxtId, createdDate, createddBy,modifiedDate,modifiedBy};
}
let message='';
function desc(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function stableSort(array, cmp) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = cmp(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map(el => el[0]);
}

function getSorting(order, orderBy) {
  return order === 'desc' ? (a, b) => desc(a, b, orderBy) : (a, b) => -desc(a, b, orderBy);
}

let rows = [
{ id: 'companyName', numeric: false, disablePadding: true, label: 'Client Firm Name' },
				   { id: 'acctGrpName', numeric: true, disablePadding: false, label: 'Account Group Name' },
				   { id: 'statusTxtId', numeric: true, disablePadding: false, label: 'Status' },
				   { id: 'createdDate', numeric: true, disablePadding: false, label: 'Created Date' },
				   { id: 'createddBy', numeric: true, disablePadding: false, label: 'Created By' },
				   { id: 'modifiedDate', numeric: true, disablePadding: false, label: 'Last Modified Date' },
				   { id: 'modifiedBy', numeric: true, disablePadding: false, label: 'Modified By' }
];

class EnhancedTableHead extends React.Component {
  createSortHandler = property => event => {
    this.props.onRequestSort(event, property);
  };

  render() {
    const { onSelectAllClick, order, orderBy, numSelected, rowCount } = this.props;

    return (
      <TableHead>
        <TableRow  style={{height:20}}>
          <TableCell padding="checkbox">
            <Checkbox  style={{fontSize:12}}
              indeterminate={numSelected > 0 && numSelected < rowCount}
              checked={numSelected === rowCount}
              onChange={onSelectAllClick}
            />
          </TableCell>
          {rows.map(row => {
            return (
              <TableCell style={{fontSize:12}}
                key={row.id}
                align={row.numeric ? 'right' : 'left'}
                padding={row.disablePadding ? 'none' : 'default'}
                sortDirection={orderBy === row.id ? order : false}
              >
                <Tooltip
                  title="Sort"
                  placement={row.numeric ? 'bottom-end' : 'bottom-start'}
                  enterDelay={300}
                >
                  <TableSortLabel
                    active={orderBy === row.id}
                    direction={order}
                    onClick={this.createSortHandler(row.id)}
                  >
                    {row.label}
                  </TableSortLabel>
                </Tooltip>
              </TableCell>
            );
          }, this)}
           <TableCell style={{width:'10px'}}  >

          </TableCell>
           <TableCell  style={{width:'10px'}} >

          </TableCell>

        </TableRow>
      </TableHead>
    );
  }
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.string.isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

const toolbarStyles = theme => ({
  root: {
    paddingRight: theme.spacing.unit,
  },
  form: {
	display: 'flex',
	flexDirection: 'column',
	margin: 'auto',
	width: 'fit-content',
	 fontSize: 11,
  },
  formControl: {
	marginTop: 0,
	minWidth: 120,
	 fontSize: 11,
  },
  formControlLabel: {
	marginTop: 0,
	 fontSize: 11,
},
  highlight:
    theme.palette.type === 'light'
      ? {
          color: theme.palette.secondary.main,
          backgroundColor: lighten(theme.palette.secondary.light, 0.85),
        }
      : {
          color: theme.palette.text.primary,
          backgroundColor: theme.palette.secondary.dark,
        },
  spacer: {
    flex: '1 1 100%',
  },
  actions: {
    color: theme.palette.text.secondary,
  },
  title: {
    flex: '0 0 auto',
  },
  button: {
	 		height:15,
             padding: 0,
            minWidth:0,
            maxHeight:0,
    },
});

let EnhancedTableToolbar = props => {
  const { numSelected, classes } = props;

  return (
    <Toolbar
      className={classNames(classes.root, {
        [classes.highlight]: numSelected > 0,
      })}
    >
      <div className={classes.title}>
        {numSelected > 0 ? (
          <Typography color="inherit" variant="subtitle1">
            {numSelected} selected
          </Typography>
        ) : (
          <Typography variant="h6" id="tableTitle">
            Account Group Data :
          </Typography>
        )}
      </div>
      <div className={classes.spacer} />
      <div className={classes.actions}>
        {numSelected > 0 ? (
          <Tooltip title="Delete">
            <IconButton aria-label="Delete">
              <DeleteIcon />
            </IconButton>
          </Tooltip>
        ) : (
          <Tooltip title="Filter list">
            <IconButton aria-label="Filter list">
              <FilterListIcon />
            </IconButton>
          </Tooltip>
        )}
      </div>
    </Toolbar>
  );
};

EnhancedTableToolbar.propTypes = {
  classes: PropTypes.object.isRequired,
  numSelected: PropTypes.number.isRequired,
};

EnhancedTableToolbar = withStyles(toolbarStyles)(EnhancedTableToolbar);

const styles = theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
  },
  table: {
    minWidth: 1020,
  },
  tableWrapper: {
    overflowX: 'auto',
  },
});


Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });
class AccountGrp extends React.Component {
    constructor(){
        super();
        this.state={
			message:'',
            results:[],
            results1:[],
            pooldata:[],
            pooldatatable:[],
            columns:[],
            screenName:'',
            from:'',
             order: 'asc',
			orderBy: 'companyName',
			selected: [],
 			data: [],
			page: 0,
			rowsPerPage: 5,
			touched:false,

        }
        this.doChange = this.doChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleClose = this.handleClose.bind(this);

    }
    componentDidMount() {
		//console.log(" IN componentDidMount ")

        this.getFilter();
    }

   getFilter(){
    this.props.dispatch(poolActions.fetchPoolData());
    message='';
   }
componentWillReceiveProps(nextProps) {
 	        if( message !== ''){

			 				let newdata =[];
							let results=[];
				 			let results1  =   nextProps.pooldata.pooldata;
							let screenName="";
							let from="REFRESH";
					        if( results1 !== undefined)
					             results1.map((item,index) => {
				    			if(item.type === "Title")
				                 screenName = item.name

					                if(item.name === "data"){
					                 	results = item.values
										 results.map(grprecord => {
				 							 newdata.push(createData(grprecord.acctGrpId,grprecord.companyId,
											grprecord.companyName, grprecord.acctGrpName,grprecord.statusTxtId, grprecord.createdDate,
											grprecord.createddBy,
											grprecord.modifiedDate,grprecord.modifiedBy))
				 						})
									}
					            })
					            //console.log('componentWillReceiveProps $$$ newdata <><> :'+JSON.stringify(newdata));
								 this.setState({pooldata : nextProps.pooldata,
											 	 pooldatatable :  nextProps.pooldatatable,
													data :newdata, });

 								this.doChange(formData) ;
									message='';

 	        }

    }
	handleSubmit(){
		//console.log('MAIN ONCHANGE formData :'+JSON.stringify(formData));
	//	formData['tableFormFileds'] = this.state.data;

		var bodyFormdata = new FormData();

		for(var k in formData){
		 bodyFormdata.append(k,formData[k])
		}
		 bodyFormdata.append('fromPage','MAIN') ;
		 bodyFormdata.append('actionFlag','MAINEDITSAVE') ;
		 bodyFormdata.append('rowCount',''+ this.state.data.length) ;


		  this.state.data.map((grprecord,index) => {
			  if(this.state.selected.includes(grprecord.id)){
				  bodyFormdata.append('chkmain'+index,'Y') ;
				bodyFormdata.append('selStatus'+index,grprecord.statusTxtId==='Active'?'Y':'N') ;
				bodyFormdata.append('companyId'+index,grprecord.companyId) ;
				bodyFormdata.append('acctGrpId'+index,grprecord.id) ;

		   	 }else {
				 bodyFormdata.append('chkmain'+index,'') ;
			 }

			  bodyFormdata.append('rowCount',''+ this.state.data.length) ;
		  })

	     this.props.dispatch(poolActions.submitPoolData(bodyFormdata));

	      message=success('Saved Successfully.');
	       this.setState({ data:[] });
 	}

  handleClose = (event, reason) => {
    message=handleMsgClose();
  };

   doChange(filterformData){
		formData=filterformData;
		//console.log('MAIN ONCHANGE filterformData :'+JSON.stringify(formData));

      //  formdata :{"selectedRegion":"CEEMEA","countryCode":"SE","entiySel":"37799213"}
       //   this.props.dispatch(poolActions.fetchPoolTableData(bodyFormData));
 	  			let results=[];
 	  			let newdata=[];
   	  	        if( this.state.pooldata.pooldata){

	  	             this.state.pooldata.pooldata.map((item,index) => {

	  	                if(item.name === "data"){
	  	                 	results = item.values
	  						 results.map(grprecord => {
	  						 	  if( filterformData.entiySel === 'ALL'  && filterformData.countryCode === 'All'  && filterformData.countryCode ==='All' )
									 newdata.push(createData(grprecord.acctGrpId,grprecord.companyId,
										 	grprecord.companyName, grprecord.acctGrpName,grprecord.statusTxtId, grprecord.createdDate,
	  										grprecord.createddBy, grprecord.modifiedDate,grprecord.modifiedBy))
								else if(( (filterformData.entiySel !==  'ALL' && grprecord.companyId === filterformData.entiySel )
									||  (filterformData.countryCode !==  'All' && grprecord.companyId === filterformData.countryCode )
									||  (filterformData.selectedRegion !==  'All' && grprecord.companyId === filterformData.selectedRegion))  ){
	  							 	newdata.push(createData(grprecord.acctGrpId,grprecord.companyId,
										grprecord.companyName, grprecord.acctGrpName,grprecord.statusTxtId, grprecord.createdDate,
										grprecord.createddBy, grprecord.modifiedDate,grprecord.modifiedBy))
	  						  }
	  						})
	  					}
	            });
			}
		//console.log('newdata :'+JSON.stringify(newdata));
		this.setState({ data:newdata})



   }


    handleRequestSort = (event, property) => {
       const orderBy = property;
       let order = 'desc';

       if (this.state.orderBy === property && this.state.order === 'desc') {
         order = 'asc';
       }

       this.setState({ order, orderBy });
     };

     handleSelectAllClick = event => {
       if (event.target.checked) {
         this.setState(state => ({ selected: state.data.map(n => n.id) }));
         return;
       }
       this.setState({ selected: [] });
     };

     handleClick = (event, id) => {
       const { selected } = this.state;
       const selectedIndex = selected.indexOf(id);
       let newSelected = [];

       if (selectedIndex === -1) {
         newSelected = newSelected.concat(selected, id);
       } else if (selectedIndex === 0) {
         newSelected = newSelected.concat(selected.slice(1));
       } else if (selectedIndex === selected.length - 1) {
         newSelected = newSelected.concat(selected.slice(0, -1));
       } else if (selectedIndex > 0) {
         newSelected = newSelected.concat(
           selected.slice(0, selectedIndex),
           selected.slice(selectedIndex + 1),
         );
       }

       this.setState({ selected: newSelected });
     };

     handleChangePage = (event, page) => {
       this.setState({ page });
     };

     handleChangeRowsPerPage = event => {
       this.setState({ rowsPerPage: event.target.value });
     };

  isSelected = id => this.state.selected.indexOf(id) !== -1;

    render(){

		//console.log(" IN RENDER ")
		const { classes } = this.props;
		const { data, order, orderBy, selected, rowsPerPage, page } = this.state;
		const emptyRows = rowsPerPage - Math.min(rowsPerPage, data.length - page * rowsPerPage);


		if(this.state.data.length ===0){

				this.state.data =  this.props.data;
			    this.state.pooldata = this.props.pooldata;
				this.state.pooldatatable = this.props.pooldatatable;
				this.state.screenName= this.props.screenName;

		}


        return(
            <div>
                 <NavBar/> 

                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{this.state.screenName}</h4>
                    </div>
                    <div>{message}</div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
                            <FormFilter method={this.doChange} data={this.state.pooldata}/>
                            </div>
                        </div>

                        <div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                                </div>
                            </div>
                            <div>
                             <Paper className={classes.root}>
 							        <div className={classes.tableWrapper}>
							          <Table className={classes.table} aria-labelledby="tableTitle">
							            <EnhancedTableHead
							              numSelected={selected.length}
							              order={order}
							              orderBy={orderBy}
							              onSelectAllClick={this.handleSelectAllClick}
							              onRequestSort={this.handleRequestSort}
							              rowCount={this.state.data.length}
							            />
							            <TableBody>
							              {stableSort(this.state.data, getSorting(order, orderBy))
							                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
							                .map(grprecord => {
							                  const isSelected = this.isSelected(grprecord.id);
							                  return (
							                  <TableRow style={{height:20,padding:0,fontSize:12,}}
												hover

												role="checkbox"
												aria-checked={isSelected}
												tabIndex={-1}
												key={grprecord.id}
												selected={isSelected}
											  >
												<TableCell  style={{width:100,fontSize:12,}}>
												  <Checkbox checked={isSelected} style={{fontSize:12,maxWidth:25, maxHeight:25, minWidth:25, minHeight: 25}} onClick={event => this.handleClick(event, grprecord.id)}  />
												</TableCell >
												<TableCell style={{width:100,padding:0,fontSize:12,}} component="th" scope="row" padding="none">
												  {grprecord.companyName}
												</TableCell>
												 <TableCell style={{width:100,padding:0,fontSize:12,}} >{grprecord.acctGrpName}</TableCell>
												<TableCell style={{width:100,padding:0,fontSize:12,}}>
												<Select required={false} value={grprecord.statusTxtId}
												inputProps={{
												name: 'max-width',
												id: 'max-width',
												}}
												onChange={ev => {
														ev.preventDefault();
 														//console.log('grprecord.statusTxtId '+grprecord.statusTxtId +'<>><>'+ev.target.value);
 														grprecord.statusTxtId=ev.target.value;
 														this.state.touched = this.state.touched?true:false;
 														 }}
 												>
												<MenuItem value="Active" selected={grprecord.statusTxtId==='Active'? true:false}>Active</MenuItem>
												<MenuItem value="In active" selected={grprecord.statusTxtId!=='Active'?true:false}>InActive</MenuItem>
												</Select>
												</TableCell>
												<TableCell style={{width:100,padding:0,fontSize:12,}}>{grprecord.createdDate}</TableCell>
												<TableCell style={{width:100,padding:0,fontSize:12,}}>{grprecord.createddBy}</TableCell>
												<TableCell style={{width:100,padding:0,fontSize:12,}}>{grprecord.modifiedDate}</TableCell>
												<TableCell >{grprecord.modifiedBy}</TableCell>
												<TableCell style={{whiteSpace: 'nowrap'}}>
 												<Button style={{maxWidth: '25px', maxHeight: '25px', minWidth: '25px', minHeight: '25px'}}   variant="outlined" className={classes.button} color="primary"> Edit </Button>
												</TableCell>
												<TableCell>
					 							<Button  style={{float:'right',maxWidth: '25px', maxHeight: '25px', minWidth: '25px', minHeight: '25px'}}  variant="outlined" className={classes.button} color="primary"> New</Button>

 												</TableCell>

                   								 </TableRow>
							                  );
							                })}
							              {emptyRows > 0 && (
							                <TableRow style={{ height: 49 * emptyRows }}>
							                  <TableCell colSpan={6} />
							                </TableRow>
							              )}
							            </TableBody>
							          </Table>
							        </div>

							        <TablePagination
							          rowsPerPageOptions={[5, 10, 25]}
							          component="div"
							          count={this.state.data.length}
							          rowsPerPage={rowsPerPage}
							          page={page}
							          backIconButtonProps={{
							            'aria-label': 'Previous Page',
							          }}
							          nextIconButtonProps={{
							            'aria-label': 'Next Page',
							          }}
							          onChangePage={this.handleChangePage}
							          onChangeRowsPerPage={this.handleChangeRowsPerPage}
							        />
							         <div>
									<Button  style={{margin:'10px 10px 10px 10px', maxWidth: '25px', maxHeight: '25px', minWidth: '25px', minHeight: '25px'}}  variant="outlined" className={classes.button} color="primary"
									onClick={this.handleSubmit}  > Save</Button>
									<Button  style={{margin:'10px 10px 10px 10px', maxWidth: '25px', maxHeight: '25px', minWidth: '25px', minHeight: '25px'}}  variant="outlined" className={classes.button} color="primary"> Clear</Button>
									<Button  style={{margin:'10px 10px 10px 10px',   maxHeight: '25px', minWidth: '25px', minHeight: '25px'}}  variant="outlined" className={classes.button} color="primary"> Create New Group</Button>
									 </div>
    						  </Paper>
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        );
    }
}
AccountGrp.propTypes = {
  classes: PropTypes.object.isRequired,
};
function mapStateToProps(state) {
	//console.log(" IN mapStateToProps ")
    const { pooldata,pooldatatable } = state;

			let data =[];
			let results=[];
 			let results1  =  pooldata.pooldata;
			let screenName="";
			let from="REFRESH";
	        if( results1 !== undefined)
	             results1.map((item,index) => {
    			if(item.type === "Title")
                 screenName = item.name

	                if(item.name === "data"){
	                 	results = item.values
						 results.map(grprecord => {
 							 data.push(createData(grprecord.acctGrpId,grprecord.companyId,
								grprecord.companyName, grprecord.acctGrpName,grprecord.statusTxtId, grprecord.createdDate,
							grprecord.createddBy,
							grprecord.modifiedDate,grprecord.modifiedBy))
 						})
					}
	            })

  //console.log('MAIN ONCHANGE newdata <><> :'+JSON.stringify(data));




    return { pooldata,pooldatatable,data,screenName,from };
}

const connectedAccountGrp = connect(mapStateToProps)(withStyles(styles)(AccountGrp));
export { connectedAccountGrp as AccountGrp };
