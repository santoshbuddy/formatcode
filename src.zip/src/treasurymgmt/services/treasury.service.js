import { authHeader,fetchHelper } from '../../_helpers';
import { alertConstants } from '../../common/constants/alert.constants';
import FromData from 'form-data';
export const treasuryService = {
    fetchReport,
    fetchReportTable,
    fetchTEditReport,
    fetchTSaveReport,
    fetchTDleteReport,
    fetchRFQReport
};

function fetchRFQReport(bodyFormData) {
    //alert("in services... ");
    var user = JSON.parse(sessionStorage.getItem('user'));
    let _reportData;
     var pathname = window.location.pathname.replace("/requestforquote/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _reportData;
}

function fetchReport() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var bodyFormData = new FromData();
    let _reportData;
     var pathname = window.location.pathname.replace("/treasury/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _reportData;
}
function fetchTEditReport() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
    let _reportData;
     var pathname = window.location.pathname.replace("/treasury/","")

    if(user[0].token !== undefined){
        filtObj.append("token",user[0].token);
        filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        filtObj.append("actionFlag",JSON.parse(sessionStorage.getItem('actionFlag')));
        filtObj.append("policyId",JSON.parse(sessionStorage.getItem('policyId')));
        filtObj.append("entiySel",JSON.parse(sessionStorage.getItem('entiySel')));


        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);

    }
    return _reportData;
}
function fetchTSaveReport(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _reportData;
     var pathname = window.location.pathname.replace("/treasury/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _reportData;
}
function fetchTDleteReport(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _reportData;
     var pathname = window.location.pathname.replace("/treasury/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _reportData;
}

function fetchReportTable(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _reportTableData;

    var pathname = window.location.pathname.replace("/treasury/","")
     if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("reactJSActionFlag","GO")
        _reportTableData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _reportTableData;
}