import React from 'react';
import { Router, Route,Link } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { treasuryActions } from '../actions/treasury.actions';
import { connect } from 'react-redux';
import '../../user/css/App.css';
import FormData from 'form-data';
import RFQMUITable from './RFQMUITable';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import 'react-datepicker/dist/react-datepicker.css';
import DatePicker from 'react-datepicker';

var dateFormat = require('dateformat');
class RequestForQuote extends React.Component {
    constructor(props){
        super(props);
        this.state={
            results:[],
            results1:[],
            saveFlag:false,
			selected: {},
			selectAll: 0,
			startDate: new Date(),
			endDate: new Date(),
			tradeDate:new Date()
		}
		this.toggleRow = this.toggleRow.bind(this);
		this.doChange = this.doChange.bind(this);
		this.handleStartDateChange = this.handleStartDateChange.bind(this);
		this.handleToDateChange = this.handleToDateChange.bind(this);
		this.handleTradeDateChange = this.handleTradeDateChange.bind(this);
	}
    componentDidMount() {
		if(this.state.saveFlag==false)
    	   this.getFilter()
	  }

   getFilter(){
	console.log("this.props.location---->")
	console.log(this.props.location)

   	//sessionStorage.setItem('clientFirm', JSON.stringify("81837075"));
   	//sessionStorage.setItem('actionFlag', JSON.stringify(this.props.location.state.actionFlag));
   	//sessionStorage.setItem('policyId', JSON.stringify(this.props.location.state.policyId));
   	//sessionStorage.setItem('entiySel', JSON.stringify(this.props.location.state.entiySel));
       this.props.dispatch(treasuryActions.fetchTreasuryEditData());
   }

doChange(fillObj){
        var bodyFormData = new FormData();
        for (name in fillObj) {
            bodyFormData.append(name, fillObj[name]);
        }
        this.props.dispatch(treasuryActions.fetchReportTableData(bodyFormData));

   }
   toggleRow(product) {
		const newSelected = Object.assign({}, this.state.selected);
		newSelected[product] = !this.state.selected[product];
		this.setState({
			selected: newSelected,
			selectAll: 2
		});
	}

   doRequestForQuote(fillObj1,fillObj2){
	var bodyFormData = new FormData();
	if(fillObj1 !== undefined)
	 for(var i =0; i<fillObj1.length; i++){
		var temp = fillObj1[i].name;
		  //alert(fillObj1[i].type);
		  if((fillObj1[i].type !== "Title") && (fillObj1[i].type !== "datepicker") && (fillObj1[i].type !== "message")){
			//alert(fillObj1[i].name+"--"+this.refs[temp].value);
			bodyFormData.append(temp, this.refs[temp].value);
		  }

		  if(fillObj1[i].type === "datepicker"){
			if(temp === "startDate"){
				bodyFormData.append(temp, dateFormat(this.state.startDate,"mmm d, yyyy"));
			}
			if(temp === "endDate"){
				bodyFormData.append(temp, dateFormat(this.state.endDate,"mmm d, yyyy"));
			}
			if(temp === "tradeDate"){
				bodyFormData.append(temp, dateFormat(this.state.tradeDate,"mmm d, yyyy"));
			}
		   }
		 }

	if(fillObj2 !== undefined)
	 for(var i =0; i<fillObj2.length; i++){
		  var temp = fillObj2[i].name;
		   //alert(fillObj2[i].name+"--"+this.refs[temp].value);
		   bodyFormData.append(fillObj2[i].name, this.refs[temp].value);
		 }
		 bodyFormData.append("actionFlag", "CLIENTSAVE");
		 bodyFormData.append("rfqactionFlag", "CLIENTSAVE");
		 bodyFormData.append("tdPRoducts", "2001");
		 bodyFormData.append("tdTenors", "1");
		//  alert(bodyFormData.get('tradeDate'));
		 // alert(bodyFormData.get('traders'));
		//  alert(bodyFormData.get('rebateRate'));
		//  alert(bodyFormData.get('fees'));
		//  alert(bodyFormData.get('collateral'));
		//  alert(bodyFormData.get('actionFlag'));
		//  alert(bodyFormData.get('rfqTradeAmount'));//reqFrUpdate
		this.state.saveFlag=true;
		this.props.dispatch(treasuryActions.fetchRFQReportData(bodyFormData));
	}

	handleStartDateChange(date) {
		this.setState({startDate:date});
	 }
	 handleToDateChange(date) {
	   this.setState({endDate:date});
	}
	handleTradeDateChange(date) {
		this.setState({tradeDate:date});
	 }

	doClear(){
	   alert("clicked clear button");
	}
    render(){


		let subHead =
			<div className="form-group col-md-12 col-sm-12">
				<label className="col-md-2 col-sm-2 col-xs-2"> Trader Quoted Request:</label>
			</div>;

let filters="";
let secondfilters="";
let screenName="";
let message="";
var results=[],results1=[],results2=[];
console.log("before condition ....")

let requestForQuoteBtn;
        requestForQuoteBtn =
        <Route render={({ history}) => (
            <button  className="btn btn-primary btn-xs"
                type='button'
                onClick={(e)=>{this.doRequestForQuote(results1,results2);}}
                >
                Request For Quote
          </button>
        )} />


console.log(this.state.saveFlag)

	 if(this.state.saveFlag==false && this.props.treasuryeditdata.treasuryeditdata !== undefined){

		results = this.props.treasuryeditdata.treasuryeditdata;
		console.log("results.RFQData testing......")
		//console.log(results.RFQData)
		//this.setState({results:[results.RFQData]})
		//this.state.results=results.RFQData;
		results1.push(results.Title);
		results1.push(results.message);
		results1.push(results.STARTDATEDATA);
		results1.push(results.ENDDATEDATA);
		results1.push(results.QUOTEREQUESTAMOUNTDATA);
		results1.push(results.TRADEDATEDATA);
		results1.push(results.TRADERLISTDATA);
		console.log(results1)

		results2.push(results.REQUESTFORUPDATEDATA);
		results2.push(results.FEESDATA);
		results2.push(results.REBATERATEDATA);
		results2.push(results.COLLATERAL);
	 }
	if(this.state.saveFlag==true && this.props.rfqreportdata.rfqreportdata !== undefined){
		results = this.props.rfqreportdata.rfqreportdata;
		console.log("rfqreportdata results.RFQData testing......")
		//console.log(results.RFQData)
		//this.setState({results:[results.RFQData]})
		//this.state.results=results.RFQData;
		results1.push(results.Title);
		results1.push(results.message);
		results1.push(results.STARTDATEDATA);
		results1.push(results.ENDDATEDATA);
		results1.push(results.QUOTEREQUESTAMOUNTDATA);
		results1.push(results.TRADEDATEDATA);
		results1.push(results.TRADERLISTDATA);
		console.log(results1)

		results2.push(results.REQUESTFORUPDATEDATA);
		results2.push(results.FEESDATA);
		results2.push(results.REBATERATEDATA);
		results2.push(results.COLLATERAL);
	}


if(results1!== undefined){
		//console.log("testing.11111.....")
		console.log(results1)

		let filetermarkup = results1.map((filter,index) => {
			if(filter.type === "message"){
			   message = filter.name
			   //alert(message);
			}
			if(filter.type === "Title")
			   screenName = filter.name
			else if(filter.type === "Select"){
				return(
					<Grid item  key={index}>
						<InputLabel> { filter.label } :</InputLabel>
					  <select ref={ filter.name }  name={filter.name} className="form-control input-sm" >
                      {
                           filter.values && filter.values.map((obj,index) => {
                                return <option key={index} value={obj.id}>{obj.name}</option>
                          })
                       }
                   </select>
					</Grid>
				);
			}else if(filter.type === "input"){
				return (
				 <Grid item  key={index}>
					   <InputLabel> { filter.label } :</InputLabel>
					  <input ref={filter.name} defaultValue={filter.value} className="form-control input-sm" ref={filter.name}/>
				   </Grid>
				);
			   }else if(filter.type === "datepicker"){
                if(filter.name === "startDate"){
                 return (
                  <Grid item  key={filter.name.toString()}>
                       <InputLabel> { filter.label }:</InputLabel>
					  <DatePicker dateFormat="MMM dd, YYYY" ref={ filter.name } name={filter.name} className="form-control"  selected={this.state.startDate}   onChange={this.handleStartDateChange} />
                   </Grid>
                 );
                }else if(filter.name === "endDate"){
					//console.log("end date......")
                 return (
                  <Grid item  key={filter.name.toString()}>
                       <InputLabel> { filter.label }:</InputLabel>
					   <DatePicker dateFormat="MMM dd, YYYY" ref={ filter.name } name={filter.name} className="form-control"  selected={this.state.endDate}   onChange={this.handleToDateChange} />
                   </Grid>
                 );
		         }else if(filter.name === "tradeDate"){
			        return (
					  <Grid item  key={filter.name.toString()}>
				      <InputLabel> { filter.label }:</InputLabel>
				      <DatePicker dateFormat="MMM dd, YYYY" ref={ filter.name } name={filter.name} className="form-control"  selected={this.state.tradeDate}   onChange={this.handleTradeDateChange} />
			        </Grid>
			);
		   }
              }
		})
		filters =  <Grid container spacing={24} >
				  {filetermarkup}
			</Grid>
let secondfiletermarkup = results2 && results2.map((filter,index) => {
	if(filter.type === "input"){
		return (
		 <Grid item  key={index}>
			   <InputLabel> { filter.label } :</InputLabel>
			   <input ref={filter.name} defaultValue={filter.value} className="form-control input-sm" ref={filter.name}/>
		   </Grid>
		);
	   }
})
secondfilters =  <Grid container spacing={24} >
				  {secondfiletermarkup}
			</Grid>

	 }

	 let msg="";
	 msg = <div style={{ color: 'red' }} className="col-md-12 col-sm-12">{message}</div>

        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{screenName}</h4>
                    </div>
					<div className="col-md-12 col-sm-12 head-cls backwhite">

					<div className="filter_div" id="filter_div" >
                            { <Route render={({ history}) => (
                                <button  className="btn btn-primary btn-xs"
                                    type='button'
                                    onClick={() => { history.push('/RFQReport/REQFORQT') }}
                                >
                                   Request For Quote Report
                                </button>
							)} />
							}
                        </div>
			<RFQMUITable  resizable={false} RFQData={results.RFQData} AccountType={results.AccountType} CusipList={results.CusipList} TradeModeList={results.TradeModeList} DataColumns={results.DataColumns} className="table table-striped" />
                        </div>
					<div>{msg}</div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
								{filters}
								<div className="clearfix"></div>
								{subHead}
								<div className="clearfix"></div>
								{secondfilters}
								<div className="col-md-6">
                    				{requestForQuoteBtn}
                    				<a title="Clear" onClick={(e)=>{this.doClear();}} className="btn btn-primary btn-xs">Clear</a>
                				</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		);
    }
}
function mapStateToProps(state) {
    const { treasuryeditdata,rfqreportdata } = state;
    return { treasuryeditdata,rfqreportdata };
}

const connectedRequestForQuote = connect(mapStateToProps)(RequestForQuote);
export { connectedRequestForQuote as RequestForQuote };
