import React from 'react'; 
import { NavBar } from '../../navbar/components/navbar'; 
import { treasuryActions } from '../actions/treasury.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';  
import '../../user/css/App.css';
import FormData from 'form-data';
import { Link } from 'react-router-dom';

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });
 let buttonFlag=true;
class TreasuryTemplate extends React.Component {
    constructor(){	
        super();
        this.state={
            results:[], 
            reportdata:[],  
			selected: {}, 
			selectAll: 0
		}
		this.toggleRow = this.toggleRow.bind(this); 
        this.doChange = this.doChange.bind(this);
    }
    componentDidMount() { 
		this.getFilter()
   }
   getFilter(){
    this.props.dispatch(treasuryActions.fetchReportData());
   }
 
   doChange(fillObj){
        var bodyFormData = new FormData(); 
        for (name in fillObj) { 
            bodyFormData.append(name, fillObj[name]); 
        }
        this.props.dispatch(treasuryActions.fetchReportTableData(bodyFormData)); 
   }
    
   toggleRow(product) { 
		const newSelected = Object.assign({}, this.state.selected);
		newSelected[product] = !this.state.selected[product];
		this.setState({
			selected: newSelected,
			selectAll: 2
		});
	}

	toggleSelectAll() {
		let newSelected = {};
		
		if (this.state.selectAll === 0) {
			this.state.results.forEach(x => {
				newSelected[x.rowNumber] = true;
			});
		}
	 
		this.setState({
			selected: newSelected,
			selectAll: this.state.selectAll === 0 ? 1 : 0
		});
	}

    render(){
		let results1=[],screenName,results,columns=[];
		console.log(this.props.treasuryreportdata.treasuryreportdata)
        this.state.reportdata = this.props.treasuryreportdata.treasuryreportdata;
        results1  = this.state.reportdata;
         
        if( results1 !== undefined)
             results1.map((item,index) => {
                if(item.type === "Title"){
				 screenName = item.name
				 if(item.name === "User Clone")
				    buttonFlag=false;
				}

                if(item.name === "data")
                  results = item.values
            })
        
        if(results !== undefined) { 
            results.map((item,index) => {
                if(index === 0){
                    var s =  item;                     
                    for(var k in s) { 
						if(k === "chktype"){
							columns.push({
								id: "checkbox",
								accessor: "",
								Cell: ({ original }) => { 
									return (
										<input
											type="checkbox"
											className="checkbox"
											checked={this.state.selected[original.rowNumber] === true}
											onChange={() => this.toggleRow(original.rowNumber)}
										/>
									);
								},
								Header: x => {
									return (
										<input
											type="checkbox"
											className="checkbox"
											checked={this.state.selectAll === 1}
											ref={input => {
												if (input) {
													input.indeterminate = this.state.selectAll === 2;
												}
											}}
											onChange={() => this.toggleSelectAll()}
										/>
									);
								} 
							})
						}else if(k === "btntype"){ 
							columns.push({
								id: "btn",
								accessor: "",
								Cell: ({ original }) => {  
									return (
										<div>
											 <Link  className="btn btn-primary btn-xs"  to={{ pathname: '/treasuryedit/TREAPLCY', state: {from:"Edit",actionFlag:"edit" ,policyId:original.selPolicyId ,entiySel:original.selecteEntity} }} >Edit</Link>
											 <Link  className="btn btn-primary btn-xs"  to={{ pathname: '/treasuryedit/TREAPLCY', state: {from:"New",actionFlag:"edit" ,policyId:original.selPolicyId ,entiySel:original.selecteEntity} }} >New</Link>
										</div>
									);
								},
								Header: x => {
									return (
										 ""
									);
								} 
							})
							
						}else if(k!=="rowNumber"){
							columns.push({
							Header: k,
							accessor: k 
							});
						}
                
                    }
                }
            });            
        }

let saveBtn;
let clearBtn;
let createBtn;
if(buttonFlag){
  saveBtn =<a title="Save" onClick={(e)=>{this.doChange();}} className="btn btn-primary btn-xs">Save</a>
  clearBtn = <a title="Clear" onClick={(e)=>{this.doChange();}} className="btn btn-primary btn-xs">Clear</a> 
  createBtn = <a title="Create New Policy" onClick={(e)=>{this.doChange();}} className="btn btn-primary btn-xs">Create New Policy</a> 
}

        return(
            <div>
                <NavBar/> 
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{screenName}</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >              
                            <Filters method={this.doChange} data={results1}/>
                            </div>
                        </div>

                        <div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                                </div>
                            </div>
                            <ReactTable resizable={false} noDataText="No Data Found" data={results} columns={columns}  className="table table-striped" />
							<div className="col-md-6">
								{saveBtn}
								{clearBtn}
								{createBtn}
							</div>							
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
function mapStateToProps(state) { 
	const { treasuryreportdata } = state; 
    return { treasuryreportdata };
}

const connectedTreasuryTemplate = connect(mapStateToProps)(TreasuryTemplate);
export { connectedTreasuryTemplate as TreasuryTemplate };
 