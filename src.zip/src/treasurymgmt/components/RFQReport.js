import React from 'react';
import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import { NavBar } from '../../navbar/components/navbar';
import { treasuryActions } from '../actions/treasury.actions';
import { connect } from 'react-redux';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';  
import '../../user/css/App.css';
import FormData from 'form-data';
import { Button } from '@material-ui/core';
import MTable from './MTable';
import { Route } from 'react-router-dom';

const tableData =  [
   {
      "id":"0",
      "label":"",
      "name":"Request For Quote1",
      "value":"",
      "flag":"",
      "image":"",
      "parentImage":"",
      "toppanelImage":"",
      "token":"",
      "href":"",
      "onclick":"",
      "checked":"",
      "fieldValue":"",
      "loginId":"",
      "companyId":"",
      "action":"",
      "link":"",
      "type":"Title"
   },   
   {
      "id":"1",
      "label":"",
      "name":"data",
      "value":"",
      "flag":"",
      "image":"",
      "parentImage":"",
      "toppanelImage":"",
      "token":"",
      "href":"",
      "onclick":"",
      "checked":"",
      "fieldValue":"",
      "loginId":"",
      "companyId":"",
      "action":"",
      "link":"",
      "type":"data",
      "values":[
         {
            "id":"10",
            "ReferenceID":"RFQ1942",
            "Trader":"Trader, UK - UKTRADER",
            "Currency":"USD",
            "Date":"Oct 25, 2018",
            "Amount":"12,225.00",
            "Rate":"5",
            "Action":"btntype"
         },
         {
            "id":"20",
            "ReferenceID":"RFQ1941",
            "Trader":"Trader, UK - UKTRADER",
            "Currency":"USD",
            "Date":"Oct 25, 2018",
            "Amount":"12,345.00",
            "Rate":"4",
            "Action":"btntype"
         },
         {
            "id":"30",
            "ReferenceID":"RFQ1861",
            "Trader":"TRADER, EUROPE - EUROPETRADER",
            "Currency":"USD",
            "Date":"Oct 17, 2018",
            "Amount":"100,000.00",
            "Rate":"44",
            "Action":"btntype"
         }
      ]
   }
]

// Object.assign(ReactTableDefaults, {
//     defaultPageSize: 5,
//     minRows: 1
// });
class RFQReport extends React.Component {
    constructor(){
        super();
        this.state={
            tableData1:[],
            results:[],
            reportdata:[],
            reportdatatable:[],
            columns:[],
            screenName:''
        }
        this.doChange = this.doChange.bind(this);
    }
    componentDidMount() { 
        //alert("component did amount111");
        this.getFilter()
   }
   getFilter(){
    var bodyFormData = new FormData();
    //alert("component did amount222222");
    bodyFormData.append("actionFlag","REPORT");
    this.props.dispatch(treasuryActions.fetchRFQReportData(bodyFormData));
   }  
   doChange(fillObj){
        var bodyFormData = new FormData(); 
        for (name in fillObj) { 
            bodyFormData.append(name, fillObj[name]); 
        }
        this.props.dispatch(treasuryActions.fetchReportTableData(bodyFormData)); 
        
   }
    render(){
        var RFQRepData=[];
        var results1=[],tableData=[];
        // this.state.reportdata = this.props.reportdata;
        // this.state.reportdatatable = this.props.reportdatatable; 
        // this.state.results1  = this.state.reportdata.reportdata;
        if(this.props.rfqreportdata.rfqreportdata !== undefined){
            RFQRepData=this.props.rfqreportdata.rfqreportdata;
        //console.log("report testing.... ");
        //console.log(RFQRepData);
        tableData.push(RFQRepData.Title);
        tableData.push(RFQRepData.LayerTitle);
        tableData.push(RFQRepData.LayerTraderList);
        tableData.push(RFQRepData.LayerCurrency);
        tableData.push(RFQRepData.LayerTradeAmount);
        tableData.push(RFQRepData.RFQrfrRep);
        //console.log("report testing222.... ");
        //console.log(tableData);

        if( tableData !== undefined)
           tableData.map((item,index) => {
                if(item.type === "Title")
                 this.state.screenName = item.name
                
                if(item.type === "rfrRep"){
                	results1 = item.rfrRep
                	//alert("data assigned ");
                	console.log(results1);
                }
            })
        }
        
        let returnbtn;
	        returnbtn =
	        <Route render={({ history}) => (
	            <button  className="btn btn-primary btn-xs"
	                type='button'
	                onClick={() => { history.push('/requestforquote/REQFORQT') }}
	            >
	                Back
	          </button>
        )} />
        
        return(
            <div>
                <NavBar/> 
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{this.state.screenName}</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12">
                               <MTable data={results1} tableData={tableData} />
                               {returnbtn}
                        </div>                        
                    </div>
                </div>
            </div>
        );
    }
}
function mapStateToProps(state) { 
    const { rfqreportdata } = state;
    return { rfqreportdata };
}

const connectedRFQReport = connect(mapStateToProps)(RFQReport);
export { connectedRFQReport as RFQReport };
 