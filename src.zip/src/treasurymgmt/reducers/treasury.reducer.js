import { treasuryConstants } from '../constants/treasury.constants';

export function rfqreportdata(state = {}, action) {
    switch (action.type) {
      case treasuryConstants.GETRFQREPORTDATA_REQUEST:
        return {
          loading: true
        };
      case treasuryConstants.GETRFQREPORTDATA_SUCCESS:
        return {
          rfqreportdata: action.rfqreportdata
        };
      case treasuryConstants.GETRFQREPORTDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
  
export function treasuryreportdata(state = {}, action) {
    switch (action.type) {
      case treasuryConstants.GETTREASURYDATA_REQUEST:
        return {
          loading: true
        };
      case treasuryConstants.GETTREASURYDATA_SUCCESS:
        return {
          treasuryreportdata: action.treasuryreportdata
        };
      case treasuryConstants.GETTREASURYDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
export function treasuryeditdata(state = {}, action) {
    switch (action.type) {
      case treasuryConstants. GETTREASURYEDITDATA_REQUEST:
        return {
          loading: true
        };
      case treasuryConstants. GETTREASURYEDITDATA_SUCCESS:
        return {
          treasuryeditdata: action.treasuryeditdata
        };
      case treasuryConstants. GETTREASURYEDITDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
export function treasurysavedata(state = {}, action) {
    switch (action.type) {
      case treasuryConstants. GETTREASURYSAVEDATA_REQUEST:
        return {
          loading: true
        };
      case treasuryConstants. GETTREASURYSAVEDATA_SUCCESS:
        return {
          treasurysavedata: action.treasurysavedata
        };
      case treasuryConstants. GETTREASURYSAVEDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
export function treasurydeletedata(state = {}, action) {
    switch (action.type) {
      case treasuryConstants. GETTREASURYDELETEDATA_REQUEST:
        return {
          loading: true
        };
      case treasuryConstants. GETTREASURYDELETEDATA_SUCCESS:
        return {
          treasurydeletedata: action.treasurydeletedata
        };
      case treasuryConstants. GETTREASURYDELETEDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }

  export function treasuryreportdatatable(state = {}, action) { 
    switch (action.type) {
      case treasuryConstants.GETTREASURYTBLDATA_REQUEST:
        return {
          loading: true
        };
      case treasuryConstants.GETTREASURYTBLDATA_SUCCESS: 
        return {
          treasuryreportdatatable: action.treasuryreportdatatable
        };
      case treasuryConstants.GETTREASURYTBLDATA_FAILURE:
        return { 
          error: action.error
        };
         default:
        return state
    }
  } 