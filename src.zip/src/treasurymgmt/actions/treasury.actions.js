import { treasuryConstants } from '../constants/treasury.constants';
import { treasuryService } from '../services/treasury.service';

export const treasuryActions = {
    fetchReportData,
    fetchReportTableData,
    fetchTreasuryEditData,
    fetchTreasurySaveData,
    fetchTreasuryDeleteData,
    fetchRFQReportData
};

function fetchRFQReportData(bodyFormData) {
    //alert("in actions... ");
    return dispatch => {
        dispatch(request());

        treasuryService.fetchRFQReport(bodyFormData)
            .then(
                rfqreportdata => dispatch(success(rfqreportdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: treasuryConstants.GETRFQREPORTDATA_REQUEST } }
    function success(rfqreportdata) { return { type: treasuryConstants.GETRFQREPORTDATA_SUCCESS, rfqreportdata } }
    function failure(error) { return { type: treasuryConstants.GETRFQREPORTDATA_FAILURE, error } }
}

function fetchReportData() {
    return dispatch => {
        dispatch(request());

        treasuryService.fetchReport()
            .then(
                treasuryreportdata => dispatch(success(treasuryreportdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: treasuryConstants.GETTREASURYDATA_REQUEST } }
    function success(treasuryreportdata) { return { type: treasuryConstants.GETTREASURYDATA_SUCCESS, treasuryreportdata } }
    function failure(error) { return { type: treasuryConstants.GETTREASURYDATA_FAILURE, error } }
}
function fetchTreasuryEditData() {
    return dispatch => {
        dispatch(request());

        treasuryService.fetchTEditReport()
            .then(
                treasuryeditdata => dispatch(success(treasuryeditdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: treasuryConstants.GETTREASURYEDITDATA_REQUEST } }
    function success(treasuryeditdata) { return { type: treasuryConstants.GETTREASURYEDITDATA_SUCCESS, treasuryeditdata } }
    function failure(error) { return { type: treasuryConstants.GETTREASURYEDITDATA_FAILURE, error } }
}
function fetchTreasurySaveData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        treasuryService.fetchTSaveReport(bodyFormData)
            .then(
                treasurysavedata => dispatch(success(treasurysavedata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: treasuryConstants.GETTREASURYSAVEDATA_REQUEST } }
    function success(treasurysavedata) { return { type: treasuryConstants.GETTREASURYSAVEDATA_SUCCESS, treasurysavedata } }
    function failure(error) { return { type: treasuryConstants.GETTREASURYSAVEDATA_FAILURE, error } }
}
function fetchTreasuryDeleteData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        treasuryService.fetchTDleteReport(bodyFormData)
            .then(
                treasurydeletedata => dispatch(success(treasurydeletedata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: treasuryConstants.GETTREASURYDELETEDATA_REQUEST } }
    function success(treasurydeletedata) { return { type: treasuryConstants.GETTREASURYDELETEDATA_SUCCESS, treasurydeletedata } }
    function failure(error) { return { type: treasuryConstants.GETTREASURYDELETEDATA_FAILURE, error } }
}
function fetchReportTableData(bodyFormData){  
    return dispatch => {
        dispatch(request());

        treasuryService.fetchReportTable(bodyFormData)
            .then(
                treasuryreportdatatable => dispatch(success(treasuryreportdatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: treasuryConstants.GETTREASURYTBLDATA_REQUEST } }
    function success(treasuryreportdatatable) { return { type: treasuryConstants.GETTREASURYTBLDATA_SUCCESS, treasuryreportdatatable } }
    function failure(error) { return { type: treasuryConstants.GETTREASURYTBLDATA_FAILURE, error } }
 
} 