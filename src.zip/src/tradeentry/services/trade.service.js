import { authHeader,fetchHelper } from '../../_helpers';
import { alertConstants } from '../../common/constants/alert.constants';
import FromData from 'form-data';
export const tradeService = {
    fetchTradeTable,
    fetchReviewData,
    fetchConfirmData,
    fetchFixedTableData,
    fetchFixedReviewData,
    fetchFixedConfirmData,
    fetchTenorupData,
    fetchfutureConfirmData,
    fetchFutureFixedConfirmData,
    fetchFixedRolloverReviewData,
    fetchFixedRolloverConfirmData
};


function fetchTradeTable(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    //var bodyFormData = new FromData();
     var pathname = window.location.pathname;
     let _tradeData;
    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("parentProdId","1700");
        _tradeData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _tradeData;
}

function fetchReviewData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tradeReviewData;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        _tradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/MULTIMMFDEALING.do',bodyFormData);
    }
    return _tradeReviewData;
}


function fetchConfirmData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tradeConfirmData;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        _tradeConfirmData = fetchHelper.httpFormPost(alertConstants.URL+'/MULTIMMFINSERTTRADE.do',bodyFormData);
    }
    return _tradeConfirmData;
}
function fetchfutureConfirmData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _futuretradeConfirmData;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        _futuretradeConfirmData = fetchHelper.httpFormPost(alertConstants.URL+'/MULTIMMFFUTUREINSERTTRADE.do',bodyFormData);
    }
    return _futuretradeConfirmData;
}

function fetchFixedTableData() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var bodyFormData = new FromData();

     let _fixedtradeData;
    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("parentProdId","TERM");
        _fixedtradeData = fetchHelper.httpFormPost(alertConstants.URL+'/DEALING.do',bodyFormData);
    }
    return _fixedtradeData;
}


function fetchFixedReviewData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _fixedTradeReviewData;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("parentProdId","TERM");
        _fixedTradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/TERMDEALING.do',bodyFormData);
    }
    return _fixedTradeReviewData;
}

function fetchFixedRolloverReviewData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _fixedTradeReviewData;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("parentProdId","TERM");
        _fixedTradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/INVESTROLLOVERPOPUP.do',bodyFormData);
    }
    return _fixedTradeReviewData;
}
function fetchFixedRolloverConfirmData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _fixedTradeReviewData;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("parentProdId","TERM");
        _fixedTradeReviewData = fetchHelper.httpFormPost(alertConstants.URL+'/INVESTINSERTTRADE.do',bodyFormData);
    }
    return _fixedTradeReviewData;
}

function fetchFixedConfirmData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _fixedtradeConfirmData;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("parentProdId","TERM");
        _fixedtradeConfirmData = fetchHelper.httpFormPost(alertConstants.URL+'/INVESTINSERTTRADE.do',bodyFormData);
    }
    return _fixedtradeConfirmData;
}
function fetchFutureFixedConfirmData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _fixedtradeConfirmData;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("parentProdId","TERM");
        _fixedtradeConfirmData = fetchHelper.httpFormPost(alertConstants.URL+'/FTRADEINSERTTRADE.do',bodyFormData);
    }
    return _fixedtradeConfirmData;
}
function fetchTenorupData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    let _tenorpopupData;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
           _tenorpopupData = fetchHelper.httpFormPost(alertConstants.URL+'/tenorPopUp.do',bodyFormData);
    }
    return _tenorpopupData;
}