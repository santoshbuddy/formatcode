import React from 'react';
import { Link } from 'react-router-dom';
import ReactTable from "react-table";
import Loading from '../../common/Loading';

class FixedTradeTable extends React.Component {
	constructor(props) {
		super(props);

		this.doSubmit = this.doSubmit.bind(this);
	}
	doSubmit(e){
        this.props.method(e.target.name)
	}
	doRollover(item){

        if(confirm("Are you sure, you want to rollover this trade?")){
			this.props.rollovermethod(item);
		}else{
			return;
		}
	}
	render() {
		var columns = [],rolColumns=[];
		var results = this.props.columns;

        if(results !== undefined) {
           results.map((item,index) => {
               if(item === "Action"){
                columns.push({
                    Header: item,
                    accessor: "",
                    Cell: ({ original }) => {
                        return (
                            <div className="text-center" style={{border: '0px solid red', marginTop:'-5px'}}>
                              <button name={original.rowNumber} id={"fixedTrade"+original.rowNumber} className="btn btn-primary btn-xs" onClick={this.doSubmit.bind(this)}>Trade</button>
                            </div>
                        );
                    }
                })
               }else{
                    columns.push({
                        Header: item,
                        accessor:item
                    });
                }
			});
        }

if(this.props.rollover){
	this.props.rollover.map((item,index)=>{
		if(index === 0){
			for(var k in item){
				if(k === "ALLOW" && item["ALLOW"] === "Y"){
					rolColumns.push({
						Header: "Action",
						accessor: "",
						Cell: ({ original }) => {
							return (
								<button id={"rolloverTrade"+index} className="btn btn-primary btn-xs mt" onClick={this.doRollover.bind(this,item)}>Rollover</button>
							);
						}
					})
				}else if(k!=="TRANSID" && k!== "PPNO" && k!== "oldTransId"){
					rolColumns.push({
						Header:k,
						accessor:k
					});
				}
			}
		}
	})

}
		return (
			<div>
			<table style={{width:'100%'}}>
					<tbody>
					<tr>
						<td style={{width:'70%',paddingRight:'50px'}}>
						{
							this.props.tdata !== undefined ?
							<ReactTable
								data={this.props.tdata}
								columns={columns}
							/>
							:
							this.props.message === undefined &&
							<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
							}
							{
							  this.props.message !== undefined && this.props.tdata === undefined &&
							  <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><div className="alert alert-danger text-center">{this.props.message}</div></div>
							}
							<div className="clearfix"></div>
							<div className="mdBodyBldTxt" style={{marginTop:'1%', marginBottom:'1%'}}>Rollover</div>
							{
							 this.props.rollover !== undefined ?
							     <ReactTable
								className="mt"
								data={this.props.rollover}
								columns={rolColumns}
							   />
							:
							this.props.rollovermsg === undefined &&
							<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
							}
							{
							  this.props.rollovermsg !== undefined && this.props.rollover === undefined &&
							  <div className="col-md-12" style={{marginTop:'1%',marginBottom:'10%'}}><div className="clearfix"></div><div className="alert alert-danger text-center">{this.props.rollovermsg}</div></div>
							}
						</td>
						<td style={{verticalAlign:'top'}}>
							 <table className="table table-striped table-bordered">
								 <thead>
									 <tr>
										 <th>
											 Related Links
										 </th>
									 </tr>
								 </thead>
								 <tbody>
									 <tr>
										 <td>
											 <Link to="">Indicative Rates  </Link>
										 </td>
										</tr>
										<tr>
										 <td>
											 <Link to="">Comparative Rates </Link>
										 </td>
									 </tr>
								 </tbody>
							 </table>
						</td>
					</tr>
					</tbody>
				</table>
 			</div>
		);
	}
}

export default FixedTradeTable;


