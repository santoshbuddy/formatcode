import {replaceChars} from './amountValidations';
import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Grid from '@material-ui/core/Grid';
import { MuiStyles } from '../../styles/MuiStyles';
import { withStyles } from '@material-ui/core/styles';
import LPMButton from '../../common/components/LPMButton';

import { muiTableStyles } from '../../styles/muidatatableCss';

import { MuiThemeProvider } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';



class TermsAndConditions extends React.Component{
    constructor(props) {
	    super(props);
           this.state = {
            open: false,
            termText:this.props.termText !== undefined?this.props.termText:'',
        }
        this.showTermsChanges=this.showTermsChanges.bind(this);
      };


 showTermsChanges = () => {
        this.setState({ open: true });
    };
    handleClose = () => {
        this.setState({ open: false });
    };

    render() {
 const { classes } = this.props;

		return (
			<span style={{float:'right'}} className={classes.root}>
			<a href="#"  onClick={this.showTermsChanges}>Read Terms & Conditions </a>

 				<Dialog  fullWidth={true}
					maxWidth={'md'}
					open={this.state.open}
					onClose={this.handleClose}
					aria-labelledby="form-dialog-title"
					>
					<DialogTitle id="form-dialog-title">Read Terms & Conditions </DialogTitle>
					<DialogContent>
					 <MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
						<div className="panel panel-primary clearfix" style={{clear:'both'}}>

							<div className="panel-body pop-panelbody" style={{width:'800px'}} >
  								 <TextField  onChange={this.handleChange}
								                              error
								                              InputProps={{
								                                            classes: {
								                                              root: classes.input1,
								                                              input: classes.inputFontColor,
								                                              focused: classes.inputFocused
								                                            }
								                                          }}
 								                              InputLabelProps={{
								                                        shrink: true,
								                                  }}
								                              className={classes.textField}
								                              margin="normal" defaultValue={replaceChars(this.state.termText,"<BR>","")}
								                              multiline
								                              rows={15} disabled={true}
								                              rowsMax="200"
								                              id={"termText"}
                        />
 							</div>
						</div>
						</MuiThemeProvider>
					</DialogContent>
					<DialogActions>
						<button onClick={this.handleClose} className="btn btn-primary btn-xs">Close</button>
					</DialogActions>
				</Dialog>
			</span>
		)
    }
}

const styles = {
  root: {
    flexGrow: 1,
    // background: '#e9f0f7',
  },
  AppBar: {
    backgroundColor: '#4e8fcc',
    boxShadow: 'none',
    border: '1px solid #cccccc',
  },
  NavTextLeft: {
    fontSize: '17px',
    fontWeight: 'bold',
    color: 'white',
    textShadow: '1px 1px 1px black',
    flexGrow: 1,
  },
  MainContent: {
    padding: '5px 32px'
  },
  ContentTitle: {
    fontSize: '16px',
    color: '#007eb6',
    fontWeight: 'bold',
    borderBottom: '2px solid #0074A6'
  },
  ContentTitleStyle: {
    background: 'linear-gradient(to bottom, #7fbeda 0%,#bfdfed 100%)',
    border: '1px, solid #d9ecf4',
    fontSize: '16px',
    color: '#007eb6',
    fontWeight: 'bold',
    paddingLeft: 20,
    marginBottom: 5
  },
  ContentBorderStyle: {
    border: '1px solid #99cbe2',
    padding: 10,
  },
  Filter: {
    padding: '10px 5px',
    fontSize: '16px',
  },
  input: {
    width: '100%',
    borderRadius: 6,
    backgroundColor: 'white',
    border: '1px solid #ced4da',
    height: '30px',
    padding: '9px',
    fontSize: 14,
  },
   input1: {
      width: '800px',
      height:'auto',
      borderRadius: 6,
      backgroundColor: 'white',
        padding: '9px',
      fontSize: 14,
  },
  tdinput: {
    width: '90%',
    borderRadius: 6,
    backgroundColor: 'white',
    border: '1px solid #ced4da',
    height: '30px',
    padding: '9px',
    fontSize: 14,
  },
  fromTextStyle: {
    marginLeft: 10,
    fontSize: 14,
    color: "#00395d",
    fontWeight: 'bold'
  },
  inputFocused: {
    borderColor: '#80bdff',
    boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)',
  },
  inputSearchStyle: {
    border: '1px solid #d5d5d6',
    paddingLeft: '9px',
    borderRadius: '6px',
    fontSize: '14px',
  },
  displayFlex: {
    display: 'flex',
    alignItems: 'center',
  },
  formBarStyle: {
    background: 'linear-gradient(to bottom, #cce5f0 0%,#f2f8fb 100%)',
    border: '1px, solid #d9ecf4',
    fontSize: '16px',
    color: 'black',
    fontWeight: 'bold',
    // paddingLeft: 20,
    marginBottom: 5
  },
  Text: {
    fontSize: '12px',
    fontWeight: 'bold',
    color: '#00395D'
  },
  select: {
    borderRadius: 6,
    background: 'linear-gradient(to bottom, #f2f2f2 0%,#ffffff 100%)',
    border: '1px solid #ced4da',
    height: '30px',
    padding: '9px',
    fontSize: 14,
    '&:hover': {
      background: 'linear-gradient(to bottom, #f5f7fa 0%,#e2e9f0 100%)',
    },
    '&:active': {
      background: 'linear-gradient(to bottom, #99cbe1 0%,#eff6fa 100%)',
    }
  },
  tdselect: {
    width:'100%',
    borderRadius: 6,
    background: 'linear-gradient(to bottom, #f2f2f2 0%,#ffffff 100%)',
    border: '1px solid #ced4da',
    height: '30px',
    padding: '9px',
    fontSize: 14,
    '&:hover': {
      background: 'linear-gradient(to bottom, #f5f7fa 0%,#e2e9f0 100%)',
    },
    '&:active': {
      background: 'linear-gradient(to bottom, #99cbe1 0%,#eff6fa 100%)',
    }
  },

  select1: {
    borderRadius: 6,
    background: 'linear-gradient(to bottom, #f2f2f2 0%,#ffffff 100%)',
    border: '1px solid #ced4da',
    height: '30px',
    padding: '9px',
    fontSize: 14,
    '&:hover': {
      background: 'linear-gradient(to bottom, #f5f7fa 0%,#e2e9f0 100%)',
    },
    '&:active': {
      background: 'linear-gradient(to bottom, #99cbe1 0%,#eff6fa 100%)',
    }
  },
  btnFill: {
    color: '#fff',
    backgroundColor: '#0074A6',
    padding: '6px 12px',
    fontSize: '14px',
    marginLeft: '10px',
    borderRadius: '6px',
    '&:hover': {
      backgroundColor: '#00618C',
    },
    '&:active': {
      backgroundColor: '#00395D',
    }
  },
  btnGridFill: {
    color: '#fff',
    backgroundColor: '#0074A6',
    padding: '6px 12px',
    fontSize: '12px',
    marginLeft: '10px',
    borderRadius: '6px',
    textTransform: 'capitalize',
    '&:hover': {
      backgroundColor: '#00618C',
    },
    '&:active': {
      backgroundColor: '#00395D',
    }
  },
  OutputbtnFill: {
    color: '#fff',
    padding: '6px',
    minWidth: '20px',
    // margin: '0px 7px',
    fontSize: '14px',
    borderRadius: '6px',
    '&:hover': {
      backgroundColor: '#00618C',
    },
    '&:active': {
      backgroundColor: '#00395D',
    }
  },
  underbtnStyle: {

  },
  searchIconStyle: {
    color: "#d5d5d6",
    paddding: 0,
  },
  menustyle: {
    background: 'white',
    '&:hover': {
      background: '#e5f2f8',
      border: '1px solid #d5d5d6',
    },
    '&:active': {
      background: '#bfdfed',
    },
    opacity: 1,
    boxShadow: '0px 1px 2px rgb(88,89,91,0.15)',
    maxHeight: 320,
    height: 30,
  },
  footer: {
    marginTop: '20px',
    textAlign: 'center',
    marginBottom: '20px'
  },
  requireStyle: {
    color: 'red',
    paddingLeft:'2px'
  },
  inputFontColor: {
    color: '#595959'
  },
  tddisplayFlex: {
    display: 'inline-flex',
    width:'85%',
  },
  socialtddisplayFlex:{
    display: 'inline-flex',
    width:'60%',
  },
  setttddisplayFlex: {
    display: 'inline-flex',
    width:'95%',
  },
  Itable:{
    width:'100%',
  },
  Setttable:{
    borderCollapse: 'separate',
    borderSpacing: '4px',
    marginBottom:'10px'
  }
};


export default  withStyles(styles)(TermsAndConditions) ;
