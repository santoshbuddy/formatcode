import React from 'react';
import {addCommasAmntLocale} from './amountValidations';
import TenorPopup from './TenorPopup';
import axios from 'axios';
import { alertConstants } from '../../common/constants/alert.constants';

 var res;
class FixedRolloverConfirmTrade extends React.Component {
    constructor(props) {
        super(props);
        this.state={pricnamt:'',pricnamtdisp:'none',rollovervalue:'',rolloverflag:'',nextFlag:'PI',rollovertypetext:'',confirmflag:false,tenor:'1 Day',tenorpopbtn:false,fflag:false,loading:false,clntRateRange:'',ck:'',amount:[],clntRateRange:[],rateFrom:[],rateTo:[],amtvalue:'',Interest_Rate:'',addnotes:'',amtFlag:true,otherAmtVal:''}
         this.doConfirm = this.doConfirm.bind(this);
         this.radioChange = this.radioChange.bind(this);
         this.autorollovertypechange = this.autorollovertypechange.bind(this);
         this.pricnamtChange = this.pricnamtChange.bind(this);
         this.autorollover = this.autorollover.bind(this);
      }

      doSubmit(){
          var submitFlag=true;
          if(this.state.nextFlag === "O"){
            var otherAmt=document.getElementsByName("OtherAmount")[0].value;
            if(otherAmt.length == 0){
              console.log("empty...",otherAmt);
              submitFlag=false;
            }
          }
      	  console.log("jan2019 ... radio flag::",this.state.nextFlag);

          if(submitFlag){
            this.setState({confirmflag:true})
          }else{
             alert("Amount is a mandatory field");
          }
        }
    doConfirm(){
        this.props.method2(res,this.state.rollovertypetext,this.state.nextFlag,this.state.rolloverflag,this.state.rollovervalue,this.state.pricnamt)
    }
    doClose = () =>{
        this.setState({tenorpopbtn:false})
     }
     onSelect = (selectRow) => {
        res.tenorFlag=selectRow.tenorFlag;
        res.durationFrom=selectRow.durationFrom;
        res.durationTo=selectRow.durationTo;

        res.exactDuration=selectRow.exactDuration;
        res.newDuration=selectRow.exactDuration;

        res.maturityDate=selectRow.MaturityDate;
        res.Interest_Rate=selectRow.Rate

        res.interestRate=selectRow.interestRate
        // res.Total_Interest = parseFloat(res.dAmount.replace(/,/g,"")) * parseFloat(res.Interest_Rate)
        this.setState({tenorpopbtn:false})
        this.setState({tenor:selectRow.Tenor})

        var user = JSON.parse(sessionStorage.getItem('user'));

        var jsonBody = new FormData();

        this.props.data && this.props.data.map((item,index) => {
            if(item.name === "data"){
                res = item.values[0].TradeDetails;
            }
        })
        jsonBody.append("dollarAmount",res.dAmount);
        jsonBody.append("ajaxFlag","YES");
        jsonBody.append("product",res.productId);
        jsonBody.append("currencyCode",res.currencyCode);
        jsonBody.append("transType",res.transType);
        jsonBody.append("tenorType",res.tenorType);
        jsonBody.append("deskId",res.deskId);
        jsonBody.append("investAccount",res.investAccount);
        jsonBody.append("branchId",res.branchId);
        jsonBody.append("groupId",res.groupId);
        jsonBody.append("exactDuration",res.exactDuration);
        jsonBody.append("newDuration",res.newDuration);
        jsonBody.append("token",user[0].token);
        jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

        axios({
            method: 'post',
            url:alertConstants.URL+"/INVESTROLLOVERPOPUP.do",
            data: jsonBody,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
            }).then((response)=>{
                console.log(response.data)
                res.Total_Interest = response.data.InterestAmount;
                // res.Interest_Rate = response.data.InterestRate;
                res.dAmount = response.data.dollarAmount;
                this.setState({ck:1});
            });

     }

     radioChange(e){
             //alert(userLocale);
             var validFlag=true;
             var jsonBody = new FormData();
             if(e.target.value === "Principal"){
                 jsonBody.append("dollarAmount",res.Principal);
                 document.getElementsByName("OtherAmount")[0].disabled=true;
                 document.getElementsByName("OtherAmount")[0].value="";
                 this.state.nextFlag = "P";
                 this.state.amtFlag=true;
                 validFlag=true;
             }
             if(e.target.value === "NetAmount"){
                 jsonBody.append("dollarAmount",res.NetAmount);
                 document.getElementsByName("OtherAmount")[0].disabled=true;
                 document.getElementsByName("OtherAmount")[0].value="";
                 this.state.nextFlag = "PI";
                 this.state.amtFlag=true;
                 validFlag=true;
             }
             if(e.target.value === "OtherAmount"){
                 document.getElementsByName("OtherAmount")[0].disabled=false;
                 document.getElementsByName("OtherAmount")[0].value="";
                 this.state.nextFlag = "O";
                 this.state.amtFlag=false;
                 validFlag=false;
             }

            //alert("validFlag::"+validFlag)
     	    if(validFlag){
             var user = JSON.parse(sessionStorage.getItem('user'));
             jsonBody.append("ajaxFlag","YES");
             jsonBody.append("product",res.productId);
             jsonBody.append("currencyCode",res.currencyCode);
             jsonBody.append("transType",res.transType);
             jsonBody.append("tenorType",res.tenorType);
             jsonBody.append("deskId",res.deskId);
             jsonBody.append("investAccount",res.investAccount);
             jsonBody.append("branchId",res.branchId);
             jsonBody.append("groupId",res.groupId);
             jsonBody.append("exactDuration",res.exactDuration);
             jsonBody.append("newDuration",res.newDuration);
             jsonBody.append("token",user[0].token);
             jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

             axios({
                 method: 'post',
                 url:alertConstants.URL+"/INVESTROLLOVERPOPUP.do",
                 data: jsonBody,
                 config: { headers: {'Content-Type': 'multipart/form-data' }}
                 }).then((response)=>{
                     console.log(response.data)
                     res.Total_Interest = response.data.InterestAmount;
                     res.Interest_Rate = response.data.InterestRate;
                     res.dAmount = response.data.dollarAmount;
                     this.setState({ck:1});
                 });
             }
     }
     amountChange(e,userLocale){
       //alert(e.target.value);
       //alert(userLocale);
         var validFlag=true;
         var res;
       this.props.data && this.props.data.map((item,index) => {
	   if(item.name === "data"){
	       res = item.values[0].TradeDetails;
	       //console.log("jan2019 jan31::res.maxDollar:",res.maxDollar+":res.minDollar:",res.minDollar);
	   }
        })
        addCommasAmntLocale(e,userLocale,true);

        if(e.target.value.length == 0 ){
          validFlag=false;
          //console.log("jan2019 e.target.value value::",e.target.value);
        }
        if((parseFloat(e.target.value.replace(/,/g,"")) > parseFloat(res.maxDollar)) || (parseFloat(e.target.value.replace(/,/g,"")) < parseFloat(res.minDollar))){
                   alert("Please enter the Amount between "+res.minDollar+" and "+res.maxDollar);
                   document.getElementsByName("OtherAmount")[0].value="";
                   validFlag=false;
        }
        if(validFlag){
          var jsonBody = new FormData();
          		if(e.target.name === "OtherAmount"){
          		    //alert("else block ",e.target.value);
	                   jsonBody.append("dollarAmount",e.target.value);
	               }

	               var user = JSON.parse(sessionStorage.getItem('user'));

	               jsonBody.append("ajaxFlag","YES");
	               jsonBody.append("product",res.productId);
	               jsonBody.append("currencyCode",res.currencyCode);
	               jsonBody.append("transType",res.transType);
	               jsonBody.append("tenorType",res.tenorType);
	               jsonBody.append("deskId",res.deskId);
	               jsonBody.append("investAccount",res.investAccount);
	               jsonBody.append("branchId",res.branchId);
	               jsonBody.append("groupId",res.groupId);
	               jsonBody.append("exactDuration",res.exactDuration);
	               jsonBody.append("newDuration",res.newDuration);
	               jsonBody.append("token",user[0].token);
	               jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

	               axios({
	                   method: 'post',
	                   url:alertConstants.URL+"/INVESTROLLOVERPOPUP.do",
	                   data: jsonBody,
	                   config: { headers: {'Content-Type': 'multipart/form-data' }}
	                   }).then((response)=>{
	                       console.log(response.data)
	                       res.Total_Interest = response.data.InterestAmount;
	                       res.Interest_Rate = response.data.InterestRate;
	                       res.dAmount = response.data.dollarAmount;
	                       this.setState({ck:1});
                 });
             }

     }

     autorollover(e){
        if(e.target.checked) {
            document.getElementById("rollovertype").disabled =false;
            this.state.rolloverflag = "Y";
        }else
            document.getElementById("rollovertype").disabled =true;

     }
     autorollovertypechange(e){
        this.state.rollovervalue = e.target.value;
        var temp = document.getElementById("rollovertype").options[e.target.selectedIndex].text;
        this.state.rollovertypetext = temp
        if(e.target.value === "102"){
            this.setState({pricnamtdisp:"block"})
        }
     }
     pricnamtChange(e){
        this.state.pricnamt = e.target.value;
     }
     goConfirmBack()
     {
        this.setState({confirmflag:false})
     }
   render(){
       //console.log("jan2019 amtFlag:***::",this.state.amtFlag);
       let userLocale="";
       var user = JSON.parse(sessionStorage.getItem('user'));
       	if(user[0].localeLang !== undefined){
       		userLocale=user[0].localeLang;
       	}
	//alert(userLocale);

       let entertrademarkup,tradedate,tradeDetails;
       let buttonMarkup,backButton;

       if(this.props.data !== undefined){
           if(this.props.data[0].name === "data")
           res = this.props.data[0].values[0].TradeDetails;

           tradedate =
               <div>
                   <div  className="form-group col-md-2 col-sm-2">
                       <label> Today ({res.actualToday}) </label>
                   </div>

               </div>

           entertrademarkup =
                <div className="col-md-12">
                <div className="form-group col-md-4">
                        <label  className="pull-left"> Investment Account:</label>
                        <label className=" TxtNrml"> { res.investAccountName } (<b>{res.currencyCode}</b>)</label>
                    </div>
                    <div className="form-group col-md-3">
                        <label  className="pull-left"> Funding Account:</label>
                        <label className=" TxtNrml"> { res.fundingAccountName }</label>
                    </div>
                    <div className="form-group col-md-3">
                        <label  className="pull-left"> Maturity Account:</label>
                        <label className=" TxtNrml"> { res.maturityAccountName }</label>
                    </div>
                </div>


	if(this.state.confirmflag !== true ){
	   buttonMarkup=<button className="btn btn-primary btn-xs mt pull-right" id="reviewTrade" onClick={this.doSubmit.bind(this)}>Review Trade</button>
	   backButton=<button className="btn btn-primary btn-xs mt" id="back" onClick={this.props.goback}>Back</button>
	}
	if(this.state.confirmflag === true ){
	    buttonMarkup=<button className="btn btn-primary btn-xs mt pull-right" id="confirmTrade" onClick={this.doConfirm.bind(this)}>Confirm Trade</button>
	    backButton=<button className="btn btn-primary btn-xs mt" id="back" onClick={this.goConfirmBack.bind(this)}>Back</button>
	}

             tradeDetails =
                <div  key="tradedetails">
                    <table className="table table-bordered" width="100%">
                        <tbody>
                        <tr>
                            <td width="30%" className="paddAll">
                               <div  className="form-group">
                                   <label className="pull-left">Value Date:</label>
                                   <label className="TxtNrml">{res.valueDate}</label>
                               </div>
                               <div className="clearfix"></div>
                               {

                                   this.state.confirmflag !== true &&
                                   <div>
                                    <div  className="form-group">
                                        <label className="pull-left">Investment Amount:</label>
                                        <div className="clearfix"></div>
                                        <input type="radio" name="amount" value="Principal" onChange={this.radioChange}/><label>Principal</label>
                                        <label className="pull-right TxtNrml">{res.Principal} {res.currencyCode}</label>
                                        <div className="clearfix"></div>
                                        <input type="radio" name="amount" value="NetAmount"  onChange={this.radioChange} defaultChecked={true}/><label>Net Amount</label>
                                        <label className="pull-right TxtNrml">{res.NetAmount} {res.currencyCode}</label>
                                        <div className="clearfix"></div>
                                        <input type="radio" name="amount" value="OtherAmount"  onChange={this.radioChange} /><label>Other Amount </label>
                                        <div className="clearfix"></div>
                                            <input type="text" id={"OtherAmount"} name={"OtherAmount"} disabled={this.state.amtFlag} onBlur={(e)=>{this.amountChange(e,userLocale)}}/>{res.currencyCode}
                                    </div>
                                    <div className="clearfix"></div>
                                    <label>Min. {parseFloat(res.minDollar).toFixed(4)} - Max. {parseFloat(res.maxDollar).toFixed(4)} </label>
                                    <div className="clearfix"></div>
                                    <div  className="form-group ">
                                    <select name="rollovertype" id="rollovertype" onChange={this.autorollovertypechange} disabled={true} ref="rollovertype" className="form-control col-md-3">
                                        {
                                            res.rollovertype && res.rollovertype.map((obj,index) => {
                                                return <option key={index} value={obj.id}>{obj.value}</option>
                                            })
                                        }
                                    </select>
                                    <input type="checkbox" name="autorollover" id="autorollover" onClick={this.autorollover}/> Auto Rollover
                                    <input type="text" name="pricnamt" id="pricnamt" style={{display:this.state.pricnamtdisp}} onBlur={this.pricnamtChange}/>
                                </div>
                                   </div>
                               }

                               {
                                   this.state.confirmflag === true &&
                                   <div>
                                        <div  className="form-group">
                                            <label className="pull-left">Investment Amount:</label>
                                            <div className="clearfix"></div>
                                            <label  className="TxtNrml">{res.dAmount}&nbsp;&nbsp;</label><span style={{textAlign : 'center', fontWeight: 'bold', color: "black"}}>{res.currencyCode}</span>
                                        </div>
                                        <div  className="form-group">
                                            <label className="pull-left">Rollover:</label>
                                            <div className="clearfix"></div>
                                            <label className="TxtNrml">{this.state.rollovertypetext}</label>
                                        </div>
                                    </div>
                               }
                            </td>
                            <td width="30%" className="paddAll">
                               <div  className="form-group">
                                   <label className="pull-left">Maturity Date:</label>
                                   <label className="TxtNrml">{res.maturityDate}</label>
                               </div>
                               {
                                   this.state.confirmflag !== true &&
                                    <button className="btn btn-primary btn-xs" id="tenor" onClick={ev => {  this.setState({tenorpopbtn:true})}}>Tenor</button>
                               }
                                <TenorPopup open={this.state.tenorpopbtn} doClose={this.doClose}  issueChild={res.productId} 	currency={res.currency} tenorType={res.tenorType} companyid={res.deskId} transDate={res.transDate}
                                investAccount={res.investAccount}  groupId={res.groupId} branchId={res.branchId} onSelect={this.onSelect} amount={this.state.amtvalue} transType={res.transType} prodCat={res.prodCat} futureFlag={this.state.dateshow}/>
                            </td>
                            <td className="paddAll">

                               <div  className="form-group">
                                   <label className="pull-left">Product:</label>
                                   <label className="pull-right TxtNrml">{res.productName}</label>
                               </div>
                               <div className="clearfix"></div>
                               <div  className="form-group">
                                   <label className="pull-left">Amount:({res.currencyCode})</label>
                                   <label className="pull-right TxtNrml">{res.dAmount}</label>
                               </div>
                               <div className="clearfix"></div>
                               <div  className="form-group">
                                   <label className="pull-left">Interest Rate:({res.exactDuration} Days)</label>
                                   <label className="pull-right TxtNrml">{res.Interest_Rate}%</label>
                               </div>
                               <hr/>
                               <div className="clearfix"></div>
                               <div  className="form-group">
                                   <label className="pull-left">Total Interest:({res.currency})</label>
                                   <label className="pull-right TxtNrml">{res.Total_Interest}</label>
                               </div>
                               <div className="clearfix"></div>
                               {
                                    this.state.confirmflag === true &&
                                <div  className="form-group">
                                        <label className="pull-left">Total Amount:({res.currency})</label>
                                        <label className="pull-right TxtNrml">{(parseFloat(res.dAmount.replace(/,/g,""))+parseFloat(res.Total_Interest.replace(/,/g,""))).toFixed(4)}</label>
                                    </div>
                               }
                               <div className="clearfix"></div>
                               <div  className="form-group">
                                   <label className="pull-left">Cut-Off time:</label>
                                   <label className="pull-right TxtNrml">{res.cutOffTime}</label>
                               </div>
                               <div className="clearfix"></div>
                               <div  className="form-group">
                                   <label className="pull-left">Trading Hours:</label>
                                   <label className="pull-right TxtNrml">{res.beginTime} to {res.endTime}</label>
                               </div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
            </div>
        }

        return(
           <div className="col-md-12">
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Trade Date </h4>
                    </div>
                    <div className="panel-body">
                        {tradedate}
                    </div>
                </div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Accounts</h4>
                    </div>
                    <div className="panel-body">
                            {entertrademarkup}
                    </div>

                </div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Trade Details </h4>
                    </div>
                    <div className="panel-body">
                            {tradeDetails}
                    </div>
                    </div>
                    {backButton}
                    {buttonMarkup}
       </div>
       )
    }
}
export default FixedRolloverConfirmTrade;