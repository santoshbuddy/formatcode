import React from 'react';
import { Link } from 'react-router-dom';
import ReactTable from "react-table";
import Loading from '../../common/Loading';
import { CustomRadio } from '../../styles/CustomRadio';
import CustomPagination from './CustomPagination'
import LPMButton from '../../common/components/LPMButton';
import ErrorMessage from '../../common/components/ErrorMessage';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts'
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts'
import { showConfirm, showAlert } from '../../common/components/showConfirmLayer';

let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;


var newSelected = Object.assign({}, {});
class TradeTable extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			loading: true, selected: {}, selectAll: 0, data: '', checkedCnt: 0, page: 0,
			rowsPerPage: 5,
            errorMessage:'',
			selectedCount: 0 
		};
		this.externalWindow = null;
		this.toggleRow = this.toggleRow.bind(this);
		this.doSubmit = this.doSubmit.bind(this);
		this.doFundSheetInfo = this.doFundSheetInfo.bind(this);
	}

	toggleRow(product) {
		// const newSelected = Object.assign({}, this.state.selected);
		// newSelected[product] = !this.state.selected[product];
		// this.setState({
		// 	selected: newSelected,
		// 	selectAll: 2
		// });

		// var cCnt = 0;
		//     for(var k in newSelected){
		//          if(newSelected[k]) {
		// 	 	cCnt++;
		// 	 }
		//     }

		// this.setState({ checkedCnt: cCnt });
		newSelected[product] = !this.state.selected[product];
		this.setState({
			selected: newSelected
		});
		newSelected = {}
	}

	doFundSheetInfo(itm, k, e) {
		if (k === 'KIID')
			this.externalWindow = window.open(itm['KIID'], '', 'width=800,height=500,left=10,top=10,resizable=yes');
		else
			this.externalWindow = window.open(itm['Fact Sheet'], '', 'width=800,height=500,left=10,top=10,resizable=yes');

	}

	toggleSelectAll() {
		let newSelected = {};

		if (this.state.selectAll === 0) {
			this.props.tdata.forEach(x => {
				newSelected[x.rowNumber] = true;
			});
		}

		this.setState({
			selected: newSelected,
			selectAll: this.state.selectAll === 0 ? 1 : 0
		});

		var cCnt = 0;
		for (var k in newSelected) {
			if (newSelected[k]) {
				cCnt++;
			}
		}

		this.setState({ checkedCnt: cCnt });
	}
	isEmpty(obj) {
		for (var key in obj) {
			if (obj.hasOwnProperty(key))
				return false;
		}
		return true;
	}
	doSubmit() {
		if (this.isEmpty(this.state.selected))
			showAlert(this,message["PSAFTT"]);
		else
			this.props.method(this.state.selected)
	}
	handleChangePage = (event, page) => {
		this.setState({ page });
	};
	handleChangeRowsPerPage = event => {
		this.setState({ page: 0, rowsPerPage: event.target.value });
	};
	 
	render() {
		const { rowsPerPage, page, selectedCount } = this.state;
		//console.log("this.props.operValDet-----"+JSON.stringify(this.props.operValDet));
		var columns = [];
		var results = this.props.columns;
		columns.push({
			id: "checkbox",
			accessor: "",
			Cell: ({ original }) => {
				if (original["EOD Cut-Off Time"] === "Suspended" || original["EOD Cut-Off Time"] === "Active Investment Not Allowed")
					return (
						<CustomRadio>
							<input style={{ marginLeft: '0px' }}
								type="radio"
								disabled="true"
								className="checkbox"
								name='radio'
								id={"mmfcheck" + original.rowNumber}
								checked={this.state.selected[original.rowNumber] === true}
								onChange={() => this.toggleRow(original.rowNumber)}
							/>
							<span></span>
						</CustomRadio>
					);
				else
					return (
						<CustomRadio>
							<input style={{ marginLeft: '0px' }}
								type="radio"
								className="checkbox"
								name='radio'
								id={"mmfcheck" + original.rowNumber}
								checked={this.state.selected[original.rowNumber] === true}
								onChange={() => this.toggleRow(original.rowNumber)}
							/>
							<span className="radiochk"></span>
						</CustomRadio>
					);
			},
			sortable: false,
			width: 23,
			style: {'padding':'4px'}
		})
		if (results !== undefined) {
			results.map((item, index) => {
				if (item === "Product") {
					columns.push({
						Header: item,
						accessor: item,
						style: { 'whiteSpace': 'nowrap' },
						width: 300
					});
				} else if (item === "Fund Type") {
					columns.push({
						Header: item,
						accessor: item,
						style: { 'whiteSpace': 'nowrap' },
						width: 70
					});
				} else if (item === "Currency") {
					columns.push({
						Header: item,
						accessor: item,
						style: { 'whiteSpace': 'nowrap' },
						width: 80
					});
				}else if (item === "Portfolio Number") {
					columns.push({
						Header: item,
						accessor: item,
						style: { 'whiteSpace': 'nowrap' },
						width: 200
					});
				}else if (item === "Cut-Off Time to Invest") {
					columns.push({
						Header: item,
						accessor: item,
						style: { 'whiteSpace': 'nowrap' },
						width: 220
					});
				}
				else if (item === "Account Number") {
					columns.push({
						Header: item,
						accessor: item,
						style: { 'whiteSpace': 'nowrap' },
						width: 100
					});
				} else if (item === "Fact Sheet" || item === "KIID") {
					columns.push({
						Header: item,
						accessor: item,
						style: { 'whiteSpace': 'nowrap' },
						Cell: ({ original }) => {
							// console.log('original--original--', original)
							return (
								<a href="javascript:void(0)" onClick={e => this.doFundSheetInfo(original, item, event)}>{item}</a> //Fact Sheet
							);
						},
						sortable: false,
						width: 150
					});
				} else {
					columns.push({
						Header: item,
						accessor: item,
						style: { 'whiteSpace': 'nowrap' },
						width: 'auto'
					});
				}
			});
		}
		let msg = 'block';
		if (this.props.message !== undefined) {
			msg = 'none';
		}
		return (
			<div>
				 
				{/* <div style={{display:msg}}>
				  <label>Select accounts to trade in below</label>  or  <Link to="/uploadtrade">upload bulk trade template</Link>
				</div> */}
				<table className="w100">
					<tbody>
						<tr>
							<td>
								{
									this.props.tdata !== undefined ?
										<ReactTable
											PaginationComponent={pagiNationProps => <CustomPagination
												pagiNationProps={pagiNationProps}
												type={"senario1"} />}

											data={this.props.tdata}
											count={this.props.tdata.length}
											columns={columns}
											showPagination={true}
											resizable={false}
											defaultPageSize={rowsPerPage}
										/>
										:
										this.props.message === undefined &&
										<div className="col-md-12 mt-mb"><div className="clearfix"></div><Loading /></div>

								}
								{
									this.props.message !== undefined &&
										<ErrorMessage text={this.props.message} type={'alert'} lang="en"/>
									// <div className="col-md-12 mt-mb"><div className="clearfix"></div><div className="alert alert-danger text-center">{this.props.message}</div></div>
								}
							</td>
							{/*<td style={{verticalAlign:'top'}}>
							 <table className="table table-striped table-bordered">
								 <thead>
									 <tr>
										 <th>
											 Related Links
										 </th>
									 </tr>
								 </thead>
								 <tbody>
									 <tr>
										 <td style={{whiteSpace:"nowrap"}}>
											 <Link to="/administrationcreate/NEWMMDAACCT">Open a new Money Fund account </Link>
										 </td>
										</tr>
									 <tr>
										 <td>
											 <Link to="">Download bulk trade template  </Link>
										 </td>
									 </tr>
								 </tbody>
							 </table>
						</td>*/}
						</tr>
					</tbody>
				</table>

				{/* <div style={{display:msg}}>
				  <label>Number of accounts selected:{this.state.checkedCnt} </label>| <a>download bulk template for selected accounts</a>
				</div> */}
				<div className="clearfix"></div>

				{
					msg !== 'none' &&
					<div className="mrgn10 text-right">
						{/*<button id="mmftrade" className="btn btn-primary btn-xs mt" onClick={this.doSubmit.bind(this)}>Trade</button>*/}
						<LPMButton id="mmftrade" style={{margin:'10px 0px'}} operval={this.props.operValDet} buttonaction={"Trade"} onClick={this.doSubmit.bind(this)}>Enter Trade</LPMButton>
					</div>
				}
			</div>
		);
	}
}

export default TradeTable;