import React from 'react';
import {IsCharsInBag} from './amountValidations';
import {addCommasAmntLocale} from './amountValidations';
import {rateDecimalChange} from './amountValidations';
import {isValidBusinessDate} from './amountValidations';
import {replaceChars} from './amountValidations';
import {doValidRates} from './amountValidations';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Loading from '../../common/Loading';
import {addCommaDV} from './amountValidations';
import { MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import { CustomCheckBox } from '../../styles/CustomCheckBox';
import { CustomRadio } from '../../styles/CustomRadio';
import Select from '@material-ui/core/Select';
import MenuItem from "@material-ui/core/MenuItem";
import keyboard_arrow_down from "@material-ui/icons/KeyboardArrowDown";
import Tooltip from '@material-ui/core/Tooltip';
import CustomDatePickerInput from '../../styles/CustomDatePickerInput';
import { ReactDatePicker } from '../../styles/ReactDatePicker';
import TermsAndConditions from './TermsAndConditions';
import ErrorMessage from '../../common/components/ErrorMessage';
import SaveMessage from '../../common/components/SaveMessage';
import { showConfirm, showAlert } from '../../common/components/showConfirmLayer';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts'
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts'
import Formatter from '../../formats/Formatters';

let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

var dateFormat = require('dateformat');
var data;
var invtype='';
var modetype='';
var arr1;
var holidayStr;
let vInvestType=[];
var weekEndStr;
var futureDate=new Date()
let backFlag="empty";
var datelbl='Today';
var title;
var fundriskreview = false;
let confirmChk = '';
var invtitleArr = [
    {"id":"10", "title":"Purchase"},
    {"id":"85", "title":"Redeem"},
    {"id":"95", "title":"Close Holding"}
]
let previousInvestType="";

class MMMFEnterTrade extends React.Component {
    constructor(props) {
        super(props);
        this.state={
            errorclass:'',
            errorMessage:'',
            redeemindex:[],
            futurechk:false,
            todaychk:true,
            redeemflag:false,
            fflag:false,
            tenor:'1 Day',
            insrate:'',
            loading:true,
            dateshow:'none',
            clntRateRange:'',
            startDate: futureDate,
            tenorpopbtn:false,
            ck:0,
            amount:[],
            clntRateRange:[],
            rateFrom:[],
            rateTo:[],
            deletedRows:[],
            amtvalue:'',
            Interest_Rate:'',
            idisabled:true,
            disabled:false,
            flag:'',
            adddisp:'none',
            addnotes:'',
            Invttitle:'',
            orderType:'M',
            limitExpiry:'0',
            nominatedAuthorise:'N',
            selectedInvestmentType:'10'
        }
        this.doSubmit = this.doSubmit.bind(this);
        this.addNotes = this.addNotes.bind(this);
        this.futureChange = this.futureChange.bind(this);
        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.onlyChange = this.onlyChange.bind(this);
        this.investTypeChange = this.investTypeChange.bind(this);
        this.doDelete = this.doDelete.bind(this);
        this.fundriskcheckreview = this.fundriskcheckreview.bind(this);
        this.doFundSheetInfo = this.doFundSheetInfo.bind(this);
        this.orderTypeChange=this.orderTypeChange.bind(this);
        this.limitExpiryChange=this.limitExpiryChange.bind(this);
        this.limitPriceChange=this.limitPriceChange.bind(this);
        this.mmftrmodeChange = this.mmftrmodeChange.bind(this);
        this.nominatedAuthoriseChange=this.nominatedAuthoriseChange.bind(this);

           }
    componentWillMount(){
		if(this.props.targetPage !== undefined && this.props.targetPage === 'HOME'){
		    this.props.loadTradeData();
        }
        invtype='';
        modetype='';
    }

    doDelete(e,index){
        document.getElementById("table"+index).style.display="none"
        this.state.deletedRows.push(index)
        this.setState({ck:0})
    }

    doFundSheetInfo(itm, e) {
		if(itm === undefined) { itm = ''; }
		this.externalWindow = window.open(itm, '', 'width=800,height=500,left=10,top=10,resizable=yes');
	}

    doSubmit()
    {
        vInvestType=[];
        var vData;
        var fld;
        var validFlag=true;
        let userLocale="";
        var warningFlag = false;
	    var user = JSON.parse(sessionStorage.getItem('user'));
        if(user[0].localeLang !== undefined){
            userLocale=user[0].localeLang;
        }
        if(this.props.data !== undefined)
        {
        	var rateFrom;
	        var rateTo;
        	var clntRateRange;
            vData = this.props.data;
            var holidayFlag;
            var refAcctNbr;
            for(var i in vData)
            {
                holidayFlag=vData.find(e=> e.rowNumber === parseInt(i)).holidayFlag;
                refAcctNbr=vData.find(e=> e.rowNumber === parseInt(i)).refAcctNbr;

 				if(this.props.errors !== [] && this.props.errors !== undefined){
					if(this.props.errors.find( e => e.refAccountNbr === refAcctNbr) !== undefined){
						holidayFlag = this.props.errors[0].holidayFlag;
					}
 				}

                if(parseInt(i) === parseInt(this.state.deletedRows.find(e=> e === parseInt(i)))){
                    continue;
                }
                fld = this.refs["tempAmount"+i];
                if(!fld.disabled && fld.value.length<=0 )
                {
                    showAlert(this,message["PLSEVAM"],fld.id);
                    validFlag=false;
                     fld.focus();
                    break;
                }
                if(!fld.disabled && parseInt(fld.value)=== 0)
                {
                    showAlert(this,message["PLSEVAM"],fld.id);
                    validFlag=false;
                    fld.focus();
                    break;
                }
                if(!(IsCharsInBag(fld.value,"0123456789.,MMmmKKkk")))
                {

                    if(this.state.redeemflag)
                   	 validFlag=true;
                   	 else{
                        showAlert(this,message["INVAMTRA"],fld.id);
                        validFlag=false;
                        fld.focus();
                    }
                    break;
                }
                let orderType = document.getElementById("orderType"+i);
                  if(orderType !== undefined && orderType.value === 'L'){

					 let limitPrice = this.refs["limitPrice"+i];
					 	if(  limitPrice.value.length<=0 )
					     {
							 showAlert(this,message["PLEVPRI"],limitPrice.id);
							 validFlag=false;
							  limitPrice.focus();
							 break;
						 }
						 if(parseFloat(limitPrice.value)=== 0)
						 {
							 showAlert(this,message["PLEVPRI"],limitPrice.id);
							 validFlag=false;
							 limitPrice.focus();
							 break;
                		}
                		 if(!(IsCharsInBag(limitPrice.value,"0123456789."))){
							  showAlert(this,message["PLEVPRI"],limitPrice.id);
							   validFlag=false;
							   limitPrice.focus();
							 break;
						 }

                		this.refs["orderType"+i] =orderType;
                		this.refs["limitExpiry"+i] =document.getElementById("limitExpiry"+i);
				}
				let addNotes = document.getElementById("addNotes"+i);
				if(addNotes!== undefined && addNotes.value.length>0)
				{
					if(!IsCharsInBag(addNotes.value,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 .,()&:@"))
					{
						showAlert(this,message["ENTVDLDCNCNOTES"],addNotes.id);
						   validFlag=false;
						   break;
					}
  		        }
                 this.refs["mmftrmode"+i] =document.getElementById("mmftrmode"+i);
                let investFld = document.getElementById("investtype"+i)
                vInvestType.push(investFld.value);
                if(this.state.dateshow == "block"){
                    rateFrom=document.getElementById("rateFrom"+i).value;
                    rateTo=document.getElementById("rateTo"+i).value;
                    clntRateRange=document.getElementById("clntRateRange"+i).checked;
                    if(clntRateRange){
                        if(doValidRates(rateFrom,rateTo,this) == false){
                            validFlag=false;
                            break;
                        }
                    }
                }

                var overRideClient = data[i].overRideClient;
                var invLimitAmt = data[i].invLimitAmt
                var ttAmount = data[i].ttAmount
                var tempAmount = parseFloat(replaceChars(this.refs["tempAmount"+i].value,",",""));
                var currentLimit = parseFloat(data[i].invLimitAmt)+parseFloat(data[i].ttAmount);
                var totalAmt = parseFloat(ttAmount) + parseFloat(tempAmount);
                var errorMessage='',popupMessage='';

                if(vInvestType[i] === "10")
                {
                    if(this.state.ck === 0)
                    {
                        if ((tempAmount.toString().length > 0 && ttAmount.length > 0 && invLimitAmt.length > 0) && ((parseFloat(totalAmt)) > parseFloat(invLimitAmt)))
                        {

                            var currentLimit = parseFloat(invLimitAmt) - parseFloat(ttAmount);
                            if (currentLimit < 0) {
                                currentLimit = 0;
                            }
                            var overRideAmount = parseFloat(tempAmount) - parseFloat(currentLimit);
                            if (overRideAmount < 0) {
                                overRideAmount = 0;
                            }
                            var existBalnce = parseFloat(ttAmount);
                            var currLimit = currentLimit;
                            var invLimAmt = parseFloat(invLimitAmt);
                            var eqFlag = false;
                            var overRideLmt = overRideClient;

                            if ("ttAmount---"+parseFloat(ttAmount) +" invLimAmt----"+ parseFloat(invLimAmt))
                                if (parseFloat(ttAmount) === parseFloat(invLimAmt))
                                    eqFlag = true;
                                    if (overRideLmt === "N") {
                                        this.state.errorclass="alert alert-danger text-center"
                                        if (currLimit > 0) {
                                            popupMessage = "Trade Amount of $" + addCommaDV(tempAmount.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + "will bring the total balance in the " + vData[i].prodName + " over the fund limit you set of $" + invLimitAmt + "."
                                            errorMessage = errorMessage + (parseInt(i)+1) + "." + "Out of Policy Trade:" + popupMessage;
                                            errorMessage = errorMessage + "Replace with maximum amount($" + currentLimit + ")to remain within the limit";
                                        }else { //Scenario 4

                                            if (eqFlag) {
                                                popupMessage = "Your existing total balance of $" + addCommaDV(existBalnce.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + " in the " + vData[i].prodName + " is equal to the fund limit you set of $" + addCommaDV(invLimitAmt.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + "." + " No trade is allowed in this fund.";
                                            } else {
                                                popupMessage = "Your existing total balance of $" + addCommaDV(existBalnce.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + " in the " + vData[i].prodName + " is over the fund limit you set of $" + addCommaDV(invLimitAmt.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + "." + " No trade is allowed in this fund.";
                                            }

                                            errorMessage = errorMessage + (parseInt(i)+1) + "." + "Out of Policy Trade:" + popupMessage;
                                            errorMessage = errorMessage + " Remove this trade";
                                        }
                                    } else {
                                        this.state.errorclass="alert alert-warning text-center"
                                        warningFlag = true;
                                        if (currLimit > 0) { //Scenario 1
                                            popupMessage = "Trade Amount of $" + addCommaDV(tempAmount.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + "will bring the total balance in the " + vData[i].prodName + " over the fund limit you set of $" + invLimitAmt + "."
                                            errorMessage = errorMessage + (parseInt(i)+1) + "." + "Out of Policy Trade:" + popupMessage;
                                            errorMessage = errorMessage + "Replace with maximum amount($" + currentLimit + ")to remain within the limit";
                                        } else if (currLimit <= 0) { //Scenario 3
                                            if (eqFlag) {
                                                popupMessage = "Your existing total balance of $" + addCommaDV(existBalnce.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + " in the " + vData[i].prodName + " is equal to the fund limit you set of $" + addCommaDV(invLimitAmt.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + "." +  " over the fund limit you set of $";
                                            } else {
                                                popupMessage = "Your existing total balance of $" + addCommaDV(existBalnce.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + " in the " + vData[i].prodName + " is over the fund limit you set of $" + addCommaDV(invLimitAmt.toString(),userLocale,vData[i].amountDecimals,vData[i].ccyRoundType) + "." +  " over the fund limit you set of $";
                                            }
                                            errorMessage = errorMessage + (parseInt(i)+1) + "." + "Out of Policy Trade:" + popupMessage;
                                            errorMessage = errorMessage + "Remove this trade";
                                        }
                                    }
                        }
                    }
                }
            }
        }

        if(validFlag==true){
            var flag=true;
            if(this.state.dateshow == "block"){
           	    var selDate=dateFormat(this.state.startDate,message["DATEFORMAT"]);
           	    flag=isValidBusinessDate(selDate,holidayStr,weekEndStr,this);
            }
                    if(fundriskreview === true) {
            if(flag){
                if(errorMessage !== '' && warningFlag===false){
                    this.setState({errorMessage})
                }else if(errorMessage !== '' && warningFlag===true){
                    this.setState({errorMessage})
                    warningFlag = false;
                    errorMessage='';
                    this.setState({ck:1})
                }else{
                     this.state.loading=true;
                     	this.props.method(this.refs,this.state.fflag,futureDate,this.state.redeemflag,vInvestType,this.props.errors,vData,this.state.deletedRows)
					}
            }
                            fundriskreview = false;
                        }
                        else{
                            showAlert(this,message["PLCTRFD"],"fundrisk");
                         }
            }
        }

    doTenor(){
         this.setState({tenorpopbtn:true});
    }

    amountChange(e,userLocale,index){
        var validFlag=true;

        var tempamtStr = (document.getElementById(e.target.name).value.replace(/,/g,""))

 		if(tempamtStr !== undefined && tempamtStr.length>0){
        	addCommasAmntLocale(e,userLocale,this.state.redeemflag,this);
		}

        var cash = parseFloat(arr1.find(e=>e.rowNumber.toString() === index.toString()).abdbal);
        var sharval = arr1.find(e=>e.rowNumber.toString() === index.toString()).Shares;
        sharval = parseFloat(replaceChars(sharval,",",""));
        var share = document.getElementById("mmftrmode"+index).value;
        var tempamt = parseFloat(document.getElementById(e.target.name).value.replace(/,/g,""))
        var investType =  document.getElementById("investtype"+index).value;

        if(investType==="85")
            if(share === "C"){
                if(tempamt > cash){
                    showAlert(this,message["AMTLTAVB"]);
                    document.getElementById(e.target.name).value ="";
                    validFlag=false;
                }
            }else{
                if(tempamt > sharval){
                    showAlert(this,message["REUEAU"]);
                    document.getElementById(e.target.name).value ="";
                    validFlag=false;
                }
            }
    }
    addNotes(e){
        var id = e.target.id;
        this.refs["addNotes"+id].style.display ='block';
        this.setState({adddisp:'block'});
    }

    handleStartDateChange(date) {
    	var selDate;
        selDate=dateFormat(date,message["DATEFORMAT"]);
        var flag=isValidBusinessDate(selDate,holidayStr,weekEndStr,this);
        if(flag){
            futureDate =date
            this.setState({startDate:date});
        }
     }

    onlyChange(e){
        var index = e.target.id.replace("clntRateRange","")
            if(e.target.checked){
            document.getElementById("rateFrom"+index).disabled=false;
            document.getElementById("rateTo"+index).disabled=false;
        }else{
            document.getElementById("rateFrom"+index).disabled=true;
            document.getElementById("rateTo"+index).disabled=true;
        }
    }

    futureChange(e,fdate){
        // var elements =  document.getElementsByClassName("errorText")
        if(e.target.value === "t"){
            this.setState({todaychk:true})
            this.setState({futurechk:false})
            this.setState({dateshow:'none'})
            this.setState({fflag:false})
            futureDate = new Date();
            // for (var i = 0; i < elements.length; i++)
            //     elements[i].style.display = "inline";
         } else {
            this.setState({todaychk:false})
            this.setState({futurechk:true})
            futureDate = new Date(fdate);
            this.setState({startDate:futureDate})
            this.setState({fflag:true})
            datelbl ='Future Date';
            this.setState({dateshow:'block'})
            // for (var i = 0; i < elements.length; i++)
            // elements[i].style.display = "none";
        }
    }

    investTypeChange(e)
    {
        vInvestType=[];
        var index = e.target.name.replace("investtype","");
        invtype = e.target.value;

        this.setState({selectedInvestmentType:e.target.value})

        if(backFlag == 'back')
        {
            if(e.target.value == "10"){
                document.getElementById("tempAmount"+index).value ="";
            }
        }
        if(e.target.value == "10"){
            this.setState({Invttitle:invtitleArr.find(ev => ev.id === e.target.value).title})
            this.setState({redeemflag:false})
            this.state.redeemindex.splice(this.state.redeemindex.findIndex(e=>e.id === index),1)
        //    document.getElementById("mmftrmode"+index).style.display ="none";
        	if(previousInvestType != "10")
            	document.getElementById("tempAmount"+index).value ="";
            document.getElementById("tempAmount"+index).readOnly = false;
		    document.getElementById("clntRateRange"+index).disabled = false;
		    document.getElementById("rateFrom"+index).disabled=true;
		    document.getElementById("rateTo"+index).disabled=true;
	}
        if(e.target.value == "85"){
            this.setState({Invttitle:invtitleArr.find(ev => ev.id === e.target.value).title})
            this.setState({redeemflag:true})
            let obj = this.state.redeemindex.find(e=>e.id === index.toString())
            if(obj !== undefined)
              obj.id = index.toString()
            else
            this.state.redeemindex.push({id:index.toString()});

      //      document.getElementById("mmftrmode"+index).style.display ="inline";
            document.getElementById("tempAmount"+index).value ="";
            document.getElementById("tempAmount"+index).readOnly = false;
            document.getElementById("clntRateRange"+index).disabled = true;
            document.getElementById("rateFrom"+index).disabled=true;
            document.getElementById("rateTo"+index).disabled=true;
            document.getElementById("clntRateRange"+index).checked = false;
            document.getElementById("rateFrom"+index).value="";
            document.getElementById("rateTo"+index).value="";
        }
        if(e.target.value == "95"){
            this.setState({Invttitle:invtitleArr.find(ev => ev.id === e.target.value).title})
            this.setState({redeemflag:true})

            let obj = this.state.redeemindex.find(e=>e.id === index.toString())
            if(obj !== undefined)
              obj.id = index.toString()
            else
            this.state.redeemindex.push({id:index.toString()});

        	document.getElementById("mmftrmode"+index).style.display ="none";
            document.getElementById("tempAmount"+index).value = arr1.find(e=> e.rowNumber === parseInt(index)).availShares;
            document.getElementById("tempAmount"+index).readOnly = true;
            document.getElementById("clntRateRange"+index).disabled = true;
            document.getElementById("rateFrom"+index).disabled=true;
            document.getElementById("rateTo"+index).disabled=true;
            document.getElementById("clntRateRange"+index).checked = false;
            document.getElementById("rateFrom"+index).value="";
            document.getElementById("rateTo"+index).value="";
        }
    }

    mmftrmodeChange(e){
        modetype = e.target.value;
         //var index = e.target.name.replace("mmftrmode","");
        //document.getElementById("tempAmount"+index).value="";

        var index = e.target.name.replace("mmftrmode","");

        if("S"==modetype){
            this.refs["ccyLabel"+index].style.display ='none';
        }else{
            this.refs["ccyLabel"+index].style.display ='block';
        }

        this.setState({ck:0})
    }

    maturityAccountChange(e){
        var index = e.target.name.replace("maturityAccountSel","");
    }
    nominatedAuthoriseChange(e){
			 var index = e.target.name.replace("nominatedAuthorise","");
 	         let nominatedAuthoriseVal=e.target.checked?"Y":"N";
	         document.getElementById("nominatedAuthorise"+index).value=nominatedAuthoriseVal;
 	 		 this.setState({['nominatedAuthorise'+index]:nominatedAuthoriseVal});

     }
	 orderTypeChange(e){
		   var index = e.target.name.replace("orderType","");
          let orderTypeVal=e.target.value;
         document.getElementById("orderType"+index).value=e.target.value;
         document.getElementById("limitPrice"+index).value='';

		 this.setState({['orderType'+index]:orderTypeVal});
         if(e.target.value === 'L'){
         	document.getElementById("limitPriceBlock"+index).style.display='';
		 }else {
			 document.getElementById("limitPriceBlock"+index).style.display='none';
		 }
     }
     limitExpiryChange(e){
		  var index = e.target.name.replace("limitExpiry","");
			let limitexpiry=e.target.value;
			document.getElementById("limitExpiry"+index).value=e.target.value;
 			this.setState({['limitExpiry'+index]:limitexpiry});
	 }

	 limitPriceChange(e){
	 		  var index = e.target.name.replace("limitPrice","");
	 			let limitPrice=e.target.value;
            // console.log("limitPrice",limitPrice)
            // console.log("substring",limitPrice.split("."))
            var limitSplit = limitPrice.split(".");
            // console.log("  parseInt(limitSplit[0])",parseInt(limitSplit[0]))

	 			if(  limitPrice ==='' )
	 			{
	 			showAlert(this,message["PLEVPRI"]);
	 			limitPrice='';
	 			}
	 			else if(limitPrice !=='' && !(IsCharsInBag(limitPrice,"0123456789."))){
                     showAlert(this,message["PLEVPRI"]);
	 				limitPrice='';
                }
                else if(parseInt(limitSplit[0]) < 1 || parseInt(limitSplit[0]) > 9999){
                    showAlert(this,message["PLSBET"]);
                    limitPrice='';
                }

		if(limitPrice!=null && limitPrice.length>0)
		{
			var amtDollar     =  e.target.value;
			if(amtDollar.indexOf(".") !=amtDollar.lastIndexOf("."))
			{
			  showAlert(this,message["PLEAVLP"]);
			  limitPrice='';
			}
		}
		document.getElementById("limitPrice"+index).value=limitPrice;
		this.setState({['limitPrice'+index]:limitPrice});
	 }

    fundriskcheckreview(e){
        fundriskreview = e.target.checked;
    }
    render(){
        const {classes}=this.props;
        let userLocale="";
        let dataLen=0;

        if(this.props.backFlag !== undefined){
            backFlag = this.props.backFlag;
        }

	    var user = JSON.parse(sessionStorage.getItem('user'));
        if(user[0].localeLang !== undefined){
            userLocale=user[0].localeLang;
        }

        let entertrademarkup,tradedate,tradeDetails,errorMsg=false,errorImg,holidayMsg;
        let reviewTradeBtn,terormarkup,wam;

        if(this.props.data !== undefined)
        {
            data = this.props.data;
            this.state.loading=false
        }

        // if(this.props.invtype !== undefined)
        // {
        //     invtype = this.props.invtype
        // }

        if(this.state.loading)
        	return( <div className="col-md-12 mt-mb"><div className="clearfix"></div><Loading/></div> );
        else{
        	// var date = dateFormat(new Date(),message["DATEFORMAT"]);
        	var date = <Formatter date={new Date()}/>
                arr1 =[];
                for(var k in data){
                    arr1.push(data[k])
                }
                reviewTradeBtn =  <button style={{margin:'0px'}} className="btn btn-primary btn-xs mt10 pull-right" id="reviewTrade" onClick={this.doSubmit.bind(this)}>Review Trade</button>
                let backButton=<button className="btn btn-default btn-xs mt10" id="back" onClick={this.props.goback}>Back to Product Select</button>

                if(data !== undefined){
                    if(arr1 !== undefined && arr1.length!==0)
                        dataLen=arr1.length;

                        entertrademarkup = arr1.map((item,index) => {
                        if(this.state.deletedRows.find(e=>e === index) === undefined){
                            var obj = item;
                            errorMsg=false;
                            errorImg='none';
                            var invAmt='';
		                    var addnotes='';
                            if(index === 0){
                                weekEndStr=obj.weekEndStr;
                                holidayStr=obj.holidayStr;
                            }

                            if(this.props.invAmtValueArray && this.props.invAmtValueArray !== undefined && this.props.invAmtValueArray.length>0)
                            {
                                if(this.props.invAmtValueArray.find(namevalue => namevalue.name === "tempAmount"+obj.rowNumber.toString()) !== undefined)
                                {
                                    invAmt=this.props.invAmtValueArray.find(namevalue => namevalue.name === "tempAmount"+obj.rowNumber.toString()).value;
                                }
                                if(this.props.invAmtValueArray.find(namevalue => namevalue.name === "addnotes"+obj.rowNumber.toString()) !== undefined)
                                {
                                    addnotes=this.props.invAmtValueArray.find(namevalue => namevalue.name === "addnotes"+obj.rowNumber.toString()).value;
                                }
                            }

                            if(backFlag === 'back' && vInvestType!== undefined && vInvestType.length>0)
                            {
                                invtype=vInvestType[obj.rowNumber];
                            }
                            if(invtype == '95') {
                                invAmt	= this.props.data[0].availShares;
                            }

                            holidayMsg='';
                            if(obj.holidayFlag !== undefined && obj.holidayFlag.length>0)
                            {
                                if(obj.holidayFlag.includes("Account is not available for trading") === true)
                                {
                                    errorMsg=true;
                                    errorImg='inline-block';
                                    holidayMsg=obj.holidayFlag;
                                }
                            }
                            if(this.state.todaychk && obj.holidayFlag !== undefined && obj.holidayFlag.length>0){
                                errorMsg=true;
                                errorImg='inline-block';
                                holidayMsg=obj.holidayFlag;
                            }

                            let selectMarkup,selectMarkup1;
                            var mindate = new Date(obj.futAllowStrtDate)
                            mindate.setDate(mindate.getDate())

                            var maxdate = new Date(obj.futAllowEndDate)
                            maxdate.setDate(maxdate.getDate())

                            if(invtype === "")
                            	previousInvestType = obj.transTypes[0].id;
                            else
                            	previousInvestType = invtype;

                            tradedate =
                                // <div>
                                    <div className="inlineblk">
                                        <label className='LabelValue mb0'>Today ({date})</label>
                                        {/* <CustomRadio> Today ({date}) <input name="date"  id="todate" type="radio" checked={this.state.todaychk}  value="t"  onChange={e=>this.futureChange(e,obj.futureDate)} /><span></span></CustomRadio> */}
                                    </div>
                                    {/* <label className="LabelValue"> Today ({date}) </label> */}
                                    {/* <div  className="form-group col-md-6 ">

                                        <input disabled={obj.holidayFlag.includes("Active Investment Not Allowed")? true : false} className="pull-left"  name="date"  id="futuredate" checked={this.state.futurechk} type="radio" onChange={e=>this.futureChange(e,obj.futureDate)} value="f"/>
                                        <label className="pull-left" style={{marginTop:'4px', marginLeft:'4px'}}> Future Date</label>

                                        <div className="form-group col-md-4 col-sm-4" style={{display:this.state.dateshow}}>
                                            <ReactDatePicker>
                                                <DatePicker maxDate={maxdate} minDate={mindate} dateFormat="MMM dd, YYYY" selected={this.state.startDate} name="futureDate" id="futureDate" ref="futureDate" className={classes.inputStyle} onChange={this.handleStartDateChange} customInput={(<CustomDatePickerInput/>)} />
                                            </ReactDatePicker>
                                            <label> Booking Date:</label>
                                            <label className="TxtNrml"> {date} </label>
                                        </div>

                                    </div> */}
                                // </div>
                        selectMarkup =
                        <div className="clearfix">
                            <div className="form-group">
                                <span style={{display:errorImg}}>
                                    <img src={require('../../images/error_icon.gif')} alt="instruction" />&nbsp;
                                </span>
                                <label className="LabelText">Investment:</label>
                            </div>
                            {holidayMsg && holidayMsg !== '' &&
                                <div className="form-group">
                                    {
                                        holidayMsg.split("/").map((item,index)=>{
                                            return(
                                                // <span className={"errorText"}>
                                                //     <span className="pull-center LabelValue red">
                                                //         <label className="TxtNrml fnt14" id={"errorId"+obj.rowNumber.toString()}>{item}</label>
                                                //     </span>
                                                // </span>
                                                <ErrorMessage text={item} type={'alert'} lang="en"/>
                                            )
                                        })
                                    }
                                    {
                                    (this.props.errors !== [] && this.props.errors !== undefined) &&
                                        this.props.errors.find(e => e.refAccountNbr === obj["Money Fund Account"]) !== undefined ?
                                            <ErrorMessage text={this.props.errors.find( e => e.refAccountNbr === obj["Money Fund Account"]).holidayFlag} type={'alert'} lang="en"/>
                                        :
                                        <span></span>

                                    }
                                </div>
                            }
                            <div  className="form-group">
                                <Tooltip title={this.state.Invttitle==""?invtitleArr.find(ev => ev.id === obj.transTypes[0].id).title:this.state.Invttitle} placement="top">
                                <Select
                                    IconComponent = {keyboard_arrow_down}
                                    ref={"investtype"+obj.rowNumber.toString()}
                                    value={invtype === "" ?obj.transTypes[0].id:invtype}
                                    name={"investtype"+obj.rowNumber.toString()}
                                    id={"investtype"+obj.rowNumber.toString()}
                                    className="mr5"
                                    onChange={e=>this.investTypeChange(e)}>
                                    {
                                    obj.transTypes && obj.transTypes.map((obj,index) => {
                                        return <MenuItem key={index} value={obj.id}>{obj.value}</MenuItem>
                                    })
                                }
                                </Select>
                                </Tooltip>
                                <input type="hidden" ref={"maturityFlag"} name={"maturityFlag"} id={"maturityFlag"} value={obj.maturityFlag} />
                                <input type="hidden" ref={"minDollar"+obj.rowNumber.toString()} name={"minDollar"+obj.rowNumber.toString()} id={"minDollar"+obj.rowNumber.toString()} value={obj.minDollar} />
                                <input type="hidden" ref={"maxDollar"+obj.rowNumber.toString()} name={"maxDollar"+obj.rowNumber.toString()} id={"maxDollar"+obj.rowNumber.toString()} value={obj.maxDollar} />
                                <input type="hidden" ref={"holidayFlag"+obj.rowNumber.toString()} name={"holidayFlag"+obj.rowNumber.toString()} id={"holidayFlag"+obj.rowNumber.toString()} value={obj.holidayFlag} />
                                <input className={classes.inputStyle + ' ' + classes.input_style} disabled={errorMsg} type="text" ref={"tempAmount"+obj.rowNumber.toString()} name={"tempAmount"+obj.rowNumber.toString()} id={"tempAmount"+obj.rowNumber.toString()}  defaultValue={invAmt} onBlur={(e)=>{this.amountChange(e,userLocale,obj.rowNumber)}} autoComplete="off"/>
                                <label className="vAlign"  >
                                 {
                                    ("95"===this.state.selectedInvestmentType) &&
                                       <div ref={"ccyLabel"+obj.rowNumber.toString()} style={{display:"none"}}>{obj.CurrencyCode}</div>
                                 }
                                 {
                                     ("95"!==this.state.selectedInvestmentType) &&
                                        <div ref={"ccyLabel"+obj.rowNumber.toString()}>{obj.CurrencyCode}</div>
                                }
                                </label>
                                         {
                                              (this.state.selectedInvestmentType!==undefined && this.state.selectedInvestmentType==='95') &&
                                              <Select  IconComponent = {keyboard_arrow_down}  onChange={this.mmftrmodeChange} value="S" className="ml5" ref={"mmftrmode"+obj.rowNumber.toString()} name={"mmftrmode"+obj.rowNumber.toString()} id={"mmftrmode"+obj.rowNumber.toString()} >
                                              <MenuItem value="S">Units</MenuItem>
                                              </Select>
                                          }
                                          {
                                            (this.state.selectedInvestmentType===undefined || (this.state.selectedInvestmentType!==undefined && this.state.selectedInvestmentType!=='95')) &&
                                            <Select  IconComponent = {keyboard_arrow_down}  onChange={this.mmftrmodeChange} value={modetype === "" ? "C" :modetype} className="ml5" ref={"mmftrmode"+obj.rowNumber.toString()} name={"mmftrmode"+obj.rowNumber.toString()} id={"mmftrmode"+obj.rowNumber.toString()} >
                                            <MenuItem value="C">Cash</MenuItem>
                                            <MenuItem value="S">Units</MenuItem>
                                            </Select>
                                           }
                                                                          { /*
                                {
                                    (obj.allowOnlyShares==='true' || obj.navType ==='V') &&
                                        <select className={classes.select}  defaultValue="Shares" style={{display:"none",marginTop:'5px',padding:'7px 9px'}} ref={"mmftrmode"+obj.rowNumber.toString()} name={"mmftrmode"+obj.rowNumber.toString()} id={"mmftrmode"+obj.rowNumber.toString()} onChange={this.mmftrmodeChange}>
                                            <option value="S">Shares</option>
                                        </select>
                                }
                                {
                                    (obj.allowOnlyShares!=='true' || obj.navType !== 'V') &&
                                        <select  className={classes.select} value="Cash" style={{display:"none",marginTop:'5px',marginLeft: '5px',padding:'7px 9px'}} ref={"mmftrmode"+obj.rowNumber.toString()} name={"mmftrmode"+obj.rowNumber.toString()} id={"mmftrmode"+obj.rowNumber.toString()} onChange={this.mmftrmodeChange}>
                                            <option value="C">Cash</option>
                                            <option value="S">Shares</option>
                                        </select>
                                }
                                */
								}
                        </div>
                        <div className="clearfix"></div>
                        <div className="col-md-6" style={{display:this.state.dateshow}}>
                            <input type="checkbox" ref={"clntRateRange"+obj.rowNumber.toString()} id={"clntRateRange"+obj.rowNumber.toString()}  onClick={this.onlyChange}/>
                            <label>Only Execute if Previous day rate is between:</label>
                            <input  className={classes.inputStyle + ' ' + classes.input_style + ' ' + classes.w50} type="text" ref={"rateFrom"+obj.rowNumber.toString()} id={"rateFrom"+obj.rowNumber.toString()} onBlur={(e)=>{rateDecimalChange(e,userLocale,obj.rateDecimals,obj.ccyRoundType)}}  name={"rateFrom"+obj.rowNumber.toString()} size="4" disabled={true}/>
                            <span className="lht">% and</span>
                            <input className={classes.inputStyle + ' ' + classes.input_style}  type="text" ref={"rateTo"+obj.rowNumber.toString()} id={"rateTo"+obj.rowNumber.toString()} onBlur={(e)=>{rateDecimalChange(e,userLocale,obj.rateDecimals,obj.ccyRoundType)}} name={"rateTo"+obj.rowNumber.toString()} size="4" disabled={true}/> %
                        </div>
                        <div className="clearfix"></div>
                        <div  className="form-group">
                            <a className='unline' id={obj.rowNumber.toString()} onClick={this.addNotes}> Nominated account & add notes (Optional)   </a>
                            {obj.termsFlag !== undefined && obj.termsFlag === 'yes'&&
                            <TermsAndConditions  termText={obj.termText !== undefined?obj.termText:''}/>}

                            <textarea maxLength="750" id={"addNotes"+obj.rowNumber.toString()} ref={"addNotes"+obj.rowNumber.toString()} style={{display:'none'}}  defaultValue={addnotes} rows="5" cols="30"/>
                       </div>
                         <div  className="form-group">
						          <span className="VTalign"> <CustomCheckBox className="txtWrap"><input type="checkbox" id={"nominatedAuthorise"+obj.rowNumber.toString()} name={"nominatedAuthorise"+obj.rowNumber.toString()}  ref={"nominatedAuthorise"+obj.rowNumber.toString()} onClick={this.nominatedAuthoriseChange} value={this.state['nominatedAuthorise'+obj.rowNumber.toString()] === undefined?'N':this.state['nominatedAuthorise'+obj.rowNumber.toString()]}/> Authorise to debit nominated bank account in case of insufficient funds in funding account.<span></span></CustomCheckBox></span>
                        </div>
                    </div>

                    	confirmChk = <div className="pull-right">
                            <span className="VTalign"><CustomCheckBox>I confirm that I have reviewed Fund details ( from <a href="javascript:void(0);" className='unline' onClick={e => this.doFundSheetInfo(obj.FACTSHEETURL, event)}>Fact Sheet</a> and <a href="javascript:void(0);" className='unline' onClick={e => this.doFundSheetInfo(obj.KIIDURL, event)}>KIID</a>) and understand the risks<input type="checkbox" ref='fundrisk' id='fundrisk' onClick={this.fundriskcheckreview}/><span></span></CustomCheckBox></span>
                            {/* <label style={{marginTop:'-4px', marginLeft:'4px',fontWeight: 'normal'}} ></label> */}
                        </div>

                    return <table id={"table"+index} key={index} width="100%" className="table table-bordered tradeTable">
                        <thead>
                            <tr>
                                    <th colSpan="3">
                                    {obj.prodName}
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td className="paddAll w25">
                                    {/* <div  className="form-group">
                                        <label className="pull-left"> Yesterday's rate: </label>
                                        <label className="pull-right TxtNrml">{obj["Yesterday's rate"] ===""?0.00:obj["Yesterday's rate"]}%</label>
                                    </div> */}
                                    {/* <div className="clearfix"></div> */}
                                    <div  className="form-group">
                                        {/*<label> EOD Cut-Off Time: </label>*/}
                                        <label className="LabelText"> Cut-Off Time to Invest: </label>
                                        <label className="pull-right LabelValue">{obj["EOD Cut-Off Time"]}</label>
                                    </div>
                                </td>
                                <td className="paddAll w30">
                                    <div  className="form-group">
                                        <label className="LabelText"> {/*Money Fund Account*/} Portfolio Number:</label>
                                        <label className="pull-right LabelValue"> {obj["dispPortfolioRefAcctnbr"]} </label>
                                    </div>
                                    <div  className="form-group">
                                        {
                                            this.state.redeemindex.find(e=> parseInt(e.id) === parseInt(obj.rowNumber)) !== undefined &&
                                            (parseInt(this.state.redeemindex.find(e=> parseInt(e.id) === parseInt(obj.rowNumber)).id) === parseInt(obj.rowNumber)) ?

                                                <span id={"fundacctdefault"+obj.rowNumber.toString()}>
                                                    <label className="LabelText mt6">Redemption Account :</label>
                                                    {
                                                        obj["maturityFlag"] === "true" ?
                                                            <Select IconComponent = {keyboard_arrow_down} value={obj.selRedeemAccountNbr} ref={"maturityAccountSel"+obj.rowNumber.toString()} name={"maturityAccountSel"+obj.rowNumber.toString()} id={"maturityAccountSel"+obj.rowNumber.toString()} onChange={this.maturityAccountChange} className="pull-right">
                                                                {
                                                                    obj.maturityAccount && obj.maturityAccount.map((obj,index) => {
                                                                        return <MenuItem key={index} value={obj.key}>{obj.value}</MenuItem>
                                                                    })
                                                                }
                                                            </Select>
                                                        :
                                                        <label className="pull-right LabelValue">{obj["Funding Account"]}</label>
                                                    }
                                                </span>
                                            :
                                            <span id={"fundacctdefault"+obj.rowNumber.toString()}>
                                                <label className="LabelText">Funding Account:</label>
                                                <label className="pull-right LabelValue">{obj["Funding Account"]}</label>
                                            </span>
                                        }
                                    </div>
                                	{/* {
										(obj.navType==='C' || obj.navType==='L') &&
											<div  className="form-group">
												<label>Current Balance(NAV={obj.NAV}):    </label>
											</div>
 									}
                                	{
										(obj.navType!=='C' && obj.navType!=='L') &&
										<div>
											<div  className="form-group">
												<label>Latest NAV {obj.NAV} {obj.navrecTime}</label>
											</div>
											<div  className="form-group">
												<label>Current Balance   </label>
											</div>
										</div>
  									} */}
                                    {/* <div  className="form-group">
                                        <label>Fund Type:    </label>
                                        <label className="pull-right TxtNrml">{obj["NAV Type"]}</label>
                                    </div>
                                    <div  className="form-group">
                                        <label>Cash ({obj.CurrencyCode}):     </label>
                                        <label className="pull-right TxtNrml">{obj.abdbal === "0.00" ? obj.abdbal :addCommaDV(obj.abdbal,userLocale,obj.amountDecimals,obj.ccyRoundType)}</label>
                                    </div>
                                    <div  className="form-group">
                                        <label>Shares:      </label>
                                        <label className="pull-right TxtNrml">{obj.Shares}</label>
                                    </div> */}
                                      <div  className="form-group">
												<label className="LabelText">Order Type:</label>
												 <span   >
												<Select  IconComponent = {keyboard_arrow_down} value={this.state['orderType'+obj.rowNumber.toString()] === '' || this.state['orderType'+obj.rowNumber.toString()] === undefined? this.state.orderType : this.state['orderType'+obj.rowNumber.toString()]}  ref={"orderType"+obj.rowNumber.toString()} name={"orderType"+obj.rowNumber.toString()} id={"orderType"+obj.rowNumber.toString()} onChange={this.orderTypeChange} className="pull-right">
												  <MenuItem key={'M'} value={'M'} >{'Market'}</MenuItem>
												  <MenuItem key={'L'} value={'L'}>{'Limit'}</MenuItem>
												</Select>

 												 </span>
                                    </div>
									<div className="clearfix"></div>
                                     <div  id={"limitPriceBlock"+obj.rowNumber.toString()} style={{display:'none'}} >
											 <div  className="form-group mt5">	<label className="LabelText">Limit Price:      </label>
 												 <input  className={classes.inputStyle + ' ' + classes.input_style1 + ' ' + classes.floatright}  type="text" ref={"limitPrice"+obj.rowNumber.toString()} id={"limitPrice"+obj.rowNumber.toString()}   name={"limitPrice"+obj.rowNumber.toString()} size="7" onChange={this.limitPriceChange} maxLength="7"/>
										 	 </div>
										 	 <div className="clearfix"></div>

											 <div  className="form-group mt5">	<label className="LabelText">Limit Expiry:      </label>
											  	<Select  value={this.state.limitExpiry}  ref={"limitExpiry"+obj.rowNumber.toString()} name={"limitExpiry"+obj.rowNumber.toString()} id={"limitExpiry"+obj.rowNumber.toString()} onChange={this.limitExpiryChange} className="pull-right">
												<MenuItem key={'0'} value={'0'} >{'Today'}</MenuItem>
												</Select>
											 </div>
                                    </div>


                                </td>
			                    <td className="paddAll w40">
			                        {selectMarkup}
			                    </td>
                                {/* <td className="paddAll">
                                    <a onClick={e => this.doDelete(e,index)}> <img src="/src/images/delete_icon.gif"/></a>
			                    </td> */}
                                {selectMarkup1}
                            </tr>
                        </tbody>
                    </table>
                }
            });
        }

        if(errorMsg === true && dataLen === 1)
        {
            reviewTradeBtn = "";
            confirmChk = '';
        }

        return(
            <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                            <div className={this.state.errorclass}>{this.state.errorMessage}</div>
                <div className="contentBorderStyle">
                    <label className="LabelText mb0">
                        Instruction Date:
                    </label>
                        {tradedate}
                        </div>
                <div>
                            {entertrademarkup}
                            {confirmChk}
                        </div>
                <div className="clearfix"></div>
                    {reviewTradeBtn}
                    {backButton}
            </MuiThemeProvider>
        );
    }
}
}

export default withStyles(MuiStyles)(MMMFEnterTrade);