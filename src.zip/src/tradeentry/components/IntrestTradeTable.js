import React from 'react'; 
import { Link } from 'react-router-dom';
import ReactTable from "react-table";
class IntrestTradeTable extends React.Component {
	constructor(props) {
		super(props);
		 
		this.state = { selected: {}, selectAll: 0, data: '' };

		this.toggleRow = this.toggleRow.bind(this); 
		this.doSubmit = this.doSubmit.bind(this); 
	}

	toggleRow(product) { 
		const newSelected = Object.assign({}, this.state.selected);
		newSelected[product] = !this.state.selected[product];
		this.setState({
			selected: newSelected,
			selectAll: 2
		});
		 
	}

	toggleSelectAll() { 
		let newSelected = {};

		if (this.state.selectAll === 0) {
			this.props.tdata.forEach(x => {
				newSelected[x.rowNumber] = true;
			});
		}

		this.setState({
			selected: newSelected,
			selectAll: this.state.selectAll === 0 ? 1 : 0
		});
	}
	isEmpty(obj) {
		for(var key in obj) {
			if(obj.hasOwnProperty(key))
				return false;
		}
		return true;
	}
	doSubmit(){ 
		if(this.isEmpty(this.state.selected))
			alert("Please check atleast one checkbox");
		else
			this.props.method(this.state.selected) 
	}
	render() { 
		var columns = []; 
		var results = this.props.columns;
		columns.push({
			id: "checkbox",
			accessor: "",
			Cell: ({ original }) => { 
				return (
					<input
						type="checkbox"
						className="checkbox"
						checked={this.state.selected[original.rowNumber] === true}
						onChange={() => this.toggleRow(original.rowNumber)}
					/>
				);
			},
			Header: x => {
				return (
					<input
						type="checkbox"
						className="checkbox"
						checked={this.state.selectAll === 1}
						ref={input => {
							if (input) {
								input.indeterminate = this.state.selectAll === 2;
							}
						}}
						onChange={() => this.toggleSelectAll()}
					/>
				);
			},
			sortable: false,
			width: 65
		})
        if(results !== undefined) { 
           results.map((item,index) => {
							columns.push({
								Header: item,
								accessor:item 
							});
						});      
		}
		 
		return (
			<div>
				<label>Select accounts to trade in below</label>  or  <Link to="/uploadtrade">upload bulk trade template</Link>
				<table style={{width:'100%'}}>
					<tbody>
					<tr>
						<td style={{width:'70%',paddingRight:'50px'}}>
							<ReactTable
								data={this.props.tdata}
								columns={columns} 
							/>							
						</td>
						<td style={{verticalAlign:'top'}}>
							 <table className="table table-striped table-bordered">
								 <thead>
									 <tr>
										 <th>
											 Related Links
										 </th>
									 </tr>
								 </thead>
								 <tbody>
									 <tr>
										 <td>
											 <Link to="/admincreate/CREATEACCT">Open a new Money Fund account </Link>
										 </td>
										</tr>
										<tr>
										 <td>
											 <Link to="">Download bulk trade template  </Link>
										 </td>
									 </tr>
								 </tbody>
							 </table>
						</td>
					</tr>
					</tbody>
				</table>
				
				<label>Number of accounts selected:0 </label>| <a>download bulk template for selected accounts</a>
				<div className="clearfix"></div>
			    <button className="btn btn-primary btn-xs mt" onClick={this.doSubmit.bind(this)}>Trade</button>
			</div>
		);
	}
}

export default IntrestTradeTable;