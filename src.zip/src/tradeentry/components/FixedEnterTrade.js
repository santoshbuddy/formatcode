import React from 'react';
 import {addCommasAmntLocale} from './amountValidations';
 import {rateDecimalChange} from './amountValidations';
 import {doValidRates} from './amountValidations';
 import {isValidBusinessDate} from './amountValidations';
 import TenorPopup from './TenorPopup';
 import DatePicker from 'react-datepicker';
 import FromData from 'form-data';
 import Loading from '../../common/Loading';
 import {IsCharsInBag} from './amountValidations';
 import axios from 'axios';
 import { alertConstants } from '../../common/constants/alert.constants';
 var dateFormat = require('dateformat');
 var data;
 var res;
 var holidayStr;
 var weekEndStr;
 var futureDate=new Date()
var datelbl='Today';
class FixedEnterTrade extends React.Component {
    constructor(props) {
        super(props);
        this.state={futurechk:false,todaychk:true,fflag:false,tenor:'Overnight',insrate:'',loading:false,dateshow:'none',clntRateRange:'',startDate: futureDate,tenorpopbtn:false,ck:'',amount:[],clntRateRange:[],rateFrom:[],rateTo:[],amtvalue:'',Interest_Rate:'',idisabled:true,disabled:false,flag:'',adddisp:'none',addnotes:''}
        this.doSubmit = this.doSubmit.bind(this);
        this.doConfirm = this.doConfirm.bind(this);
        this.addNotes = this.addNotes.bind(this);
        this.investChange = this.investChange.bind(this);
        this.futureChange = this.futureChange.bind(this);
        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.onlyChange = this.onlyChange.bind(this);
        this.tenorOpen = this.tenorOpen.bind(this);
    }
    doSubmit(){
        var validFlag=true;
        console.log("*** target this.state.dateshow::",this.state.dateshow);
	if(this.state.dateshow == "block"){
	var flag=true;
	  if(this.state.dateshow == "block"){
		var selDate=dateFormat(this.state.startDate,"mmm d, yyyy");
		flag=isValidBusinessDate(selDate,holidayStr,weekEndStr);
	  }
	  if(flag){
	    var rateFrom;
	    var rateTo;
		var clntRateRange;
		rateFrom=document.getElementById("rateFrom").value;
		rateTo=document.getElementById("rateTo").value;
		clntRateRange=document.getElementById("clntRateRange").checked;
		console.log("*** target rateFrom::",rateFrom+",rateTo:"+rateTo+",clntRateRange:"+clntRateRange);
		if(clntRateRange){
			//alert(clntRateRange)
			if(doValidRates(rateFrom,rateTo) == false){
			  //alert("errors exist");
			  validFlag=false;
			}
		}
	    }else{
	      validFlag=false;
	    }
	  }

        if(validFlag){
          if(res.paymentMethod === "NONE"){
            alert("Selected DDA account is currently not available for trading, please try again later")
            validFlag=false;
            }
        }
        if(validFlag){
            if(this.state.amtvalue !== ''){
                this.setState({disabled:true})
                this.setState({flag:"confirm"})
                this.setState({addnotes:this.refs.addNotes.value})
                this.setState({adddisp:'none'});

            }else{
                alert("Please Enter Investment Amount");
            }
           }
    }

goConfirmBack()
{
	this.setState({disabled:false})
	this.setState({flag:""})
	//this.setState({addnotes:this.refs.addNotes.value})
	this.setState({adddisp:'none'});
}
doConfirm(){
        this.props.method2(this.props.selectedRows,this.state.amtvalue,res.Interest_Rate,res,this.state.clntRateRange,this.state.rateFrom,this.state.rateTo,dateFormat(futureDate,"mmm d, yyyy"),this.state.fflag,this.state.insrate)
        this.state.loading = true;
    }
    doTenor(){
         this.setState({tenorpopbtn:true});
    }
    amountChange(e,userLocale){
        var res;
        this.props.data && this.props.data.map((item,index) => {
            if(item.name === "data"){
                res = item.values[0].TradeDetails;
            }
        })
        //alert("mindollar::"+res.minDollar);
        //alert(parseFloat(e.target.value.replace(/,/g,"")));
        //alert(parseFloat(res.minDollar))
        addCommasAmntLocale(e,userLocale);
        if((parseFloat(e.target.value.replace(/,/g,"")) > parseFloat(res.maxDollar)) || (parseFloat(e.target.value.replace(/,/g,"")) < parseFloat(res.minDollar))){
            alert("Please Enter Amount min max range");
            res.Interest_Rate=""
            this.setState({insrate:""})
            this.setState({amtvalue:""})
            document.getElementById("amount").value="";
        }
        else{
            this.setState({amtvalue:e.target.value})
            var jsonBody = new FormData();

            var user = JSON.parse(sessionStorage.getItem('user'));
            jsonBody.append("token",user[0].token)
            jsonBody.append("ajaxFlag","YES");
            jsonBody.append("dollarAmount",e.target.value);
            jsonBody.append("clCompanyId",JSON.parse(sessionStorage.getItem('clientFirm')));
            jsonBody.append("product",res.productId);
            jsonBody.append("currencyCode",res.currency);
            jsonBody.append("transType",res.transType);
            jsonBody.append("tenorType",res.tenorType);
            jsonBody.append("selectedDDAAcctNbr",res.selectedDDAAcctNbr);
            jsonBody.append("deskId",res.deskId);
            jsonBody.append("investAccount",res.investAccount);
            jsonBody.append("branchId",res.branchId);
            jsonBody.append("groupId",res.groupId);
            jsonBody.append("exactDuration",res.exactDuration);
            jsonBody.append("newDuration",res.newDuration);

            axios({
                method: 'post',
                url:alertConstants.URL+"/TERMDEALING.do",
                data: jsonBody,
                config: { headers: {'Content-Type': 'multipart/form-data' }}
                }).then((response)=>{
                    res.Interest_Rate = response.data.InterestRate
                    this.setState({insrate:response.data.InterestAmount})
                });
            }


   }
    addNotes(e){
        var id = e.target.id;
        this.refs["addNotes"+id].style.display ='block';
       this.setState({adddisp:'block'});
    }
    investChange(e){

        var index = e.target.selectedIndex;

        var temp = e.target.value;
        res.investAccount = e.target[index].text;

        data && data.map((item,index) => {
            if(item.name === "Funding Account"){
                var fundrows = item.rows.find(e => e.id===temp)

                data && data.map((filter,index) => {
                    if(filter.label === "Funding Account"){
                        filter.values = fundrows.rows;
                        res.fundingAccount = fundrows.rows[0].name;
                        res.paymentMethod = fundrows.rows[0].name;
                    }
                 })
            }
            if(item.name === "Maturity Account"){
                var fundrows = item.rows.find(e => e.id===temp)
                data && data.map((filter,index) => {
                    if(filter.label === "Maturity Account"){
                        filter.values = fundrows.rows;
                        res.maturityAccount = fundrows.rows[0].name;
                    }
                 })
            }
        })

        this.setState({ck:0})
    }

    onSelect = (selectRow) => {
       res.tenorFlag=selectRow.tenorFlag;
       res.durationFrom=selectRow.durationFrom;
       res.durationTo=selectRow.durationTo;

       res.exactDuration=selectRow.exactDuration;
       res.newDuration=selectRow.exactDuration;

       res.maturityDate=selectRow.MaturityDate;
       res.Interest_Rate=selectRow.Rate
       res.interestRate=selectRow.interestRate
    //    alert(res.Interest_Rate)
    //    console.log("selectRow.Rate",selectRow.Rate)
    //    console.log("selectRow.interestRate",selectRow.interestRate)
    //    this.setState({Interest_Rate:selectRow.Rate})
       this.setState({tenorpopbtn:false})
       this.setState({tenor:selectRow.Tenor})

       var jsonBody = new FormData();


        this.props.data && this.props.data.map((item,index) => {
            if(item.name === "data"){
                res = item.values[0].TradeDetails;
            }
        })
        var user = JSON.parse(sessionStorage.getItem('user'));
        jsonBody.append("token",user[0].token)
        jsonBody.append("ajaxFlag","YES");
        jsonBody.append("dollarAmount",this.state.amtvalue);
        jsonBody.append("clCompanyId",JSON.parse(sessionStorage.getItem('clientFirm')));
        jsonBody.append("product",res.productId);
        jsonBody.append("currencyCode",res.currency);
        jsonBody.append("transType",res.transType);
        jsonBody.append("tenorType",res.tenorType);
        jsonBody.append("selectedDDAAcctNbr",res.selectedDDAAcctNbr);
        jsonBody.append("deskId",res.deskId);
        jsonBody.append("investAccount",res.investAccount);
        jsonBody.append("branchId",res.branchId);
        jsonBody.append("groupId",res.groupId);
        jsonBody.append("exactDuration",res.exactDuration);
        jsonBody.append("newDuration",res.newDuration);

        axios({
            method: 'post',
            url:alertConstants.URL+"/TERMDEALING.do",
            data: jsonBody,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
            }).then((response)=>{
                // res.Interest_Rate = response.data.InterestRate
                this.setState({insrate:response.data.InterestAmount})
                // console.log(response.data.InterestAmount)
            });

    }
    doClose = () =>{
       this.setState({tenorpopbtn:false})
    }
    handleStartDateChange(date) {
	var selDate;
	selDate=dateFormat(date,"mmm d, yyyy");
	var flag=isValidBusinessDate(selDate,holidayStr,weekEndStr);
	if(flag){
        futureDate =date
        this.setState({startDate:date});

        res.valueDate  =   dateFormat(date,"mmm d, yyyy")
        // res.maturityDate =
        res.transDate  = dateFormat(date,"mmm d, yyyy")

        var bodyFormData = new FromData();
        bodyFormData.append("issueChild",res.productId);
       bodyFormData.append("company",res.deskId);
       bodyFormData.append("currencyCode",res.currency);
       bodyFormData.append("transType",res.transType);
       bodyFormData.append("tenorType",res.tenorType);
       bodyFormData.append("invstAcct",res.investAccount);
       bodyFormData.append("branchId",res.branchId);
       bodyFormData.append("dollarAmount",res.amount);
       bodyFormData.append("product",res.prodCat);
       bodyFormData.append("groupId",res.groupId);
       bodyFormData.append("transDate",res.transDate);
       var user = JSON.parse(sessionStorage.getItem('user'));
       bodyFormData.append("token",user[0].token)
       bodyFormData.append("clCompanyId",JSON.parse(sessionStorage.getItem('clientFirm')));

       axios({
        method: 'post',
        url:alertConstants.URL+"/tenorPopUp.do",
        data: bodyFormData,
        config: { headers: {'Content-Type': 'multipart/form-data' }}
        }).then((response)=>{
            // res.Interest_Rate = response.data.InterestRate
            // console.log("this.state.tenor--->",this.state.tenor)
            res.maturityDate  = response.data.find(e=>e.Tenor === this.state.tenor).MaturityDate;
            console.log("res->maturityDate-->",res.maturityDate)
            this.setState({ck:0})
        });
      }
     }
     onlyChange(e){

            if(e.target.checked){
             this.setState({idisabled:false})
             this.setState({clntRateRange:"Y"})
            }else
             this.setState({idisabled:true})

     }
    futureChange(e){
       if(e.target.value === "t"){
         this.setState({todaychk:true})
         this.setState({futurechk:false})
        futureDate.setDate(futureDate.getDate() - 1);

            this.setState({dateshow:'none'})
            datelbl ='Today Date';
            res.valueDate  =   dateFormat(new Date(),"mmm d, yyyy")

            // res.maturityDate =
            res.transDate  = dateFormat(new Date(),"mmm d, yyyy")
            this.state.fflag=false;

            var bodyFormData = new FromData();
            bodyFormData.append("issueChild",res.productId);
           bodyFormData.append("company",res.deskId);
           bodyFormData.append("currencyCode",res.currency);
           bodyFormData.append("transType",res.transType);
           bodyFormData.append("tenorType",res.tenorType);
           bodyFormData.append("invstAcct",res.investAccount);
           bodyFormData.append("branchId",res.branchId);
           bodyFormData.append("dollarAmount",res.amount);
           bodyFormData.append("product",res.prodCat);
           bodyFormData.append("groupId",res.groupId);
           bodyFormData.append("transDate",res.transDate);
           var user = JSON.parse(sessionStorage.getItem('user'));
           bodyFormData.append("token",user[0].token)
           bodyFormData.append("clCompanyId",JSON.parse(sessionStorage.getItem('clientFirm')));

           axios({
            method: 'post',
            url:alertConstants.URL+"/tenorPopUp.do",
            data: bodyFormData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
            }).then((response)=>{
                // res.Interest_Rate = response.data.InterestRate
                // console.log("this.state.tenor--->",this.state.tenor)
                res.maturityDate  = response.data.find(e=>e.Tenor === this.state.tenor).MaturityDate;
                console.log("res->maturityDate-->",res.maturityDate)
                this.setState({ck:0})
            });

        } else {
            this.setState({todaychk:false})
            this.setState({futurechk:true})
            futureDate = new Date();
            futureDate.setDate(futureDate.getDate() + 1);
            this.setState({startDate:futureDate})


            // res.maturityDate =
            res.valueDate  = dateFormat(futureDate,"mmm d, yyyy")
            res.transDate  = dateFormat(futureDate,"mmm d, yyyy")
            this.state.fflag=true;
            datelbl ='Future Date';
            this.setState({dateshow:'block'})

            var bodyFormData = new FromData();
            bodyFormData.append("issueChild",res.productId);
           bodyFormData.append("company",res.deskId);
           bodyFormData.append("currencyCode",res.currency);
           bodyFormData.append("transType",res.transType);
           bodyFormData.append("tenorType",res.tenorType);
           bodyFormData.append("invstAcct",res.investAccount);
           bodyFormData.append("branchId",res.branchId);
           bodyFormData.append("dollarAmount",res.amount);
           bodyFormData.append("product",res.prodCat);
           bodyFormData.append("groupId",res.groupId);
           bodyFormData.append("transDate",res.transDate);
           var user = JSON.parse(sessionStorage.getItem('user'));
           bodyFormData.append("token",user[0].token)
           bodyFormData.append("clCompanyId",JSON.parse(sessionStorage.getItem('clientFirm')));

           axios({
            method: 'post',
            url:alertConstants.URL+"/tenorPopUp.do",
            data: bodyFormData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
            }).then((response)=>{
                // res.Interest_Rate = response.data.InterestRate
                // console.log("this.state.tenor--->",this.state.tenor)
                res.maturityDate  = response.data.find(e=>e.Tenor === this.state.tenor).MaturityDate;
                 this.setState({ck:0})
            });
        }
    }
    tenorOpen(e){
        this.setState({tenorpopbtn:true})
    }

    render(){
         if(this.state.loading)
        return( <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div> );
       else{
         let userLocale="";
         let language="en-US";
         var user = JSON.parse(sessionStorage.getItem('user'));

      	 if(user[0].localeLang !== undefined){
      	      userLocale=user[0].localeLang;
                language=userLocale;

      	      language=language.replace("_","-");
            }

            var date;
            if(this.state.fflag){
                datelbl = "Future Date"
                 date = dateFormat(futureDate,"mmm d, yyyy");
             }
             else
                date = dateFormat(new Date(),"mmm d, yyyy");

        let entertrademarkup,tradedate,tradeDetails;
        let buttonMarkup,terormarkup,productDisplayName,dda,backButton;

            if(this.props.data !== undefined){
                data = this.props.data;
                if(this.state.flag !== "confirm"){
                    var mindate = new Date()
                    mindate.setDate(mindate.getDate() + 1)

                    var maxdate = new Date()
                        maxdate.setDate(maxdate.getDate() + 111)

                tradedate =
                <div>
                    <div  className="form-group col-md-2 col-sm-2">
                        <input  name="date"  id="todate"  type="radio" checked={this.state.todaychk} value="t"  onChange={this.futureChange} />
                        <label> Today ({dateFormat(new Date,"mmm d, yyyy")}) </label>
                    </div>
                    <div  className="form-group col-md-6 col-sm-2">
                        <input className="pull-left" name="date" id="futuredate" checked={this.state.futurechk} type="radio" onChange={this.futureChange} value="f"/>
                        <label className="pull-left" style={{marginTop:'4px'}}> Future Date</label>
                        <div className="form-group col-md-4 col-sm-4" style={{display:this.state.dateshow}}>
                            <DatePicker maxDate={maxdate} minDate={mindate} dateFormat="MMM dd, YYYY" selected={this.state.startDate} name="futureDate"  id="futureDate" ref="futureDate" className="form-control"  onChange={this.handleStartDateChange} />
                            <label> Booking Date:</label>
                            <label className="TxtNrml"> {dateFormat(new Date,"mmm d, yyyy")} </label>
                        </div>
                    </div>
                </div>
                if(data && data!== undefined && data.length > 0){
                  entertrademarkup = data && data.map((filter,index) => {
                    if(filter.name === "data"){

                         productDisplayName =
                         <div><h4>{filter.values[0].TradeDetails.productDisplayName}-{filter.values[0].TradeDetails.product}</h4></div>
                         dda = <div className="col-md-7 text-center">DDA Balance:{filter.values[0].TradeDetails.currency} </div>
                    }
                    if(filter.values!== undefined && filter.type === "select"){
                        return(
                         <div className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                              <label> { filter.label } :</label>
                              <select ref={ filter.name }  name={filter.name} id={filter.name} className="form-control input-sm" onChange={(e) => this.investChange(e)}>
                                 {
                                      filter.values && filter.values.map((obj,index) => {
                                         return <option key={index} value={obj.id}>{obj.name}</option>
                                       })
                                  }
                              </select>
                          </div>
                          );
                       }
                  })
                }

            }else{
                tradedate =
                    <div>
                        <div  className="form-group col-md-2 col-sm-2">
                            <label> {datelbl} ({date}) </label>
                        </div>

                    </div>
                entertrademarkup = data && data.map((filter,index) => {
                    if(filter.type === "select"){
                        var valuelabel;
                        if(this.refs[filter.name] !== undefined)
                         if(filter.name === "investAccount"){
                            valuelabel= filter.values.find(e => e.id===this.refs[filter.name].value).name;
                         }else
                          valuelabel = this.refs[filter.name].value;

                        return(
                         <div className="form-group col-md-4 col-sm-4" key={filter.id.toString()}>
                              <label  className="pull-left"> { filter.label } :</label>
                              <label className="pull-right TxtNrml"> { valuelabel }</label>
                          </div>
                          );
                       }
                       if(filter.name === "data"){
                       productDisplayName =
                       <div><h4>{filter.values[0].TradeDetails.productDisplayName}-{filter.values[0].TradeDetails.product}</h4></div>
                       }
                })
            }

                data && data.map((item,index) => {
                    if(item.name === "data"){
                        res = item.values[0].TradeDetails;
                         weekEndStr=res.weekEndStr;
                         holidayStr=res.holidayStr;
                    }
                })
                if(this.state.flag !== "confirm"){
                    buttonMarkup =  <button className="btn btn-primary btn-xs mt pull-right" id="reviewTrade" onClick={this.doSubmit.bind(this)}>Review Trade</button>
                    terormarkup = <button className="btn btn-primary btn-xs" id="tenor" onClick={this.tenorOpen }>Tenor</button>
                    backButton=<button className="btn btn-primary btn-xs mt" id="back" onClick={this.props.goback}>Back</button>
                }else{
                    buttonMarkup =  <button className="btn btn-primary btn-xs mt pull-right" id="confirmTrade" onClick={this.doConfirm.bind(this)}>Confirm Trade</button>
                    backButton=<button className="btn btn-primary btn-xs mt" id="back" onClick={this.goConfirmBack.bind(this)}>Back</button>
                }

                // var insrate;
                if(res !== undefined){
                //  insrate = (((parseInt(this.state.amtvalue) * parseFloat(this.state.Interest_Rate))/100)/parseInt(res.newDuration.toString())).toFixed(4);
                // if(insrate === "NaN")
                //   insrate ="";
                // console.log("before===>",res.valueDate)
                var temp;
                 if(res.valueDate.includes("Today")){
                    temp = res.valueDate;
                    temp= temp.replace("[",'')
                    temp= temp.replace("]",'')
                    temp= temp.split(":,")
                    res.valueDate = temp
                 }
                tradeDetails =
                         <div  key="tradedetails">
                         <table className="table table-bordered" width="100%">
                             <tbody>
                             <tr>
                                 <td width="30%" className="paddAll">
                                    <div  className="form-group">
                                        <label className="pull-left">Value Date:</label>
                                        {
                                            (typeof res.valueDate === 'string' || res.valueDate instanceof String) ?
                                                <label className="pull-right TxtNrml">{res.valueDate}</label>
                                            :
                                            <select style={{width:"50%",marginBottom:"5px"}} ref="valueDate"  name="valueDate" id="valueDate" className="form-control input-sm pull-right" onChange={(e) => this.valueDateChange(e)}>
                                            {
                                                 res.valueDate && res.valueDate.map((obj,index) => {
                                                    return <option key={index} value={index}>{obj}</option>
                                                })
                                             }
                                         </select>
                                        }
                                    </div>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Investment Amount:</label>
                                        <label className="pull-right TxtNrml">
                                        {
                                            this.state.disabled === true ?
                                            <div>  {this.state.amtvalue} <b> {res.currency}</b></div>
                                            :
                                              <div>  <input  type="text" ref={"amount"} id={"amount"} name={"amount"} defaultValue={this.state.amtvalue} onBlur={(e)=>{this.amountChange(e,userLocale)}}/>
                                                {res.currency}
                                                </div>
                                        }

                                        </label>
                                    </div>
                                    <div className="clearfix"></div>
                                    {
                                    this.state.flag !== "confirm" &&
                                    <div>
                                        <label>Min. {parseFloat(res.minDollar).toFixed(4)} - Max. {parseFloat(res.maxDollar).toFixed(4)} </label>
                                        <div className="clearfix"></div>
                                        <div className="col-md-12" style={{display:this.state.dateshow}}>
                                            <input type="checkbox" ref={"clntRateRange"} id={"clntRateRange"} value={this.state.clntRateRange} onClick={this.onlyChange}/>
                                            <label>Only Execute if Previous day rate is between:</label>
                                            <input type="text" ref={"rateFrom"} name={"rateFrom"} id={"rateFrom"} size="4"  disabled={this.state.idisabled} onBlur={(e)=>{rateDecimalChange(e,userLocale,res.rateDecimals,res.ccyRoundType)}} />% and <input type="text" ref={"rateTo"} name={"rateTo"} id={"rateTo"} size="4" disabled={this.state.idisabled} onBlur={(e)=>{rateDecimalChange(e,userLocale,res.rateDecimals,res.ccyRoundType)}} /> %
                                        </div>
                                    </div>
                                    }
                                    <div className="clearfix"></div>
                                    {
                                        this.state.flag !== "confirm" &&
                                        <div>
                                            <a id="addNotestotrade" onClick={(e)=>this.addNotes(e)}>Add Notes to Trade(Optional)</a>
                                            <textarea ref="addNotes" id="addNotes" style={{display:this.state.adddisp}} rows="5" cols="15"/>
                                        </div>
                                    }
                                 </td>
                                 <td width="30%" className="paddAll">
                                    <div  className="form-group">
                                        <label className="pull-left">Maturity Date:</label>
                                        <label className="pull-right TxtNrml">{res.maturityDate}</label>
                                    </div>
                                    {terormarkup}
                                     <TenorPopup  open={this.state.tenorpopbtn} doClose={this.doClose}  issueChild={res.productId} 	currency={res.currency} tenorType={res.tenorType} companyid={res.deskId} transDate={res.transDate}
                                     investAccount={res.investAccount}  groupId={res.groupId} branchId={res.branchId} onSelect={this.onSelect} amount={this.state.amtvalue} transType={res.transType} prodCat={res.prodCat} futureFlag={this.state.dateshow}/>
                                 </td>
                                 <td className="paddAll">
                                 {
                                    this.state.addnotes !== "" &&
                                    <div  className="form-group">
                                        <label className="pull-left"> View Notes:</label>
                                        <label className="pull-right TxtNrml">{this.state.addnotes}</label>
                                    </div>
                                 }
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Product:</label>
                                        <label className="pull-right TxtNrml">{res.product}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Amount:({res.currency})</label>
                                        <label className="pull-right TxtNrml">{this.state.amtvalue}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Interest Rate:({res.exactDuration} Days)</label>
                                        <label className="pull-right TxtNrml">{res.Interest_Rate}%</label>
                                    </div>
                                    <hr/>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Total Interest:({res.currency})</label>
                                        <label className="pull-right TxtNrml">{this.state.insrate}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                   {
                                    this.state.flag === "confirm" &&

                                        <div  className="form-group">
                                            <label className="pull-left">Total Amount:({res.currency})</label>
                                            <label className="pull-right TxtNrml">{(parseFloat(this.state.insrate.replace(/,/g,""))+parseFloat(this.state.amtvalue.replace(/,/g,""))).toLocaleString(language, {maximumFractionDigits:4})}</label>
                                        </div>
                                   }
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Cut-Off time:</label>
                                        <label className="pull-right TxtNrml">{res.Cut_Off_time}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Trading Hours:</label>
                                        <label className="pull-right TxtNrml">{res.Trading_Hours}</label>
                                    </div>


                                 </td>
                             </tr>
                             </tbody>
                         </table>
                        </div>
                }
            }
                var arr1 =[];
                for(var k in data){
                    arr1.push(data[k])
                }

                var obj = this.props.selectedRows;
                var arr = [];

                for(var k in obj){
                    arr.push({
                        "rowNumber" : k
                    });
                }

                if(this.refs.rateFrom !== undefined){
                    this.state.rateFrom=this.refs.rateFrom.value;

                }
                if(this.refs.rateTo !== undefined){
                    this.state.rateTo=this.refs.rateTo.value;
                }



            return(
                <div className="col-md-12">
                {productDisplayName}
              <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Trade Date </h4>
                    </div>
                    <div className="panel-body">
                       {tradedate}
                    </div>
                </div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Accounts</h4>
                    </div>
                    <div className="panel-body">
                            {entertrademarkup}
                            {dda}
                    </div>

                </div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Trade Details </h4>
                    </div>
                    <div className="panel-body">
                            {tradeDetails}
                    </div>
                    </div>
               {backButton}
               {buttonMarkup}
            </div>
            )

    }
}
}

export default FixedEnterTrade;