import React from 'react';
import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import '../../user/css/App.css';
import TradeTable from './TradeTable';
import FixedTradeTable from './FixedTradeTable';
import { connect } from 'react-redux';
import { tradeActions } from '../actions/trade.actions';
import IntrestTradeTable from './IntrestTradeTable';

class SelectProduct extends React.Component {
    constructor() {
        super();
        this.state = { tabIndex: 0 };
        this.selectTradeSubmit = this.selectTradeSubmit.bind(this);
        this.selectFixedTradeSubmit = this.selectFixedTradeSubmit.bind(this);
        this.fixedTerm = this.fixedTerm.bind(this);
        this.doRollover = this.doRollover.bind(this);
      }

      selectTradeSubmit(obj){
         this.props.method1(obj);
      }
      selectFixedTradeSubmit(obj){
        this.props.fixedmethod(obj);
     }
     componentDidUpdate(){
        if(this.props.TradeType === "FixedTerm")
        this.state.tabIndex = 2;

        if(this.props.tabIndex === "tabfixed")
          this.state.tabIndex = 2;
     }
    /*  componentDidMount(){
        this.props.dispatch(tradeActions.fetchFixedData());

      }*/
      fixedTerm(){

      }
      doRollover(item){
          this.props.rolloverMethod(item);
      }
    render(){
        const{ fixedtradedata } = this.props.fixedtradedata;
        let results,results1,columns,rollover,rollovermsg,operValdet;
        if(fixedtradedata !== undefined)
        fixedtradedata.map((item,index) => {
            if(item.name === "data")
                results = item.values
            if(item.name === "Columns")
                columns = item.values
        })

         if(fixedtradedata !== undefined)
        fixedtradedata.map((item,index) => {
            if(item.name === "data")
                results1 = item.values
            if(item.name === "rollOverData")
                rollover = item.values
            if(item.type === "rollovermessage")
                rollovermsg = item.name
         })

        return(
            <div>


                {/* <Tabs selectedIndex={this.state.tabIndex} onSelect={tabIndex => this.setState({ tabIndex })}>
                            <TabList>
                            <Tab title="moneyFunds">Money Funds</Tab> */}
                            {/* <Tab title="interestBearing">Interest Bearing</Tab> */}
                            {/* <Tab title="fixedTerm" onClick={this.fixedTerm.bind(this)}>Fixed Term</Tab> */}
                            {/* </TabList>
                            <TabPanel> */}
                                <div>
                                    <TradeTable method={this.selectTradeSubmit.bind(this)} columns={this.props.columns} operValDet={this.props.operValDet} message={this.props.message} tdata={this.props.data} />
                                </div>
                            {/* </TabPanel> */}
                            {/* <TabPanel>
                                <div className="col-md-12">
                                    <IntrestTradeTable method={this.selectTradeSubmit.bind(this)} columns={this.props.columns} tdata={this.props.data} />
                                </div>
                            </TabPanel>
                            <TabPanel>
                                <div className="col-md-12">
                                    <FixedTradeTable rollovermethod={this.doRollover.bind(this)} method={this.selectFixedTradeSubmit.bind(this)} columns={columns} message={this.props.message} rollovermsg={rollovermsg} tdata={results1} rollover={rollover}/>
                                </div>
                            </TabPanel> */}
                        {/* </Tabs> */}
            </div>
        );
    }
}
function mapStateToProps(state) {
    const { fixedtradedata } = state;
    return { fixedtradedata };
}

const connectedSelectProduct = connect(mapStateToProps)(SelectProduct);
export { connectedSelectProduct as SelectProduct };