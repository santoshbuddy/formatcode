import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
// import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import Loading from '../../common/Loading';
import '../../user/css/App.css';
import { connect } from 'react-redux';
import { SelectProduct } from './SelectProduct';
import { tradeActions } from '../actions/trade.actions';
import FormData from 'form-data';
import { Route , Redirect } from 'react-router-dom';
import MMMFEnterTrade from './MMMFEnterTrade';
// import FixedEnterTrade from './FixedEnterTrade';
import MMMFConfirmTrade from './MMMFConfirmTrade';
// import FixedRolloverConfirmTrade from './FixedRolloverConfirmTrade';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepConnector from '@material-ui/core/StepConnector';
import PropTypes from 'prop-types';
import { MuiThemeProvider, withStyles } from "@material-ui/core/styles";
import { alertConstants } from '../../common/constants/alert.constants';
import Dialog from "@material-ui/core/Dialog";
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import { Link } from 'react-router-dom';
import {muiTableStyles} from '../../styles/muidatatableCss';

import axios from 'axios';
import { Typography } from '@material-ui/core';
import ErrorMessage from '../../common/components/ErrorMessage';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts'
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts'

let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

var dateFormat = require('dateformat');

var frompage='',
    cnfflag='',
    errorDescription='',
    TradeType='',
    tabItem='',
    cData = '',
    targetPage = '',
    paramVal = '',
    invtype = '',
    backFlag='empty';

const styles = theme => ({
    root: {
      width: "90%"
    },
    button: {
      marginRight: theme.spacing.unit
    },
    instructions: {
    //   marginTop: theme.spacing.unit,
      marginBottom: theme.spacing.unit
    },
    connectorActive: {
        '& $connectorLine': {
        borderColor: "#00395c",
        borderWidth: '2px'
        },
    },
    connectorCompleted: {
        '& $connectorLine': {
        borderColor: "#00395c",
        borderWidth: '2px'
        },
    },
    connectorDisabled: {
        '& $connectorLine': {
        borderColor: theme.palette.grey[100],
        borderWidth: '2px'
        },
    },
    connectorLine: {
        transition: theme.transitions.create('border-color,border-size'),
    },
    stepIcon: {
      color: "#828384",
      fontSize: '19px',
      zIndex: '0',
      "&$active": {
        color: "#00395c",
        fontSize: '37px',
        marginTop: '-10px',
        zIndex: '1'
      },
      "&$completed": {
        color: "#00395c",
        fontSize: '19px'
      }
    },
    active: {},
    completed: {},
    typography: {
        useNextVariants: true,
    },
    iconContainer :{
        paddingRight: "0",
        zIndex: '2'
    },
    stepStyle:{
        paddingRight: "0",
        paddingLeft: "0"
    },
    alternativeLabel: {
        top: '9px',
        left: 'calc(-50% + 9px)',
        right: 'calc(50% + 9px)',
        zIndex: '1',
        fontFamily: 'MyFirstFont',
        src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
    },
  });

class TradeEntry extends React.Component {
    constructor() {
        super();
        this.state = {
            deletedRows:[],
            cflag:false,
            err:[],
            errors:[],
            activeStep: 0,
            invAmtValueArray:[],
            redeemflag:'',
            mmffuturedate:'',
            entertrade:true,
            ck:0,
            mmfflag:'',
            loading: false,
            rollover:'',
            tabIndex: 0,
            enterdata: '',
            fixed:'',
            tempAmout:'',
            open: false,
            msg:'',
            addnotes:'',
            lopen:false
        };
        this.tradeSubmit = this.tradeSubmit.bind(this);
        this.fixedTradeSubmit = this.fixedTradeSubmit.bind(this);
        this.reviewSubmit = this.reviewSubmit.bind(this);
        this.loadTradeData = this.loadTradeData.bind(this);
        this.confirmSubmit = this.confirmSubmit.bind(this);
        this.rolloverSubmit = this.rolloverSubmit.bind(this);
        this.rolloverConfirmSubmit = this.rolloverConfirmSubmit.bind(this);
        this.goFixedEntryback = this.goFixedEntryback.bind(this);
        this.goEntryback = this.goEntryback.bind(this);
        this.selectProd = this.selectProd.bind(this);
        this.doMMFBackConfirm = this.doMMFBackConfirm.bind(this);
        this.vData=[];
    }
    handleOpen(){
    	this.setState({lopen:true})
    }
    handleClose = () => {
        this.setState({ lopen: false });
   };
    componentDidMount()
    {
        frompage=''
        cnfflag=''
        TradeType=''
        tabItem=''
        errorDescription=''
        targetPage = ''
        invtype = ''

        if(this.props.location.state !== undefined){
            TradeType = this.props.location.state.TradeType;
            frompage = this.props.location.state.fromPage;
            cData = this.props.location.state.bformdata;
            targetPage = this.props.location.state.fromPage;
            paramVal = this.props.location.state.paramVal;
        }

        if(targetPage == 'ViewChanges') {
			var bodyFormdata = new FormData();
            var user = JSON.parse(sessionStorage.getItem('user'));
            if(cData != null && cData != '' && cData != undefined)
            {
                this.setState({ tabIndex: this.props.location.state.tabIndex });
                this.setState({ activeStep: this.props.location.state.activeStep });

                bodyFormdata.append("parentProdId0", cData.parentprodid);
                bodyFormdata.append("mmmfDealListSize", '1');
                bodyFormdata.append("fromPage", "multiDealingInput");
                bodyFormdata.append("mmfProdName0", cData.subprodname);
                bodyFormdata.append("mmfProdId0", cData.prodid);
                bodyFormdata.append("mmfRefacctNbr0", cData.refacctnbr);
                bodyFormdata.append("dispRefAcctnbr0", cData.refacctnbr);
                bodyFormdata.append("mmfFundAcct0", cData.escrowacctnbr);
                bodyFormdata.append("mmfInvestAcct0", cData.acctnbr);
                bodyFormdata.append("mmfsettlementAccountRefNbr0", cData.settleacctnbr);
                bodyFormdata.append("mmfsettlementAccount0", cData.settleacctname);
                bodyFormdata.append("maturityAccount0", cData.settleacctname);
                bodyFormdata.append("currencyCode0", cData.currency);

                if(paramVal == 'CLOSEACCOUNT') {
                    bodyFormdata.append("transTypes0", cData.transtype);
		            invtype  = '95';
                } else {
                    bodyFormdata.append("transTypes0", cData.transtype);
                    invtype  = cData.transtype
				}

                bodyFormdata.append("navType0", cData.navType);
                bodyFormdata.append("navTypeDesc0", cData.navTypeDesc);
                bodyFormdata.append("settlementAccount0", cData.settleacctname);
                bodyFormdata.append("settlementAccountRefNbr", cData.settleacctnbr);
                bodyFormdata.append("mmftodaysCutOFF0", cData['EOD Cut-Off Time']);

                this.props.dispatch(tradeActions.fetchTradeData(bodyFormdata));
            }
        }else if(targetPage == 'HOME') {
			    this.setState({ tabIndex: this.props.location.state.tabIndex ,enterdata:this.props.location.state.selected });
			    this.setState({ activeStep: this.props.location.state.activeStep });
			    var bformdata=this.props.location.state.bformdata;

			    var bodyFormdata = new FormData();
                var user = JSON.parse(sessionStorage.getItem('user'));

				bodyFormdata.append("token",user[0].token)
				bodyFormdata.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
			    bodyFormdata.append("fromPage", "multiDealingInput");

			    if(bformdata && bformdata.length>0){

                    bodyFormdata.append("mmmfDealListSize", bformdata.length);

                    bformdata && bformdata.map((item,index)=>{
                        bodyFormdata.append("parentProdId"+index, item[16]);

                        bodyFormdata.append("mmfProdName"+index, item[0]);
                        bodyFormdata.append("mmfProdId"+index, item[11]);
                        bodyFormdata.append("mmfRefacctNbr"+index, item[2]);
                        bodyFormdata.append("dispRefAcctnbr"+index, item[2]);
                        bodyFormdata.append("mmfFundAcct"+index, item[9]);
                        bodyFormdata.append("mmfInvestAcct"+index, item[12]);
                        bodyFormdata.append("mmfsettlementAccountRefNbr"+index, item[15]);
                        bodyFormdata.append("mmfsettlementAccount"+index,item[14]);
                        bodyFormdata.append("maturityAccount"+index, item[14]);
                        bodyFormdata.append("currencyCode"+index, item[13]);
                        bodyFormdata.append("transTypes"+index, item[18]);
                        bodyFormdata.append("navType"+index, item[17]);
                        bodyFormdata.append("navTypeDesc"+index, item[1]);
                    });
			    this.props.dispatch(tradeActions.fetchTradeReviewData(bodyFormdata));
			}
		}
        else
        {
            var bodyFormdata = new FormData();
            if(targetPage == 'INDICATIVERATES') {
                if(this.props.location.state.prodId != undefined)
                    bodyFormdata.append("prodId", this.props.location.state.prodId);
            }

           this.props.dispatch(tradeActions.fetchTradeData(bodyFormdata));
        }
    }

    tradeSubmit(obj)
    {
        this.state.enterdata = obj;
        this.setState({ tabIndex:1 })
        this.handleNext();
        var arr = [];
        for(var k in obj){
           if(obj[k])
            arr.push({
                "rowNumber" : k
            });
        }

        var results2;
        this.props.tradedata.tradedata && this.props.tradedata.tradedata.map((item,index) => {
            if(item.name === "data")
                results2 = item.values;
        })

       var bodyFormdata = new FormData();
        results2 && results2.map((item,index) => {
             for(var i=0 ;i <arr.length;i++){
                if(arr[i].rowNumber === item.rowNumber){
                    for(var k in item){
                        if(k === "fromPage" || k === "mmmfDealListSize")
                            bodyFormdata.append(k,item[k])
                        else
                            bodyFormdata.append(k+item.rowNumber,item[k])
                    }
                }
             }
        });

        this.props.dispatch(tradeActions.fetchTradeReviewData(bodyFormdata));
    }

    doMMFBackConfirm(amt)
    {
 		this.state.invAmtValueArray=[];
		this.setState({ tabIndex:0 })
		this.state.fixed= "";
		tabItem = ""
		this.handleBack();
		this.setState({errors:[]})
		this.setState({
		      activeStep: 0,
    		});
            this.handleClose();
    }

    goback()
    {
        this.setState({ tabIndex:0 })

    }

    goFixedEntryback()
    {
        this.setState({ tabIndex:0 })
        tabItem = "tabfixed"
        this.state.fixed= "";
    }

    goEntryback()
    {
        this.state.invAmtValueArray=[];
        this.setState({ tabIndex:0 })
        this.state.fixed= "";
        tabItem = ""
        this.handleBack();
        this.setState({errors:[]})
        // backFlag = 'back'
    }

    selectProd(){
        this.state.fixed= "";
        tabItem = ""
    }

    fixedTradeSubmit(obj)
    {
        this.state.enterdata = obj;
        this.setState({ tabIndex:1 })
        var results2;

        if(this.props.fixedtradedata.fixedtradedata !== undefined)
            this.props.fixedtradedata.fixedtradedata.map((item,index) => {
                if(item.name === "data")
                    results2 = item.values;
            })

       var bodyFormdata = new FormData();
        results2 && results2.map((item,index) => {
            if(obj === item.rowNumber){
                for(var k in item){
                    if(k === "fromPage")
                        bodyFormdata.append(k,"dealing")
                    else
                        bodyFormdata.append(k,item[k])
                }
            }
        });

        this.props.dispatch(tradeActions.fetchFixedTradeReviewData(bodyFormdata));
        this.setState({fixed:'fixed'})
    }

    loadTradeData(){
        if(targetPage === 'HOME'){
            var bodyFormdata = new FormData();
            this.props.dispatch(tradeActions.fetchTradeData(bodyFormdata));
        }
	}

    reviewSubmit(obj, fflag, futureDate, redeemflag, vInvestType, err,vData,deletedRows)
    {
        var arr = [];
        this.vData = vData;
        this.state.tempAmout = obj;
        this.setState({ entertrade:false });
        this.setState({ mmfflag:fflag});
        this.setState({ deletedRows:deletedRows})

        if(targetPage == 'ViewChanges')
        {
			var bodyFormdata = new FormData();
			if(err.length === 0)
			{
				var data;
                var user = JSON.parse(sessionStorage.getItem('user'));

                bodyFormdata.append("mmfProdName0", cData.subprodname);
                bodyFormdata.append("mmfProdId0", cData.prodid);
                bodyFormdata.append("mmfRefacctNbr0", cData.refacctnbr);
                bodyFormdata.append("dispRefAcctnbr0", cData.refacctnbr);
                bodyFormdata.append("mmfFundAcct0", cData.escrowacctnbr);
                bodyFormdata.append("mmfInvestAcct0", cData.acctnbr);
                bodyFormdata.append("mmfsettlementAccountRefNbr0", cData.settleacctnbr);
                bodyFormdata.append("maturityAccount0", cData.settleacctname);
                bodyFormdata.append("currencyCode0", cData.currency);

                if(paramVal == 'CLOSEACCOUNT')
                    bodyFormdata.append("transTypes0", "95");
                else
                    bodyFormdata.append("transTypes0", cData.transtype);

                bodyFormdata.append("navType0", cData.navType);
                bodyFormdata.append("navTypeDesc0", cData.navTypeDesc);
                bodyFormdata.append("tempAmount0", obj["tempAmount0"].value);
                bodyFormdata.append("addFlag0", 1);
                bodyFormdata.append("parentProdId", cData.parentprodid);
                bodyFormdata.append("mmmfDealListSize", '1');
                bodyFormdata.append("fromPage", "multiDealingInput");
                bodyFormdata.append("parentProdId0", cData.parentprodid);
				bodyFormdata.append("reactAjaxFlag","TRUE")

				if( obj["orderType0"] !== undefined){
				bodyFormdata.append("orderType0", obj["orderType0"].value);
				bodyFormdata.append("limitPrice0", obj["limitPrice0"].value);
				bodyFormdata.append("limitExpiry0", obj["limitExpiry0"].value);
				}
				bodyFormdata.append("nominatedAuthorise0", obj["nominatedAuthorise0"].value);
				bodyFormdata.append("token",user[0].token)
				bodyFormdata.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))

				if(this.state.mmfflag)
				{
					cnfflag='futufcnfflag'
					axios({
						method: 'post',
						url:alertConstants.URL+"/FTRADEINSERTTRADE.do",
						data: bodyFormdata,
						config: { headers: {'Content-Type': 'multipart/form-data' }}
					}).then((response)=>{
						data = response.data;
						if(data.length === 0 || data === undefined) {
							this.setState({ tabIndex:2 })
							this.setState({ errors:data })
							this.setState({ mmffuturedate:futureDate})
							this.setState({ redeemflag:redeemflag})
							this.setState({ vInvestType:vInvestType})
							this.setState({ err:err})
							this.handleNext();
						} else {
							var result;
							this.setState({ errors:data })
 							this.props.tradedata.tradedata && this.props.tradedata.tradedata.map((item,index) => {
								if(item.name === "data")
									result = item.values
							})

							var indexact = result.find(e =>e.mmfRefacctNbr === data[0].refAccountNbr).rowNumber;
							delete this.state.enterdata[indexact]
 						}
					});
				}
				else{
					axios({
						method: 'post',
						url:alertConstants.URL+"/MULTIMMFINSERTTRADE.do",
						data: bodyFormdata,
						config: { headers: {'Content-Type': 'multipart/form-data' }}
					}).then((response)=>{
						data = response.data;
						if(data.length === 0 || data === undefined) {
							this.setState({ tabIndex:2 })
							this.setState({ errors:data })
							this.setState({ mmffuturedate:futureDate})
							this.setState({ redeemflag:redeemflag})
							this.setState({ vInvestType:vInvestType})
							this.setState({ err:err})
							this.handleNext();
						} else {
							var result;
							this.setState({ errors:data })
							this.props.tradedata.tradedata && this.props.tradedata.tradedata.map((item,index) => {
								if(item.name === "data")
									result = item.values
							})

							var indexact = result.find(e =>e.mmfRefacctNbr === data[0].refAccountNbr).rowNumber;
							delete this.state.enterdata[indexact]
						}
                    });
                }
			} else {
				this.setState({ tabIndex:2 })
				this.setState({ errors:data })
				this.setState({ mmffuturedate:futureDate})
				this.setState({ redeemflag:redeemflag})
				this.setState({ vInvestType:vInvestType})
				this.setState({ err:err})
				this.handleNext();
			}
        }
        else
        {
             for(var k in this.state.enterdata){
                if(deletedRows.find(e=>e === k) === undefined){
                    if(this.state.enterdata[k])
                    arr.push({
                        "rowNumber" : k
                    });
                }
            }

            var results2,results3;
            var bodyFormdata = new FormData();

            this.props.tradedata.tradedata && this.props.tradedata.tradedata.map((item,index) => {
                if(item.name === "data")
                    results2 = item.values;
            })
            this.props.tradereviewdata.tradereviewdata && this.props.tradereviewdata.tradereviewdata.map((item,index) => {
                if(item.name === "data")
                    results3 = item.values;
            })

                results2 && results2.map((item,index) => {
                    for(var i=0 ;i <arr.length;i++){
                        if(deletedRows.find(e=>e === i) === undefined){
                            if((targetPage !== 'HOME' && arr[i].rowNumber === item.rowNumber) || (targetPage === 'HOME' && arr[i].rowNumber === item.mmfRefacctNbr) ){
                                for(var k in item){
                                    if(obj["tempAmount"+i] !== undefined && obj["tempAmount"+i].value !== undefined && obj["tempAmount"+i].value !== ""){
                                        if(k === "amount"){
                                            bodyFormdata.append("tempAmount"+i,obj["tempAmount"+i].value)
                                            bodyFormdata.append("shareAmount"+i,obj["tempAmount"+i].value)
                                            bodyFormdata.append("availShares"+i,results3[i].availShares)
                                            bodyFormdata.append("maxDollar"+i,results3[i].maxDollar)
                                            bodyFormdata.append("minDollar"+i,results3[i].minDollar)
                                        }
                                        else if(k === "addFlag")
                                            bodyFormdata.append(k+i,item.rowNumber)
                                        else if(k === "mmmfDealListSize")
                                            bodyFormdata.append(k,arr.length)
                                        else if(k === "maturityAccount")
                                            bodyFormdata.append(k+i,item["mmfsettlementAccount"])
                                        else if(k === "transTypes"){
                                            bodyFormdata.append(k+i,vInvestType[i])
                                        }else if(k === "parentProdId"  || k==="fromPage")
                                            bodyFormdata.append(k,item[k])
                                        else if(k === "tradePrivilege"){
                                         //   if(vInvestType[i] === "85")
                                                bodyFormdata.append("mmftrmode"+i,obj["mmftrmode"+i].value)
                                            if(this.state.mmfflag)
                                                bodyFormdata.append(k,"F")
                                            else
                                                bodyFormdata.append(k,item[k])
                                        }
                                        else if(k === "nav")
                                            bodyFormdata.append("nav"+i,this.vData[i].NAV)
                                        else
                                            bodyFormdata.append(k+i,item[k])
                                    }


                                }

								if( obj["orderType"+i] !== undefined){
								bodyFormdata.append("orderType"+i, obj["orderType"+i].value);
								bodyFormdata.append("limitPrice"+i, obj["limitPrice"+i].value);
								bodyFormdata.append("limitExpiry"+i, obj["limitExpiry"+i].value);
								}
								bodyFormdata.append("nominatedAuthorise"+i, obj["nominatedAuthorise"+i].value);
                            }
                        }
                    }
                });

                var data;
                var user = JSON.parse(sessionStorage.getItem('user'));
                bodyFormdata.append("reactAjaxFlag","TRUE")
                bodyFormdata.append("futureDate",dateFormat(futureDate,message["DATEFORMAT"]))
                bodyFormdata.append("isFutureTrade",fflag)
                bodyFormdata.append("token",user[0].token)
                bodyFormdata.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))

                    axios({
                        method: 'post',
                        url:alertConstants.URL+"/MULTIMMFINSERTTRADE.do",
                        data: bodyFormdata,
                        config: { headers: {'Content-Type': 'multipart/form-data' }}
                    }).then((response)=>{
                        data = response.data;
                        this.setState({ tabIndex:2 })
                        this.setState({ errors:data })
                        this.setState({ mmffuturedate:futureDate})
                        this.setState({ redeemflag:redeemflag})
                        this.setState({ vInvestType:vInvestType})
                        this.setState({ err:err})
                        this.handleNext();
                    });

        }
    }

    // confirmSubmit1(obj,amt,ins,data,clntRateRange,rateFrom,rateTo,futureDate,fflag,totins)
    // {
    //     frompage="";
    //     this.state.fixed='fixed';
    //     var arr = [];
    //     for(var k in obj){
    //         arr.push({
    //             "rowNumber" : k
    //         });
    //     }
    //     var results2;
    //     var bodyFormdata = new FormData();
    //     results2 = data;
    //        for(var k in results2){
    //           if(k === "amount"){
    //             bodyFormdata.append(k,amt)
    //         }
    //          else if(k === "Interest_Rate"){
    //             bodyFormdata.append(k,ins)
    //         }else if(k === "Total_Interest"){
    //             bodyFormdata.append(k,totins)
    //         }
    //         else if(k === "fromPage" )
    //             bodyFormdata.append("fromPage","dealing")
    //         else if(k === "tradePrivilege"){
    //             if(fflag)
    //                 bodyFormdata.append(k,"F")
    //             else
    //                 bodyFormdata.append(k,results2[k])
    //         }
    //         else
    //             bodyFormdata.append(k,results2[k])
    //      }

    //      if(fflag){
    //         if(k === "valueDate")
    //             bodyFormdata.append("valueDate",futureDate)
    //         if(k === "settlementDate")
    //             bodyFormdata.append("settlementDate",futureDate)
    //         if(k === "maturityDate")
    //             bodyFormdata.append("maturityDate",data.maturityDate)
    //         if(k === "fromPage" )
    //             bodyFormdata.append("fromPage","futuretrading")

    //         bodyFormdata.append("tradeDate",futureDate)
    //     }

    //     if(clntRateRange !== undefined)
    //         bodyFormdata.append("clntRateRange",clntRateRange)
    //     if(rateFrom !== undefined)
    //         bodyFormdata.append("rateFrom",rateFrom[0])
    //     if(rateTo !== undefined)
    //         bodyFormdata.append("rateTo",rateTo[0])


    //     if(fflag){
    //         cnfflag='ffcnfflag'
    //         this.props.dispatch(tradeActions.fetchFutureFixedTradeConfirmData(bodyFormdata));
    //     }else{
    //        cnfflag='fcnfflag'
    //          this.props.dispatch(tradeActions.fetchFixedTradeConfirmData(bodyFormdata));
    //     }
    // }

    confirmSubmit(deletedRows,obj,amt,ins,res,clntRateRange,rateFrom,rateTo,futureDate,mmfflag,mmftrmode,maturityAccount,vInvestType,errors,orderTypeArry,nominatedAuthoriseArry,notes)
    {

 		frompage	= "";
        cnfflag		= 'cnfflag'
        this.state.cflag = true
		var arr 	= [];
  		if(targetPage == 'ViewChanges')
		{
			arr.push({ "rowNumber" : 0 });
			var results2,results3;
			var bodyFormdata = new FormData();
			this.props.tradereviewdata.tradereviewdata && this.props.tradereviewdata.tradereviewdata.map((item,index) => {
				if(item.name === "data")
					results3 = item.values;
			})

 			bodyFormdata.append("rowNumber0",0)
 			bodyFormdata.append("mmfProdName0",cData.subprodname)
 			bodyFormdata.append("mmfProdId0",cData.prodid)
 			bodyFormdata.append("mmfRefacctNbr0",cData.refacctnbr)
 			bodyFormdata.append("dispRefAcctnbr0", cData.refacctnbr);
 			bodyFormdata.append("mmfFundAcct0", cData.escrowacctnbr);
 			bodyFormdata.append("mmfInvestAcct0", cData.acctnbr);
            bodyFormdata.append("mmfsettlementAccountRefNbr0", cData.settleacctnbr);

            if(paramVal == 'CLOSEACCOUNT')
                bodyFormdata.append("transTypes0", "95");
            else
                bodyFormdata.append("transTypes0", cData.transtype);

  			bodyFormdata.append("currencyCode0", cData.currency);
 			bodyFormdata.append("currency0", cData.currency);
 			bodyFormdata.append("mmmfDealListSize", '1');
 			bodyFormdata.append("fromPage", "multiDealingInput");
 			bodyFormdata.append("mmfsettlementAccount0",cData.settleacctname);
 			bodyFormdata.append("addFlag0",0);
 			bodyFormdata.append("termProdId0",cData.prodid);
 			bodyFormdata.append("todaysCutOFF0", cData['EOD Cut-Off Time']);
 			bodyFormdata.append("mmftodaysCutOFF0", cData['EOD Cut-Off Time']);
 			bodyFormdata.append("parentProdId", cData.parentprodid);
 			bodyFormdata.append("product0",cData.prodid);
 			bodyFormdata.append("craProdId0",cData.prodid);
 			bodyFormdata.append("craProdName0",cData.subprodname)
			bodyFormdata.append("availShares0",results3[0].availShares);
			bodyFormdata.append("tempAmount0",amt[0]);
			bodyFormdata.append("shareAmount0",amt[0]);
			bodyFormdata.append("nav0",results3[0].nav);
			bodyFormdata.append("navType0", cData.navType);
			bodyFormdata.append("navTypeDesc0", cData.navTypeDesc);
			if(orderTypeArry !== undefined && orderTypeArry[0] !== undefined)
			console.log('orderTypeArry[0].orderType>>>'+orderTypeArry[0].orderType)
				if(orderTypeArry !== undefined && orderTypeArry[0] !== undefined && orderTypeArry[0].orderType ==='L'){
				bodyFormdata.append("orderType0", orderTypeArry[0].orderType);
				bodyFormdata.append("limitPrice0", orderTypeArry[0].limitPrice);
				bodyFormdata.append("limitExpiry0", orderTypeArry[0].limitExpiry);
		 		}else {
                                bodyFormdata.append("orderType0", 'M');
				bodyFormdata.append("limitPrice0", '');
				bodyFormdata.append("limitExpiry0", '');
	                       }
				if(nominatedAuthoriseArry !== undefined && nominatedAuthoriseArry[0] !== undefined)
		 		bodyFormdata.append("nominatedAuthorise0", nominatedAuthoriseArry[0]);

			if(mmfflag)
				bodyFormdata.append("tradePrivilege","F");
			else
				bodyFormdata.append("tradePrivilege","T");

			if(clntRateRange[0] !== undefined)
				bodyFormdata.append("clntRateRange0",clntRateRange[0])

			if(rateFrom[0] !== undefined)
				bodyFormdata.append("rateFrom0",rateFrom[0])

			if(rateTo[0] !== undefined)
				bodyFormdata.append("rateTo0",rateTo[0])

			if(mmftrmode[0] !== undefined)
				bodyFormdata.append("mmftrmode0",mmftrmode[0])

			if(mmfflag)
				bodyFormdata.append("futureDate",futureDate)
		}
		else
		{
  			for(var k in obj)
			{
                if(obj[k]){

                        arr.push({
                            "rowNumber" : k
                        });

                }
			}
            console.log("arrr",arr)
			var results2,results3;
			var bodyFormdata = new FormData();
			this.props.tradedata.tradedata && this.props.tradedata.tradedata.map((item,index) => {
				if(item.name === "data")
					results2 = item.values;
			})

			this.props.tradereviewdata.tradereviewdata && this.props.tradereviewdata.tradereviewdata.map((item,index) => {
				if(item.name === "data")
					results3 = item.values;
			})

			results2 && results2.map((item,index) => {
 				for(var i=0 ;i <arr.length;i++)
				{
                    if((targetPage !== 'HOME' && arr[i].rowNumber === item.rowNumber) || (targetPage === 'HOME' && arr[i].rowNumber === item.mmfRefacctNbr) ){
                        console.log("deletedRows::",deletedRows,"===> item.rowNumebr ::",i)
                        if(deletedRows.find(e=>e === parseInt(i)) === undefined){
						for(var k in item)
						{
							if(k === "amount") {
								bodyFormdata.append("tempAmount"+i,amt[i])
								bodyFormdata.append("shareAmount"+i,amt[i])
								bodyFormdata.append("availShares"+i,results3[i].availShares)
							}
							else if(k === "txtTrade")
								bodyFormdata.append(k+i,notes.find(e=> e.name.includes("addnotes")).value)
							else if(k === "addFlag")
								bodyFormdata.append(k+i,item.rowNumber)
							else if(k === "mmmfDealListSize")
								bodyFormdata.append(k,arr.length)
							else if(k === "maturityAccount") {
								bodyFormdata.append(k+i,maturityAccount[i])
							}
							else if(k === "transTypes")
								bodyFormdata.append(k+i,vInvestType[i])
							else if(k === "parentProdId"  || k==="fromPage")
								bodyFormdata.append(k,item[k])
							else if(k === "tradePrivilege") {
								if(mmfflag)
									bodyFormdata.append(k,"F")
								else
									bodyFormdata.append(k,item[k])
							}
							else if(k === "nav"){
 								bodyFormdata.append("nav"+i,this.vData[i].NAV)
                            }else
								bodyFormdata.append(k+i,item[k])
						}

						if(orderTypeArry !== undefined && orderTypeArry[i] !== undefined && orderTypeArry[i].orderType ==='L'){
							bodyFormdata.append("orderType"+i, orderTypeArry[i].orderType);
							bodyFormdata.append("limitPrice"+i, orderTypeArry[i].limitPrice);
							bodyFormdata.append("limitExpiry"+i, orderTypeArry[i].limitExpiry);
		 				}else{
							bodyFormdata.append("orderType"+i, orderTypeArry[i].orderType);
							bodyFormdata.append("limitPrice"+i, '');
							bodyFormdata.append("limitExpiry"+i, '');
						}
						if(nominatedAuthoriseArry !== undefined && nominatedAuthoriseArry[i] !== undefined ){
							bodyFormdata.append("nominatedAuthorise"+i, nominatedAuthoriseArry[i]);
 						}

						if(clntRateRange[i] !== undefined)
							bodyFormdata.append("clntRateRange"+i,clntRateRange[i])
						if(rateFrom[i] !== undefined)
							bodyFormdata.append("rateFrom"+i,rateFrom[i])
						if(rateTo[i] !== undefined)
							bodyFormdata.append("rateTo"+i,rateTo[i])
						if(mmftrmode[i] !== undefined){
							//if(vInvestType[i] === "85")
								bodyFormdata.append("mmftrmode"+i,mmftrmode[i])
                                // bodyFormdata.append("txtTrade"+i,notes.find(e=> e.name.includes("addnotes")).value)
                                // console.log("notes",notes.find(e=> e.name.includes("addnotes")).value)
                            }
                            if(mmfflag)
                            bodyFormdata.append("futureDate",futureDate)


                        }
                    }
            }

			});
		}

		this.state.loading = true;
		if(mmfflag) {
			cnfflag='futufcnfflag'
			this.props.dispatch(tradeActions.fetchfutureTradeConfirmData(bodyFormdata));
		}
		else
			this.props.dispatch(tradeActions.fetchTradeConfirmData(bodyFormdata));
	}

    rolloverSubmit(selectedRollover){
        var bodyFormdata = new FormData();
        for(var k in selectedRollover){
            if(k === "TRANSID")
                bodyFormdata.append("oldTransId",selectedRollover[k])
        }
        this.props.dispatch(tradeActions.fetchFixedRolloverTradeReviewData(bodyFormdata));
        this.setState({rollover:'rollover'})
        this.setState({ tabIndex:2 })
    }

    rolloverConfirmSubmit(res,rollovertypetext,nextFlag,rolloverflag,rollovervalue,pricnamt){
        cnfflag='rollcnfflag';
        var bodyFormdata = new FormData();
        for(var k in res){
            bodyFormdata.append(k,res[k])
            if(nextFlag === 'O'){
                bodyFormdata.append("amount",res.dAmount)
                bodyFormdata.append("dollarAmount",pricnamt)
            }
        }
        bodyFormdata.append("nextFlag",nextFlag)
        bodyFormdata.append("rollovertext",rollovertypetext)
        bodyFormdata.append("rollovertype",rollovervalue)

        if(rolloverflag !== "")
            bodyFormdata.append("rolover",rolloverflag)

        this.props.dispatch(tradeActions.fetchFixedRolloverTradeConfirmData(bodyFormdata));
        this.setState({ck:1})
    }

    handleNext = () => {
        const { activeStep } = this.state;
        this.setState({
            activeStep: activeStep + 1
        });
    };

    handleBack = () => {
        var bodyFormdata = new FormData();
        this.props.dispatch(tradeActions.fetchTradeData(bodyFormdata));
        this.setState(state => ({
            activeStep: state.activeStep - 1,
        }));
    };

    getSteps() {
        return ['Select Trade', 'Enter Trade', 'Confirm Trade'];
    }

    render(){

        const{ tradedata } = this.props.tradedata;
        const{ tradereviewdata } = this.props.tradereviewdata;
        const{ fixedtradereviewdata } = this.props.fixedtradereviewdata;
        const { classes } = this.props;
        const steps = this.getSteps();
        const { activeStep } = this.state;
        let tvar="";
        errorDescription="";
        const connector = (
            <StepConnector
              classes={{
                active: classes.connectorActive,
                completed: classes.connectorCompleted,
                disabled: classes.connectorDisabled,
                line: classes.connectorLine,
                alternativeLabel: classes.alternativeLabel,
              }}
            />
          );

        if(this.props.fixedtradeconfirmdata.fixedtradeconfirmdata !== undefined){
            if(this.props.fixedtradeconfirmdata.fixedtradeconfirmdata.tradeinfo !== undefined){
                if(this.props.fixedtradeconfirmdata.fixedtradeconfirmdata.tradeinfo.FIXRED_TERM_TRADEINITIATED === "YES"){
                    if(frompage!=="newtrade" && cnfflag==="fcnfflag"){
                            cnfflag="false";
                            frompage="false";
                            tvar= <Route
                                render={()=>
                                	<Redirect to={{ pathname: 'CONFTRD', state: { transId: this.props.tradeconfirmdata.tradeconfirmdata[0].transId } }} />
                                }
                            />
                        }
                    }
                }
                else if(frompage!=="newtrade" && cnfflag==="fcnfflag"){
                    cnfflag="false";
                    frompage="false";
                    errorDescription = this.props.fixedtradeconfirmdata.fixedtradeconfirmdata.errorDescription
                }
        }

        if(this.props.futurefixedtradeconfirmdata.futurefixedtradeconfirmdata !== undefined){
            if(this.props.futurefixedtradeconfirmdata.futurefixedtradeconfirmdata.tradeinfo !== undefined){
                if(this.props.futurefixedtradeconfirmdata.futurefixedtradeconfirmdata.tradeinfo.FIXRED_TERM_TRADEINITIATED === "YES"){
                    if(frompage!=="newtrade" && cnfflag==="ffcnfflag"){
                        cnfflag="false";
                        frompage="false";
                        tvar= <Route
                            render={()=>
                                <Redirect  to='report/FUTTRD' />
                            }
                        />
                    }
                }
            }
            else if(frompage!=="newtrade" && cnfflag==="ffcnfflag"){
                    cnfflag="false";
                    frompage="false";
                    errorDescription = this.props.futurefixedtradeconfirmdata.futurefixedtradeconfirmdata.errorDescription
            }
        }

        if(this.props.tradeconfirmdata.tradeconfirmdata !== undefined){
            if(this.props.tradeconfirmdata.tradeconfirmdata[0].TRADE_INITIATED === "YES"){
                if(frompage!=="newtrade" && cnfflag==="cnfflag"){
                    cnfflag="false";
                    frompage="false";
                    if(this.props.tradeconfirmdata.tradeconfirmdata[0].TradeStatus !== "Initiated"){
                        this.handleOpen();
                        tvar= <Route
                        render={(e)=>
                            <Redirect  to='DEALENT' />
                        }
                    />
                    }else
                    tvar= <Route
                            render={(e)=>
                            	<Redirect to={{ pathname: 'CONFTRD', state: { transId: this.props.tradeconfirmdata.tradeconfirmdata[0].transId } }} />
                            }
                        />
                }
            }
            else if(frompage!=="newtrade" && cnfflag==="cnfflag"){
                cnfflag="false";
                frompage="false";
                errorDescription = this.props.tradeconfirmdata.tradeconfirmdata[0].errorDescription
            }
        }

        if(this.props.futuretradeconfirmdata.futuretradeconfirmdata !== undefined){
            if(this.props.futuretradeconfirmdata.futuretradeconfirmdata[0].TRADE_INITIATED === "YES"){
                if(frompage!=="newtrade" && cnfflag==="futufcnfflag"){
                    cnfflag="false";
                    frompage="false";
                    if(this.props.futuretradeconfirmdata.futuretradeconfirmdata[0].TradeStatus !== "Initiated"){
                        this.handleOpen();
                        tvar= <Route
                        render={(e)=>
                            <Redirect  to='DEALENT' />
                        }
                    />
                    }else
                    tvar= <Route
                            render={ (e)=>
                                <Redirect  to='report/FUTTRD' />
                            }
                        />
                }
            }
            else if(frompage!=="newtrade" && cnfflag==="futufcnfflag"){
                cnfflag="false";
                frompage="false";
                errorDescription = this.props.futuretradeconfirmdata.futuretradeconfirmdata[0].errorDescription
            }
        }

        if(this.props.rolloverfixedtradeconfirmdata.rolloverfixedtradeconfirmdata !== undefined){
            if(this.props.rolloverfixedtradeconfirmdata.rolloverfixedtradeconfirmdata.tradeinfo !== undefined){
                if(this.props.rolloverfixedtradeconfirmdata.rolloverfixedtradeconfirmdata.tradeinfo.FIXRED_TERM_TRADEINITIATED === "YES"){
                    if(frompage!=="newtrade" && cnfflag==="rollcnfflag"){
                        cnfflag="false";
                        frompage="false";
                        tvar= <Route
                            render={()=>
                            	<Redirect to={{ pathname: 'CONFTRD', state: { transId: this.props.tradeconfirmdata.tradeconfirmdata[0].transId } }} />
                            }
                         />
                    }
                }
            }else if(frompage!=="newtrade" && cnfflag==="rollcnfflag"){
                cnfflag="false";
                frompage="false";
                errorDescription = this.props.rolloverfixedtradeconfirmdata.rolloverfixedtradeconfirmdata.errorDescription
            }
        }

        let results,message,results1,results2,columns,bannerMessage,operVal;
        if(tradedata !== undefined)
            tradedata.map((item,index) => {
                if(item.name === "data")
                    results = item.values
                    if(item.name === "commonData"){
                      operVal = item.commonData.operVal
                      //console.log("tradedata-------------"+JSON.stringify(item.name)+"uuuu---"+JSON.stringify(item.commonData.operVal));
                     }

                if(item.type === "Message")
                    message = item.label
                if(item.name === "Columns")
                    columns = item.values
                if(item.name === "bannerMessage")
                    bannerMessage = item.value

                    if(bannerMessage !== undefined && bannerMessage.length>0){
                    	bannerMessage = bannerMessage.replace("<BR>","")
					}
            })

        if(tradereviewdata !== undefined)
            tradereviewdata.map((item,index) => {
                if(item.name === "data")
                    results1 = item.values

            })
        if(fixedtradereviewdata !== undefined)
            results2 = fixedtradereviewdata

        return(
            <div >
                <NavBar />
                <div className="mainContent">
                {tvar}
                    <Typography variant="h5" component="h3" className="screenTitle">Trade Entry</Typography>
                    {
                        errorDescription !== '' &&
                        <div className="alert alert-danger">{errorDescription}</div>
                    }
                        <div className="clearfix">
                        {/* {
                            bannerMessage !== undefined && bannerMessage.length >0 &&
                        <div className="alert alert-danger" style={{width:"61%"}}>
                        {
                            bannerMessage
                        }
                        </div>
                        } */}
                        {/*<label className="pull-left">Money Funds </label>*/}
                        <MuiThemeProvider theme={muiTableStyles.getstepper()}>
                            <Stepper className="col-md-4 stepperStyle" alternativeLabel activeStep={activeStep} connector={connector}>
                                {steps && steps.map((label, index) => {
                                    const props = {};
                                    const labelProps = {};
                                    return (
                                    <Step key={label} {...props} className={classes.stepStyle}>
                                        <StepLabel classes={{iconContainer:classes.iconContainer}}
                                            StepIconProps={{
                                                classes: { root: classes.stepIcon, active:classes.active, completed:classes.completed }
                                            }}>
                                            {label}
                                        </StepLabel>
                                    </Step>
                                    );
                                })}
                            </Stepper>
                        </MuiThemeProvider>
                        <div className="clearfix"></div>
                        <Typography variant="h6" component="h3" className="screenSubTitle">Money Market Fund</Typography>

				{this.state.loading===false ?
                <div className={classes.instructions}>

                       {
                           activeStep === 0 &&
                            <SelectProduct tabIndex={tabItem} rolloverMethod={this.rolloverSubmit.bind(this)} method1={this.tradeSubmit.bind(this)} fixedmethod={this.fixedTradeSubmit.bind(this)} operValDet={operVal} data={results} message={message} columns={columns} TradeType={TradeType}/>
                       }
                       {
                           activeStep === 1 &&
                            <MMMFEnterTrade  errors={this.state.errors}  goback={this.goEntryback.bind(this)}  invAmtValueArray={this.state.invAmtValueArray} method={this.reviewSubmit.bind(this)} selectedRows={this.state.enterdata} invtype={invtype} data={results1} backFlag={backFlag}  loadTradeData={this.loadTradeData.bind(this)} targetPage={targetPage}/>
                       }
                        {
                           activeStep === 2 && !this.state.cflag &&
                            <MMMFConfirmTrade deletedRows={this.state.deletedRows} err={this.state.err} errors={this.state.errors} goback={this.doMMFBackConfirm.bind(this)} vInvestType={this.state.vInvestType} redeemflag={this.state.redeemflag} mmffuturedate={this.state.mmffuturedate} mmfflag={this.state.mmfflag} addnotes={this.state.addnotes} amount={this.state.tempAmout} fixed={this.state.fixed} flag="confirm" method2={this.confirmSubmit.bind(this)} selectedRows={this.state.enterdata} data={results1}/>
                        }
                </div>:<div className="col-md-12 mt-mb"><div className="clearfix"></div><Loading/></div>
				}
            </div>
                        {/* <Tabs selectedIndex={this.state.tabIndex} onSelect={tabIndex => this.setState({ tabIndex }) }>
                            <TabList>
                            <Tab onClick={this.selectProd}>1. Select Product</Tab>
                            <Tab disabled={this.state.entertrade}>2. Enter Trade </Tab>
                            <Tab disabled={true}>3. Confirm Trade  </Tab>
                            </TabList>
                            <TabPanel>
                                <SelectProduct tabIndex={tabItem} rolloverMethod={this.rolloverSubmit.bind(this)} method1={this.tradeSubmit.bind(this)} fixedmethod={this.fixedTradeSubmit.bind(this)} data={results} message={message} columns={columns} TradeType={TradeType}/>
                            </TabPanel>
                            <TabPanel>
                                {   this.state.fixed === "fixed" &&
                                    <FixedEnterTrade  goback={this.goFixedEntryback.bind(this)} fixed={this.state.fixed} method={this.reviewSubmit.bind(this)} method2={this.confirmSubmit1.bind(this)} selectedRows={this.state.enterdata} data={results2}/>
                                }
                                {
                                    this.state.fixed !== "fixed" &&
                                    <MMMFEnterTrade   goback={this.goEntryback.bind(this)}  invAmtValueArray={this.state.invAmtValueArray} method={this.reviewSubmit.bind(this)} selectedRows={this.state.enterdata} data={results1}/>
                                }
                            </TabPanel>
                            <TabPanel>
                                {
                                    this.state.rollover === "rollover" &&
                                        <FixedRolloverConfirmTrade goback={this.goFixedEntryback.bind(this)} method2={this.rolloverConfirmSubmit.bind(this)} data={rolloverfixedtradereviewdata}/>
                                }
                                {
                                     this.state.rollover !== "rollover" &&
                                        <MMMFConfirmTrade goback={this.doMMFBackConfirm.bind(this)} redeemflag={this.state.redeemflag} mmffuturedate={this.state.mmffuturedate} mmfflag={this.state.mmfflag} addnotes={this.state.addnotes} amount={this.state.tempAmout} fixed={this.state.fixed} flag="confirm" method2={this.confirmSubmit.bind(this)} selectedRows={this.state.enterdata} data={results1}/>
                                }
                            </TabPanel>
                        </Tabs> */}

                        </div>
                    {/* </div> */}
                {/* </div> */}
                <div style={{display:this.state.lopen === true?"block":"none"}}>
                    <ErrorMessage text={"This Trade is Not Initiated."} type={'alert'} lang="en"/>
                </div>
            </div>
        );
    }
}

TradeEntry.propTypes = {
    classes: PropTypes.object,
};


function mapStateToProps(state) {
    const { tradedata,tradereviewdata,tradeconfirmdata,fixedtradedata,fixedtradereviewdata,fixedtradeconfirmdata,futuretradeconfirmdata,futurefixedtradeconfirmdata,rolloverfixedtradereviewdata,rolloverfixedtradeconfirmdata } = state;
    state="";
    return { tradedata,tradereviewdata,tradeconfirmdata,fixedtradedata,fixedtradereviewdata,fixedtradeconfirmdata,futuretradeconfirmdata,futurefixedtradeconfirmdata,rolloverfixedtradereviewdata,rolloverfixedtradeconfirmdata };
}

const connectedTradeEntry = connect(mapStateToProps)(withStyles(styles)(TradeEntry));
export { connectedTradeEntry as TradeEntry };