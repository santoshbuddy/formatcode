import React from 'react';
import Loading from '../../common/Loading';
import {replaceChars} from './amountValidations';
import {addCommaDV} from './amountValidations';
import { CustomCheckBox } from '../../styles/CustomCheckBox';
import Select from '@material-ui/core/Select';
import MenuItem from "@material-ui/core/MenuItem";
import ErrorMessage from '../../common/components/ErrorMessage';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import { MapsTransferWithinAStation } from 'material-ui/svg-icons';
import { showConfirm, showAlert } from '../../common/components/showConfirmLayer';
import { Grid, InputLabel, withStyles } from '@material-ui/core';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import { MuiStyles } from '../../styles/MuiStyles';
import { MuiThemeProvider } from 'material-ui/styles';
import { muiTableStyles } from '../../styles/muidatatableCss';
import Formatter from '../../formats/Formatters';

let message = (sessionStorage.getItem('userLocaleTxt') === null || sessionStorage.getItem('userLocaleTxt')==="en_US")?messageUS:messageTr;
var dateFormat = require('dateformat');
var data;
var res,navtypeflag=false;
var datelbl='Today';
let fundriskconfrim=false;
var cashVal='';
var temp='';
var temp1='',clntRateRange='',rateFrom='',rateTo='',mmftrmode='',maturityAccount='';
let newcash='',newshares='',transshares='';
let	CNAVLVNAVSHAREDECIMALS		= "2";
let	DEFAULTSHAREDECIMALS	= "3";


class MMMFConfirmTrade extends React.Component {
    constructor(props) {
        super(props);
        this.state={openRisk: false,deletedRows:[],sindex:-1,invAmtValueArray:[],loading:true,clntRateRange:'',ck:'',amount:[],clntRateRange:[],rateFrom:[],rateTo:[],mmftrmode:[],maturityAccount:[],amtvalue:'',Interest_Rate:'',addnotes:'',orderTypeArry:[],nominatedAuthoriseArry:[]}
         this.doConfirm = this.doConfirm.bind(this);
         this.doMMFBackConfirm = this.doMMFBackConfirm.bind(this);
         this.fundriskcheckconfirm = this.fundriskcheckconfirm.bind(this);
         this.doFundSheetInfo = this.doFundSheetInfo.bind(this);
         this.hideConfirm = this.hideConfirm.bind(this);
         this.showRisk = this.showRisk.bind(this);

      }
      hideConfirm(){
        document.getElementById("confirmTrade").style.display="none"
      }

    showRisk() {
        this.setState({openRisk: true});
    }

    handleClose = () => {
        this.setState({ openRisk: false });
    };

    doFundSheetInfo(itm, e) {
    	if(itm === undefined) { itm = ''; }
		this.externalWindow = window.open(itm, '', 'width=800,height=500,left=10,top=10,resizable=yes');
	}

    doConfirm(e){
        if(fundriskconfrim === true){
            if(this.props.errors !== undefined && this.props.errors.find(e=>e.alertFlag) !== undefined){
                if(confirm(this.props.errors.find(e=>e.alertFlag).alertFlag)){
                    var inv = this.state.vInvestType.find(e => e === "10")
                    if(inv === "10" && navtypeflag)
                       showAlert(this,message["NAVDELMSG"]);
                    navtypeflag=false
                    fundriskconfrim = false;
                    this.props.method2(this.state.deletedRows,this.props.selectedRows,this.state.amount,this.state.Interest_Rate,res,this.state.clntRateRange,this.state.rateFrom,this.state.rateTo,dateFormat(this.props.mmffuturedate,message["DATEFORMAT"]),this.props.mmfflag,this.state.mmftrmode,this.state.maturityAccount,this.state.vInvestType,this.props.errors,this.state.orderTypeArry,this.state.nominatedAuthoriseArry,this.state.invAmtValueArray)
                }
            }else{
                var inv = this.state.vInvestType.find(e => e === "10")
                if(inv === "10" && navtypeflag)
                   showAlert(this,message["NAVDELMSG"]);
                navtypeflag=false;
                fundriskconfrim = false;
                this.props.method2(this.state.deletedRows,this.props.selectedRows,this.state.amount,this.state.Interest_Rate,res,this.state.clntRateRange,this.state.rateFrom,this.state.rateTo,dateFormat(this.props.mmffuturedate,message["DATEFORMAT"]),this.props.mmfflag,this.state.mmftrmode,this.state.maturityAccount,this.state.vInvestType,this.props.errors,this.state.orderTypeArry,this.state.nominatedAuthoriseArry,this.state.invAmtValueArray)
            }
        }
        else{
            showAlert(this,message["PLSCRASC"]);
        }
    }

    doMMFBackConfirm(){
      this.props.goback(this.state.invAmtValueArray)
    }
    changeMyVariable(){
        navtypeflag = true;
    }
    fundriskcheckconfirm(e){
        fundriskconfrim = e.target.checked;
    }
    render(){
        const {classes} = this.props;
     	let userLocale="";
    	var user = JSON.parse(sessionStorage.getItem('user'));
    	if(user[0].localeLang !== undefined){
    		userLocale=user[0].localeLang;
	    }

        if(this.props.data !== undefined){
            data = this.props.data;
            this.state.loading=false;

        }
        if(this.state.loading)
         return( <div className="col-md-12 mt-mb"><div className="clearfix"></div><Loading/></div> );
        else{
         var date;
         if(this.props.mmfflag === true){
            datelbl = "Future Date"
             date = dateFormat(this.props.mmffuturedate,message["DATEFORMAT"]);
         }
         else{
            datelbl='Today'
            //  date = dateFormat(new Date(),message["DATEFORMAT"]);
             date = <Formatter date={new Date()}/>;
         }

        let entertrademarkup,tradedate,factsheeturl,kiidurl;
        let buttonMarkup;


            var arr1 =[];
                for(var k in data){
                    arr1.push(data[k]);
                }

                this.state.vInvestType = this.props.vInvestType;
                var obj = this.props.selectedRows;
                var arr = [];

                if(this.props.deletedRows !== undefined)
                    this.state.deletedRows = this.props.deletedRows
                for(var k in obj){
                    if(this.props.deletedRows.find(e=>e === k) === undefined){
                        arr.push({
                        "rowNumber" : k
                    });
                    }
                }


              let backButton;
       		backButton=<button className="btn btn-default btn-xs mt mt5" id="back" onClick={this.doMMFBackConfirm.bind(this)}>Back to Product Select</button>
                if(data !== undefined){

                    var act;
                     arr1 && arr1.map((item,index) => {
                        if(this.props.err.length > 0 ){
                            if(this.props.err[0].refAccountNbr === item["Money Fund Account"]){
                                act = this.props.err[0].refAccountNbr;
                                this.state.vInvestType.splice(index, 1)
                                this.state.sindex = index;
                            }
                            }
                        })


                entertrademarkup = arr1 && arr1.map((item,index) => {
                    if(this.props.deletedRows.find(e=>e === index) === undefined){
                    if(this.state.sindex !== index){
                    var obj = item;

                    let selectMarkup,selectMarkup1;

                    if(obj.FACTSHEETURL)
                    	factsheeturl	= obj.FACTSHEETURL;

                    if(obj.KIIDURL)
                    	kiidurl	= obj.KIIDURL;



                    tradedate =
                        <div key={index} className="displayinline">
                            <label className="LabelValue mb0"> {datelbl} ({date})  </label>
                        </div>

                        if(this.props.amount["tempAmount"+obj.rowNumber] !== undefined){
                            temp = this.props.amount["tempAmount"+obj.rowNumber].value;
                        }
                        if(this.props.amount["addNotes"+obj.rowNumber] !== undefined){
                            temp1 = this.props.amount["addNotes"+obj.rowNumber].value;
                        }
                        if(this.props.amount["clntRateRange"+obj.rowNumber] !== undefined){
                            if(this.props.amount["clntRateRange"+obj.rowNumber].checked)
                                clntRateRange = "Y";
                            else
                                clntRateRange = "";
                        }
                        if(this.props.amount["rateFrom"+obj.rowNumber] !== undefined){
                            rateFrom = this.props.amount["rateFrom"+obj.rowNumber].value;
                        }
                        if(this.props.amount["rateTo"+obj.rowNumber] !== undefined){
                            rateTo = this.props.amount["rateTo"+obj.rowNumber].value;
                        }
                        if(this.props.amount["mmftrmode"+obj.rowNumber] !== undefined){
                            mmftrmode = this.props.amount["mmftrmode"+obj.rowNumber].value;
                        }
                        if(this.props.amount["maturityAccountSel"+obj.rowNumber] !== undefined){
                            maturityAccount = this.props.amount["maturityAccountSel"+obj.rowNumber].props.value;

                            if(maturityAccount===undefined)
                           	 	maturityAccount = '';
                        }
                        let holidayMsg='';
                        if(obj.holidayFlag !== undefined && obj.holidayFlag.length>0){
                            holidayMsg=obj.holidayFlag;
                        }
                        if(this.props.errors !== []
                            && this.props.errors !== undefined
                            && this.props.errors.find( e => e.refAccountNbr === obj["Money Fund Account"]) !== undefined
                        ){
                            this.state.deletedRows.push(parseInt(obj.rowNumber))
                        }

                        this.state.amount.push(temp);
                        this.state.clntRateRange.push(clntRateRange);
                        this.state.rateFrom.push(rateFrom);
                        this.state.rateTo.push(rateTo);
                        this.state.mmftrmode.push(mmftrmode);
                        this.state.maturityAccount.push(maturityAccount);
                        if(this.props.amount["nominatedAuthorise"+obj.rowNumber] !== undefined){
                       	 this.state.nominatedAuthoriseArry.push(this.props.amount["nominatedAuthorise"+obj.rowNumber].value);
						}else {
							this.state.nominatedAuthoriseArry.push('N');
						}

                        if(this.props.amount["orderType"+obj.rowNumber] !== undefined && this.props.amount["orderType"+obj.rowNumber].value ==='L'){
						       let orderTypeObj = {
								   orderType:this.props.amount["orderType"+obj.rowNumber].value,
								   limitPrice:this.props.amount["limitPrice"+obj.rowNumber].value,
								   limitExpiry:this.props.amount["limitExpiry"+obj.rowNumber].value,
							   }
							   this.state.orderTypeArry.push(orderTypeObj);
                        }else {
						 	let orderTypeObj = {
								   orderType:'M',
								   limitPrice:'',
								   limitExpiry:'',
							   }
							   this.state.orderTypeArry.push(orderTypeObj);
						}
						// console.log('this.props.amount["nominatedAuthorise"+obj.rowNumber]<<>>>>',this.props.amount["nominatedAuthorise"+obj.rowNumber]);


                        this.state.invAmtValueArray.push({name:"tempAmount"+obj.rowNumber,value:temp},{name:"addnotes"+obj.rowNumber,value:temp1})
                        // buttonMarkup =  <button  style={{margin:'0px'}} className="btn btn-primary btn-xs mt pull-right mt5" id="confirmTrade" onClick={this.doConfirm.bind(this)}>Confirm Trade</button>


            if(obj.abdbal !== undefined && temp !== undefined && this.state.vInvestType[obj.rowNumber] === "85")
            {
                let transAmount = parseFloat(replaceChars(temp,",",""));

                if(mmftrmode === "C"){
                    cashVal = parseFloat(transAmount);
                    // cashVal=addCommaDV(cashVal.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType);

                    transshares = parseFloat(replaceChars(temp,",","")) / parseFloat(replaceChars(obj.NAV,",","")) ;

                    if(obj.navType === "C"  || obj.navType === "L")
                    transshares = addCommaDV(transshares.toString(),userLocale,CNAVLVNAVSHAREDECIMALS,obj.ccyRoundType)
                    else   transshares = addCommaDV(transshares.toString(),userLocale,DEFAULTSHAREDECIMALS,obj.ccyRoundType)

                    newcash = parseFloat(obj.abdbal) - parseFloat(replaceChars(temp,",",""));
                    newcash = addCommaDV(newcash.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType)

                    if(obj.abdbal.includes(transAmount))
                        newshares = parseFloat(replaceChars("0.0",",",""));
                    else
                        newshares = parseFloat(replaceChars(obj.Shares,",","")) - parseFloat(replaceChars(transshares,",",""));

                         if(obj.navType === "C"  || obj.navType === "L")
                    	newshares = addCommaDV(newshares.toString(),userLocale,CNAVLVNAVSHAREDECIMALS,obj.ccyRoundType)
                    	else
                    	newshares = addCommaDV(newshares.toString(),userLocale,DEFAULTSHAREDECIMALS,obj.ccyRoundType)
                }else{
                    cashVal = parseFloat(transAmount) * parseFloat(replaceChars(obj.NAV,",","")) ;
                    // cashVal=addCommaDV(cashVal.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType);

                    transshares = parseFloat(replaceChars(temp,",",""));
                      if(obj.navType === "C"  || obj.navType === "L")
                    transshares = addCommaDV(transshares.toString(),userLocale,CNAVLVNAVSHAREDECIMALS,obj.ccyRoundType)
                    else
                     transshares = addCommaDV(transshares.toString(),userLocale,DEFAULTSHAREDECIMALS,obj.ccyRoundType)

                    if(parseFloat(replaceChars(obj.Shares,",","")).toString().includes(transAmount))
                        newcash = parseFloat("0.0");
                    else
                        newcash = parseFloat(replaceChars(obj.abdbal,",","")) - parseFloat(replaceChars(cashVal,",",""));
                    newcash = addCommaDV(newcash.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType)

                    newshares = parseFloat(replaceChars(obj.Shares,",","")) - parseFloat(replaceChars(transshares,",",""));
                    if(obj.navType === "C"  || obj.navType === "L")
                    newshares = addCommaDV(newshares.toString(),userLocale,CNAVLVNAVSHAREDECIMALS,obj.ccyRoundType)
                    else
                    newshares = addCommaDV(newshares.toString(),userLocale,DEFAULTSHAREDECIMALS,obj.ccyRoundType)
                }

            }else if(obj.abdbal !== undefined && temp !== undefined && this.state.vInvestType[obj.rowNumber] === "95"){
                cashVal = parseFloat(replaceChars(obj.Shares,",","")) * parseFloat(replaceChars(obj.NAV,",","")) ;
                // cashVal=addCommaDV(cashVal.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType);

                transshares = obj.Shares;

                newcash = parseFloat("0.0");
                newcash = addCommaDV(newcash.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType)

                newshares = parseFloat(replaceChars("0.0",",",""));
                if(obj.navType === "C"  || obj.navType === "L")
                newshares = addCommaDV(newshares.toString(),userLocale,CNAVLVNAVSHAREDECIMALS,obj.ccyRoundType)
                else  newshares = addCommaDV(newshares.toString(),userLocale,DEFAULTSHAREDECIMALS,obj.ccyRoundType)
            }else{
				/*
                transshares = parseFloat(replaceChars(temp,",","")) / parseFloat(replaceChars(obj.NAV,",","")) ;
                transshares = addCommaDV(transshares.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType)

                newcash = parseFloat(obj.abdbal) + parseFloat(replaceChars(temp,",",""));
                newcash = addCommaDV(newcash.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType)

                newshares = parseFloat(replaceChars(obj.Shares,",","")) + parseFloat(replaceChars(transshares,",",""));
                newshares = addCommaDV(newshares.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType)
                */
                let transAmount = parseFloat(replaceChars(temp,",",""));
				if(mmftrmode === "C"){
				    cashVal = parseFloat(transAmount);
				    // cashVal=addCommaDV(cashVal.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType);

				    transshares = parseFloat(replaceChars(temp,",","")) / parseFloat(replaceChars(obj.NAV,",","")) ;
				    if(obj.navType === "C"  || obj.navType === "L")
				    transshares = addCommaDV(transshares.toString(),userLocale,CNAVLVNAVSHAREDECIMALS,obj.ccyRoundType)
				    else transshares = addCommaDV(transshares.toString(),userLocale,DEFAULTSHAREDECIMALS,obj.ccyRoundType)
				    newcash = cashVal;
				    newshares=transshares;
				}else{
				    cashVal = parseFloat(transAmount) * parseFloat(replaceChars(obj.NAV,",","")) ;
				    // cashVal=addCommaDV(cashVal.toString(),userLocale,obj.amountDecimals,obj.ccyRoundType);

				    transshares = parseFloat(replaceChars(temp,",",""));
				     if(obj.navType === "C"  || obj.navType === "L")
				    transshares = addCommaDV(transshares.toString(),userLocale,CNAVLVNAVSHAREDECIMALS,obj.ccyRoundType)
				    else  transshares = addCommaDV(transshares.toString(),userLocale,DEFAULTSHAREDECIMALS,obj.ccyRoundType)
				    newcash = cashVal;
				    newshares=transshares;
				}
            }

            {/* Transaction */}
            selectMarkup =
                <div key={index}>
                    {/* <div className="form-group clearfix">
                        <label>&nbsp;</label>
                    </div> */}
                       {/* <span key={index} className="pull-center TxtNrml errormess fnt14">
                            {
                                holidayMsg && holidayMsg.split("/").map((item,hindex)=>{
                                    if(obj.holidayFlag !== ""){
                                        this.state.deletedRows.push(parseInt(obj.rowNumber))
                                    }
                                    return <div key={hindex}  id={"errorId"+obj.rowNumber.toString()}>{item}</div>
                                })
                            }
                        </span> */}
                        {
                            (this.props.errors !== [] && this.props.errors !== undefined) &&
                                this.props.errors.find( e => e.refAccountNbr === obj["Money Fund Account"]) !== undefined ?
                                <div>
                                    <ErrorMessage method={this.hideConfirm} text={this.props.errors.find( e => e.refAccountNbr === obj["Money Fund Account"]).holidayFlag} type={'alert'} lang="en"/>
                                </div>
                                :
                                <span></span>
                        }
                    <div className="form-group">
                        {
                            (this.state.vInvestType[obj.rowNumber] === "85") &&
                            <label className="LabelText">Redeem</label>
                        }
                        {
                            (this.state.vInvestType[obj.rowNumber] === "95") &&
                            <label className="LabelText">Close Holding</label>
                        }
                        {
                            (this.state.vInvestType[obj.rowNumber] === "10") &&
                            <label className="LabelText">Purchase</label>
                        }
                    </div>
                    <div className="clearfix"></div>
                    <div className="form-group">
                        <label className="LabelText"> Cash ({obj.CurrencyCode}):</label>
                        {
                            (obj.navType === "F"  || obj.navType === "V") &&
                            <span>{this.changeMyVariable()}</span>
                        }
                        {
                            ((obj.navType === "F"  || obj.navType === "V") && (this.state.vInvestType[obj.rowNumber] === "10" || this.state.vInvestType[obj.rowNumber] === "85" || this.state.vInvestType[obj.rowNumber] === "95")) ?
                            			(mmftrmode==="C")?
                        <label className="pull-right LabelValue">{<Formatter currency={cashVal}/>}</label>
 	                                			:
 	                                		<label className="pull-right LabelValue">Pending</label>
                                :
                                    (this.state.vInvestType[obj.rowNumber] === "85" || this.state.vInvestType[obj.rowNumber] === "95")?
                                          <label className="pull-right LabelValue">{<Formatter currency={cashVal}/>}</label>
                                    :
                                        <label className="pull-right LabelValue">{<Formatter currency={cashVal}/>}</label>
                        }
                    </div>
                    <div className="clearfix"></div>
                    <div className="form-group clearfix">
                        <label className="LabelText">Units:</label>
                        {
                            ((obj.navType === "F"  || obj.navType === "V") && (this.state.vInvestType[obj.rowNumber] === "10" || this.state.vInvestType[obj.rowNumber] === "85"|| this.state.vInvestType[obj.rowNumber] === "95")) ?

                               		(mmftrmode==="S") ?
                               			<label className="pull-right LabelValue">{transshares}</label>
                               			:
										<label className="pull-right LabelValue">Pending</label>

                                :
                                    (this.state.vInvestType[obj.rowNumber] === "85" || this.state.vInvestType[obj.rowNumber] === "95")  ?
                                        <label className="pull-right LabelValue">{transshares}</label>
                                    :
                                        <label className="pull-right LabelValue">{transshares}</label>
                        }
                    </div>
                    <div className="form-group clearfix">
                        <label className="LabelText"> View Notes:</label>
                        <label className="pull-right LabelValue txtWrap w340px">{temp1}</label>
                        {/* <label>&nbsp;</label> */}
                    </div>
                </div>

            {/* New balance */}
            selectMarkup1 =
            <td key={index} className="paddAll w25">
                <div>
                    <div  className="form-group clearfix">
                         <span key={index} className="pull-center TxtNrml errormess fnt14">
                            {
                                holidayMsg && holidayMsg.split("/").map((item,hindex)=>{
                                    if(obj.holidayFlag !== ""){
                                        this.state.deletedRows.push(parseInt(obj.rowNumber))
                                    }
                                    return <div key={hindex} id={"errorId"+obj.rowNumber.toString()}>{item}</div>
                                })
                            }
                        </span>
                        {
                            (this.props.errors !== [] && this.props.errors !== undefined) &&
                                this.props.errors.find( e => e.refAccountNbr === obj["Money Fund Account"]) !== undefined ?
                                <span key={index} className="pull-center TxtNrml errormess fnt14">
                                    {this.props.errors.find( e => e.refAccountNbr === obj["Money Fund Account"]).holidayFlag}
                                </span>
                                :
                                <span></span>
                        }
                        <div className="clearfix"></div>
                            <label className="pull-left"> View Notes:</label>
                            <label className="pull-right TxtNrml">{temp1}</label>
                        </div>
                    <div className="clearfix"></div>
                    <div  className="form-group">
                        <label>New Balance:</label>
                    </div>
                    <div className="clearfix"></div>
                    <div  className="form-group">
                        <label className="pull-left"> Cash ({obj.CurrencyCode}):</label>
                        {/*
                            ((obj.navType === "F"  || obj.navType === "V") && (this.state.vInvestType[obj.rowNumber] !== "10")) ?
                                    <label className="pull-right TxtNrml">Pending</label>
                                :
                                    (this.state.vInvestType[obj.rowNumber] === "85" || this.state.vInvestType[obj.rowNumber] === "95") ?
                                        <label className="pull-right TxtNrml">{newcash}</label>
                                    :
                                        <label className="pull-right TxtNrml">{newcash}</label>
                        */
                        	<label className="pull-right TxtNrml">{newcash}</label>
                        }
                    </div>
                    <div className="clearfix"></div>
                    <div  className="form-group">
                        <label className="pull-left">Units:</label>
                        {/*
                            (((obj.navType === "F"  || obj.navType === "V") && (this.state.vInvestType[obj.rowNumber] === "10" ))) ?
                                    <label className="pull-right TxtNrml">Pending</label>
                                :
                                    (this.state.vInvestType[obj.rowNumber] === "85" || this.state.vInvestType[obj.rowNumber] === "95") ?
                                        <label className="pull-right TxtNrml">{newshares}</label>
                                    :
                                        <label className="pull-right TxtNrml">{newshares}</label>
                        */
                        	<label className="pull-right TxtNrml">{newshares}</label>
                        }
                    </div>
                </div>
            </td>


                return <table key={index} width="100%" className="table table-bordered tradeTable">
                    <thead>
                            <tr>
                                <th colSpan="3">
                                    {obj.prodName}
                                </th>
                            </tr>
                    </thead>
                    <tbody>
                        <tr>

                            <td className="paddAll w25">
                                {/* <div  className="form-group">
                                    <label> {obj.prodName} </label>
                                </div>
                                <div className="clearfix"></div> */}
                                {/* <div  className="form-group">
                                    <label className="pull-left"> Yesterday's rate: </label>
                                    <label className="pull-right TxtNrml">{obj["Yesterday's rate"] ===""?0.00:obj["Yesterday's rate"]}%</label>
                                </div> */}
                                {/* <div className="clearfix"></div> */}
                                <div  className="form-group">
                                    {/*<label> EOD Cut-Off Time: </label>*/}
                                    <label className="LabelText"> Cut-Off Time to Invest: </label>
                                    <label className="pull-right LabelValue">{obj["EOD Cut-Off Time"]}</label>
                                </div>
                                <div className="clearfix"></div>
                                {
                                    rateFrom !== "" && rateFrom !== undefined &&
                                <div  className="form-group">
                                    <label className="LabelText"> Acceptable rates: </label>
                                    <label className="pull-right LabelValue">{rateFrom}% to {rateTo}%</label>
                                </div>
                                }
                            </td>
                            <td className="paddAll w30">
                                <div  className="form-group">
                                    <label className="LabelText"> Portfolio Number:</label>
                                    <label className="LabelValue pull-right">{obj["dispPortfolioRefAcctnbr"]} </label>
                                </div>
                                <div  className="form-group">
                                 {
                                    this.props.amount["maturityAccountSel"+obj.rowNumber] !== undefined &&
                                   (this.state.vInvestType[obj.rowNumber] === "85" || this.state.vInvestType[obj.rowNumber] === "95") ?
                                    <span>
                                        <label className="LabelText"> Redemption Account:</label>
                                        <label className="LabelValue pull-right"> {this.props.amount["maturityAccountSel"+obj.rowNumber].props.value}    </label>
                                    </span>
                                    :
                                    <span>
                                        <label className="LabelText"> Funding Account:</label>
                                        <label className="LabelValue pull-right">{obj["Funding Account"]}</label>
                                    </span>
                                }
                                </div>

                                 	{/* {
 										(obj.navType==='C' || obj.navType==='L') &&
 											<div  className="form-group">
 												<label>Current Balance(NAV={obj.NAV}):    </label>
 											</div>
  									}

                                 	{
 										(obj.navType!=='C' && obj.navType!=='L') &&
 										<div>
 											<div  className="form-group">
 												<label>Latest NAV {obj.NAV} {obj.navrecTime}</label>
 											</div>
 											<div  className="form-group">
 												<label>Current Balance   </label>
 											</div>
 										</div>
  									}

                                <div  className="form-group">
                                    <label>Fund Type:    </label>
                                    <label className="pull-right TxtNrml">{obj["NAV Type"]}</label>
                                </div>
                                <div  className="form-group">
                                    <label>Cash ({obj.CurrencyCode}):     </label>
                                    <label className="pull-right TxtNrml">{obj.abdbal === "0.00" ? obj.abdbal :addCommaDV(obj.abdbal,userLocale,obj.amountDecimals,obj.ccyRoundType)}</label>
                                </div>
                                <div  className="form-group">
                                    <label>Shares:      </label>
                                    <label className="pull-right TxtNrml">{obj.Shares}</label>
                                </div> */}

                                 <div  className="form-group">
											<label className="LabelText">Order Type:      </label>
											{
                                                this.props.amount["orderType"+obj.rowNumber.toString()] !== undefined &&
                                                    <label className="LabelValue pull-right">{this.props.amount["orderType"+obj.rowNumber.toString()].value  === 'L'?'Limit':'Market'}      </label>
                                            }
							 	</div>

								{
                                    this.props.amount["orderType"+obj.rowNumber.toString()] !== undefined &&
                                    this.props.amount["orderType"+obj.rowNumber.toString()].value ==='L' &&<div> <div   className="form-group">
											<label className="LabelText">Limit Price:      </label>
                                            {
                                                this.props.amount["limitPrice"+obj.rowNumber.toString()] !== undefined &&
											        <label className="LabelValue pull-right">{this.props.amount["limitPrice"+obj.rowNumber.toString()].value}</label>
                                            }
									  </div>
									  <div  className="form-group">  <label className="LabelText">Limit Expiry:      </label>
                                      {
                                                this.props.amount["limitExpiry"+obj.rowNumber.toString()] !== undefined &&
											        <label className="LabelValue pull-right">{this.props.amount["limitExpiry"+obj.rowNumber.toString()].value === '0'?'Today':''}</label>
                                      }

                                    </div>
                                     </div>
								}
                            </td>
                            <td className="paddAll w30">
                                {selectMarkup}
                            </td>
                            {/* {selectMarkup1} */}
                        </tr>
                    </tbody>
                </table>
                }
            }
                });
            }


        return(
            <div>

                <div className="contentBorderStyle">
                    <label className="LabelText inlineblk mb0">
                        Instruction Date:
                    </label>
                       {tradedate}
                    </div>
                <div>
                        {entertrademarkup}
                    <div className='pull-right'>
                        <CustomCheckBox>I have read and confirm I understand the <a href="javascript:void(0)" onClick={this.showRisk} className='unline'>risk</a> associated with this product. <a href="javascript:void(0);" className='unline' onClick={e => this.doFundSheetInfo(factsheeturl, event)}>Fact Sheet</a> and <a href="javascript:void(0);" className='unline' onClick={e => this.doFundSheetInfo(kiidurl, event)}>KIID</a>
                        <input type="checkbox" ref='fundrisk' id='fundrisk' onClick={this.fundriskcheckconfirm}/><span></span></CustomCheckBox>
                        {/* <label style={{marginTop:'-4px', marginLeft:'4px',fontWeight: 'normal'}} ></label> */}
                    </div>
                </div>
                <div className="clearfix"></div>
                {backButton}
                <button  style={{margin:'0px'}} className="btn btn-primary btn-xs mt pull-right mt5" id="confirmTrade" onClick={this.doConfirm.bind(this)}>Confirm Trade</button>

                {/* Risk Dialog */}
                <Dialog  fullWidth={true}
					maxWidth={'md'}
					open={this.state.openRisk}
					onClose={this.handleClose}
					aria-labelledby="form-dialog-title"
					>
					<DialogTitle id="form-dialog-title">LIQUIDITY PORTAL – DISCLAIMERS AND RISK WARNINGS</DialogTitle>
					<DialogContent>
					    <MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
                            <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                                <div className="panel-body pop-panelbody" style={{width:'800px'}} >
                                    <Grid container spacing xs={12}>
                                        <label className="fnt14">
                                            Investments can fall as well as rise in value. Your capital or the income generated from your investment may be at risk.
                                        </label>
                                        <p className="justifytext pdr10">
                                            Before entering into any transaction you should take steps to ensure that you understand and have made an independent assessment of the suitability and appropriateness of the transaction and contractual relationship into which you are entering and the nature and extent of your exposure to risk of loss in light of your own objectives, financial and operational resources and other relevant circumstances.  You should take such independent investigations and such professional advice as you consider necessary or appropriate for such purpose.
                                        </p>
                                        <p className="justifytext pdr10">
                                        Clients should seek advice concerning any impact investments may have on their personal tax position from their own tax adviser. Clients have sole responsibility for the management of their tax and legal affairs including making any applicable filings and payments and complying with any applicable laws and regulations. Barclays has not and will not provide you with tax or legal advice and recommend that you obtain your own independent tax and legal advice tailored to your individual circumstances. Clients must perform, to their own satisfaction, independent due diligence in respect of any opportunity before making any final investment decision.
                                        </p>
                                        <p className="justifytext pdr10">
                                        Barclays is not responsible for information stated to be obtained or derived from third party sources or statistical services. Neither Barclays nor any of its directors, officers, employees, representatives or agents, accepts any liability whatsoever for any direct, indirect or consequential losses (in contract, tort or otherwise) arising from the use of this communication or its contents or reliance on the information contained herein, except to the extent this would be prohibited by law or regulation.
                                        </p>
                                        <p className="justifytext pdr10">
                                            Investments will be exposed to a variety of risks, <span className="unline">including but not limited to:</span>
                                        </p>
                                        <p className="justifytext pdr10">
                                            <span className="fnt14 fntbld">FX Risk:</span> Investors will have exposure to a business earning revenues and incurring costs that may differ from domestic currency of the investor.
                                        </p>
                                        <p className="justifytext pdr10">
                                            <span className="fnt14 fntbld">Market risk:</span> The valuation of the business may vary in value based upon both fundamentals and sentiment in the broader market.
                                        </p>
                                        <p className="justifytext pdr10">
                                            <span className="fnt14 fntbld">Volatility Risk:</span> The value of investments and the amount of income derived from them may go down as well as up. All investments can be affected by a variety of factors, including macro-economic market conditions such as the interest or exchange rate environment, or other general political factors in addition to more company or investment specific factors.
                                        </p>
                                        <p className="justifytext pdr10">
                                            <span className="fnt14 fntbld">Liquidity Risk:</span> Clients will have their capital locked up during the life of the investment and there will not necessarily be any ready secondary market. The investment will generally be illiquid compared to other asset classes. The liquidity position of this investment will be dependent upon the success of the targeted exit strategy.
                                        </p>
                                        <p className="justifytext pdr10">
                                            <span className="fnt14 fntbld">Currency Risk:</span> Investors will be exposed to currency fluctuations between their domestic currency and the currencies in which revenue is earned.
                                        </p>
                                        <p className="justifytext pdr10">
                                            <span className="fnt14 fntbld">Regulatory risk:</span> Liabilities, obligations and operating restrictions arising from substantial and evolving laws and other regulations in the form of conventions, national, state and local laws and national and international regulations in force in the jurisdictions in which the investment company operates.
                                        </p>
                                    </Grid>
                                </div>
                            </div>

						</MuiThemeProvider>
					</DialogContent>
					<DialogActions>
						<button onClick={this.handleClose} className="btn btn-primary btn-xs">Close</button>
					</DialogActions>
				</Dialog>
            </div>
        );
        }
    }
}

export default withStyles(MuiStyles)(MMMFConfirmTrade);