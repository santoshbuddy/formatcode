import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { connect } from 'react-redux';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import FormData from 'form-data';
import {success,handleMsgClose} from '../../messages/Message';
import Button from '@material-ui/core/Button';
import { Route } from 'react-router-dom';

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });
class UploadTrade extends React.Component {
    constructor(){
        super();
        this.state={
			message:'',
            results:[],
            results1:[],
            pooldata:[],
            pooldatatable:[],
            columns:[],
            screenName:'',            
        }
        this.doChange = this.doChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleClose = this.handleClose.bind(this);

    }
    componentDidMount() {
         this.getFilter();
    }
    getFilter(){
    }
    componentWillReceiveProps(nextProps) {
    }
	handleSubmit(){

 	}

  handleClose = (event, reason) => {
   };

   doChange(filterformData){
   }
    render(){

        return(
            <div>
                 <NavBar/> 

                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">Upload bulk trade template</h4>
                    </div>
                        <div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12" style={{ color: 'red',fontSize:12, padding:'5px 100px 0px 20px'}}>
                        IMPORTANT: Due to application limitations, the Online Investments portal cannot display accurate rates, factors or yields for negative rate funds.
                        </div>
                         <div className="col-md-12 col-sm-12" style={{ color: 'red',fontSize:12,padding:'0px 100px 0px 20px' }}>
                            You must rely on rate information on the Fund Company website when making investment decisions for negative rate funds.
                         </div>
                        
                        <div  className="form-group col-md-10">
                        <div  className="form-group col-md-4"> Click Browse and select a file or type file path in the box  </div>
                        <div  className="form-group col-md-2"><input type="file"/></div>
                        <div  className="form-group col-md-2"><button  className="btn btn-primary btn-xs" type='button' > File Upload</button></div>
                                
                                
                            </div>    
                        </div>
                 </div>
         );
    }
} 
function mapStateToProps(state) {
    const { pooldata,pooldatatable } = state;
    return { pooldata,pooldatatable};
}

const connectedUploadTrade = connect(mapStateToProps)((UploadTrade));
export { connectedUploadTrade as UploadTrade };
