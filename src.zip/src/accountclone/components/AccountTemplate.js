import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { accountcloneActions } from '../actions/accountclone.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import FormData from 'form-data';
import { Route } from 'react-router-dom';

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });

class AccountTemplate extends React.Component {
    constructor(){
        super();
        this.state={
            results:[],
            results1:[],
            resultstable:[],
            reportdata:[],
            reportdatatable:[],
            columns:[],
            screenName:'',
            message:''
		}
        this.doChange = this.doChange.bind(this);

    }

    componentWillMount() {

        this.getFilter()
   }
   getFilter(){

    this.props.dispatch(accountcloneActions.fetchReportData());
   }


   doChange(fillObj){
	         if (!(fillObj.txtCRA))
	          {
	                window.alert('Please Enter New Interest Bearing Description');
	          }else if (window.confirm('Are you sure, you want to clone the account?')){
                var bodyFormData = new FormData();
                for (name in fillObj) {
                    //alert("value::"+fillObj[name]+":name"+name);
                    bodyFormData.append(name, fillObj[name]);
                }
                bodyFormData.append('actionFlag', 'SAVE');
                bodyFormData.append("acctnbr",bodyFormData.get(3));
                bodyFormData.append("taxId",bodyFormData.get(4));
                bodyFormData.append("clientFirm",bodyFormData.get(5));
                bodyFormData.append("companyid",bodyFormData.get(5));
                bodyFormData.append("deskId",bodyFormData.get(6));
                bodyFormData.append("fromacctnbr",bodyFormData.get(7));
                bodyFormData.append("productId",bodyFormData.get(8));
	   		this.props.dispatch(accountcloneActions.fetchReportTableData(bodyFormData));
        }
   }
   render(){

//console.log(this.props)
if(this.props.accountclonedata !== undefined){
        this.state.reportdata = this.props.accountclonedata;
        this.state.results1  = this.state.reportdata.accountclonedata;
}
if(this.props.accountclonedatatable !== undefined){
    this.state.reportdata = this.props.accountclonedatatable;
    this.state.resultstable  = this.state.reportdata.accountclonedatatable;
    //console.log("testing.............");
    if(this.state.resultstable !== undefined){
      //console.log(this.state.resultstable);
      this.state.results1=this.state.resultstable;
    }
}

if( this.state.results1 !== undefined)
this.state.results1.map((item,index) => {
    //console.log(item)
   if(item.type === "Title"){
     this.state.screenName = item.name
     //alert(this.state.screenName)
   }
    if(item.type === "message"){
      this.state.message = item.name
      //alert(this.state.message)
    }

   if(item.name === "data"){
     this.state.results = item.values
     //console.log(this.state.results);
   }
})


if(this.state.results !== undefined) {
    this.state.results.map((item,index) => {
        if(index === 0){
            var s =  item;
            for(var k in s) {
                //console.log("in for loop testing");
                //console.log(k);
                if(k === "Account Name" || k === "Company Name" || k === "Created Date" || k === "Created By" || k === "Ref Account Number"){
                 this.state.columns.push({
                     Header: k,
                     accessor: k
                     });
                }
            }
        }
    });

}


        // const columns1 = ["Name", "Company", "City", "State"];

        // const data1 = [
        //  ["Joe James", "Test Corp", "Yonkers", "NY"],
        //  ["John Walsh", "Test Corp", "Hartford", "CT"],
        //  ["Bob Herm", "Test Corp", "Tampa", "FL"],
        //  ["James Houston", "Test Corp", "Dallas", "TX"],
        // ];
        let msg="";
        msg = <div style={{ color: 'red' }} className="col-md-12 col-sm-12">{this.state.message}</div>
        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{this.state.screenName}</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
                            <Filters method={this.doChange} data={this.state.results1}/>
                            </div>
                        </div>

                        <div className="clearfix"></div>
                        {msg}
                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                                </div>
                            </div>
                            <ReactTable resizable={false} noDataText="No Data Found" data={this.state.results} columns={this.state.columns}  className="table table-striped" />

				</div>
                    </div>
                </div>
            </div>
        );
    }
  }

function mapStateToProps(state) {
	const { accountclonedata,accountclonedatatable } = state;
	//console.log(accountclonedata)
    return { accountclonedata,accountclonedatatable };
}

const connectedAccountTemplate = connect(mapStateToProps)(AccountTemplate);
export { connectedAccountTemplate as AccountTemplate };
