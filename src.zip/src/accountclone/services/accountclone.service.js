import { authHeader,fetchHelper } from '../../_helpers';
import { alertConstants } from '../../common/constants/alert.constants';
import FromData from 'form-data';
export const accountcloneService = {
    fetchReport,
    fetchReportTable
};


function fetchReport() {
    //alert("service fetchReport")
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
    let _reportData;
     var pathname = window.location.pathname.replace("/accountclone/","")

    if(user[0].token !== undefined){
        filtObj.append("token",user[0].token);
       // filtObj["token"] =user[0].token;
        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);

    }
    return _reportData;
}

function fetchReportTable(bodyFormData) {
    //alert("service fetchReportTable***** ")
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _reportTableData;

    var pathname = window.location.pathname.replace("/accountclone/","")
     if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("reactJSActionFlag","GO")
        _reportTableData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _reportTableData;
}