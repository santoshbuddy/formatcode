export const labelUS = new Array();
labelUS["SAVEUNSUCCF"] = "Save Unsuccessful";
labelUS["SAVEDSUCCF"] = "Saved Successfully";
labelUS["DELSUCCF"] = "Deleted Successfully";
labelUS["DELUNSUCCF"] = "Delete Unsuccessful";
labelUS["CURRBALN"] = "Current Balance";
labelUS["FUNDFAMY"] = "Fund Family";
labelUS["COMPANY"] = "Company";
labelUS["TRADENT"]= "Trade Entry";
labelUS["MMFUNDS"] = "Money Market Fund";
labelUS["ENTTRDE"] = "Enter Trade";
labelUS["TRDINQR_tradeDate"] = "Instruction Date";
labelUS["FUNDINFO_CUTOFF"]="Cut-Off Time to Invest";
labelUS["SUBACCT_PORTFOILIONO"]="Portfolio Number";
labelUS["FUNDINGACCT"]=" Funding Account";
labelUS["ORDTYP"]="Order Type";
labelUS["INVST"]="Investment";
labelUS["REVIEWTRADE"] = "Review Trade";
labelUS["REDIMACCT"] = "Redemption Account";
labelUS["PURCHASE"] = "Purchase";
labelUS["CASH"] = "cash";
labelUS["UNITS"] = "Units";
labelUS["VWNOTES"] = "View Notes";
labelUS["CONTRD"] = "Confirm Trade";
labelUS["REDEEM"] = "Redeem";
labelUS["VIEWALL"] = "View All";
labelUS["PENDAPPR"] = "Pending Approval";
labelUS["USERNAME"]  = "User Name";
labelUS["EMAILADD"] = "Email Address";
labelUS["ROLE"] = "Role";
labelUS["ALLOWINVST"]="Is Allowed to override Investment Policy";
labelUS["CHKPARAM"] = "Trade Approval Process";
labelUS["USRROLESE"]   = "User Roles";
labelUS["EMLADSMT"] = "Email Address Maintenance";
labelUS["SHORTNAM"]    = "Short Name";
labelUS["LONGNAME"] = "Long Name";
labelUS["CLIENTIDE"] =	"Client Identifier";
labelUS["INVSTACCNAME"] ="Investment  Account Name";
labelUS["ACCTSTRT"] = "Account Structure";
labelUS["SETTTYPE"] = "Settle Type";
labelUS["REDIMDDANUM"]= "Redemption DDA Number";
labelUS["DVDNACCT"] = "Dividend Account";
labelUS["DVDNTYPE"] = "Dividend Type";
labelUS["TAXTYPE"]	 = "Taxpayer Type";
labelUS["TAXID"]     = "Tax ID";
labelUS["SOCCODE"]  = "Acc Social Code";
labelUS["COMPNAME"] = "Company Name";
labelUS["CITY"]	 = "City";
labelUS["ZIP"]	 = "Zip";
labelUS["ADDRESS"]  = "Address";
labelUS["STATE"]	 = "State";
labelUS["COUNTRY"]  = "Country";
labelUS["ESCNUM"] = "Escrow Number";
labelUS["ESCNAME"]  = "Escrow Name";
labelUS["CFNDANLT_CUSIP"]= "CUSIP/ISIN";
labelUS["CURRENCY"] = "Currency";
labelUS["FUNDTYPE"] = "Fund Type";
labelUS["NAV"]        = "NAV";
labelUS["AUMM"]="AUM(MM)";
labelUS["EODCUTOFFTIME"] = "EOD Cut-Off Time";
labelUS["FACTOR"] = "Factor";
labelUS["DAYEILD"] = "Daily Yield";
labelUS["DAYCURYIELD"]="7-Day Current Yield";
labelUS["SEVDAYEFTID"] = "7-Day Effective Yield";
labelUS["DAYYIELD"]= "30-day Yield" ;
labelUS["S&P"] ="S&P";
labelUS["MOODY"]="Moody's";
labelUS["FITCH"]=" Fitch";
labelUS["NAIC"] = "NAIC";
labelUS["STATUS"] = "Status";
labelUS["CREATEDATE"] = "Creation Date";
labelUS["INVSTMNTACT"] = "Investment Account";
labelUS["SUBDDANUM"]= "Subscription DDA Number";
labelUS["FATCACOMPL"] = "FATCA Compliant";
labelUS["REMARKS"]="Remarks";
labelUS["INVSTACC"] ="Investment  Account";
labelUS["FUNDACCT"]    = "Fund Account";
labelUS["SETTLEMENTTYPE"] ="Settlement Type";
labelUS["TEMPNAME"] = "Template Name";
labelUS["CLIENTNME"] = "Client Name";
labelUS["PRODUCT"] = "Product";
labelUS["ACCTY"]="Account";
labelUS["RATE"]	 = "Rate";
labelUS["POSTDATE"]   = "Posted Date";
labelUS["RULENAME"] = "Rule Name";
labelUS["DDATYPE"] = "DDA Type";
labelUS["RULEMODE"] = "Rule Mode";
labelUS["ACCTRULE"] = "Account Rule";
labelUS["RONDTRIP"] = "Round Trip";
labelUS["INVSTMNAC"] = "Investment A/c";
labelUS["ACCTGRP"]= "Accout Group";
labelUS["TRGTBALCCY"]= "Target Balance CCY ";
labelUS["TRGTBAL"] = "Target Balance";
labelUS["TRIGCCY"] = "Trigger CCY";
labelUS["EUR"] = "EUR";
labelUS["TRIGAMT"] = "Trigger Amount";
labelUS["INCRAMT"] = "Increment Amount";
labelUS["BALDETLS"] = "Balance Details";
labelUS["BALTYPE"] = "Balance Type";
labelUS["AVLBBAL"]   = "Available Balance";
labelUS["VALDATBAL"] = "Value Dated Balance";
labelUS["VLDGRBAL"] = "Ledger Balance";
labelUS["PROJBAL"] = "Projected Balance ";
labelUS["OVERBAL"]="Override Balance";
labelUS["AUTOMATIC"] = "Automatic";
labelUS["MANUL"]	 = "Manual";
labelUS["REBALANCE"]	= "Re-balance";
labelUS["REDEEMONLY"]	= "Redeem Only";
labelUS["INVSTONLY"]= "Invest Only";
labelUS["INVSTND"]="Invest Net of Debit";
labelUS["REDEEMND"]="Redeem Net To Debit";
labelUS["INVSTNDA"]="Invest Net of Debt And Target";
labelUS["RDMDT"]="Redeem Net to Debt And Target";
labelUS["PENDING"] = "Pending";
labelUS["YESTRATES"] = "Yesterday's rate";
labelUS["ACCTRATES"] = "Acceptable rates";
labelUS["LIMITPRICE"] = "Limit Price";
labelUS["LIMITEXPRY"] = "Limit Expiry";
labelUS["CLOSE"] = "Close";
labelUS["SHARES"] = "Shares";
labelUS["FUTRDTE"] = " Future Date";
labelUS["BOKDTE"] = " Booking Date";













































































































