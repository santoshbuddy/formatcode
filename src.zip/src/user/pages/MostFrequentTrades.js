

import React from 'react';
import { Route } from 'react-router-dom';
import { MuiThemeProvider } from '@material-ui/core/styles';
import MUIDataTable from "mui-datatables";
import { muiTableStyles } from '../../styles/muidatatableCss';
import TableLoader from '../../common/TableLoader';
import { Link } from 'react-router-dom';

 const columns = [

   {
     name: "Product Name",
     options: {
      	display: true,
	  	sort: false,
	  	download: false,
	  	filter: false,

     }
   },
   {
     name: "Action",
     options: {
      filter: true,
      sort: true,
       customBodyRender: (value, tableMeta, updateValue) => {

		   if(tableMeta && tableMeta !== undefined){
		   let parentProdId=tableMeta.rowData[2];
		//   console.log('parentProdId >>'+parentProdId);
		   	if(parentProdId && parentProdId !== undefined)
		     	if (parentProdId == "1700" || parentProdId == "2000") {
			 		parentProdId=parentProdId;
			 	} else {
			 		parentProdId="TERM";
				}

  	 	           return (
					   <Link to={{ pathname: '/DEALENT', state: { parentProdId: parentProdId} }}
					   id="palceanot" className="btn btn-primary btn-xs">Trade</Link>

              );
		  }else {
			  return <div></div>
		  }
     }
  	}
   },{  name: "PRODID",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   },{  name: "PARENTPRODID",
    options: {
	display: false,
	sort: false,
	download: false,
	filter: false,
    }
   }
   ,{  name: "ALLROWS",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   },{  name: "SUSPENDED",
    options: {
	display: false,
	sort: false,
	download: false,
	filter: false,
    }
   },{  name: "VALIDTIME",
    options: {
	display: false,
	sort: false,
	download: false,
	filter: false,
    }
   },{  name: "ISNEGFLAG",
    options: {
	display: false,
	sort: false,
	download: false,
	filter: false,
    }
   },
];

class MostFrequentTrades extends React.Component{

	   getMuiTheme = () => createMuiTheme({
		 	 		  typography: {
		 	 							useNextVariants: true,
		 	 	 			 },
		 	 	    	overrides: {
		 	 			  MuiButtonBase: {
		 	 					  	        root: {
		 	 					   	           padding: '0px',
		 	 					   	        }
		 	 	      },
		 	 	    }
	 	   })

    constructor(props) {
        super(props);
        this.state={
         }
          	this.doTrade=this.doTrade.bind(this);

     };

 doTrade() {

   }
    render() {
        const { dataVec} = this.props;

        let data=[];
					if(dataVec && dataVec.length>0){
						 dataVec.map(row => {
		                let cdata=[];
						cdata.push(row.ISSUERNAME);
						cdata.push(row.PRODID);
						cdata.push(row.PARENTPRODID);
						cdata.push(row.ALLROWS);
						cdata.push(row.SUSPENDED);
						cdata.push(row.VALIDTIME);
					 	cdata.push(row.ISNEGFLAG);

						data.push(cdata);
				})

			}
          const options = {
            filter: false,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:false,
            rowsPerPage: (data && data.length>0 )?10:0,
            pagination:(data && data.length>0 )?true:false,
			responsive: "scroll",
			fixedHeader: false,
			filter:false,
			search:false,
			print:false,
			download:false,
      		viewColumns:false,
            textLabels: {
                body: {
                     noMatch: this.props.userhomepagedata.loading ?<TableLoader />:<div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No data found</b></div>,
                },
            }
        };


         return(
            <div>
                 <div className="clearfix"></div>
                <div className="col-md-12 col-sm-12" style={{marginBottom:'20px'}}>

                     <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                            <MUIDataTable title={'Most Frequent Trades'}
                            data={data}
                            columns={columns} options={options}  />
                        </MuiThemeProvider>

                </div>
            </div>
        )
    }
}

export default MostFrequentTrades;