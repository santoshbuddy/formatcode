
	import React from 'react';
	import { Route } from 'react-router-dom';
	import { NavBar } from '../../navbar/components/navbar';
	 import ReactTable, { ReactTableDefaults } from "react-table";
	import '../../../node_modules/react-table/react-table.css';
	import '../../user/css/App.css';
	import FormData from 'form-data';
	import MUIDataTable from "mui-datatables";
	import { MuiThemeProvider } from '@material-ui/core/styles';
	import { muiTableStyles } from '../../styles/muidatatableCss';
	import TableLoader from '../../common/TableLoader';
	import AcctScrollDialogPopUp from "./AcctScrollDialogPopUp";

	import { connect } from 'react-redux';
	import { userActions } from '../actions/user.actions';

	import Typography from '@material-ui/core/Typography';

	import PropTypes from 'prop-types';
	import {createMuiTheme, withStyles } from '@material-ui/core/styles';
	import AppBar from '@material-ui/core/AppBar';
	import Tabs from '@material-ui/core/Tabs';
	import Tab from '@material-ui/core/Tab';
	 import Paper from '@material-ui/core/Paper';
	import Grid from '@material-ui/core/Grid';
	import PriorityIcon from "@material-ui/icons/PriorityHigh";
	import IconButton from "@material-ui/core/IconButton";
	import MostFrequentTrades  from './MostFrequentTrades';
	import LastestTrades from './LastestTrades';
	import Notifications  from './Notifications';
	import QuickLinks  from './QuickLinks';
	import Button from '@material-ui/core/Button';
	import Info from "@material-ui/icons/Info";
	import ScrollDialog from "../../reports/components/ScrollDialog";
	 import { Link } from 'react-router-dom';
 	import Loading from '../../common/Loading';

	import Filters from './Filters';

	 let msg='';

	const styles = theme => ({
	  root: {
		flexGrow: 1,
		backgroundColor: theme.palette.background.paper,
	  },
	  button: {
				margin: theme.spacing.unit,
				 fontSize: 11,
		  },
	  tabsRoot: {
		borderBottom: '1px solid #e8e8e8',
	  },
	  tabsIndicator: {
		backgroundColor: '#1890ff',
	  },
	  tabRoot: {
		textTransform: 'initial',
		minWidth: 72,
		fontWeight: theme.typography.fontWeightRegular,
		marginRight: theme.spacing.unit * 4,
		// fontFamily: [
		//   '-apple-system',
		//   'BlinkMacSystemFont',
		//   '"Segoe UI"',
		//   'Roboto',
		//   '"Helvetica Neue"',
		//   'Arial',
		//   'sans-serif',
		//   '"Apple Color Emoji"',
		//   '"Segoe UI Emoji"',
		//   '"Segoe UI Symbol"',
		// ].join(','),
		'&:hover': {
		  color: '#40a9ff',
		  opacity: 1,
		},
		'&$tabSelected': {
		  color: '#1890ff',
		  fontWeight: theme.typography.fontWeightMedium,
		},
		'&:focus': {
		  color: '#40a9ff',
		},
	  },
	  tabSelected: {},

	   root: {
		  flexGrow: 1,
		},
		paper: {
		  padding: theme.spacing.unit * 2,
		  textAlign: 'center',
		  color: theme.palette.text.secondary,
	  },
		priorityIcon: {
			  color: "#000",
		},
		iconButton: {
			marginRight: "24px",
			top: "50%",
			display: "inline-block",
			position: "relative",
			transform: "translateY(-50%)",
	  },
	});
	 class BottomHomePage extends React.Component {
		   getMuiTheme = () => createMuiTheme({
					  typography: {
										useNextVariants: true,
							 },
						overrides: {
						  MuiButtonBase: {
											root: {
											   padding: '0px',
											}
					  },
					}
			   })

	 constructor() {
		super();

		this.state = {
		//	filterFlag:true,
		value: 0,
		tabName:'MMF',
		  allRows:[],
		  loading:true
		}
		this.doTabChange=this.doTabChange.bind(this)
		this.getAccountSummarrData=this.getAccountSummarrData.bind(this);
		this.doTrade=this.doTrade.bind(this);
		this.doChange = this.doChange.bind(this);
		 this.checkClick = this.checkClick.bind(this);

	   }

	doChange(bodyFormData){

			this.props.dispatch(userActions.fetchUserHomePageData(bodyFormData));
		//    this.setState({ filterFlag:false});

	   }

	  handleChange = (event, value) => {
		 if(value === 0){
			 this.doTabChange("MMF");
		}else if(value === 1){
			 this.doTabChange("MMDA");
		}else if(value === 2){
			 this.doTabChange("TERM");
		}
	  };


	 doTrade() {

	var newData=[];
	var obj = {};
if(this.state.allRows.length === 0){
          	 alert("Please check atleast one checkbox")
          	 }
     else{


 		 this.props.commonData && this.props.commonData.map((item,index)=>{
					  if(this.state.allRows.find(e => e.index.toString() === index.toString()) !== undefined){
						  newData.push(item);
						  obj[item[2]] = true;
					  }
				  });
console.log('obj:::$$$$$$'+ JSON.stringify(obj));
			this.props.history.push({
						pathname: '/DEALENT',
						state: {
							tabIndex: 1,
							activeStep: 1,
							paramVal: 'TRADEENTRY',
							fromPage:'HOME',
							bformdata:  newData,
							selected:obj,
						}
					});
	   }
	   }

	   componentDidMount() {
					 this.getAccountSummarrData()
 	   }

	/*shouldComponentUpdate(nextProps, nextState) {
		// console.log('shouldComponentUpdate', nextProps, nextState);
		if (nextProps && this.props.selectedTabSrc !== nextProps.selectedTabSrc) {

				  if(nextProps.selectedTabSrc === 'MMF'){
					  this.setState({tabName: nextProps.selectedTabSrc,value:0});
				  }else if(nextProps.selectedTabSrc === 'MMDA'){
					  this.setState({tabName: nextProps.selectedTabSrc,value:1});

				  }else if(nextProps.selectedTabSrc === 'TERM'){
					  this.setState({tabName: nextProps.selectedTabSrc,value:2});

				  }
			}
		return (nextProps.selectedTabSrc !==  this.props.selectedTabSrc)
	}*/

	componentWillReceiveProps(nextProps) {
		 // console.log('componentWillReceiveProps', nextProps);
			if (this.props.selectedTabSrc !== nextProps.selectedTabSrc) {
				if(nextProps.selectedTabSrc === 'MMF'){
							  this.setState({tabName: nextProps.selectedTabSrc,value:0});
						  }else if(nextProps.selectedTabSrc === 'MMDA'){
							  this.setState({tabName: nextProps.selectedTabSrc,value:1});

						  }else if(nextProps.selectedTabSrc === 'TERM'){
							  this.setState({tabName: nextProps.selectedTabSrc,value:2});

				  }
			}
		  }


		getAccountSummarrData(){
		var bodyFormdata = new FormData();
		this.props.dispatch(userActions.fetchUserHomePageData(bodyFormdata));
	   }

	   doTabChange(tabName){

			msg='';
			var bodyFormdata = new FormData();
				bodyFormdata.append("clientFirm", JSON.parse(sessionStorage.getItem('clientFirm')));
				bodyFormdata.append("selectedTabSrc", tabName);
				this.props.dispatch(userActions.fetchUserHomePageData(bodyFormdata));
								this.setState({ tabName:tabName, });


		}
		 checkClick(cData, paramVal) {

					if(paramVal == 'TRADEENTRY' || paramVal == 'CLOSEACCOUNT') {
						this.props.history.push({
							pathname: '/DEALENT',
							state: {
								tabIndex: 1,
								activeStep: 1,
								paramVal: paramVal,
								fromPage:'ViewChanges',
								bformdata: cData
							}
						});
					} else if(paramVal == 'TRADEHISTORY') {
						this.props.history.push({
							pathname: '/report/TRDINQR',
							state: {
								fromPage:'ViewChanges',
								product: cData.parentprodid,
								issueChild: cData.prodid
							}
						});
					} else if(paramVal == 'EDITACCOUNT') {
						this.props.history.push({
							pathname: '/administration/MMFEDITACCT',
							state: {
								fromPage:'ViewChanges',
								mmmfAcct: cData.escrowacctnbr,
								clientFirm: cData.clientFirm,
								product: cData.subprodname,
								currency: cData.currency,
							}
						});
					}

			}


	  render() {
		const { classes ,userhomepagedata,commonData,commonCols, fqTradeDetVec , ltFiveTradeVeccolumns ,
				ltFiveTradeVecDATA ,tradeinqOperval ,totalHoldingsm ,mmfAcctPosOperval ,checkPosition,selectedTabSrc,
				mmmfTotalPosition,mmdaTotalPosition,termProdTotalPosition,
				notificationCnt,tradeVec} = this.props;
				const { value } = this.state;
				if( userhomepagedata !== undefined){
					this.state.loading=false;
				}

				// console.log('value :'+value);
				// console.log('commonData :'+JSON.stringify(commonData));
			let  filtermarup = <Filters method={this.doChange} data={this.props.userhomepagedata} filterFlag={true}  selectedTabSrc={selectedTabSrc} />
			let mmmfTotalPositionLabel= "Money Funds : " +mmmfTotalPosition;
			let mmdaTotalPositionLabel= "Interest Bearing : " +mmdaTotalPosition;
			let termProdTotalPositionLabel= "Fixed Term : " +termProdTotalPosition;


					let screenLinkImage = 'HOME';
					if(selectedTabSrc === 'MMF') screenLinkImage = 'HOME';
					else if(selectedTabSrc === 'MMDA') screenLinkImage = 'HOMEINBA';
					else if(selectedTabSrc === 'TERM') screenLinkImage = 'HOME';

					 commonCols && commonCols.map((item,index)=>{
								   //console.log("mar02,2019  item.name:::::",item.name)
								if(item.name === "Account Number"){
									item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
									 return (
										<AcctScrollDialogPopUp
										onClick={e => this.openPopUp(e, tableMeta)}
										rowData={tableMeta}
										linkName={value}
										screenLinkImage={screenLinkImage}
										func={this.checkClick }

										/>
									  );
									 }
								}
							});


					 const options = {
						filter: false,
						filterType: 'dropdown',
						rowsPerPage: (commonData && commonData.length>0 )?10:0,
						fixedHeader: false,
						filter:false,
						responsive: "scroll",
						 pagination:(commonData && commonData.length>0 )?true:false,
						search:false,
						print:false,
						download:false,
						viewColumns:false,
						selectableRows: (commonData && commonData.length>0 )?true:false,
						isRowSelectable: (dataIndex) => {
							//	console.log("checkPosition .....", checkPosition);
								return commonData[dataIndex][checkPosition] !== "disabled";
						},
						 customToolbarSelect: (selectedRows, displayData, setSelectedRows) => <div></div>,
						textLabels: {
							body: {
								 noMatch: this.props.userhomepagedata.loading?<TableLoader />:
								 (<div>

									 {(selectedTabSrc === 'MMF'?<div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No MMF Data Available</b></div>:'')}

									 {(selectedTabSrc === 'MMDA'?<div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No Interest Bearing Account Data Available</b></div>:'')}

									{(selectedTabSrc === 'TERM'? <div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No Fixed Term Data Available</b></div>:'')}
								   </div>   ),
							},
						},
						onRowsSelect: (rowsSelected, allRows) => {
										this.setState({allRows})
						 }
			};
 	if(this.state.loading)
         return( <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div> );
        else{

	 return (
	 <div>
			<NavBar/>
			<div className="panel panel-primary clearfix" style={{clear:'both'}}>
			 <div className={classes.root}>
			 <Grid container spacing={8} direction="row" item xs={12} >
			<Grid item xs={9}>
			 <div className="clearfix"></div>

					<div className="panel-heading" style={{width:'100%',margin:'3px'}}>
							<h4 className="panel-title" style={{padding:'10px'}}>Account Summary</h4>
				</div>
				<div className="filter_div" id="filter_div" style={{padding:'10px'}}>
						{filtermarup}
					</div>
					<div className="clearfix"></div>
					<div className="filter_div"  style={{padding:'10px'}}>
					{mmmfTotalPositionLabel}
					</div>

				<div className="clearfix"></div>
			<Grid item xs={12}>



				  <div>
								 <div className="clearfix"></div>
					<div className="col-md-12 col-sm-12">

					<MuiThemeProvider theme={muiTableStyles.getMuiTheme()} style>
									<MUIDataTable title={'Account Summmary'}
									data={commonData}
									columns={commonCols} options={options}  />
							</MuiThemeProvider>
							{((commonData && commonData.length>0)?
							<button style={{marginBottom:'10px'}}  color="primary" className="btn btn-primary btn-xs" onClick={this.doTrade} >
											Trade
							</button>:''
							)}

							{(this.props.mmfAcctPosOperval != ''  &&  parseInt(this.props.mmfAcctPosOperval)>0)?
									<div style={{paddingTop:10, float:'right'}}>
									<Route render={({ history}) => (
											 <a   onClick={() => { history.push('/report/ACCPOREP') }}>	View Money Fund Account Position	</a>
									)} />
							</div>:''}
							</div>
							</div>


				</Grid>
				<Grid item xs={12}>
					<MostFrequentTrades   userhomepagedata={userhomepagedata} dataVec={fqTradeDetVec}   tradeinqOperval={tradeinqOperval}/>
		   		</Grid>
				<Grid item xs={12}>
					<LastestTrades  userhomepagedata={userhomepagedata} data={ltFiveTradeVecDATA} columns={ltFiveTradeVeccolumns} tradeinqOperval={tradeinqOperval}/>
				</Grid>



		   </Grid>
			<Grid item xs={3}>


					 <Notifications   userhomepagedata={userhomepagedata} dataVec={tradeVec}   notificationCnt={notificationCnt}   />
					  <QuickLinks userhomepagedata={userhomepagedata}    />

		 </Grid>

		 </Grid>
	 </div>
		   </div>
			</div>
		);
	  }
 	 }
	}


	function mapStateToProps(state) {
		const { userhomepagedata } = state;

				let mmmfListcolumns = [];
				let mmmfListDATA = [];

				let mmdaListcolumns = [];
				let mmdaListDATA = [];


				let termProdListcolumns = [];
				let termProdListDATA = [];


				let fqTradeDetVec = [];
				//	let termProdListDATA = [];


				let ltFiveTradeVeccolumns = [];
				let ltFiveTradeVecDATA = [];

				let tradeVec = [];

				let tradeinqOperval='';
				let selectedTabSrc='MMF';
				let mmfAcctPosOperval='';
				let totalHoldings='';
				let checkPosition='';
				let notificationCnt='';

				let mmdaTotalPosition='';
				let mmmfTotalPosition='';
				let termProdTotalPosition='';


				let commonData = [];
				let commonCols = [];
		if(userhomepagedata && userhomepagedata.userhomepagedata){
			const results1=userhomepagedata.userhomepagedata;




			if( results1 !== undefined && results1.length>0)
				results1.map((item,index) => {


				if(item.name === "mmmfListcolumns")
				mmmfListcolumns = item.mmmfListCOLUMNS






				if(item.name === "mmmfListDATA")
				mmmfListDATA = item.mmmfListDATA


				if(item.name === "mmdaListcolumns")
				mmdaListcolumns = item.mmdaListCOLUMNS






				if(item.name === "mmdaListDATA")
				mmdaListDATA = item.mmdaListDATA



				if(item.name === "termProdListcolumns")
				termProdListcolumns = item.termProdListCOLUMNS

					if(item.name === "termProdListDATA")
				termProdListDATA = item.termProdListDATA


					if(item.name === "fqTradeDetVec")
					fqTradeDetVec = item.values

				if(item.name === "tradeVec")
					tradeVec = item.tradeVec

			if(item.name === "ltFiveTradeVeccolumns")
				ltFiveTradeVeccolumns = item.ltFiveTradeVecCOLUMNS



				ltFiveTradeVeccolumns && ltFiveTradeVeccolumns.map((item,index)=>{
				   //console.log("mar02,2019  item.name:::::",item.name)
				if(item.name === "Reference ID"){
					item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
					 return (
						<ScrollDialog
						onClick={e => this.openPopUp(e, tableMeta)}
						rowData={tableMeta}
						linkName={value}
						screenLinkImage={'LATESTFIVETRDS'}
						/>
					  );
					 }
				}
			});

					if(item.name === "ltFiveTradeVecDATA")
				ltFiveTradeVecDATA = item.ltFiveTradeVecDATA

			if(item.name === "totalHoldings")
				totalHoldings = item.totalHoldings


			if(item.name === "tradeinqOperval")
						tradeinqOperval = item.value
			if(item.name === "mmfAcctPosOperval")
			mmfAcctPosOperval = item.value

			if(item.name === "checkPosition")
					checkPosition = item.value
			if(item.name === "notificationCnt")
					notificationCnt = item.value


		if(item.name === "selectedTabSrc")
		 selectedTabSrc = item.value

		 if(item.name === "mmdaTotalPosition")
		 mmdaTotalPosition = item.value

		 if(item.name === "mmmfTotalPosition")
		 mmmfTotalPosition = item.value

		 if(item.name === "termProdTotalPosition")
		 termProdTotalPosition = item.value


			})

			if(selectedTabSrc === 'MMF')
			{
				commonData = mmmfListDATA;
				commonCols =mmmfListcolumns;

			}else if(selectedTabSrc === 'MMDA')
			{
				commonData = mmdaListDATA;
				commonCols =mmdaListcolumns;

			}else if(selectedTabSrc === 'TERM')
			{
				commonData = termProdListDATA;
				commonCols =termProdListcolumns;
			}
		}

		return { userhomepagedata ,commonData,commonCols , fqTradeDetVec ,
		ltFiveTradeVeccolumns , ltFiveTradeVecDATA ,tradeinqOperval ,
		totalHoldings,mmfAcctPosOperval,checkPosition ,selectedTabSrc,
		mmmfTotalPosition,mmdaTotalPosition,termProdTotalPosition ,
		notificationCnt,tradeVec};
	}
	const connectedHomePage = connect(mapStateToProps)((withStyles(styles))(BottomHomePage));
	export { connectedHomePage as BottomHomePage };