import React from 'react';
import { history } from '../../_helpers';

import '../css/App.css';
import '../css/index.css';
import '../css/custom.css';
import '../css/layout.css';
 import 'react-tabs/style/react-tabs.css';
import Loading from '../../common/Loading';
import { HomePage } from '../../rootindex/pages';
import { BottomHomePage } from '../../rootindex/pages';
 class Home extends React.Component {
  constructor() {
        super()
        this.state = { loading:true,tabIndex: 0, enterdata: '',fixed:'' };
    }

    render() {
 		 let user = JSON.parse(sessionStorage.getItem('user'));
		 		console.log('Member CATID >>>'+user[0].memberCatId	);

 		if(user[0].memberCatId  === '4')
		{
			return ( <HomePage  /> )
		} else if(user[0].memberCatId  === '3')
		{
			return ( <HomePage  /> )
		}else
			return ( <HomePage  /> )

    }
}
const connectedHomePage =  (Home);
export { connectedHomePage as Home };

