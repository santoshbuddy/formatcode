

import React from 'react';
import { Route } from 'react-router-dom';
import { MuiThemeProvider } from '@material-ui/core/styles';
import MUIDataTable from "mui-datatables";
import { muiTableStyles } from '../../styles/muidatatableCss';
import TableLoader from '../../common/TableLoader';
import { Link } from 'react-router-dom';
import CustomerSupport from './CustomerSupport';

 const columns = [

   {
     name: "",
     	display: true,
     options: {
      filter: true,
      sort: true,

       customBodyRender: (value, tableMeta, updateValue) => {

		   if(tableMeta && tableMeta !== undefined){
		   let link=tableMeta.rowData[1];

				if(tableMeta.rowData[1] === 'CUSTOMERSUPPORT'){

					return (<CustomerSupport />);


  	 	        }else {   return (
					   <Link to={{ pathname: tableMeta.rowData[1], state: { parentProdId: '1700'} }}
					   id="palceanot"  >{value}</Link>
 						);
		 	 }
		  }else {
			  return <div></div>
		  }
     }
  	}
   } ,{  name: "LINK",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   }
];

class QuickLinks extends React.Component{

	   getMuiTheme = () => createMuiTheme({
		 	 		  typography: {
		 	 							useNextVariants: true,
		 	 	 			 },
		 	 	    	overrides: {
		 	 			  MuiButtonBase: {
		 	 					  	        root: {
		 	 					   	           padding: '0px',
		 	 					   	        }
		 	 	      },
		 	 	    }
	 	   })

    constructor(props) {
        super(props);
        this.state={
         }

     };


    render() {
        const { } = this.props;

        let data=[
				["View Trade History","/report/TRDINQR"],
				["Trade Entry","/DEALENT"],
				["Money Fund account management","/administration/LOOKUP"],
				["Customer Support","CUSTOMERSUPPORT"],
				["Todays Trade Approvals","/reportCheck/WATFRAPP"]
				];


          const options = {
            filter: false,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:false,
            rowsPerPage: 5,
			responsive: "scroll",
			fixedHeader: false,
			filter:false,
			search:false,
			print:false,
			download:false,
      		viewColumns:false,
      		pagination: false,
            textLabels: {
                body: {
                     noMatch: this.props.userhomepagedata.loading ?<TableLoader />:<div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No data found</b></div>,
                },
            }
        };


         return(
            <div>
                 <div className="clearfix"></div>
                <div className="col-md-12 col-sm-12">

                     <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                            <MUIDataTable title={'Quick Links'}
                            data={data}
                            columns={columns} options={options}  />
                        </MuiThemeProvider>

                </div>
            </div>
        )
    }
}

export default QuickLinks;