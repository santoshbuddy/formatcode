import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Paper from '@material-ui/core/Paper';
import Loading from '../../common/Loading';

 let title = 'Customer Support';
let loading=true

class CustomerSupport extends React.Component {
 constructor(props) {
	    super(props);
	    this.state = {
		open: this.props?this.props.open:false,
   };
}


  handleOpen = () => {
    this.setState({ open: true });
   };

   handleClose = () => {
      this.setState({ open: false });
   };

  render(){



 return (

      <div>
      <a href='#' onClick={this.handleOpen} color="primary">
	                Contact Us

            </a>

        <Dialog  fullWidth={true}
          maxWidth={'xs'}
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="scroll-dialog-title"> {title}
          </DialogTitle>

          <DialogContent>

           <div>
			 <table cellpadding="5" cellspacing="0" border="0" bordercolor='red' width="100%">
		 						<tr>
		 							<td class="mdBodyBldTxt" colspan='2'>
		 								For Customer Support
		 							</td>
		 						</tr>
		 						<tr>
		 							<td class="fieldtxt" colspan='2'>&nbsp;</td>
		 						</tr>
		 					<tr>
		 						<td class="fieldtxt" colspan='2'>
		 							During business hours in the United States and Latin America:
		 						</td>
		 					</tr>
		 					<tr>
		 						<td class="fieldtxt" width='10%'>
		 							<div class="paddedL20"><b>Email:</b>&nbsp;</div>
		 						</td>
		 						<td class="fieldtxt">
		 							<a href="#">usinvestment.support@test.com</a>
		 						</td>
		 					</tr>
		 					<tr>
		 						<td class="fieldtxt">
		 							<div class="paddedL20"><b>Telephone:</b>&nbsp;</div>
		 						</td>
		 						<td class="fieldtxt">
		 							 1 (777) 777-7777
		 						</td>
		 					</tr>
		 						<tr>
		 							<td class="fieldtxt" colspan='2'>&nbsp;</td>
		 						</tr>
		 					<tr>
		 						<td class="fieldtxt" colspan='2'>
		 							During business hours in Europe:
		 						</td>
		 					</tr>
		 					<tr>
		 						<td class="fieldtxt" width='10%'>
		 							<div class="paddedL20"><b>Email:</b>&nbsp;</div>
		 						</td>
		 						<td class="fieldtxt">
		 							<a href="#">investment.support@test.com</a>
		 						</td>
		 					</tr>
		 					<tr>
		 						<td class="fieldtxt">
		 							<div class="paddedL20"><b>Telephone:</b>&nbsp;</div>
		 						</td>
		 						<td class="fieldtxt">
		 							 +999 (9) 999-9999
		 						</td>
		 					</tr>
					</table>
					</div>

          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

export default  CustomerSupport ;