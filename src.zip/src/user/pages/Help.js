import React from 'react';

import { NavBar } from '../../navbar/components/navbar';
import { Route } from 'react-router-dom';
import Filters from './Filters';
import { Link } from 'react-router-dom';
import Button from '@material-ui/core/Button';

import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import { withStyles } from '@material-ui/core/styles';




class HelpDetail extends React.Component{
    constructor(props) {
        super(props);
        this.state={
         }
        this.scrollToTop =  this.scrollToTop.bind(this);
     };
     scrollToTop(){
       window.scrollTo(0,0);
     }		
    render() {
         return(
            <div>
                 <div className="clearfix"></div>
                 <NavBar/>
                <div className="col-md-12 col-sm-12 ">

                <div class="panel panel-primary">
<div class="panel-heading">
<h4 class="panel-title">Help</h4></div>
<div class="panel-body">

<Tabs  >
				<TabList>
				<Tab>FAQ's </Tab>
				<Tab>User Manual </Tab>
				</TabList>
				<TabPanel> 
	<div class="col-md-12 col-sm-12">
 
  <div><a href='#gene'>General FAQ's</a></div>
 <div style={{fontSize: '11px',
   
    fontWeight: 'bold',background:'#C5C7DC',padding:'5px 10px 5px 10px',margin:'10px 0px 10px 0'}}>NORTHERN AMERICA FAQ's:    <a href='#gene'>General FAQ's</a> |<a href='#fo2faq'> Fo2 FAQ's </a>|<a href='#operate'>Operational FAQ's</a></div>
 
 <div id="gene" style={{marginTop:'10px'}}><strong>General FAQ's</strong></div>
    <ul>
      <li>
        <div>
          <a href='#whatis'>What is Fo2 Online Investments?
          </a>
          </div>
          </li>
      <li>
        <div><a href="#whatin" style={{marginTop:'10px'}}>What investments are currently being offered on Fo2 Online Investments?</a></div>
        </li>
    </ul>
 <div id="fo2faq" style={{marginTop:'10px'}}><strong>Fo2 FAQ's</strong></div>
  <ul>
    <li><div><a href="#fo2a">Is the Fo2 Online Investments part of Fo2 Online Banking, or does it represent a separate product?</a></div></li>
    <li><div><a href="#fo2b">Do I have to have Fo2 to access Fo2 Online Investment Services?</a></div></li>
    <li><div><a href="#fo2c">How secure is the system?</a></div></li>
    <li><div><a href="#fo2d">Can I access the system 24 hours a day 7 days a week?</a></div></li>
    <li><div><a href="#fo2e">What can I do in the Administration function?</a></div></li>
    <li><div><a href="#fo2f">What reporting is available?</a></div></li>
    <li><div><a href="#fo2g">Can I have downloads of my investment information?</a></div></li>
  </ul>
  
 <div id="operate" style={{marginTop:'10px'}}><strong>Operational FAQ's</strong></div>
  <ul>
    <li><div><a href="#opea">Do I need to open an additional cash and/or custody account in order to arrange our transactions via Fo2 Online Investments?</a></div></li>
    <li><div><a href="#opeb">Is it necessary to keep in reserve a certain amount in USD (i.e., to make any special provisions as a kind of our security deposit) in order to assure our transactions made</a></div></li>
    <li><div><a href="#opea">via F Online Investments?</a></div></li>
    <li><div><a href="#oped">Will the trade ticket made in Fo2 Online Investments be sufficient for our mutual trade confirmation procedure, or it also will be necessary to exchange special SWIFT messages?</a></div></li>
    <li><div><a href="#opee">Can I make active investments through Fo2 Online Investments as well as passive investments through Sweeps?</a></div></li>
  </ul>
 <div style={{marginTop:'10px'}}><strong  id="gene" style={{marginTop:'10px'}}>General FAQ's
</strong></div>
<ul>
  <li>
  <strong id='whatis'>What is Fo2 Online Investments?</strong></li>
  Fo2? Online Investments is a global, secure, Web-based investment system offering a wide variety of short-term investment choices with tenors ranging from overnight to a year.
  Top
  <li><div  style={{marginTop:'10px'}}><strong id="whatin" >What investments are currently being offered on Fo2 Online Investments?</strong></div></li>
  For US Domiciled Investors, the following investments are available:
  <li>Minimum Maturity Time Deposits (MMTD)</li>
  <li>Money Market Deposit Accounts (MMDA)</li>
  <li>Money Market Mutual Funds (MMMF)</li>
  <li>Time Deposits (Fo2, N.A., Nassau)</li>
  
 <div style={{marginTop:'10px'}}>For non-US Domiciled Investors, the following investments are available:</div>
 <li>Minimum Maturity Time Deposits (MMTD)</li>
 <li>Offshore Money Market Mutual Funds (available in select jurisdictions only)</li>
 <li>Time Deposits (Fo2, N.A., Nassau and International Banking Facility)</li>
  <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
 <strong>Fo2 FAQ's</strong>
 <li><strong id="fo2a">Is the Fo2 Online Investments part of Fo2 Online Banking, or does it represent a separate product?</strong></li>
 Yes, Fo2 Online Investments is an integral part of the Fo2 platform that is accessed through the "single sign-on" mechanism.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  <li><strong id="fo2b">Do I have to have Fo2 to access Fo2 Online Investment Services?</strong></li>
 Yes, a customer must have Fo2 to access Fo2 Online Investment Services. This requirement ensures the ease-of-use and security that Fo2 customers have come to expect from our products and services.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  <li><strong id="fo2c">How secure is the system?</strong></li>
 Fo2 Online Investment Services is only accessible through Fo2 Online Banking. All protections provided by Fo2 are therefore a part of the FO2 platform.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  <li><strong id="fo2d">Can I access the system 24 hours a day 7 days a week?</strong></li>
 Transactions can only be placed during the New York trading day, generally the Eastern Time 9 AM to 4:30 PM. However, customers can access the system and look up past transactions at any time, 24 hours a day, 7 days a week except for those times where Green Zones have been declared, normally for system maintenance.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  
  <li><strong id="fo2e">What can I do in the Administration function?</strong></li>
 The administration function allows clients to give their employees different functionalities/ screens within Fo2 Online Investments. Please note that Administrators can only give permission to those system features that the company<br/> is configured to use.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  <div class="clearfix"></div>
  <li><strong id="fo2f">What reporting is available?</strong></li>
 Currently, the trade inquiry screen is the main method of reporting. Information can be sorted and downloaded to a spreadsheet from this ad-hoc query mechanism. If a client wishes to have special reports delivered, they can be specified and priced on a one-off negotiated basis.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  
  <li><strong id="fo2g">Can I have downloads of my investment information?</strong></li>
 Yes, information can be exported to a spreadsheet directly from the trade inquiry screen. Also, Fo2 will work with clients to develop special reports and customized methods of downloading information electronically.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  
 <div><strong>Operational FAQ's</strong></div>
 <li> <strong id="opea">Do I need to open an additional cash and/or custody account in order to arrange our transactions via Fo2 Online Investments?</strong></li>
 Fo2 opens an in-house custody account, which is a specific to this service. Fo2 Online Investments does not deliver to external custody accounts.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  
  <li><strong id="opeb">Is it necessary to keep in reserve a certain amount in USD (i.e., to make any special provisions as a kind of our security deposit) in order to assure our transactions
 made via Fo2 Online Investments?</strong></li>
 No. However, Fo2 does require the customer to have sufficient cash or credit availability to cover all purchase requests.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  
  <li><strong id="oped">Will the trade ticket made in Fo2 Online Investments be sufficient for our mutual trade confirmation procedure, or it also will be necessary to exchange
 special SWIFT messages?</strong></li>
 All trades are made online, and confirmations are provided over the Web immediately. There is no need for swift confirmations, as all securities are held in custody in-house by Global Security Services.
 <div className="col-md-11"></div><div className="col-md-1"><img  src="/src/images/icon_up.gif" height="10" width="10" /><a onClick={this.scrollToTop}>Top</a></div>
  
  <li ><strong id="opee">Can I make active investments through Fo2 Online Investments as well as passive investments through Sweeps?</strong></li>
 Yes you can divide your portfolio to make investments through the Online investments platform and actively redeem such investments. At the same time, you can invest the balance of your portfolio through Sweeps where investments would be automatically redeemed.
 </ul>
 </div>
 </TabPanel>
        <TabPanel>
        <div className="col-md-12"><img  src="/src/images/icon_exptopdf.gif" height="23" width="22" /><a style={{paddingLeft:'10px',textDecoration:'underline'}}>Download User Manual</a></div>
        <br/>
        <br/>
        <br/>
        <div className="col-md-12"></div>         
        
        <div className="col-md-12">
        <Button target="_blank" href='http://www.adobe.com/uk/products/acrobat/readstep2.html'> 
        	<img  src="/src/images/get_adobe_reader.gif" height="31" width="88" />
        </Button><br/><br/><br/><a>Download Adobe Reader</a></div>        
        <div className="col-md-12"><br/>
        <br/>
        <br/><br/>
        <br/>
        <br/>
        <br/><br/>
        <br/>
        <br/><span>S.No	Link Name</span> </div>
        </TabPanel>
      
      </Tabs>
 
                 </div>

                 </div>
                 </div>
            </div>
        )
    }
}

export default HelpDetail;