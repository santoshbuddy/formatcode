import {error,success,handleMsgClose} from '../../messages/Message';

export function updateMenubarRefreshElem(xmlStr ,refreshData) {
	if(xmlStr !== undefined){
 	 let xml = new DOMParser().parseFromString(xmlStr, 'application/xml');

	/*if(xml.getElementsByTagName("TodaysDate")[0]!=null) {
		dispDate(xml,refreshData);
	}
	if(xml.getElementsByTagName("pendTrdCntFlag")[0]!=null) {
		dispMenuPendingTradeCnt(xml,refreshData);
	}
	if(xml.getElementsByTagName("pendFutureTrdCnt")[0]!=null) {
		dispMenuPendingFutureTradeCnt(xml,refreshData);
	}*/
	if(xml.getElementsByTagName("NOTIFICATIONCOUNT")[0]!=null) {
		dispNotificationCount(xml,refreshData);
	}

	}
}

export  function updateBottomHomeRefreshElem(xmlStr ,notificationdata) {

	if(xmlStr !== undefined){
  let xml = new DOMParser().parseFromString(xmlStr, 'application/xml');


	 if(((xml.getElementsByTagName("sdLoginIdFlag")[0]!=null)  &&
	   (xml.getElementsByTagName("ccyMsgCntFlag")[0]!=null))){
			getMessage(xml,notificationdata);
	}
	if(xml.getElementsByTagName("pendTrdCntFlag")[0]!=null) {
		dispPendingTradeCnt(xml,notificationdata);
	}
	if(xml.getElementsByTagName("pendFutureTrdCntFlag")[0]!=null) {
			dispPendingFutureTradeCnt(xml,notificationdata);
	}
/*	if(xml.getElementsByTagName("MMDAAccounts")[0]!=null)
	{
		doMMDAPopUp();
	}*/
	if(xml.getElementsByTagName("MMMFAccounts")[0]!=null)
	{
		doMMMFPopUp(xml,notificationdata);
	}
 	if(xml.getElementsByTagName("investPolicy")[0]!=null)
	{
		doinvPopUp(xml,notificationdata);
	}
	if(xml.getElementsByTagName("Template")[0]!=null)
	{
		doTemplatePopUp(xml,notificationdata);
	}
	}



	return notificationdata;
}


export  function dispPendingTradeCnt(xml,notificationdata)
{
					// console.log('dispPendingTradeCnt@@@#@<<<<<<'+notificationdata.length);


 //	if(parseInt(xml.getElementsByTagName("PREVTRADECOUNT")[0].firstChild.nodeValue) < parseInt(xml.getElementsByTagName("CURRTRADECOUNT")[0].firstChild.nodeValue)
//		&& parseInt(xml.getElementsByTagName("CURRTRADECOUNT")[0].firstChild.nodeValue) != 0) {

		var tradeDetails = xml.documentElement.getElementsByTagName("TradeDetails");
		if (tradeDetails != null) {
			for(var i =0; i < tradeDetails.length; i++) {
				if(tradeDetails[i]!=null) {
					var elenum = tradeDetails[i].childNodes.length;
					var transid = "";
					var webreference = "";
					var transdate = "";
					var nttype = "";

					for(var j=0;j<elenum;j++){
 						if (tradeDetails[i].childNodes[j].nodeName == "transId") {
							transid = tradeDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (tradeDetails[i].childNodes[j].nodeName == "webreference") {
							webreference = tradeDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (tradeDetails[i].childNodes[j].nodeName == "transdate") {
							transdate = tradeDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (tradeDetails[i].childNodes[j].nodeName == "nttype") {
							nttype = tradeDetails[i].childNodes[j].firstChild.nodeValue;
						}

					}
					let newdata =[];
					newdata.push("TRADE");
					newdata.push(transid);
					newdata.push(webreference);
					newdata.push(transdate);
					newdata.push("1");
					newdata.push(nttype);
					newdata.push("");
					newdata.push("");

					if (newdata !== null)
					{
				//	notificationdata.push(newdata);

					}


				}
			}
		}
		// console.log('notificationdata>><<<<<<'+JSON.stringify(notificationdata));
	//}
	//if (parseInt(xml.getElementsByTagName("PREVTRADECOUNT")[0].firstChild.nodeValue) < parseInt(xml.getElementsByTagName("CURRTRADECOUNT")[0].firstChild.nodeValue)) {
		var tradeDetails = xml.documentElement.getElementsByTagName("TradeDetails");
		var tableLength = 0;


		if (tradeDetails != null) {

			for(var i =0; i < tradeDetails.length; i++) {
				if(tradeDetails[i]!=null) {
					var elenum = tradeDetails[i].childNodes.length;
					var transid = "";
					var webreference = "";
					var transdate = "";
					var nttype = "";
					for(var j=0;j<elenum;j++){

						if (tradeDetails[i].childNodes[j].nodeName == "transId") {
							transid = tradeDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (tradeDetails[i].childNodes[j].nodeName == "webreference") {
							webreference = tradeDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (tradeDetails[i].childNodes[j].nodeName == "transdate") {
							transdate = tradeDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (tradeDetails[i].childNodes[j].nodeName == "nttype") {
							nttype = tradeDetails[i].childNodes[j].firstChild.nodeValue;
						}


					}
					let newdata =[];
					newdata.push("TRADE");
					newdata.push(transid);
					newdata.push(webreference);
					newdata.push(transdate);
					newdata.push("1");
					newdata.push(nttype);
					newdata.push("");
					newdata.push("");

					if (newdata !== null)
					{
					notificationdata.push(newdata);

					}

				}
			}
					// console.log('dispPendingTradeCnt@@@#@<<<<<<'+JSON.stringify(notificationdata));

		}
	//}


 }


export  function dispPendingFutureTradeCnt(xml,notificationdata)
{
	// console.log('dispPendingFutureTradeCnt@@@#@<<<<<<'+JSON.stringify(notificationdata));
	var prevFutureTrdCnt=0;
	if (xml.getElementsByTagName("PREVFUTURETRDCNT")[0] != null) {
		prevFutureTrdCnt = parseInt(xml.getElementsByTagName("PREVFUTURETRDCNT")[0].firstChild.nodeValue);
	}
	var newfutureTradeDetails = xml.documentElement.getElementsByTagName("NewFutureTradeDetails");
	if (newfutureTradeDetails != null) {
		for(var i =0; i < newfutureTradeDetails.length; i++) {
			if(newfutureTradeDetails[i]!=null) {
				var elenum = newfutureTradeDetails[i].childNodes.length;
				var webreference = "";
				var bookingdate = "";
				var nttype = "";
				for(var j=0;j<elenum;j++){
 					if (newfutureTradeDetails[i].childNodes[j].nodeName == "webreference") {
						webreference = newfutureTradeDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newfutureTradeDetails[i].childNodes[j].nodeName == "bookingdate") {
						bookingdate = newfutureTradeDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newfutureTradeDetails[i].childNodes[j].nodeName == "nttype") {
						nttype = newfutureTradeDetails[i].childNodes[j].firstChild.nodeValue;
					}

				}
				let newdata=[];
				newdata.push("FTRADE");
				newdata.push(webreference);
				newdata.push(webreference);
				newdata.push(bookingdate);
				newdata.push("1");
				newdata.push(nttype);
				newdata.push("");
				newdata.push("");
				if (newdata !== null)
				{
				//notificationdata.push(newdata);

				}

			}
		}
	}

 	var futureTradeDetails = xml.documentElement.getElementsByTagName("FutureTradeDetails");
	var tableLength = 0;

		if (futureTradeDetails != null) {

			for(var i =0; i < futureTradeDetails.length; i++) {
				if(futureTradeDetails[i]!=null) {
					var elenum = futureTradeDetails[i].childNodes.length;
					var webreference = "";
					var bookingdate = "";
					var nttype = "";
					for(var j=0;j<elenum;j++){
 						if (futureTradeDetails[i].childNodes[j].nodeName == "webreference") {
							webreference = futureTradeDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (futureTradeDetails[i].childNodes[j].nodeName == "bookingdate") {
							bookingdate = futureTradeDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (futureTradeDetails[i].childNodes[j].nodeName == "nttype") {
							nttype = futureTradeDetails[i].childNodes[j].firstChild.nodeValue;
						}

					}

						let newdata=[];
						newdata.push("FTRADE");
						newdata.push(webreference);
						newdata.push(webreference);
						newdata.push(bookingdate);
						newdata.push("1");
						newdata.push(nttype);
						newdata.push("");
						newdata.push("");
						if (newdata !== null)
						{
							 notificationdata.push(newdata);

						}

				}
			}
		}

}



export function doMMMFPopUp(xml,notificationdata)
{
		// console.log('success doMMMFPopUp@@@#@doMMMFPopUp@@@#@<<<<<<'+JSON.stringify(notificationdata));

	var prevMmfAccountCnt=0;
	if (xml.getElementsByTagName("PREVMMFACCOUNTSCNT")[0] != null) {
		prevMmfAccountCnt = parseInt(xml.getElementsByTagName("PREVMMFACCOUNTSCNT")[0].firstChild.nodeValue);
	}
	var newMmfAccountDetails = xml.documentElement.getElementsByTagName("NewMMFAccountDetails");
	if (newMmfAccountDetails != null) {
		for(var i =0; i < newMmfAccountDetails.length; i++) {
			if(newMmfAccountDetails[i]!=null) {
				var elenum = newMmfAccountDetails[i].childNodes.length;
				for(var j=0;j<elenum;j++){
					var acctnbr = "";
					var refacctnbr = "";
					var createddate = "";
					var processid = "";
					var nttype = "";
					for(var j=0;j<elenum;j++){
						if (newMmfAccountDetails[i].childNodes[j].nodeName == "ACCTNBR") {
							acctnbr = newMmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (newMmfAccountDetails[i].childNodes[j].nodeName == "REFACCTNBR") {
							refacctnbr = newMmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (newMmfAccountDetails[i].childNodes[j].nodeName == "CREATEDDATE") {
							createddate = newMmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (newMmfAccountDetails[i].childNodes[j].nodeName == "PROCESSID") {
							processid = newMmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (newMmfAccountDetails[i].childNodes[j].nodeName == "NTTYPE") {
							nttype = newMmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						}
					}
				}

				 var msgStr = "<table id = 'PopupNotifyMMF"+(i+prevMmfAccountCnt)+"' width='100%' cellspacing='0' cellpadding='0' style='border-bottom:1px solid #cccccc'><TR><TD class='paddedL10' valign='top' align='left'><img src=\"images/amber_alert.gif\"></TD><TD class='fieldtxt paddedL10 paddedR10'>"
					+"Money Fund Account:<br/>"
					+ "<span class='secHdTxt'>"
					+ refacctnbr
					+ "</span>"
					+ "<br/>is waiting for approval<br/><i><span class='graytxt'>"
					+ createddate
					+ "</span></i></TD><TD width='10px' class='paddedR10' valign='top' align='right'><img src=\"images/delete_icon_grey.gif\" onClick='closeThisNotificationPopup(\"NotifyMMFTable\", \"PopupNotifyMMF"+(i+prevMmfAccountCnt)+"\", \""+nttype+"\", \""+acctnbr+"\", \"207\", \""+processid+"\");'></TD></TR></TABLE>";

					success(msgStr);
			}
		}
		// console.log('success doMMMFPopUp@@@#@<<<<<<'+JSON.stringify(notificationdata));
	}

	var mmfAccountDetails = xml.documentElement.getElementsByTagName("MMFAccountDetails");

		if (mmfAccountDetails !== null  && mmfAccountDetails !== undefined) {
			for(var i =0; i < mmfAccountDetails.length; i++) {
				if(mmfAccountDetails[i]!=null) {
					var elenum = mmfAccountDetails[i].childNodes.length;
					var acctnbr = "";
					var refacctnbr = "";
					var createddate = "";
					var processid = "";
					var nttype = "";
					for(var j=0;j<elenum;j++){
						if (mmfAccountDetails[i].childNodes[j].nodeName == "ACCTNBR") {
							acctnbr = mmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (mmfAccountDetails[i].childNodes[j].nodeName == "REFACCTNBR") {
							refacctnbr = mmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (mmfAccountDetails[i].childNodes[j].nodeName == "CREATEDDATE") {
							createddate = mmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (mmfAccountDetails[i].childNodes[j].nodeName == "PROCESSID") {
							processid = mmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (mmfAccountDetails[i].childNodes[j].nodeName == "NTTYPE") {
							nttype = mmfAccountDetails[i].childNodes[j].firstChild.nodeValue;
						}
					}
					let newdata=[];
					newdata.push("MMFACCT");
					newdata.push(acctnbr);
					newdata.push(refacctnbr);
					newdata.push(createddate);
					newdata.push("1");
					newdata.push(nttype);
					newdata.push("");
					newdata.push(processid);
					if (newdata !== null)
					{
						notificationdata.push(newdata);
					}
			}
		}

	}
}


export function dispNotificationCount(xml,refreshData)
{
	if(xml.getElementsByTagName("NOTIFICATIONCOUNT")[0] != null) {
		var notificationCnt = xml.getElementsByTagName("NOTIFICATIONCOUNT")[0].firstChild.nodeValue;
		 refreshData.notificationCnt = notificationCnt;
	}

}

export function dispDate(xml,refreshData)
{
	if(xml.getElementsByTagName("TodaysDate")[0] != null) {
		var tdate = xml.getElementsByTagName("TodaysDate")[0].firstChild.nodeValue;
 		refreshData.tdate = tdate;
	}

}

export function dispMenuPendingTradeCnt (xml,refreshData) {
    		var currPendCount = parseInt(xml.getElementsByTagName("CURRTRADECOUNT")[0].firstChild.nodeValue);

   		refreshData.currPendCount = currPendCount;

}

export function dispMenuPendingFutureTradeCnt (xml,refreshData) {
 		if(xml.getElementsByTagName("CURRFUTURETRADECOUNT")[0] != null) {
			var currPendCount = parseInt(xml.getElementsByTagName("CURRFUTURETRADECOUNT")[0].firstChild.nodeValue);

 			refreshData.pendFutureCount = currPendCount;
		}

}

export function doinvPopUp(xml,notificationdata)
{
	var prevInvPolicyCnt = 0;
	if (xml.getElementsByTagName("PREVPOLICYCNT")[0] != null) {
		prevInvPolicyCnt = parseInt(xml.getElementsByTagName("PREVPOLICYCNT")[0].firstChild.nodeValue);
	}
	var newInvestPolicyDetails = xml.documentElement.getElementsByTagName("NewInvestPolicyDetails");
	if (newInvestPolicyDetails != null) {
		for(var i =0; i < newInvestPolicyDetails.length; i++) {
			if(newInvestPolicyDetails[i]!=null) {
				var elenum = newInvestPolicyDetails[i].childNodes.length;
				var companyid = "";
				var companyname = "";
				var description = "";
				var createddate = "";
				var processid = "";
				var policyid = "";
				var nttype = "";
				for(var j=0;j<elenum;j++){
					if (newInvestPolicyDetails[i].childNodes[j].nodeName == "COMPANYID") {
						companyid = newInvestPolicyDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newInvestPolicyDetails[i].childNodes[j].nodeName == "COMPANYNAME") {
						companyname = newInvestPolicyDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newInvestPolicyDetails[i].childNodes[j].nodeName == "DESCRIPTION") {
						description = newInvestPolicyDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newInvestPolicyDetails[i].childNodes[j].nodeName == "CREATEDDATE") {
						createddate = newInvestPolicyDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newInvestPolicyDetails[i].childNodes[j].nodeName == "PROCESSID") {
						processid = newInvestPolicyDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newInvestPolicyDetails[i].childNodes[j].nodeName == "POLICYID") {
						policyid = newInvestPolicyDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newInvestPolicyDetails[i].childNodes[j].nodeName == "NTTYPE") {
						nttype = newInvestPolicyDetails[i].childNodes[j].firstChild.nodeValue;
					}
				}
				   let newdata=[];
					newdata.push("POLICY");
					newdata.push(policyid);
					newdata.push(description);
					newdata.push(createddate);
					newdata.push("1");
					newdata.push(nttype);
				 	newdata.push(companyid);
 					newdata.push(processid);
					if (newdata !== null)
					{
					//	notificationdata.push(newdata);
					}
			}
		}
	}

 	var investPolicyDetails = xml.documentElement.getElementsByTagName("InvestPolicyDetails");
	var tableLength = 0;

		if (investPolicyDetails != null) {

			for(var i =0; i < investPolicyDetails.length; i++) {
				if(investPolicyDetails[i]!=null) {
					var elenum = investPolicyDetails[i].childNodes.length;
					var companyid = "";
					var companyname = "";
					var description = "";
					var createddate = "";
					var processid = "";
					var policyid = "";
					var nttype = "";
					for(var j=0;j<elenum;j++){
						if (investPolicyDetails[i].childNodes[j].nodeName == "COMPANYID") {
							companyid = investPolicyDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (investPolicyDetails[i].childNodes[j].nodeName == "COMPANYNAME") {
							companyname = investPolicyDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (investPolicyDetails[i].childNodes[j].nodeName == "DESCRIPTION") {
							description = investPolicyDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (investPolicyDetails[i].childNodes[j].nodeName == "CREATEDDATE") {
							createddate = investPolicyDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (investPolicyDetails[i].childNodes[j].nodeName == "PROCESSID") {
							processid = investPolicyDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (investPolicyDetails[i].childNodes[j].nodeName == "POLICYID") {
							policyid = investPolicyDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (investPolicyDetails[i].childNodes[j].nodeName == "NTTYPE") {
							nttype = investPolicyDetails[i].childNodes[j].firstChild.nodeValue;
						}
					}

					let newdata=[];
					newdata.push("POLICY");
					newdata.push(policyid);
					newdata.push(description);
					newdata.push(createddate);
					newdata.push("1");
					newdata.push(nttype);
					newdata.push(companyid);
					newdata.push(companyname);
 					newdata.push(processid);
					if (newdata !== null)
					{
						notificationdata.push(newdata);
					}
				}
			}
		}

}
export function doTemplatePopUp(xml,notificationdata)
{
	var prevTemplateCnt = 0;
	if (xml.getElementsByTagName("PREVTEMPLATECNT")[0] != null) {
		prevTemplateCnt = parseInt(xml.getElementsByTagName("PREVTEMPLATECNT")[0].firstChild.nodeValue);
	}
	var newTemplateDetails = xml.documentElement.getElementsByTagName("NewTemplateDetails");
	if (newTemplateDetails != null) {
		for(var i =0; i < newTemplateDetails.length; i++) {
			if(newTemplateDetails[i]!=null) {
				var elenum = newTemplateDetails[i].childNodes.length;
				var templateid = "";
				var processid = "";
				var description = "";
				var createddate = "";
				var nttype = "";
				for(var j=0;j<elenum;j++){
					if (newTemplateDetails[i].childNodes[j].nodeName == "TEMPLATEID") {
						templateid = newTemplateDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newTemplateDetails[i].childNodes[j].nodeName == "PROCESSID") {
						processid = newTemplateDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newTemplateDetails[i].childNodes[j].nodeName == "DESCRIPTION") {
						description = newTemplateDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newTemplateDetails[i].childNodes[j].nodeName == "CREATEDDATE") {
						createddate = newTemplateDetails[i].childNodes[j].firstChild.nodeValue;
					} else if (newTemplateDetails[i].childNodes[j].nodeName == "NTTYPE") {
						nttype = newTemplateDetails[i].childNodes[j].firstChild.nodeValue;
					}
				}

				let newdata=[];
				newdata.push("TEMPLATE");
				newdata.push(templateid);
				newdata.push(description);
				newdata.push(createddate);
				newdata.push("1");
				newdata.push(nttype);
				newdata.push("");
				newdata.push(processid);
				if (newdata !== null)
				{
			//	notificationdata.push(newdata);
				}
			}
		}
	}


	var templateDetails = xml.documentElement.getElementsByTagName("TemplateDetails");
	var tableLength = 0;

		if (templateDetails != null) {

			for(var i =0; i < templateDetails.length; i++) {
				if(templateDetails[i]!=null) {
					var elenum = templateDetails[i].childNodes.length;
					var templateid = "";
					var processid = "";
					var description = "";
					var createddate = "";
					var nttype = "";
					for(var j=0;j<elenum;j++){
						if (templateDetails[i].childNodes[j].nodeName == "TEMPLATEID") {
							templateid = templateDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (templateDetails[i].childNodes[j].nodeName == "PROCESSID") {
							processid = templateDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (templateDetails[i].childNodes[j].nodeName == "DESCRIPTION") {
							description = templateDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (templateDetails[i].childNodes[j].nodeName == "CREATEDDATE") {
							createddate = templateDetails[i].childNodes[j].firstChild.nodeValue;
						} else if (templateDetails[i].childNodes[j].nodeName == "NTTYPE") {
							nttype = templateDetails[i].childNodes[j].firstChild.nodeValue;
						}
					}
					let newdata=[];
					newdata.push("TEMPLATE");
					newdata.push(templateid);
					newdata.push(description);
					newdata.push(createddate);
					newdata.push("1");
					newdata.push(nttype);
					newdata.push("");
					newdata.push(processid);
					if (newdata !== null)
					{
					notificationdata.push(newdata);
					}
				}
			}

	}
}

function getMessage(xml,notificationdata)
{
  	if(xml.getElementsByTagName("PREVMESSAGECOUNT")[0] !=null && xml.getElementsByTagName("CURRMESSAGECOUNT")[0] != null){
		if((parseInt(xml.getElementsByTagName("PREVMESSAGECOUNT")[0].firstChild.nodeValue) <= parseInt(xml.getElementsByTagName("CURRMESSAGECOUNT")[0].firstChild.nodeValue)
			&& parseInt(xml.getElementsByTagName("CURRMESSAGECOUNT")[0].firstChild.nodeValue)!=0))
		{
			var messageDetails = xml.documentElement.getElementsByTagName("MessageDetails");
			var tableLength = 0;

				if (messageDetails != null) {
					for(var i =0; i < messageDetails.length; i++) {
						if(messageDetails[i]!=null) {
							var elenum = messageDetails[i].childNodes.length;
							var messageId = "";
							var sendername = "";
							var messageTxt = "";
							var createddate = "";
							var nttype = "";
							for(var j=0;j<elenum;j++){
								if (messageDetails[i].childNodes[j].nodeName == "MESSAGEID") {
									messageId = messageDetails[i].childNodes[j].firstChild.nodeValue;
								} else if (messageDetails[i].childNodes[j].nodeName == "SENDERNAME") {
									sendername = messageDetails[i].childNodes[j].firstChild.nodeValue;
								} else if (messageDetails[i].childNodes[j].nodeName == "MESSAGETEXT") {
									messageTxt = messageDetails[i].childNodes[j].firstChild.nodeValue;
								} else if (messageDetails[i].childNodes[j].nodeName == "CREATEDDATE") {
									createddate = messageDetails[i].childNodes[j].firstChild.nodeValue;
								} else if (messageDetails[i].childNodes[j].nodeName == "NTTYPE") {
									nttype = messageDetails[i].childNodes[j].firstChild.nodeValue;
								}
							}
							let newdata=[];
							newdata.push("MSG");
							newdata.push(messageId);
 							newdata.push(createddate);
							newdata.push(sendername);
							newdata.push(messageTxt);
							newdata.push(nttype);
							newdata.push("");
							newdata.push('');
							if (newdata !== null)
							{
							notificationdata.push(newdata);
							}
						}
					}
				}

		} else {
			var messageDetails = xml.documentElement.getElementsByTagName("MessageDetails");
			var tableLength = 0;

				if (messageDetails != null) {

					for(var i =0; i < messageDetails.length; i++) {
						if(messageDetails[i]!=null) {
							var elenum = messageDetails[i].childNodes.length;
							var messageId = "";
							var sendername = "";
							var messageTxt = "";
							var createddate = "";
							var nttype = "";
							for(var j=0;j<elenum;j++){
								if (messageDetails[i].childNodes[j].nodeName == "MESSAGEID") {
									messageId = messageDetails[i].childNodes[j].firstChild.nodeValue;
								} else if (messageDetails[i].childNodes[j].nodeName == "SENDERNAME") {
									sendername = messageDetails[i].childNodes[j].firstChild.nodeValue;
								} else if (messageDetails[i].childNodes[j].nodeName == "MESSAGETEXT") {
									messageTxt = messageDetails[i].childNodes[j].firstChild.nodeValue;
								} else if (messageDetails[i].childNodes[j].nodeName == "CREATEDDATE") {
									createddate = messageDetails[i].childNodes[j].firstChild.nodeValue;
								} else if (messageDetails[i].childNodes[j].nodeName == "NTTYPE") {
									nttype = messageDetails[i].childNodes[j].firstChild.nodeValue;
								}
							}
							let newdata=[];
							newdata.push("MSG");
							newdata.push(messageId);
							newdata.push(createddate);
							newdata.push(sendername);
							newdata.push(messageTxt);
							newdata.push(nttype);
							newdata.push("");
							newdata.push('');
							if (newdata !== null)
							{
							notificationdata.push(newdata);
							}
						}
					}
				}

		}
	}
}