import React from 'react';


import { NavBar } from '../../navbar/components/navbar';
import Filters from './Filters';
import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import { withStyles } from '@material-ui/core/styles';
import { Route } from 'react-router-dom';
import MUIDataTable from "mui-datatables";
import TableLoader from '../../common/TableLoader';
import { Link } from 'react-router-dom';
import Typography from '@material-ui/core/Typography';
import ScrollDialog from "../../reports/components/ScrollDialog";
import axios from 'axios';
import { alertConstants } from '../../common/constants/alert.constants';
import Dialog from "@material-ui/core/Dialog";
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import ScrollDialogPopUp  from "../../invest/components/ScrollDialogPopUp";
import AcctScrollDialogPopUp  from "./AcctScrollDialogPopUp";
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiThemeProvider } from '@material-ui/core/styles';



let loading=true
class HomeNotification extends React.Component{
    constructor(props) {
	    super(props);
	    this.state = {
 		open: false,
   };
   	    	 this.handleNotifications=this.handleNotifications.bind(this);

}
	componentWillMount(){

		this.handleNotifications();
	}
  handleOpen = () => {
     this.handleNotifications();
   };
  handleClose = () => {
    this.setState({ open: false });
   };

  handleNotifications() {
    var data;
    var url;
     var bodyFormData = new FormData();
     var user = JSON.parse(sessionStorage.getItem('user'));

    	 bodyFormData.append("token",user[0].token)
    	bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
    	axios({
  		method: 'POST',
  		url:alertConstants.URL+"/NTFYALTS.do",
  		data: bodyFormData,
  		config: { headers: {'Content-Type': 'application/x-www-form-urlencoded' }}
  					  }).then((response)=>{
  					  data = response.data;
   					   console.log('<<data wwwew>>>>'+JSON.stringify(data[1].tradeVec));
  					   this.setState({ open:true, notificatinData:data[1].tradeVec});
  					   console.log('<<######################>>>>'+JSON.stringify(this.state.notificatinData));
  					   loading=false;
   					  });


 }
    render() { const { title } = this.props;
	console.log("title-->"+title);
	const options = {
			 filter: false,
			 filterType: 'dropdown',
			 responsive: 'scroll',
			 selectableRows:false,
			 rowsPerPage: 5,
			 responsive: "scroll",
			 fixedHeader: false,
			 filter:false,
			 search:false,
			 print:false,
			 download:false,
			   viewColumns:false,
			   pagination: false,
			 textLabels: {
				 body: {
					  noMatch:  this.state.notificatinData === undefined ?<TableLoader />:
					   <div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>You have No Messages </b></div>,
 				 },
			 }
		 };

	const columns = [

	   {
		 name: "From",
		  display: true,
		 options: {
		  filter: true,
		  sort: true,
		   }
	   } , {  name: "TYPE",
		   options: {
		   display: false,
		   sort: false,
		   download: false,
		   filter: false,
		   }
	   } , {  name: "TRANSID",
		   options: {
		   display: false,
		   sort: false,
		   download: false,
		   filter: false,
		   }
	   },{  name: "Message",
			   display: true,
			options: {
		 sort: false,
		 download: false,
		 filter: false,
		  customBodyRender: (value, tableMeta, updateValue) => {

					if(tableMeta && tableMeta !== undefined){
					  let tradeLabel='Trade Deal';
					  let id =tableMeta.rowData[2];
					 if(tableMeta.rowData[1] === 'FTRADE')
						 tradeLabel='Future Trade Deal';
					 else if(tableMeta.rowData[1] === 'MMFACCT')
					 tradeLabel='Money Fund Account';

					  else if(tableMeta.rowData[1] === 'MSG')
					 tradeLabel='Message from';
						else if(tableMeta.rowData[1] === 'TEMPLATE')
					 tradeLabel='Email Alert Template';

					   else if(tableMeta.rowData[1] === 'POLICY')
					 tradeLabel='Investment Policy';

					  tradeLabel='Approve Alert';
				   //  console.log('tableMeta.rowData[3]::'+tableMeta.rowData[3]);

						 if(tableMeta.rowData[5]
						 && parseInt(tableMeta.rowData[5])>0
						 && tableMeta.rowData[1] === 'TRADE'){
								   return   <div>
									   <div style={{paddingLeft:'40px'}}> {tradeLabel}:
									 <br/>
									   <ScrollDialog 		onClick={(e) => this.openPopUp(e, tableMeta)}
													   rowData={tableMeta}
													   linkName={tableMeta.rowData[3]}
													   screenLinkImage={'NOTIFICATIONS'}
									 /> is waiting for Checker Approval<br/>
									 <ScrollDialog 		onClick={(e) => this.openPopUp(e, tableMeta)}
												 rowData={tableMeta}
												 linkName={'Click here to view the request '}
												 screenLinkImage={'NOTIFICATIONS'}
									 />

									 </div> </div>

						 }else if(tableMeta.rowData[5] && parseInt(tableMeta.rowData[5])>0 && tableMeta.rowData[1] === 'FTRADE'){

								   return   <div>
								   <div style={{paddingLeft:'40px'}}> {tradeLabel}:

								   <br/> <ScrollDialog 		onClick={(e) => this.openPopUp(e, tableMeta)}
													   rowData={tableMeta}
													   linkName={tableMeta.rowData[3]}
													   screenLinkImage={'NOTIFICATIONS'}
									 />is waiting for Checker Approval<br/>
									 <ScrollDialog 		onClick={(e) => this.openPopUp(e, tableMeta)}
													   rowData={tableMeta}
													   linkName={'Click here to view the request '}
													   screenLinkImage={'NOTIFICATIONS'}
									 /></div></div>

						 }else if(tableMeta.rowData[1] === 'MMFACCT'){
								  if(tableMeta.rowData[5] && parseInt(tableMeta.rowData[5])>0){
								   return   <div>
								   <div style={{paddingLeft:'40px'}}> {tradeLabel}:
									   <br/>
								   <AcctScrollDialogPopUp
																		   onClick={e => this.openPopUp(e, tableMeta)}
																		   rowData={tableMeta}
																		   linkName={tableMeta.rowData[3]}
																		   screenLinkImage={'NOTIFICATIONS'}
																		   func={this.checkClick }

												 />

									  is waiting for Checker Approval<br/>
									  <AcctScrollDialogPopUp
																		   onClick={e => this.openPopUp(e, tableMeta)}
																		   rowData={tableMeta}
																		   linkName={'Click here to view the request '}
																		   screenLinkImage={'NOTIFICATIONS'}
																		   func={this.checkClick }

												 /></div></div>
								 }
							}else if(tableMeta.rowData[1] === 'TEMPLATE'){
								  if(tableMeta.rowData[5] && parseInt(tableMeta.rowData[5])>0){
								   return   <div>
								   <div style={{paddingLeft:'40px'}}> {tradeLabel} :
									<br/>
								   <Link to={{ pathname:"/administration/EDITEMAILTEMP",
									   state: { processId: tableMeta.rowData[7],
									   selTemplate:tableMeta.rowData[2],
									   tempclientFirm: '',
									   mcFlag:'',
									   vecsize:'1'} }}>{tableMeta.rowData[3]}</Link><br/>
										is waiting for Checker Approval<br/>
										<Link to={{ pathname:"/administration/EDITEMAILTEMP",
																			state: { processId: tableMeta.rowData[7],
																			selTemplate:tableMeta.rowData[2],
																			tempclientFirm: '',
																			mcFlag:'',
									   vecsize:'1'} }}>'Click here to view the request '</Link>
									 </div></div>
								 }
							}else if(tableMeta.rowData[1] === 'POLICY'){
								  if(tableMeta.rowData[5] && parseInt(tableMeta.rowData[5])>0){
								   return   <div>
								   <div style={{paddingLeft:'40px'}}> {tradeLabel}:
									  <br/>

									 <ScrollDialogPopUp
												 onClick={(e) => this.openPopUp(e, tableMeta)}
												 rowData={tableMeta}
												  linkName={tableMeta.rowData[3]}
												 screenLinkImage={'NOTIFICATIONS'}

									 />

									 is waiting for Checker Approval<br/>
									 <ScrollDialogPopUp
											 onClick={(e) => this.openPopUp(e, tableMeta)}
											 rowData={tableMeta}
											 linkName={'Click here to view the request '}
											 screenLinkImage={'NOTIFICATIONS'}

									 />
									 </div> </div>
								 }


						 }else if( tableMeta.rowData[1] === 'MSG'){
								   return   <div>
								   <div style={{paddingLeft:'40px'}}> {tradeLabel}:
									 <br/>{tableMeta.rowData[3]}<br/>{tableMeta.rowData[5]}
								   <Link to={{ pathname: '/reportCheck/WATFRAPP', state: { transId: tableMeta.rowData[2]} }}
								id="palceanot"  >View Message</Link><br/>
							   <Link to={{ pathname: '/reportCheck/WATFRAPP', state: { transId: tableMeta.rowData[2]} }}
								id="palceanot"  >'Click here to view the request '</Link></div> </div>

						 }else {
							 return  <div>Trade Deal:<br/>{tableMeta.rowData[3]}<br/>is waiting for Checker Approval<br/></div>
						 }
				   }else {
					   return <div></div>
				   }
	  }
		}
	   }
	   ,{  name: "Received",
		   display: true,
		   options: {
		   sort: false,
		   download: false,
		   filter: false,
		   }
	   } ,{  name: "watFrAppOperval",
		   options: {
		   display: false,
		   sort: false,
		   download: false,
		   filter: false,
		   }
	   },{  name: "ACCTTYPEID",
		   options: {
		   display: false,
		   sort: false,
		   download: false,
		   filter: false,
		   }
	   },{  name: "COMPANYID",
		   options: {
		   display: false,
		   sort: false,
		   download: false,
		   filter: false,
		   }
	   },{  name: "COMPANYNAME",
		   options: {
		   display: false,
		   sort: false,
		   download: false,
		   filter: false,
		   }
	   } ,{  name: "PROCESSID",
		   options: {
		   display: false,
		   sort: false,
		   download: false,
		   filter: false,
		   }
	   }
 ];
         return(
            <div>
                 <div className="clearfix"></div>
                 <NavBar/>
                <div className="col-md-12 col-sm-12 ">

                <div class="panel panel-primary">
					<div class="panel-heading">
					<h4 class="panel-title">Notifications</h4></div>
					<div class="panel-body">
					<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>

			<MUIDataTable
					title='Notifications'
					data={this.state.notificatinData}
					columns={columns}
					options={options}
			/>
	</MuiThemeProvider>


                 </div>

                 </div>
                 </div>
            </div>
        )
    }
}

export default HomeNotification;