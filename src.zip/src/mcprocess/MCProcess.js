import React from 'react';
import { NavBar } from '../navbar/components/navbar';
import Typography from '@material-ui/core/Typography';
import Loading from '../common/Loading';
import CustomPagination from '../reports/components/CustomPagination';
import DatePicker from 'react-datepicker';
import { withStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import { ReactDatePicker } from '../styles/ReactDatePicker';
import CustomDatePickerInput from '../styles/CustomDatePickerInput';
import { MuiStyles } from '../styles/MuiStyles';
import MUIDataTable from "mui-datatables";
import { MuiThemeProvider } from "@material-ui/core/styles";
import { muiTableStyles } from '../styles/muidatatableCss';

var columns =
    ["User", "Role Type", "Nature of Change", "Maker", "Checker", "Approved At", "Approved By", "Changes done By", "Status"];
var data = [
    ["Pete", "MAKER", "Modified Account Number", "LPMaker", "LPChecker", "Jun 11, 2019 09:41:01", "LPCHECKER", "LPMAKER", "Approved"],
    ["Adams", "MAKER", "Modified Email",  "LPMaker", "LPChecker", "Jun 11, 2019 09:43:13", "LPCHECKER", "LPMAKER", "Pending"],
    ["David", "MAKER", "Modified Address",  "LPMaker", "LPChecker", "Jun 11, 2019 09:46:21", "LPCHECKER", "LPMAKER", "Pending"],
    ["Lee", "MAKER", " Modified Phone",  "LPMaker", "LPChecker", "Jun 11, 2019 09:52:51", "LPCHECKER", "LPMAKER", "Approved"]
];

class MCProcess extends React.Component {
    constructor() {
        super()
    }
    render() {
        const { classes } = this.props;

        const options = {
            filterType: "dropdown",
            customFooter: (
                count,
                page,
                rowsPerPage,
                changeRowsPerPage,
                changePage
            ) => {
                return <CustomPagination
                    count={count}
                    page={page}
                    rowsPerPage={rowsPerPage}
                    changeRowsPerPage={changeRowsPerPage}
                    // changePage={changePage}
                    onChangePage={(_, page) => changePage(page)}
                    onChangeRowsPerPage={event => changeRowsPerPage(event.target.value)}
                    type={"senario1"}
                />;
            }
        };
        return (
            <div>
                <NavBar />
                <div className="mainContent">
                    <Typography variant="h5" component="h3" className="screenTitle">Maker Checker Report</Typography>
                    <div className="form-group col-md-2 col-sm-2">
                        <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
                            From Date:</InputLabel>
                        <ReactDatePicker>
                            <DatePicker dateFormat="MMM dd, YYYY" autoOk={true} name={"fromDate"} className="form-control" selected={new Date()} customInput={(<CustomDatePickerInput />)} />
                        </ReactDatePicker>                   
                    </div>
                    <div className="clearfix"></div>
                    {
                        data !== undefined ?
                            <div>
                                <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                                    <MUIDataTable
                                        data={data}
                                        columns={columns}
                                        options={options}
                                    />
                                    <button className="btn btn-xs btn-primary">Approve</button>
                                    <button className="btn btn-xs btn-primary">Reject</button>
                                </MuiThemeProvider>
                            </div>
                            :
                            <div className="col-md-12" style={{ marginTop: '10%', marginBottom: '10%' }}><div className="clearfix"></div><Loading /></div>
                    }
                </div>
            </div>
        );
    }
}

export default withStyles(MuiStyles)(MCProcess);