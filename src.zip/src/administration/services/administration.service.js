import { authHeader,fetchHelper } from '../../_helpers';
import { alertConstants } from '../../common/constants/alert.constants';
import FromData from 'form-data';
export const administrationService = {
    fetchReport,
    fetchReportTable,
    fetchUserData,
    fetchUserLinksPermData,
    fetchUserLinksViewChangesData,
    fetchUserApprovalViewChangesData,
     fetchUserApprovalData,
    fetchUserGroupsMgmtViewChangesData,
    fetchUserRolesTradeApprovalProcessViewChangesData,
    fetchUserRolesViewChangesData,
    fetchUserRolesEmailAddMaintainceViewChangesData,
    fetchGroupUserLinksPermData,
    fetchAcctDet,
    fetchCNMFAcct,
    fetchMakerCheckerParams,
    saveCheckerParamsData,
    fetchAdminmfrevpros,
    fetchAssociatedUserDetPopData,
    fetchtempUserAccData,
    fetchIBAAcctDetData,
    fetchAlertTempDataDet,
    fetchMmfeditAcctDet,
    fetchMmfcreateAcctDet,
    fetchMmfReviewProspectus,
    fetchViewChangeHistoryPopUp,
    fetchAssignAlertRecipients,
    fetchFundAccounts,
    fetchassignAlertRecipientsTableData,
    fetchResearchMoney
};

function fetchIBAAcctDetData(bodyFormData) {
    //alert("in services");
    var user = JSON.parse(sessionStorage.getItem('user'));
    //var filtObj = new FormData();
    let _ibaacctdata;
     var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
       // filtObj["token"] =user[0].token;
        _ibaacctdata = fetchHelper.httpFormPost(alertConstants.URL+'/CRAADCNT.do',bodyFormData);

    }
    return _ibaacctdata;
}

function fetchAdminmfrevpros(bodyFormData) {
    //alert("in services");
    var user = JSON.parse(sessionStorage.getItem('user'));
    //var filtObj = new FormData();
    let _reportData;
     var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
       // filtObj["token"] =user[0].token;
        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _reportData;
}


function fetchCNMFAcct(bodyFormData) {
    //alert("in services");
    var user = JSON.parse(sessionStorage.getItem('user'));
    //var filtObj = new FormData();
    let _reportData;
     var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
       // filtObj["token"] =user[0].token;
        _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _reportData;
}

function fetchReport(filtObj) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    //var filtObj = new FromData();
    let _reportData;
     var pathname = window.location.pathname.replace("/administration/","");

     //if(tabval != undefined && tabval != '')
     //filtObj.append("tabName",tabval);

     if(pathname == '/admincreate/CREATEACCT')
     	pathname = '/admincreate/LOOKUP';

    if(user[0].token !== undefined){
        filtObj.append("token",user[0].token);
        filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
         _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);

    }
    return _reportData;
}
function fetchReportTable(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _reportTableData;

    var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("reactJSActionFlag","GO")
        _reportTableData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _reportTableData;
}
function fetchUserData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userData;

    var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("reactJSActionFlag","GO")
          bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _userData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _userData;
}

function fetchUserLinksPermData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userLinksPermData;

    var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("reactJSActionFlag","SHOWDATA")
          bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _userLinksPermData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _userLinksPermData;
}
function fetchGroupUserLinksPermData(bodyFormData,actionFlag) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userLinksPermData;

    var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
      /*  let newGrpFlag=false;
        let actionFlag= "";
        for (var pair of bodyFormData.entries()) {
		            if(pair[0]=== 'selLnkGrpId' &&  pair[1]=== 'NEW' )
		            newGrpFlag=true;
		             if(pair[0]=== 'actionFlag' &&  pair[1]=== 'SAVE' )
		            actionFlag='SAVE';
        }

        if(newGrpFlag && actionFlag === 'SAVE'){
			 bodyFormData.append("reactJSActionFlag","GO")
		}else{
		 bodyFormData.append("reactJSActionFlag","SHOW")
		}*/

	  if( actionFlag === 'NEW'){
			 bodyFormData.append("reactJSActionFlag","GO")
		}else{
		 bodyFormData.append("reactJSActionFlag","SHOW")
		}
          bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _userLinksPermData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _userLinksPermData;
}
function fetchUserLinksViewChangesData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userLinksViewChangsData;


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _userLinksViewChangsData = fetchHelper.httpFormPost(alertConstants.URL+'/USERPRPopUp.do',bodyFormData);
    }
    return _userLinksViewChangsData;
}
function fetchUserApprovalViewChangesData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userLinksViewChangsData;


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _userLinksViewChangsData = fetchHelper.httpFormPost(alertConstants.URL+'/CLGRPUSRASSOCPopUp.do',bodyFormData);
    }
    return _userLinksViewChangsData;
}
function fetchUserApprovalData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userApprovalData;
    var pathname = window.location.pathname.replace("/administration/","")


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
                 _userApprovalData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _userApprovalData;
}
function fetchUserGroupsMgmtViewChangesData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userLinksViewChangsData;


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _userLinksViewChangsData = fetchHelper.httpFormPost(alertConstants.URL+'/PRTMCGMRPopUp.do',bodyFormData);
    }
    return _userLinksViewChangsData;
}
function fetchUserRolesTradeApprovalProcessViewChangesData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userLinksViewChangsData;


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
         _userLinksViewChangsData = fetchHelper.httpFormPost(alertConstants.URL+'/trdApprParamViewChangesPopUp.do',bodyFormData);
    }
    return _userLinksViewChangsData;
}
function fetchUserRolesViewChangesData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userLinksViewChangsData;


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
         _userLinksViewChangsData = fetchHelper.httpFormPost(alertConstants.URL+'/userRoleViewChangesPopUp.do',bodyFormData);
    }
    return _userLinksViewChangsData;
}
function fetchUserRolesEmailAddMaintainceViewChangesData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userLinksViewChangsData;


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
           bodyFormData.append("processId",JSON.parse(sessionStorage.getItem('processId')))
         _userLinksViewChangsData = fetchHelper.httpFormPost(alertConstants.URL+'/EMLADSMTPopUp.do',bodyFormData);
    }
    return _userLinksViewChangsData;
}
function fetchMakerCheckerParams(bodyFormData, actionName) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userData;

    var pathname = actionName; //window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("reactJSActionFlag","GO")
          bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))

          console.log("GGGGGGGGGGGGGGGGGGGGGGG::::"+JSON.parse(sessionStorage.getItem('clientFirm')));

        _userData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

        console.log("_userData:11111:::"+JSON.stringify( _userData));
    }
    return _userData;
}
function saveCheckerParamsData(bodyFormData, actionName) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _userData;

    var pathname = actionName; //window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
       // bodyFormData.append("clientFirm",'19687983')
        _userData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

        console.log("_userData:after Save::"+JSON.stringify( _userData));
    }
    return _userData;
}

function fetchAcctDet() {
    //alert("in services");
    var user = JSON.parse(sessionStorage.getItem('user'));
    var filtObj = new FromData();
    let _acctData;
     var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        filtObj.append("token",user[0].token);
       // filtObj["token"] =user[0].token;
        _acctData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);

    }
    return _acctData;
}

function fetchAssociatedUserDetPopData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _associateduserdata;


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _associateduserdata = fetchHelper.httpFormPost(alertConstants.URL+'/CONTACTDETAILSPopUp.do',bodyFormData);
    }
    return _associateduserdata;
}

function fetchtempUserAccData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _tempuserdata;


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
           bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _tempuserdata = fetchHelper.httpFormPost(alertConstants.URL+'/EDITEMAILTEMP.do',bodyFormData);
    }
    return _tempuserdata;
}

function fetchAlertTempDataDet(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _alerttempdatadet;


    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _alerttempdatadet = fetchHelper.httpFormPost(alertConstants.URL+'/CLEMAIL.do',bodyFormData);
    }
    return _alerttempdatadet;
}

function fetchMmfReviewProspectus(bodyFormData) {
	var user = JSON.parse(sessionStorage.getItem('user'));
	let mmfreviewPropDet;

	if(user[0].token !== undefined) {
		bodyFormData.append("token",user[0].token)
		bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
		mmfreviewPropDet = fetchHelper.httpFormPost(alertConstants.URL+'/REVIEWPROSPECT.do',bodyFormData);
	}

	return mmfreviewPropDet;
}

function fetchMmfcreateAcctDet(bodyFormData) {
	var user = JSON.parse(sessionStorage.getItem('user'));
	let mmfcreateAcctDet;

	if(user[0].token !== undefined) {
		bodyFormData.append("token",user[0].token)
		bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
		mmfcreateAcctDet = fetchHelper.httpFormPost(alertConstants.URL+'/ADDACCNT.do',bodyFormData);
	}

	return mmfcreateAcctDet;
}

function fetchMmfeditAcctDet(bodyFormData) {
	var user = JSON.parse(sessionStorage.getItem('user'));
	let mmfeditAcctDet;

	if(user[0].token !== undefined) {
		bodyFormData.append("token",user[0].token)
		//if(bodyFormData.get("pageFrom") !== undefined && bodyFormData.get("pageFrom") === 'EDITACCT')
		//{
		  bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
		//}
		mmfeditAcctDet = fetchHelper.httpFormPost(alertConstants.URL+'/MMMFACCTLOOKUP.do',bodyFormData);
	}
	//console.log("mar 25, 2019 target value ::mmfeditAcctDet::",mmfeditAcctDet);
	return mmfeditAcctDet;
}

function fetchViewChangeHistoryPopUp(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _viewchangehistory;

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
        _viewchangehistory = fetchHelper.httpFormPost(alertConstants.URL+'/EALERTPopUp.do',bodyFormData);
    }
    return _viewchangehistory;
}

function fetchAssignAlertRecipients(filtObj, selFirm) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    //var filtObj = new FromData();
    let _reportData;
     //var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        filtObj.append("token",user[0].token);
        if(selFirm != null && selFirm != '')
        {
          filtObj.append("selFirm", selFirm);
          filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        }else{
          filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        }
         _reportData = fetchHelper.httpFormPost(alertConstants.URL+'/administration/EAUACL.do',filtObj);

    }
    return _reportData;
}
function fetchassignAlertRecipientsTableData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _reportTableData;

    var pathname = window.location.pathname.replace("/administration/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("reactJSActionFlag","GO")
        _reportTableData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _reportTableData;
}

function fetchFundAccounts(filtObj)
{
	var user = JSON.parse(sessionStorage.getItem('user'));
	let _reportData;
	var pathname = window.location.pathname.replace("/administration/","");

	pathname = '/admincreate/CREATEACCT';

    if(user[0].token !== undefined)
    {
		filtObj.append("token",user[0].token);
		filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
		_reportData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',filtObj);
    }

    return _reportData;
}
function fetchResearchMoney(filtObj)
{
	var user = JSON.parse(sessionStorage.getItem('user'));
	let researchDet;
    if(user[0].token !== undefined)
    {
		filtObj.append("token",user[0].token);
		filtObj.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
		researchDet = fetchHelper.httpFormPost(alertConstants.URL+'/FUNDINFO.do',bodyFormData);
    }

    return researchDet;
}