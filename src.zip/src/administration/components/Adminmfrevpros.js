import React from 'react';
import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import { NavBar } from '../../navbar/components/navbar';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { AdministrationActions } from '../actions/administration.actions';
import { withStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import InputLabel from '@material-ui/core/InputLabel';

import MTable from './MTable';
import { Adminmfacctdet }  from './Adminmfacctdet';
import { Link } from 'react-router-dom';

const styles = theme => ({
    root: {
      width: '100%',
    },
    heading: {
      fontSize: theme.typography.pxToRem(15),
      fontWeight: theme.typography.fontWeightRegular,
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
        margin:'2px',
    }
});

class Adminmfrevpros extends React.Component{
    constructor(props) {
        super(props);
        this.state={
	    tabIndex: 1,
        }
        this.handleChange = this.handleChange.bind(this);
        this.doForward = this.doForward.bind(this);
    }
    componentDidMount() { 
        this.getFilters()
       // alert(" select file Adminmfrevpros.js ... component did amount........");
      }
     getFilters(){
	//alert(" select file Adminmfrevpros.js ... component did amount........");
	var bodyFormData = new FormData();
	bodyFormData.append("company","81837075");
	bodyFormData.append("fundTypeId","101");
	bodyFormData.append("fundFamilyId","17903322");
	bodyFormData.append("prodId","47806054");
	bodyFormData.append("ccy","EUR");
        this.props.dispatch(AdministrationActions.fetchAdminmfrevprosdata(bodyFormData));
    } 
    handleChange = name => event => {
        this.setState({
            [name]: event.target.value,
        });
        
    };
   doForward(obj){
         alert("in select method ");
         this.setState({ tabIndex:0})   
    }
    render(){
        let data = [];
        data = this.props.data;
        console.log("select fund data::",data);
        
	let screenName='';
	let cusipisin='';
	let currency='';
	let FundType='';
	let NAV='';
	let AUM='';
	let EODCutOffTime='';
	let Factor='';
	let DailyYield='';
	let DayCurrentYield7='';
	let DayEffectiveYield7='';
	let DayYield30='';
	let SP='';
	let Moodys='';
	let Fitch='';
	let NAIC='';
	
        const { classes } = this.props;
        console.log("inital data:"+this.props.adminmfrevprosdata);
        var results=[],results1=[];
        
        console.log("prospect data::",this.props.adminmfrevprosdata.adminmfrevprosdata);
        console.log("select fund data::",this.props.cnmfaccountdata);
        
        
        if(this.props.adminmfrevprosdata.adminmfrevprosdata !== undefined){
            results = this.props.adminmfrevprosdata.adminmfrevprosdata;	
            results1.push(results.Title);
            results1.push(results.commonData);
            
            console.log("results1::"+JSON.stringify(results1));
            
            if(results1 !== undefined){
            results1.map((item,index) => {
                if(item.type === "Title"){
                  screenName = item.name  
                }
		cusipisin = item.CUSIPISIN;
		currency = item.Currency;
		FundType = item.FundType;
		NAV = item.NAV;
		AUM = item.AUM;
		EODCutOffTime = item.EODCutOffTime;
		Factor = item.Factor;
		DailyYield = item.DailyYield;
		DayCurrentYield7 = item.DayCurrentYield7;
		DayEffectiveYield7 = item.DayEffectiveYield7;
		DayYield30 = item.DayYield30;
		SP = item.SP;
		Moodys = item.Moodys;
		Fitch = item.Fitch;
		NAIC = item.NAIC;
             });
           }
        }
       
           
                return  (


 		<div>
                <NavBar/> 
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">Create New Money Fund Account</h4>
                    </div>
                    <div className="panel-body">
                   <label>{screenName}</label>
                    <div className="col-md-12 col-sm-12">
			<Tabs selectedIndex={this.state.tabIndex} onSelect={tabIndex => this.setState({ tabIndex })} >
				<TabList>
				<Link  to={{ pathname: '/admincreate/CREATEACCT', state: {company:"81837075",fundTypeId:"101" ,fundFamilyId:"17903322" ,prodId:"47806054" ,ccy:"EUR"} }} ><Tab>1.Select Fund</Tab></Link>
				<Tab>2.Review Prospectus </Tab>
				<Tab>3.Enter Account Details </Tab>
				</TabList>
				<TabPanel> 
				 <MTable data={data} method={this.doForward.bind(this)} />
				 {/* <MuiTable data={result1} method={this.doForward.bind(this)} /> */}
				</TabPanel>
				<TabPanel>
				    <div className={classes.root}>
				                             
				                            <ExpansionPanel defaultExpanded>
				                               
				                                <ExpansionPanelDetails>
				    
				                               
				                                <Grid container spacing={16}>
				                                        <Grid item xs={4}   >
				                                            <InputLabel>CUSIP/ISIN :</InputLabel>
				                                            <TextField  ref="cusipisin" name="cusipisin" value={cusipisin}/>
				                                        </Grid>
				                                        <Grid item xs={4}  >
				                                            <InputLabel>Currency :</InputLabel>
				                                            <TextField ref="currency" name="currency" value={currency} />
				                                        </Grid>
				    
				                                        <Grid item xs={4} >
				                                        <InputLabel>Fund Type :</InputLabel>
				                                        <TextField ref="FundType" name="FundType" value={FundType} />
				                                        </Grid>
				                                        <Grid item xs={4} >
				                                        <InputLabel>NAV:</InputLabel>
				                                        <TextField ref="NAV" name="NAV" value={NAV}/>
				                                        </Grid>
				                                        <Grid item xs={4}  >
				                                        <InputLabel>AUM(MM):</InputLabel>
				                                        <TextField ref="AUM" name="AUM" value={AUM} />
				                                        </Grid>
				                                        <Grid item xs={4}  >
				                                        <InputLabel>EOD Cut-Off Time:</InputLabel>
				                                        <TextField ref="EODCutOffTime" name="EODCutOffTime" value={EODCutOffTime} />
				                                        </Grid>
				                                    </Grid>
				                                </ExpansionPanelDetails>
				                            </ExpansionPanel>
				                            <ExpansionPanel defaultExpanded>>
				                                <ExpansionPanelDetails>
				                                <Grid container spacing={16}>
				                                        <Grid item xs={4}   >
				                                        <InputLabel>Factor:</InputLabel>
				                                        <TextField  ref="Factor" name="Factor" value={Factor} />
				                                        </Grid>
				                                        <Grid item xs={8} >
				                                        <InputLabel>Daily Yield:</InputLabel>
				                                        <TextField ref="DailyYield" name="DailyYield" value={DailyYield} />
				                                        </Grid>
				    
				                                        <Grid item xs={4}  >
				                                        <InputLabel>7-Day Current Yield:</InputLabel>
				                                        <TextField  ref="DayCurrentYield7" name="DayCurrentYield7" value={DayCurrentYield7} />
				                                        </Grid>
				                                        <Grid item xs={4}  >
				                                        <InputLabel>7-Day Effective Yield</InputLabel>
				                                        <TextField  ref="DayEffectiveYield7" name="DayEffectiveYield7" value={DayEffectiveYield7} />
				                                        </Grid>
				                                        <Grid item xs={4} >
				                                        <InputLabel>30-day Yield:</InputLabel>
				                                        <TextField  ref="DayYield30" name="DayYield30" value={DayYield30} />
				                                        </Grid>
				                                        
				                                    </Grid>
				                               
				                                </ExpansionPanelDetails>
				                            </ExpansionPanel>
				                            <ExpansionPanel defaultExpanded>
				                                <ExpansionPanelDetails>
				                                <Grid container spacing={16}>
				                                        <Grid item xs={4}  >
				                                        <InputLabel>S&P:</InputLabel>
				                                        <TextField   ref="SP" name="SP" value={SP} />
				                                        </Grid>
				                                        <Grid item xs={4}  >
				                                        <InputLabel>Moody's:</InputLabel>
				                                        <TextField  ref="Moodys" name="Moodys" value={Moodys} />
				                                        </Grid>
				    
				                                        <Grid item xs={4}  >
				                                        <InputLabel>Fitch:</InputLabel>
				                                        <TextField  ref="Fitch" name="Fitch" value={Fitch} />
				                                        </Grid>
				                                        <Grid item xs={4} >
				                                        <InputLabel>NAIC</InputLabel>
				                                        <TextField ref="NAIC" name="NAIC" value={NAIC} />
				                                        </Grid>
				                                       
				                                        
				                                    </Grid>
				                               
				                                </ExpansionPanelDetails>
				                            </ExpansionPanel>
				                            <ExpansionPanel defaultExpanded>
				                                <ExpansionPanelDetails>
				                                <Grid container spacing={16}>
				                                        <Grid item xs={4}  >
				                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM9 9.5h1v-1H9v1zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm10 5.5h1v-3h-1v3z"/></svg>
				    
				                                        <a href="#">Fund Fact Sheet:</a>
				                                       
				                                        </Grid>
				                                        <Grid item xs={4} >
				                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM9 9.5h1v-1H9v1zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm10 5.5h1v-3h-1v3z"/></svg>
				    
				                                        <a href="#">Prospectus:</a>
				                                       
				                                        </Grid>
				    
				                                        <Grid item xs={4}  >
				                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM9 9.5h1v-1H9v1zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm10 5.5h1v-3h-1v3z"/></svg>
				    
				                                        <a href="#">KIID:</a>
				                                       
				                                        </Grid>
				                                        <Grid item xs={4} >
				                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM9 9.5h1v-1H9v1zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm10 5.5h1v-3h-1v3z"/></svg>
				    
				                                        <a href="#">Annual Report :</a>
				                                       
				                                        </Grid>
				                                        <Grid item xs={4}   >
				                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM9 9.5h1v-1H9v1zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm10 5.5h1v-3h-1v3z"/></svg>
				    
				                                        <a href="#">Semi-Annual Report</a>
				                                       
				                                        </Grid>
				    
				                                        <Grid item xs={4}   >
				                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM9 9.5h1v-1H9v1zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm10 5.5h1v-3h-1v3z"/></svg>
				    
				                                        <a href="#">Holdings Report</a>
				                                        </Grid>
				                                        <Grid item xs={12}  >
				                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM9 9.5h1v-1H9v1zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm10 5.5h1v-3h-1v3z"/></svg>
				                                        <a href="#">sai</a>
				                                       
				                                        </Grid>
				                                        <Grid item xs={8} >
				                                        <InputLabel></InputLabel>
				                                       
				                                        </Grid>
				                                        <Grid item xs={4}   >
				                                       
				                                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="6 2 5 12"><path d="M6.61 11.89L3.5 8.78 2.44 9.84 6.61 14l8.95-8.95L14.5 4z"/></svg>
				                                        <a href="#">I have reviewed the Fund prospectus</a>
				                                    </Grid>
				                                       
				                                   
				                                    <Grid item xs={11}  >
				                                    <a href='#'>Back</a>
				                                    </Grid>
				                                    <Grid item xs={1}  >
				                                    <button className="btn btn-xs btn-primary">Next</button>
				                                    </Grid>
				                                    </Grid>
				    
				                              
				                                </ExpansionPanelDetails>
				                            </ExpansionPanel>
				                           
                    </div>
				</TabPanel>
				<TabPanel>
				    <Adminmfacctdet />
				</TabPanel>
			</Tabs>
                    
                    
                    </div>
		                        </div>
		                    </div>
            </div>
                  
                )
           
    }

}


function mapStateToProps(state) { 
    const { adminmfrevprosdata } = state;
    return { adminmfrevprosdata };
}

Adminmfrevpros.propTypes = {
    classes: PropTypes.object.isRequired,
  };

const connectedAdminmfrevpros = connect(mapStateToProps)(withStyles(styles)(Adminmfrevpros));
export { connectedAdminmfrevpros as Adminmfrevpros };
