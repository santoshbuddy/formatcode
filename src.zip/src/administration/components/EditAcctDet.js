import React from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
import { connect } from 'react-redux';
import FormData from 'form-data';
import { alertConstants } from '../../common/constants/alert.constants';
import { withStyles,MuiThemeProvider } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import { NavBar } from '../../navbar/components/navbar';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import { AdministrationActions } from '../actions/administration.actions';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import Loading from '../../common/Loading'
const styles = theme => ({
    root: {
      flexGrow: 1,
    },
    heading: {
      fontSize: theme.typography.pxToRem(15),
      fontWeight: theme.typography.fontWeightRegular,
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
        margin:'2px',
        display: 'inline',
    }
});

var msg='';
let saveFlag=false;
let msgTxt='';
var savedData;
var revokeData;
let firstBtn="";
let secondBtn="";
let thirdBtn="";
let editBtn="";
let backBtn="";
let titleBlk="";
let descrBlk="";
let acctBlk="";
let taxInfoBlk="";
let primaryAddrBlk="";
let stmtMailBlk="";
let remarkBlk="";
let pageFrom="";
let cData=[];
let cData1=[];
let errMsg="";
let errMsgTxt="";
class EditAcctDet extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            columns:[],
            acctNbr: '',
            dividentAcct:'',
            dividentType:'',
            shortname:'',
            longname:'',
            remarks:'',
            clientidentifier:'',
            name:'',
            updateFlag: false,
        }

        this.handleChange = this.handleChange.bind(this);
        this.saveDetails = this.saveDetails.bind(this);
        this.revokeDetails = this.revokeDetails.bind(this);
        this.cancelDetails = this.cancelDetails.bind(this);
        this.rejectDetails = this.rejectDetails.bind(this);
        this.approveDetails = this.approveDetails.bind(this);
        this.doBack = this.doBack.bind(this);
        this.editAcctDetails = this.editAcctDetails.bind(this);
        }


cancelDetails() {
		var bodyFormdata = new FormData();
		var user 		= JSON.parse(sessionStorage.getItem('user'));
			bodyFormdata.append("token",user[0].token);
			bodyFormdata.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
			axios({
				method: 'post',
				url:alertConstants.URL+"/MMMFACCTLOOKUP.do",
				data: bodyFormdata,
				config: { headers: {'Content-Type': 'multipart/form-data' }}
			  }).then((response)=>{
					  revokeData = response.data;
					  this.setState({ updateFlag: true });
					  //alert("successfully revoked::"+revokeData);
					  pageFrom="EDIT";
					  //console.log("response.data===>",revokeData)
					//alert("revoke success block forwarding to lookup screen ");
					this.props.history.push({
						pathname: '/administration/LOOKUP',
						state: {
							fromPage:'ViewChanges',
							fromLink: this.props.location.pathname,
							product: 'ALL',
							issueChild: 'ALL'
						}
					});
			  });

	}

 revokeDetails() {
		var bodyFormdata = new FormData();
		var user 		= JSON.parse(sessionStorage.getItem('user'));
			bodyFormdata.append("token",user[0].token);
			if(pageFrom!== undefined && pageFrom === 'MMFREL')
			{
			  bodyFormdata.append("clientFirm",this.props.location.state.ecompanyid);
			}else{
			  bodyFormdata.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
			}
			bodyFormdata.append("processId", this.props.cData.processId);
			//alert("this.props.cData.processId::::"+this.props.cData.processId);
			bodyFormdata.append("investAccount", this.props.cData.acctnbr);
			bodyFormdata.append("selectedProd", this.props.cData.prodid);
			bodyFormdata.append("currencyCode", this.props.cData.currency);
			bodyFormdata.append("actionVal", "");
			bodyFormdata.append("actionFlag", "REVOKE");
			bodyFormdata.append("mmmfAcct", this.props.cData.escrowacctnbr);
			bodyFormdata.append("refFundNbr", this.props.cData.refacctnbr);
			bodyFormdata.append("mmfDesc", this.state.shortname==""?this.props.cData.mmfDesc:this.state.shortname);
			bodyFormdata.append("mmfDescLong", this.state.longname==""?this.props.cData.mmfDescLong:this.state.longname);
			bodyFormdata.append("clientIdentifier", this.state.clientidentifier==""?this.props.cData.clientIdentifier:this.state.clientidentifier);
			bodyFormdata.append("acctStruID", this.props.cData.acctStruID);
			bodyFormdata.append("ddaAcct", this.props.cData.ddaAcct);
			bodyFormdata.append("remarks1",  this.state.remarks);
			bodyFormdata.append("taxidtxt", this.props.cData.taxidtxt);
			bodyFormdata.append("taxId", this.props.cData.taxId);
			bodyFormdata.append("acctlookup", this.props.cData.acctlookup);
			bodyFormdata.append("dividendType", this.props.cData.ddaSettleId);
			bodyFormdata.append("addresstxt", "");
			bodyFormdata.append("dividendAcct", this.props.cData.ddaAcct);
			bodyFormdata.append("redemddaAcct", this.props.cData.redemddaAcct);
			bodyFormdata.append("fundProduct", this.props.cData.fundProduct);
			bodyFormdata.append("mmfSearch", this.props.cData.refacctnbr);
			bodyFormdata.append("balanceProdFlag", "LOOKUP");
			bodyFormdata.append("selectedProdName", this.props.cData.subprodname);
			bodyFormdata.append("currentBal", this.props.cData.currentBal);
			bodyFormdata.append("acctStatus", this.props.cData.acctStatus);
			bodyFormdata.append("acctnature", this.props.cData.acctnature);
			bodyFormdata.append("product", this.props.cData.prodid);
			bodyFormdata.append("currency", this.props.cData.currency);
			bodyFormdata.append("chkStatus", "Y");
			bodyFormdata.append("cutOffTime", this.props.cData.cutOffTime);
			bodyFormdata.append("ddaAcctDescr", this.props.cData.settleacctname);
			bodyFormdata.append("cutOffFlag", this.props.cData.cutOffFlag);
			bodyFormdata.append("fundAcct", this.props.cData.escrowacctnbr);
			bodyFormdata.append("escrowCheck", "N");
			bodyFormdata.append("socialCode", this.props.cData.socialCode);
			bodyFormdata.append("taxPayerType", this.props.cData.taxPayerType);
			bodyFormdata.append("ddaSettleId", this.props.cData.ddaSettleId);
			bodyFormdata.append("mmfSrch", "Y");
			bodyFormdata.append("lookUpFlag", "YES");
			if(confirm("Are you sure, you want to revoke the data?"))
			{
			axios({
				method: 'post',
				url:alertConstants.URL+"/MMMFACCTLOOKUP.do",
				data: bodyFormdata,
				config: { headers: {'Content-Type': 'multipart/form-data' }}
			  }).then((response)=>{
					  revokeData = response.data;
					  this.setState({ updateFlag: true });
					  //alert("successfully revoked::"+revokeData);
					  pageFrom="EDIT";
					  //console.log("response.data===>",revokeData)
					//alert("revoke success block forwarding to lookup screen ");
					this.props.history.push({
						pathname: '/administration/LOOKUP',
						state: {
							fromPage:'ViewChanges',
							fromLink: this.props.location.pathname,
							product: 'ALL',
							issueChild: 'ALL'
						}
					});
			  });



			}
	}

 rejectDetails() {
		var bodyFormdata = new FormData();
		var user 		= JSON.parse(sessionStorage.getItem('user'));

			bodyFormdata.append("token",user[0].token);
			if(pageFrom!== undefined && pageFrom === 'MMFREL')
			{
			  bodyFormdata.append("clientFirm",this.props.location.state.ecompanyid);
			}else{
			  bodyFormdata.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
			}
			bodyFormdata.append("processId", this.props.cData.processId);
			//alert("this.props.cData.processId::::"+this.props.cData.processId);
			bodyFormdata.append("investAccount", this.props.cData.acctnbr);
			bodyFormdata.append("selectedProd", this.props.cData.prodid);
			bodyFormdata.append("currencyCode", this.props.cData.currency);
			bodyFormdata.append("actionVal", "");
			bodyFormdata.append("actionFlag", "REJECT");
			bodyFormdata.append("mmmfAcct", this.props.cData.escrowacctnbr);
			bodyFormdata.append("refFundNbr", this.props.cData.refacctnbr);
			bodyFormdata.append("mmfDesc", this.state.shortname==""?this.props.cData.mmfDesc:this.state.shortname);
			bodyFormdata.append("mmfDescLong", this.state.longname==""?this.props.cData.mmfDescLong:this.state.longname);
			bodyFormdata.append("clientIdentifier", this.state.clientidentifier==""?this.props.cData.clientIdentifier:this.state.clientidentifier);
			bodyFormdata.append("acctStruID", this.props.cData.acctStruID);
			bodyFormdata.append("ddaAcct", this.props.cData.ddaAcct);
			bodyFormdata.append("remarks1",  this.state.remarks);
			bodyFormdata.append("taxidtxt", this.props.cData.taxidtxt);
			bodyFormdata.append("taxId", this.props.cData.taxId);
			bodyFormdata.append("acctlookup", this.props.cData.acctlookup);
			bodyFormdata.append("dividendType", this.props.cData.ddaSettleId);
			bodyFormdata.append("addresstxt", "");
			bodyFormdata.append("dividendAcct", this.props.cData.ddaAcct);
			bodyFormdata.append("redemddaAcct", this.props.cData.redemddaAcct);
			bodyFormdata.append("fundProduct", this.props.cData.fundProduct);
			bodyFormdata.append("mmfSearch", this.props.cData.refacctnbr);
			bodyFormdata.append("balanceProdFlag", "LOOKUP");
			bodyFormdata.append("selectedProdName", this.props.cData.subprodname);
			bodyFormdata.append("currentBal", this.props.cData.currentBal);
			bodyFormdata.append("acctStatus", this.props.cData.acctStatus);
			bodyFormdata.append("acctnature", this.props.cData.acctnature);
			bodyFormdata.append("product", this.props.cData.prodid);
			bodyFormdata.append("currency", this.props.cData.currency);
			bodyFormdata.append("chkStatus", "Y");
			bodyFormdata.append("cutOffTime", this.props.cData.cutOffTime);
			bodyFormdata.append("ddaAcctDescr", this.props.cData.settleacctname);
			bodyFormdata.append("cutOffFlag", this.props.cData.cutOffFlag);
			bodyFormdata.append("fundAcct", this.props.cData.escrowacctnbr);
			bodyFormdata.append("escrowCheck", "N");
			bodyFormdata.append("socialCode", this.props.cData.socialCode);
			bodyFormdata.append("taxPayerType", this.props.cData.taxPayerType);
			bodyFormdata.append("ddaSettleId", this.props.cData.ddaSettleId);
			bodyFormdata.append("mmfSrch", "Y");
			bodyFormdata.append("lookUpFlag", "YES");
			if(confirm("Are you sure, you want to reject the data?"))
			{
			axios({
				method: 'post',
				url:alertConstants.URL+"/MMMFACCTLOOKUP.do",
				data: bodyFormdata,
				config: { headers: {'Content-Type': 'multipart/form-data' }}
			  }).then((response)=>{
					  revokeData = response.data;
					  this.setState({ updateFlag: true });
					  //alert("successfully revoked::"+revokeData);
					  pageFrom="EDIT";
					  //console.log("response.data===>",revokeData)
					//alert("reject  success block forwarding to lookup screen ");
					this.props.history.push({
						pathname: '/administration/LOOKUP',
						state: {
							fromPage:'ViewChanges',
							fromLink: this.props.location.pathname,
							product: 'ALL',
							issueChild: 'ALL'
						}
					});
			  });

			}
	}

 approveDetails() {
		var bodyFormdata = new FormData();
		var user 		= JSON.parse(sessionStorage.getItem('user'));

			bodyFormdata.append("token",user[0].token);
			if(pageFrom!== undefined && pageFrom === 'MMFREL')
			{
			  bodyFormdata.append("clientFirm",this.props.location.state.ecompanyid);
			}else{
			  bodyFormdata.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
			}
			bodyFormdata.append("processId", this.props.cData.processId);
			//alert("this.props.cData.processId::::"+this.props.cData.processId);
			bodyFormdata.append("investAccount", this.props.cData.acctnbr);
			bodyFormdata.append("selectedProd", this.props.cData.prodid);
			bodyFormdata.append("currencyCode", this.props.cData.currency);
			bodyFormdata.append("actionVal", "");
			bodyFormdata.append("actionFlag", "APPROVE");
			bodyFormdata.append("mmmfAcct", this.props.cData.escrowacctnbr);
			bodyFormdata.append("refFundNbr", this.props.cData.refacctnbr);
			bodyFormdata.append("mmfDesc", this.state.shortname==""?this.props.cData.mmfDesc:this.state.shortname);
			bodyFormdata.append("mmfDescLong", this.state.longname==""?this.props.cData.mmfDescLong:this.state.longname);
			bodyFormdata.append("clientIdentifier", this.state.clientidentifier==""?this.props.cData.clientIdentifier:this.state.clientidentifier);
			bodyFormdata.append("acctStruID", this.props.cData.acctStruID);
			bodyFormdata.append("ddaAcct", this.props.cData.ddaAcct);
			bodyFormdata.append("remarks1",  this.state.remarks);
			bodyFormdata.append("taxidtxt", this.props.cData.taxidtxt);
			bodyFormdata.append("taxId", this.props.cData.taxId);
			bodyFormdata.append("acctlookup", this.props.cData.acctlookup);
			bodyFormdata.append("dividendType", this.props.cData.ddaSettleId);
			bodyFormdata.append("addresstxt", "");
			bodyFormdata.append("dividendAcct", this.props.cData.ddaAcct);
			bodyFormdata.append("redemddaAcct", this.props.cData.redemddaAcct);
			bodyFormdata.append("fundProduct", this.props.cData.fundProduct);
			bodyFormdata.append("mmfSearch", this.props.cData.refacctnbr);
			bodyFormdata.append("balanceProdFlag", "LOOKUP");
			bodyFormdata.append("selectedProdName", this.props.cData.subprodname);
			bodyFormdata.append("currentBal", this.props.cData.currentBal);
			bodyFormdata.append("acctStatus", this.props.cData.acctStatus);
			bodyFormdata.append("acctnature", this.props.cData.acctnature);
			bodyFormdata.append("product", this.props.cData.prodid);
			bodyFormdata.append("currency", this.props.cData.currency);
			bodyFormdata.append("chkStatus", "Y");
			bodyFormdata.append("cutOffTime", this.props.cData.cutOffTime);
			bodyFormdata.append("ddaAcctDescr", this.props.cData.settleacctname);
			bodyFormdata.append("cutOffFlag", this.props.cData.cutOffFlag);
			bodyFormdata.append("fundAcct", this.props.cData.escrowacctnbr);
			bodyFormdata.append("escrowCheck", "N");
			bodyFormdata.append("socialCode", this.props.cData.socialCode);
			bodyFormdata.append("taxPayerType", this.props.cData.taxPayerType);
			bodyFormdata.append("ddaSettleId", this.props.cData.ddaSettleId);
			bodyFormdata.append("mmfSrch", "Y");
			bodyFormdata.append("lookUpFlag", "YES");
			if(confirm("Are you sure, you want to approve the data?"))
			{
			axios({
				method: 'post',
				url:alertConstants.URL+"/MMMFACCTLOOKUP.do",
				data: bodyFormdata,
				config: { headers: {'Content-Type': 'multipart/form-data' }}
			  }).then((response)=>{
					  revokeData = response.data;
					  this.setState({ updateFlag: true });
					  //alert("successfully revoked::"+revokeData);
					  pageFrom="EDIT";
					  //console.log("response.data===>",revokeData)
					//alert("approve success block forwarding to lookup screen ");
					this.props.history.push({
						pathname: '/administration/LOOKUP',
						state: {
							fromPage:'ViewChanges',
							fromLink: this.props.location.pathname,
							product: 'ALL',
							issueChild: 'ALL'
						}
					});
			  });


			}
	}


	doBack(){
	   //alert("clicked back button ... ");
	   pageFrom="MMFREL";
	   this.setState({ updateFlag: false });
	}
	editAcctDetails(){
	   //alert("edit account details ... ");
	   pageFrom="EDIT";
	   this.setState({ updateFlag: false });
	}
    saveDetails() {
		var bodyFormdata = new FormData();
		var user 		= JSON.parse(sessionStorage.getItem('user'));
 		let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
		//alert("acctStatus:::::"+this.props.cData.acctStatus)
		if(this.props.cData.acctStatus == 'Dontallow')
		{
			alert(this.props.cData.mmfDesc + " is " + message["MMFACCT_CHANGES"]);
		}
		else
		{
			bodyFormdata.append("token",user[0].token);

			//alert("22 clientFirm firm "+this.props.cData.clientFirm);
			//alert("11 cleint firm "+this.props.location.state.ecompanyid);
			//alert("333 cleint firm "+sessionStorage.getItem('clientFirm')+",pageFrom:"+pageFrom);

			if(pageFrom!= undefined && pageFrom === 'EDIT')
			{
			  bodyFormdata.append("clientFirm",this.props.cData.clientFirm);
			}else{
			  bodyFormdata.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
			}
			bodyFormdata.append("investAccount", this.props.cData.acctnbr);
			bodyFormdata.append("selectedProd", this.props.cData.prodid);
			bodyFormdata.append("currencyCode", this.props.cData.currency);
			bodyFormdata.append("actionVal", "");
			bodyFormdata.append("actionFlag", "UPDATE");
			bodyFormdata.append("mmmfAcct", this.props.cData.escrowacctnbr);
			bodyFormdata.append("refFundNbr", this.props.cData.refacctnbr);
			bodyFormdata.append("mmfDesc", this.state.shortname==""?this.props.cData.mmfDesc:this.state.shortname);
			bodyFormdata.append("mmfDescLong", this.state.longname==""?this.props.cData.mmfDescLong:this.state.longname);
			bodyFormdata.append("clientIdentifier", this.state.clientidentifier==""?this.props.cData.clientIdentifier:this.state.clientidentifier);
			bodyFormdata.append("acctStruID", this.props.cData.acctStruID);
			bodyFormdata.append("ddaAcct", this.props.cData.ddaAcct);
			bodyFormdata.append("remarks1",  this.state.remarks);
			bodyFormdata.append("taxidtxt", this.props.cData.taxidtxt);
			bodyFormdata.append("taxId", this.props.cData.taxId);
			bodyFormdata.append("acctlookup", this.props.cData.acctlookup);
			bodyFormdata.append("dividendType", this.props.cData.ddaSettleId);
			bodyFormdata.append("addresstxt", "");
			bodyFormdata.append("dividendAcct", this.props.cData.ddaAcct);
			bodyFormdata.append("redemddaAcct", this.props.cData.redemddaAcct);
			bodyFormdata.append("fundProduct", this.props.cData.fundProduct);
			bodyFormdata.append("mmfSearch", this.props.cData.refacctnbr);
			bodyFormdata.append("balanceProdFlag", "LOOKUP");
			bodyFormdata.append("selectedProdName", this.props.cData.subprodname);
			bodyFormdata.append("currentBal", this.props.cData.currentBal);
			bodyFormdata.append("acctStatus", this.props.cData.acctStatus);
			bodyFormdata.append("acctnature", this.props.cData.acctnature);
			bodyFormdata.append("product", this.props.cData.prodid);
			bodyFormdata.append("currency", this.props.cData.currency);
			bodyFormdata.append("chkStatus", "Y");
			bodyFormdata.append("cutOffTime", this.props.cData.cutOffTime);
			bodyFormdata.append("ddaAcctDescr", this.props.cData.settleacctname);
			bodyFormdata.append("cutOffFlag", this.props.cData.cutOffFlag);
			bodyFormdata.append("fundAcct", this.props.cData.escrowacctnbr);
			bodyFormdata.append("escrowCheck", "N");
			bodyFormdata.append("socialCode", this.props.cData.socialCode);
			bodyFormdata.append("taxPayerType", this.props.cData.taxPayerType);
			bodyFormdata.append("ddaSettleId", this.props.cData.ddaSettleId);
			bodyFormdata.append("mmfSrch", "Y");
			bodyFormdata.append("lookUpFlag", "YES");
			pageFrom="EDIT";
			//alert("save details submited successfully ");
			saveFlag = true;
			this.props.dispatch(AdministrationActions.fetchMmfeditAcctData(bodyFormdata));
		   }
	}

    handleChange = name1 => event => {
		//console.log('name1--',name1);
		//console.log('event.target.value--',event.target.value);
        this.setState({ [name1]: event.target.value });
    };
    enterTrade(paramVal,cData) {
		//console.log('In EditAcctDet---->commonData--',commonData);
		if(paramVal == 'TRADEENTRY' || paramVal == 'CLOSEACCOUNT') {
					this.props.history.push({
						pathname: '/DEALENT',
						state: {
							tabIndex: 1,
							activeStep: 1,
							paramVal: paramVal,
							fromPage:'ViewChanges',
							fromLink: this.props.location.pathname,
							bformdata: cData
						}
					});
				} else if(paramVal == 'TRADEHISTORY') {
					this.props.history.push({
						pathname: '/report/TRDINQR',
						state: {
							fromPage:'ViewChanges',
							fromLink: this.props.location.pathname,
							product: 'ALL',
							issueChild: 'ALL'
						}
					});
		}
		//this.props.func(commonData, paramVal);
	}
    componentWillMount(){
        var user = JSON.parse(sessionStorage.getItem('user'));
        var jsonBody = new FormData();
        //console.log('mmmfAcct--mmmfAcct--',this.props.location.state.mmmfAcct);
        jsonBody.append("mmmfAcct", this.props.location.state.mmmfAcct)
        if(this.props.location.state.pageFrom!== undefined && this.props.location.state.pageFrom === 'MMFREL')
        {
                //alert("vallid from mmf relationship reporting screen ");
		jsonBody.append("lookUpFlag", this.props.location.state.lookUpFlag)
		jsonBody.append("acctNbr", this.props.location.state.acctNbr)
		jsonBody.append("prId", this.props.location.state.prId)
		jsonBody.append("subProd", this.props.location.state.subProd)
		jsonBody.append("currency", this.props.location.state.currency)
		jsonBody.append("clientFirm", this.props.location.state.ecompanyid)
		jsonBody.append("clCompanyId", this.props.location.state.ecompanyid)
		jsonBody.append("refFundNbr", this.props.location.state.refFundNbr)
		jsonBody.append("escAcctNbr", this.props.location.state.escAcctNbr)
		jsonBody.append("selectedProd", this.props.location.state.subProd)
		jsonBody.append("currencyCode", this.props.location.state.currency)
		jsonBody.append("investAccount", this.props.location.state.acctNbr);
		jsonBody.append("clientName", this.props.location.state.clientName);
		jsonBody.append("format", 'MMM dd, yyyy');
		jsonBody.append("pageFrom", this.props.location.state.pageFrom);
		pageFrom=this.props.location.state.pageFrom;
        }else{
            jsonBody.append("pageFrom", "EDITACCT");
            pageFrom='EDITACCT';
           //alert("came from other page  ");
        }

        this.props.dispatch(AdministrationActions.fetchMmfeditAcctData(jsonBody));
	}

    render(){
	const { classes } = this.props;
	let { cData } = this.props;
	if(saveFlag!==true)
	    cData1 =cData;

	errMsg="";
	errMsgTxt="";
	let notEnterFlag='true';
	if(cData!==undefined && cData.ErrorDescription!== undefined && cData.ErrorDescription.length>0)
	{
	  errMsg=cData.ErrorDescription;
	  errMsgTxt = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">{errMsg}</div>
	  cData=cData1;
	}
	const { data } = this.props;

        //alert("in render block cData.Status::"+cData.Status);

		var saveBtn='';
		var cancelBtn='';
		var revokeBtn='';

		var approveBtn='';
		var rejectBtn='';
		var disptbody='';
		var DividendType = [];
		var DividendAcct = [];
		//console.log("mar 25, 2019 cData:::",cData);
		//console.log("mar 25, 2019 cData1:::",cData1);
		//console.log("mar 25, 2019 data:::",data);
		if(cData != undefined && cData.toString().length > 0)
		{
		//alert("in cdata block ... ");

		if(pageFrom!== undefined && pageFrom === 'MMFREL')
		{
		 //checkerFlag

		 titleBlk="";
		 descrBlk="";
		 acctBlk="";
		 taxInfoBlk="";
		 primaryAddrBlk="";
		 stmtMailBlk="";
		 remarkBlk="";
		 backBtn="";
		 approveBtn="";
		 rejectBtn="";

		 if(cData.checkerFlag !== undefined && cData.checkerFlag === 'true')
		 {
		 	approveBtn=<button onClick={e => this.approveDetails()} className="btn btn-primary btn-xs mt pull-right">Approve</button>
		 	rejectBtn=<button onClick={e => this.rejectDetails()} className="btn btn-primary btn-xs mt pull-right">Reject</button>
		 }

				//alert("in mmfrel block ");
 				    let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

					if(this.state.alertmsg) {
						alertdiv = <Grid container spacing={24}>
								<Grid item xs={12}>
									<Paper className={classes.paper}>{message["RECTIFY_PROCEED"]}<br/>{message["CLOSEBALAM"]}</Paper>
								</Grid>
							</Grid>
					}

					thirdBtn	= <button onClick={e => this.enterTrade('TRADEHISTORY',cData)} className="btn btn-primary btn-xs mt pull-right">Trade History</button>
					if(cData.fundAcctStatus !== undefined && cData.fundAcctStatus !== 'D')
					{
					  editBtn		= <button onClick={e => this.editAcctDetails()} className="btn btn-primary btn-xs mt">Edit Account Details</button>
					}else{
					  editBtn ="";
					}
					if(cData.Status!== undefined && cData.Status!== 'Waiting for Approval'){
					  //alert("showing edit account details");
					  firstBtn	= <button onClick={e => this.enterTrade('TRADEENTRY',cData)} className="btn btn-primary btn-xs mt pull-right">Enter Trade</button>
					  secondBtn	= <button onClick={e => this.enterTrade('CLOSEACCOUNT',cData)} className="btn btn-primary btn-xs mt pull-right">Close this account</button>
					}else{
					  firstBtn="";
					  secondBtn="";
					}

					disptbody =
					<div>
					<table className="table table-striped table-bordered" width="100%">
					<tbody>
					<tr>
					<td style={{ background: '#cccccc'}}>
					<label> &nbsp; &nbsp; Account Number: </label>
					<label className="TxtNrml"> {cData['refacctnbr']} </label>

					</td>
					<td style={{ background: '#cccccc'}}>
					<label> Status: </label>
					<label className="TxtNrml"> {cData.Status} </label>
					</td>
					<td style={{ background: '#cccccc'}}>
					<label>  Creation Date: </label>
					<label className="TxtNrml"> {cData.acctOpened} </label>
					</td>
					</tr>
						</tbody>
					</table>
					<div className="panel panel-primary clearfix" >
						<div className="panel-heading"><h4 className="panel-title">Description </h4></div>
					<div className="panel-body">
					<table className="table table-striped table-bordered" width="100%">

					<tbody>


					<tr>
					      <td>
						  <label> Short Name : </label>
						  <label className="TxtNrml"> {cData['Short Name']} </label>
					      </td>
					      <td>
						  <label> Long Name : </label>
						  <label className="TxtNrml"> {cData['Long Name']} </label>
					      </td>
					      <td>
						  <label> Client Identifier: </label>
						  <label className="TxtNrml"> {cData['Client Identifier']} </label>
					      </td>
					</tr>
								</tbody>
								</table>
							</div>
							</div>
							<div className="panel panel-primary clearfix" >
						<div className="panel-heading"><h4 className="panel-title">Accounts & Dividend Options </h4></div>
					<div className="panel-body">
								<table className="table table-striped table-bordered" width="100%">

					<tbody>
					<tr>
					      <td>
						  <label> Investment Account : </label>
						  <label className="TxtNrml"> {cData['Investment Account']} </label>
					      </td>
					      <td>
						  <label> Account Structure : </label>
						  <label className="TxtNrml"> {cData['Account Structure']} </label>
					      </td>
					      <td>
						  <label> Subscription DDA Number: </label>
						  <label className="TxtNrml"> {cData['Subscription DDA Number']} </label>
					      </td>
					</tr>
					<tr>
						      <td>
							  <label> Settle Type : </label>
							  <label className="TxtNrml"> {cData.dvndStleType} </label>
						      </td>
						      <td>
							  <label> Dividend Account: </label>
							  <label className="TxtNrml"> {cData['Dividend Account']} </label>
						      </td>
						      <td>
							  <label> Dividend Type  : </label>
							  <label className="TxtNrml"> {cData['Dividend Type']} </label>
						      </td>
					</tr>
								</tbody>
								</table>
								</div>
								</div>
								<div className="panel panel-primary clearfix" >
						<div className="panel-heading"><h4 className="panel-title">Tax Information  </h4></div>
					<div className="panel-body">
								<table className="table table-striped table-bordered" width="100%">

					<tbody>
									<tr>
						      <td>
							  <label> Tax ID  : </label>
							  <label className="TxtNrml"> {cData['Tax ID']} </label>
						      </td>
						      <td>
							  <label> Taxpayer Type : </label>
							  <label className="TxtNrml"> {cData['Taxpayer Type']} </label>
						      </td>
						      <td>
							  <label> Acc Social Code : </label>
							  <label className="TxtNrml"> {cData['Acc Social Code']} </label>
						      </td>
					</tr>
									<tr>

						      <td colSpan="3">
							  <label> FATCA Compliant  : </label>
							  <label className="TxtNrml"> {cData['FATCA Compliant']} </label>
						      </td>
					</tr>
									</tbody>
								</table>
								</div>
								</div>
								<div className="panel panel-primary clearfix" >
						<div className="panel-heading"><h4 className="panel-title">Primary Legal Address  </h4></div>
					<div className="panel-body">
								<table className="table table-striped table-bordered" width="100%">

					<tbody>
									<tr>
						      <td>
							  <label> Company Name : </label>
							  <label className="TxtNrml"> {cData['Company Name']} </label>
						      </td>
						      <td>
							  <label> City : </label>
							  <label className="TxtNrml"> {cData['City']} </label>
						      </td>
						      <td>
							  <label> Zip  : </label>
							  <label className="TxtNrml"> {cData['Zip']} </label>
						      </td>
					</tr>
									<tr>
						      <td>
							  <label> Address : </label>
							  <label className="TxtNrml"> {cData['Address']} </label>
						      </td>
						      <td>
							  <label> State : </label>
							  <label className="TxtNrml"> {cData['State']} </label>
						      </td>
						      <td>
							  <label> Country  : </label>
							  <label className="TxtNrml"> {cData['Country']} </label>
						      </td>
					</tr>
									</tbody>
								</table>
								</div>
								</div>
								<div className="panel panel-primary clearfix" >
						<div className="panel-heading"><h4 className="panel-title">Statement Mailing Address  </h4></div>
					<div className="panel-body">
								<table className="table table-striped table-bordered" width="100%">

					<tbody>
									<tr>
						      <td>
							  <label> Company Name : </label>
							  <label className="TxtNrml"> {cData['Company Name']} </label>
						      </td>
						      <td>
							  <label> City : </label>
							  <label className="TxtNrml"> {cData['City']} </label>
						      </td>
						      <td>
							  <label> Zip  : </label>
							  <label className="TxtNrml"> {cData['Zip']} </label>
						      </td>
					</tr>
									<tr>
						      <td>
							  <label> Address : </label>
							  <label className="TxtNrml"> {cData['Address']} </label>
						      </td>
						      <td>
							  <label> State : </label>
							  <label className="TxtNrml"> {cData['State']} </label>
						      </td>
						      <td>
							  <label> Country  : </label>
							  <label className="TxtNrml"> {cData['Country']} </label>
						      </td>
					</tr>
									</tbody>
								</table>
								</div>
								</div>
								<div className="panel panel-primary clearfix" >
						<div className="panel-heading"><h4 className="panel-title">Remarks </h4></div>
					<div className="panel-body">
								<table className="table table-striped table-bordered" width="100%">

					<tbody>
									<tr>
						      <td colSpan="3">
							  <label> Remarks  : </label>
							  <label className="TxtNrml"> {cData['Remarks']} </label>
						      </td>
					</tr>
					</tbody>
					</table>
					</div>
					</div>
					</div>

		       }
		else {
			firstBtn="";
			secondBtn="";
			thirdBtn="";
			editBtn="";
			backBtn="";
			titleBlk="";

			if(cData.dividendType != undefined)
				DividendType	= cData.dividendType;

			if(cData.dividendAcct != undefined)
				DividendAcct	= cData.dividendAcct;



			if(cData.makerFlag !== undefined && cData.makerFlag === 'true')
			{
			  revokeBtn=<button onClick={e => this.revokeDetails()} className="btn btn-primary btn-xs mt pull-right">Revoke</button>
			  saveBtn=<button onClick={e => this.saveDetails()} className="btn btn-primary btn-xs mt pull-right">Save</button>
			  cancelBtn=<button onClick={e => this.cancelDetails()} className="btn btn-primary btn-xs mt pull-right">Cancel</button>
			  backBtn=<button onClick={e => this.doBack()} className="btn btn-primary btn-xs mt pull-right">Back</button>
			  notEnterFlag='false';
			}
			if(cData.saveBtn !== undefined && cData.saveBtn === 'true' && notEnterFlag=== 'true')
			{
			  //alert("cData.saveBtn::"+cData.saveBtn);
			  saveBtn=<button onClick={e => this.saveDetails()} className="btn btn-primary btn-xs mt pull-right">Save</button>
			  cancelBtn=<button onClick={e => this.cancelDetails()} className="btn btn-primary btn-xs mt pull-right">Cancel</button>
			  titleBlk = <h5 style={{fontWeight:'bold'}}>&nbsp;&nbsp; Edit Account Details &nbsp;&nbsp;{errMsgTxt} </h5>
			  backBtn=<button onClick={e => this.doBack()} className="btn btn-primary btn-xs mt pull-right">Back</button>
			}

			if(cData.Status !== undefined && cData.Status.length!==0)
			{
			  msg = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "right", }}  className="col-md-12 col-sm-12">{(cData.Status === "Active")?"":cData.Status}</div>
			}

			descrBlk=<ExpansionPanel defaultExpanded>
                        <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                        	<Typography className={classes.heading}><b>Description</b><br/></Typography>
                        </ExpansionPanelSummary>

                        <ExpansionPanelDetails>

							<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel required className={classes.labelStyle}>Short Name:</InputLabel>
									<TextField
										ref="refshortname"
										inputProps={{
											maxLength: 19,
										}}
										className={classes.inputStyle}
										value={this.state.value}
										defaultValue={ cData.mmfDesc }
										onChange={this.handleChange('shortname')} />
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Long Name:</InputLabel>
									<TextField
										ref="reflongname"
										inputProps={{
											maxLength: 19,
										}}
										className={classes.inputStyle}
										value= { this.state.value }
										defaultValue={ cData.mmfDescLong }
										onChange={this.handleChange('longname')}  />
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Client Identifier:</InputLabel>
									<TextField
										ref="refclientIdentifier"
										inputProps={{
											maxLength: 19,
										}}
										className={classes.inputStyle}
										value= { this.state.value }
										defaultValue={ cData.clientIdentifier }
										onChange={this.handleChange('clientidentifier')} />
								</Grid>
							</Grid>

                        </ExpansionPanelDetails>
                    </ExpansionPanel>

	acctBlk= <ExpansionPanel>
                        <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                        	<Typography className={classes.heading}><b>Accounts & Dividend Options</b></Typography>
                        </ExpansionPanelSummary>

                        <ExpansionPanelDetails>

							<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Investment Account:</InputLabel>
									<InputLabel className="TextNrml">{ cData.txtInv }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Account Structure:</InputLabel>
									<InputLabel className="TextNrml">{ cData.acctStruName }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Fund Account:</InputLabel>
									<InputLabel className="TextNrml">{ cData.ddaNumber }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Settlement Type:</InputLabel>
									<InputLabel className="TextNrml">{ cData.dvndStleType }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Dividend Account:</InputLabel>
									<TextField
										id="standard-select-dividentAcct-native"
										ref="dividentAcct"
										select
										disabled
										className={classes.textField}
										value={this.state.value}
										defaultValue={cData.ddaAcct}
										onChange={this.handleChange('dividentAcct')}
										SelectProps={{
											native: true,
											MenuProps: {
												className: classes.menu,
											},
										}}

										margin="normal" >
										{DividendAcct && DividendAcct.map(option => (
											<option key={option.key} value={option.key}>
												{option.value}
											</option>
										))}
									</TextField>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Dividend Type:</InputLabel>
									<TextField
										id="standard-select-dividentType-native"
										ref="dividentType"
										select
										disabled
										className={classes.textField}
										value={this.state.value}
										defaultValue={cData.ddaSettleId}
										onChange={this.handleChange('dividentType')}
										SelectProps={{
											native: true,
											MenuProps: {
												className: classes.menu,
											},
										}}

										margin="normal" >
										{DividendType && DividendType.map(option => (
											<option key={option.key} value={option.key}>
												{option.value}
											</option>
										))}
									</TextField>
								</Grid>
							</Grid>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>

 taxInfoBlk=<ExpansionPanel>
                        <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                        	<Typography className={classes.heading}><b>Tax Information</b></Typography>
                        </ExpansionPanelSummary>

                        <ExpansionPanelDetails>
							<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Tax ID:</InputLabel>
									<InputLabel className="TextNrml">{ cData.taxId }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Taxpayer Type:</InputLabel>
									<InputLabel className="TextNrml">{ cData.taxPayerType1 }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Acc Social Code:</InputLabel>
									<InputLabel className="TextNrml">{ cData.socialCodeDesc }</InputLabel>
								</Grid>
							</Grid>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>


 primaryAddrBlk= <ExpansionPanel>
                        <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                        	<Typography className={classes.heading}><b>Primary Legal Address (not editable)</b></Typography>
                        </ExpansionPanelSummary>

                        <ExpansionPanelDetails>
                        	<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Company Name:</InputLabel>
									<InputLabel className="TextNrml">{ cData.legalComp }</InputLabel>
								</Grid>
								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>City:</InputLabel>
									<InputLabel className="TextNrml">{ cData.legalCity }</InputLabel>
								</Grid>
								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Zip:</InputLabel>
									<InputLabel className="TextNrml">{ cData.legalZip }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Address:</InputLabel>
									<InputLabel className="TextNrml">{ cData.legalAddr1 }</InputLabel>
								</Grid>
								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>State:</InputLabel>
									<InputLabel className="TextNrml">{ cData.legalStateDesc }</InputLabel>
								</Grid>
								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Country:</InputLabel>
									<InputLabel className="TextNrml">{ cData.legalCountryDesc }</InputLabel>
								</Grid>
							</Grid>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>

			stmtMailBlk= <ExpansionPanel>
                        <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                        	<Typography className={classes.heading}><b>Statement Mailing Address (not editable)</b></Typography>
                        </ExpansionPanelSummary>

                        <ExpansionPanelDetails>
                        	<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Company Name:</InputLabel>
									<InputLabel className="TextNrml">{ cData.stmtComp }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>City:</InputLabel>
									<InputLabel className="TextNrml">{ cData.stmtCity }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Zip:</InputLabel>
									<InputLabel className="TextNrml">{ cData.stmtZip }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Address:</InputLabel>
									<InputLabel className="TextNrml">{ cData.stmtZip }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>State:</InputLabel>
									<InputLabel className="TextNrml">{ cData.stmtStateDesc }</InputLabel>
								</Grid>

								<Grid item xs={4}>
									<InputLabel className={classes.labelStyle}>Country:</InputLabel>
									<InputLabel className="TextNrml">{ cData.stmtCountryDesc }</InputLabel>
								</Grid>
							</Grid>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>


			remarkBlk=<ExpansionPanel>
                        <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                        	<Typography className={classes.heading}><b>Remarks</b></Typography>
                        </ExpansionPanelSummary>

                        <ExpansionPanelDetails>
                        	<Typography>
                        	    <InputLabel className={classes.labelStyle}>Remarks:</InputLabel>
                        	    <TextField
                        	        multiline
                        	        rows="4"
                        	        className={classes.textField}
                        	        onChange={this.handleChange('remarks')}
                        	        value={this.state.value}
                        	        defaultValue={cData.Remarks}
                        	        margin="normal" />
                        	</Typography>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>
}

            return  (
                <div className={classes.root}>
					<NavBar/>
					<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
					<div style={{clear:'both'}}></div>
					<div style={{ color: 'red', textAlignVertical: "center",textAlign: "right", }}  className="col-md-12 col-sm-12">{ cData.reactMonthMsg }</div>
					<div style={{clear:'both'}}></div>
					{titleBlk}
                    <h5 style={{fontWeight:'bold'}}>&nbsp;&nbsp;&nbsp;&nbsp; { cData.mmfDesc } (&nbsp;{cData.refacctnbr}&nbsp;) {editBtn} {thirdBtn}{secondBtn}{firstBtn} </h5>
					{disptbody}
					<div style={{clear:'both'}}></div>
		    		{descrBlk}
                    {acctBlk}
		    		{taxInfoBlk}
                    {primaryAddrBlk}
		    		{stmtMailBlk}
                    {remarkBlk}
                    <div style={{textAlign:'center',padding: '2px 15px'}}>
						{msg}
						{backBtn}
						{cancelBtn}
						{saveBtn}
						{revokeBtn}
						{approveBtn}
						{rejectBtn}
                    </div>
										</MuiThemeProvider>
                </div>
			)
		}
		else
		{
		return (

                <div><Loading/>{msg}</div>
			)
		}
    }

}
EditAcctDet.propTypes = {
    classes: PropTypes.object.isRequired,
};

 function mapStateToProps(state) {
    const { mmfeditAcctDet } = state;
    let cData = [];

    if(mmfeditAcctDet != undefined ) {
		 if(mmfeditAcctDet.mmfeditAcctDet != undefined ) {
    	    cData   = mmfeditAcctDet.mmfeditAcctDet.commonData;
    	    //console.log("mar 25, 2019 cData1111::",cData);
		}
    }

    return { cData };
}

const connectedEditAcctDet = connect(mapStateToProps)(withStyles(MuiStyles)(EditAcctDet));
export { connectedEditAcctDet as EditAcctDet };