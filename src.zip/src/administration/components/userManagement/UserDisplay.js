import React from "react";
import { render } from "react-dom";
import Paper from "@material-ui/core/Paper";
import { RowDetailState, DataTypeProvider } from "@devexpress/dx-react-grid";
import {
  Grid,
  Table,
  TableHeaderRow,
  TableRowDetail
} from "@devexpress/dx-react-grid-material-ui";
import { createMuiTheme, withStyles,MuiThemeProvider} from '@material-ui/core/styles';


const styles = theme => ({

	  typography: {
	        useNextVariants: false,
    },
    paper: {
	      padding: theme.spacing.unit * 1,
	      textAlign: 'center',
	      color: theme.palette.text.secondary,
	      backgroundColor:'#fff',
  },
	  MuiPaperRounded: {
	     borderRadius: 0,
	},

	readonly: {
	    border: '1px solid #cccccc',
	    backgroundColor: '#afb1b0',
	     padding: theme.spacing.unit * 1, textAlign: 'center',
	},
	selected: {
		    border: '1px solid #cccccc',
		    backgroundColor: '#e2f0fd',
		     padding: theme.spacing.unit * 1, textAlign: 'center',
	}
});

class UserDisplay extends React.PureComponent {
	  getMuiTheme = () => createMuiTheme({
		 		  typography: {
		 							useNextVariants: true,
		 	 			 },
		 	    overrides: {
		 			   MuiPaperRounded: {
					  	     borderRadius: 0,
						},
						MuiPaperRoot: {
						   backgroundColor:'#afb1b0',
						}
						, TableNoDataCell: {
							cell: {
							   textAlign: 'center',
							}
						}
		 	    }
	   })

  constructor(props) {
    super(props);

    this.state = {
	selectedUser:'',
      columns: [
        { name: "name", title: "DESCR" }
       ],
      rows: [
        { isExpand: true, name: "" }
      ]
    };
    this.getUserLinksPerm=this.getUserLinksPerm.bind(this)
  }
  getUserLinksPerm(linkDet){

	//   console.log('getUserLinksPerm')
		 this.setState({selectedUser:linkDet.LOGINID});
 		 this.props.handleUserLinksPerm(linkDet);
     }
  render() {
	  const { classes } = this.props;
    const { rows, columns, booleanColumns } = this.state;
	const RowDetail = ({ row }) => {

	if(row.VIEWLNKGRPLST.length>0){
			return row.VIEWLNKGRPLST.map((linkDet,index) => {
			const rowDet= Object.assign({ENCLINKGROUPID:row.ENCLINKGROUPID,tabName:this.props.params.tabName}, linkDet);

			return(
			  <Paper key={index} className={rowDet.STATUS === "P" ?(classes.readonly):((rowDet.LOGINID === this.state.selectedUser)?classes.selected:classes.paper) }>
				<a key={index} href="javaScript:void(0)"  onClick={(ev)=>{
				 //	console.log(rowDet.LOGINID)
					this.getUserLinksPerm(rowDet)}}  >{rowDet.LOGINNAME}</a>
			  </Paper>
			)

			});
			}else {
					return(	 <Paper key={0} className={classes.paper }>
										(Empty)
						  </Paper>)
		}
		}



const ToggleCellComponent = ({ row, ...restProps }) => {
  if (row.isExpand)
    return <TableRowDetail.ToggleCell row={row} {...restProps} />;
  return (
    <TableRowDetail.ToggleCell
      style={{
        pointerEvents: "none",
        opacity: 0.5
      }}
    />
  );
};

let finalData=[];
const { linksdata,params } = this.props;


 //console.log('params :'+JSON.stringify(params));
    return (
		 <MuiThemeProvider theme={this.getMuiTheme()}>
      <Paper>
        <Grid rows={linksdata} columns={columns}>
          <RowDetailState />
          <Table />
          <TableHeaderRow />
          <TableRowDetail
            contentComponent={RowDetail}
            toggleCellComponent={ToggleCellComponent}
          />
        </Grid>
      </Paper>
      </MuiThemeProvider>
    );
  }
}

export default  (withStyles(styles) (UserDisplay));