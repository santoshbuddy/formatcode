import React from 'react';
import Button from '@material-ui/core/Button';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import GrpUserAssocViewChanges from './GrpUserAssocViewChanges';
import FromData from 'form-data';
import { AdministrationActions } from '../../actions/administration.actions';
import { connect } from 'react-redux';


class UserNameApproval extends React.Component {
 constructor(props) {
	    super(props);
	    this.state = {
   	}
    };
doUserApprove = (processId,linkGroupId) => {
 		this.props.doUserApprove(processId,linkGroupId);
 }

doUserReject = (processId) => {
 		this.props.doUserReject(processId);
 }
 componentWillMount() {


			 var bodyFormData = new FromData();
			bodyFormData.append("grpName",this.props.groupDetails.DESCR);
			bodyFormData.append("userFlag",'SHOW');
			bodyFormData.append("addFlag",'');
			bodyFormData.append("userProcessId",this.props.userDetails.PROCESSID);
			bodyFormData.append("userCreatedBy",this.props.userDetails.CREATEDBY);
			bodyFormData.append("loginId",this.props.userDetails.LOGINID);
			bodyFormData.append("selLinkGrpId",this.props.userDetails.LINKGROUPID);



		   this.props.dispatch(AdministrationActions.fetchUserApprovalData(bodyFormData));

 }

 componentDidUpdate(prevProps) {
    if (this.props.userDetails.LOGINID &&  (prevProps == null) || (prevProps && this.props.userDetails.LOGINID !== prevProps.userDetails.LOGINID)) {
 				 var bodyFormData = new FromData();


					 var bodyFormData = new FromData();
					bodyFormData.append("grpName",this.props.groupDetails.DESCR);
					bodyFormData.append("userFlag",'SHOW');
					bodyFormData.append("addFlag",'');
					bodyFormData.append("userProcessId",this.props.userDetails.PROCESSID);
					bodyFormData.append("userCreatedBy",this.props.userDetails.CREATEDBY);
					bodyFormData.append("loginId",this.props.userDetails.LOGINID);
					bodyFormData.append("selLinkGrpId",this.props.userDetails.LINKGROUPID);

				  this.props.dispatch(AdministrationActions.fetchUserApprovalData(bodyFormData));

}
}
  render() {
          let sourceGrpdet ={};
         	if(this.props.groupDetails && this.props.userDetails && this.props.selecteduserDetails){
     return (
      <div style={{marginTop:'20px',}}>

		   <h4>User Name Approval
		</h4>
		 <h6>User : {this.props.userDetails.LOGINNAME}
		</h6>
           <Paper style={{marginTop:'20px',}}>

		<Table style={{widht:'50%' ,float:'left'}}>
		<TableHead>
		</TableHead>
			<TableBody>
				<TableRow style={{height:'auto',}}>
					<TableCell>Old Group Name</TableCell>

					<TableCell >New Group Name</TableCell>
 				</TableRow>

				<TableRow style={{height:'auto',}}>
 					<TableCell>{this.props.selecteduserDetails?this.props.selecteduserDetails.OLDGRP:''}</TableCell>

 					<TableCell >{this.props.selecteduserDetails?this.props.selecteduserDetails.NEWGRP:''}</TableCell>
				</TableRow>


			</TableBody>
		</Table>
			<div style={{float:'right',marginTop:'10px'}} ><GrpUserAssocViewChanges open={true}
			params={this.props.params}
				   						loginId={this.props.userDetails?this.props.userDetails.LOGINID:''}
				   						doUserApprove={this.doUserApprove} doUserReject={this.doUserReject}
			  /></div>
 			 </Paper>
         </div>
    );
	}else {
		return null;

	}
  }
}
function mapStateToProps(state) {
    const { userapprovaldata } = state;
    let changesVec =[];
let params= null;
	let selecteduserDetails={};
			let results=[];
 			let results1  =  userapprovaldata.userapprovaldata;

 		 //    console.log('UserNameApproval : results1'+JSON.stringify( results1));

			let screenName="";
 	        if( results1 !==  undefined && results1.length>0)
	             results1.map((item,index) => {

		//			 console.log('item.type '+item.type);
    			if(item.type === "Title")
                 screenName = item.name


 	                if(item.name === "userDetails" && item.values){
	                 	results = item.values
						 results.map(row => {
						 selecteduserDetails=row;

						})
					}
				if(item.name === "Params" && item.values.length>0)
				params = item.values[0]

	            });

 console.log('params : results1'+JSON.stringify( params));
    return { userapprovaldata ,selecteduserDetails,params};
}

 export default connect(mapStateToProps)(UserNameApproval)  ;



