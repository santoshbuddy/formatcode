import React, { Component } from 'react';
import update from 'react-addons-update';
import User from './User';
 import { DropTarget } from 'react-dnd';
const readOnlystyle ={
 	    backgroundColor: '#afb1b0',
	    border: '1px dashed #cccccc',
		padding: '0.5rem 1rem',
		margin: '.5rem',
  	};
const normalstyle ={
 	    backgroundColor: '#fff',
	    border: '1px dashed #cccccc',
		padding: '0.5rem 1rem',
		margin: '.5rem',
  	};
  	const selected ={
			    border: '1px solid #cccccc',
			    backgroundColor: '#e2f0fd',
			     padding:  '0.5rem 1rem',
			     margin: '.5rem',
	}

class Container extends Component {

	constructor(props) {
		super(props);
		this.state = {users: props.list ,group:props.group,groups:props.groups };
 	}
 onClickUser =(user,group,groups)=>{
	 this.props.onClickUser(user,group,groups);

 }
	pushUser(user) {

			if(this.state.group && this.state.group.ACTION=="N"){
				alert("User cannot be moved to a new group waiting for approval");
			}else{
				if(user.PROCESSID !== ""){
					alert("Pending user cannot be moved ");
				}else if(confirm('Are you sure, you want to add the user?')){
					this.setState(update(this.state, {
						users: {
							$push: [ user ]
						}
					}));
 				 this.props.addmarked(user,this.state.group);
				}
		}
	}

	removeUser(index) {

			this.setState(update(this.state, {
			users: {
				$splice: [
					[index, 1]
				]
			}
		}));

	}

	moveUser(dragIndex, hoverIndex) {
		const { users } = this.state;
		const dragUser = users[dragIndex];

		this.setState(update(this.state, {
			users: {
				$splice: [
					[dragIndex, 1],
					[hoverIndex, 0, dragUser]
				]
			}
		}));
	}

	render() {
 		const { users } = this.state;
		const { canDrop, isOver, connectDropTarget } = this.props;
		const isActive = canDrop && isOver;
		const style = {
			width: "200px",
			height: "404px",
			border: '1px dashed gray'
		};
 		const backgroundColor = isActive ? '#337ab7' : '#FFF';

		return connectDropTarget(
			<div style={{ backgroundColor}}>
				{users && users.map((user, i) => {
					return ( (user.PROCESSID !== "")?
							<div   style={(this.props.tabName==='VIEWALL'?readOnlystyle:((this.props.selecteduser === user.LOGINID)?selected:normalstyle))} key={user.LOGINID}>
							 {((this.props.tabName !== 'VIEWALL')?
									        <a href="javascript:void(0);" onClick={ev => {
												//console.log('event fired');
												 this.onClickUser(user,this.props.group,this.props.groups)
												}
												}>{user.LOGINNAME} </a>
									       :<a href="javascript:void(0);" > {user.LOGINNAME} </a>
       								 )}
							</div>
							: <User
														key={user.LOGINID}
														index={i}
														listId={this.props.id}
														user={user}
														removeUser={this.removeUser.bind(this)}
							moveUser={this.moveUser.bind(this)} />
					);
				})}
			</div>
		);
  }
}

const userTarget = {
	drop(props, monitor, component ) {
		const { id } = props;
		const sourceObj = monitor.getItem();
		if ( id !== sourceObj.listId ) component.pushUser(sourceObj.user);
		return {
			listId: id
		};
	}
}

export default DropTarget("CARD", userTarget, (connect, monitor) => ({
	connectDropTarget: connect.dropTarget(),
	isOver: monitor.isOver(),
	canDrop: monitor.canDrop()
}))(Container);