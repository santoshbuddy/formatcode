import * as React from 'react';
import Paper from '@material-ui/core/Paper';
import {
  SelectionState,
  IntegratedSelection,
  TreeDataState,
  CustomTreeData,
} from '@devexpress/dx-react-grid';
import {
  Grid,
  Table,
  TableHeaderRow,
  TableTreeColumn,TableEditColumn,CheckboxProps,
} from '@devexpress/dx-react-grid-material-ui';

import TextField from '@material-ui/core/TextField';


import { connect } from 'react-redux';
import { AdministrationActions } from '../../actions/administration.actions';
import Button from '@material-ui/core/Button';
import { createMuiTheme, withStyles,MuiThemeProvider} from '@material-ui/core/styles';
import RFPSnackbars from '../../../messages/RFPSnackbars';
import Typography from '@material-ui/core/Typography';
import LinearProgress from '@material-ui/core/LinearProgress';
import UserGroupsMgmtViewChanges from './UserGroupsMgmtViewChanges';
import Checkbox from '@material-ui/core/Checkbox';
import {IsCharsInBag} from '../../../common/amountValidations';
let viewChangesbtn=false;
let linkOperations=[];
let loading=true;


const styles = theme => ({

  textField: {
      marginLeft: theme.spacing.unit,
      marginRight: theme.spacing.unit,
      width: 200,
  },
   formControl: {
  		    marginTop: 0,
  		    minWidth: 120,
  		     fontSize: 11,
  		  },
  		  formControlLabel: {
  		    marginTop: 0,
  		     fontSize: 11,
    		},
  	  button: {
  	    margin: theme.spacing.unit,
  	     fontSize: 11,
	  },
	  typography: {
	        useNextVariants: false,
    },
    paper: {
	      padding: theme.spacing.unit * 2,
	      textAlign: 'center',
	      color: theme.palette.text.secondary,
  },
	  MuiPaperRounded: {
	     borderRadius: 0,
	},
});


const getChildRows = (row, rootRows) => {
  const childRows = rootRows.filter(r => r.parentId === (row ? row.id : null));
  return childRows.length ? childRows : null;
};

 function arrayRemove(arr, value) {

	   return arr.filter(function(ele){
	       return ele != value;
	   });

}

 class GroupUserLinksPerm extends React.PureComponent {

	  getMuiTheme = () => createMuiTheme({
	 		  typography: {
	 							useNextVariants: true,
	 	 			 },
	 	    overrides: {
	 			 MuiFormControl: {
	 					  	        marginNormal: {
	 					   	           marginTop: '0px',
	 					   	            marginBottom: '0px',
	 					   	        }
	 	      }, MuiIconButton: {
	 					  	        root: {
	 					   	           padding: '2px',
	 					   	        }
	 	      }, MuiTableCell: {
	 					  	        root: {
	 					   	           padding: '0px',
	 					   	        }
	 	      }, MuiPrivateSwitchBase: {
	 					  	        root: {
	 					   	           padding: '0px',
	 					   	           minHeight:'100%'
	 					   	        }
	 	      },MuiTableRow:{root: {
				  height:'25px',}
			  },MuiSvgIcon:{root: {
				  height:'0.75em', }
			  },
	 	      MUIDataTableBodyCell: {
	 	        root: {
	  	           whiteSpace: 'nowrap',
	  	           padding:'0px 56px 0px 24px'
	  	        }
	 	      },
	 	      MUIDataTableBodyRow: {
	 		  	        root: {
	 		   	           height: '20px',
	 		   	        }
	 	      },
	 	    }
	   })


  constructor(props) {
    super(props);

    this.state = {
	completed: 0,
    buffer: 10,
      groupName:this.props.userLinksPermDet?this.props.userLinksPermDet.DESCR:"",
	  userLinksPermDet: this.props?this.props.userLinksPermDet:null,
	  selection: [],
	  operationPerms:{},
  	   selectedLinks: [],
	   tabName:this.props.tabName=== ""?"VIEWALL":this.props.tabName,
      columns: [
        { name: 'name', title: 'Menu' , getCellValue: row =>(this.props.params != null && this.props.params.displayMode === 'disabled'?(<div> <Checkbox onChange={ev => { let linkdet=this.props.selectedLinks.find((item) => item.LINKID === row.linksDet.LINKID);  }  } checked={row.linksDet.MNUCHKD ==='checked'?true:false} value={row.linksDet.LINKID}
         readOnly={row.linksDet.VWONLY !== 'true'?true:false}
          disabled={(this.props.params &&
          (  (this.props.params.displayMode === 'disabled' && row.linksDet.MNUCHKD === 'checked')
			|| (row.linksDet.MNUCHKD !== 'checked')
          	||((!this.state.selection.includes(row.index)))
          	|| (!(this.state.selection.includes(this.props.linkIndexdata[row.parentId]))))
          	?true:false)} />
          <span>{row.linksDet.DESCR}</span></div>):row.linksDet.DESCR)	 },
         { name: 'chkadd', title: 'Add' ,getCellValue: row =>(((row.parentId === null)||(row.linksDet.PARENTOPERVAL === '6' || row.linksDet.PARENTOPERVAL === '2' || row.linksDet.PARENTOPERVAL === '4'))?'': <Checkbox onChange={ev => {
 			  let { operationPerms,selection } = this.state;
  			  if(operationPerms){
					let addperms=operationPerms[row.linksDet.LINKID];
					addperms[1]=  (addperms[1] === 'checked')?'':'checked';
					if(this.props.params.selLnkGrpId !== 'NEW'){
					operationPerms[row.linksDet.LINKID]=addperms;
					 let parentparentlinkdet=this.props.selectedLinks.find((item) => item.LINKID === row.linksDet.PARENTID);
					selection=arrayRemove(selection,this.props.linkIndexdata[parentparentlinkdet.PARENTID]);
					selection=arrayRemove(selection,this.props.linkIndexdata[row.linksDet.PARENTID]);
				 	selection=arrayRemove(selection,this.props.linkIndexdata[row.linksDet.LINKID]);
					this.setState({operationPerms,selection});
					selection.push(this.props.linkIndexdata[parentparentlinkdet.PARENTID]);
				 	selection.push(this.props.linkIndexdata[row.linksDet.PARENTID]);
				 	selection.push(this.props.linkIndexdata[row.linksDet.LINKID]);
					this.setState({operationPerms,selection});
					}else {
						this.setState({operationPerms});
						this.changeSelection(this.state.selection);
					}

 		 	 }
 			 let linkdet=this.props.selectedLinks.find((item) => item.LINKID === row.linksDet.LINKID);
			 linkdet.chkadd=this.props.operVec[0]}

			 }

			 defaultChecked={this.state.operationPerms !== undefined &&
			 this.state.operationPerms[row.linksDet.LINKID] !== undefined &&
			 this.state.operationPerms[row.linksDet.LINKID][1] !== undefined &&
			 this.state.operationPerms[row.linksDet.LINKID][1] ==='checked'?true:false}

			 value={this.props.operVec[0]}  readOnly={row.linksDet.VWONLY !== 'true'?true:false}
			 disabled={(this.props.params && (this.props.params.selLnkGrpId !== 'NEW') &&
			 ((this.props.params.displayMode === 'disabled' && row.linksDet.MNUCHKD === 'checked') ||
			 (row.linksDet.MNUCHKD !== 'checked')|| ((!this.state.selection.includes(row.index))))?
			 ((this.state.tabName === "PENDINGAPR")?true:false):false)} />)	 },
         { name: 'chkmod', title: 'Modify' ,getCellValue: row =>(((row.parentId === null)||(row.linksDet.PARENTOPERVAL === '3' || row.linksDet.PARENTOPERVAL === '1' || row.linksDet.PARENTOPERVAL === '2'))?'': <Checkbox onChange={ev => {
			  let { operationPerms,selection } = this.state;
  			  if(operationPerms){
					let addperms=operationPerms[row.linksDet.LINKID];
					addperms[2]=  (addperms[2] === 'checked')?'':'checked';
					if(this.props.params.selLnkGrpId !== 'NEW'){
					operationPerms[row.linksDet.LINKID]=addperms;
					 let parentparentlinkdet=this.props.selectedLinks.find((item) => item.LINKID === row.linksDet.PARENTID);
					selection=arrayRemove(selection,this.props.linkIndexdata[parentparentlinkdet.PARENTID]);
					selection=arrayRemove(selection,this.props.linkIndexdata[row.linksDet.PARENTID]);
					selection=arrayRemove(selection,this.props.linkIndexdata[row.linksDet.LINKID]);
					this.setState({operationPerms,selection});
					selection.push(this.props.linkIndexdata[parentparentlinkdet.PARENTID]);
					selection.push(this.props.linkIndexdata[row.linksDet.PARENTID]);
					selection.push(this.props.linkIndexdata[row.linksDet.LINKID]);
					this.setState({operationPerms,selection});
					}else {
						this.setState({operationPerms});
						this.changeSelection(this.state.selection);
					}


 		 	 }let linkdet=this.props.selectedLinks.find((item) => item.LINKID === row.linksDet.LINKID); linkdet.chkdel=this.props.operVec[2]}  }
 		 	 defaultChecked={this.state.operationPerms !== undefined && this.state.operationPerms[row.linksDet.LINKID] !== undefined && this.state.operationPerms[row.linksDet.LINKID][2] !== undefined && this.state.operationPerms[row.linksDet.LINKID][2] ==='checked'?true:false}
 		 	 value={this.props.operVec[2]} readOnly={row.linksDet.VWONLY!== 'true'?true:false}
 		 	 disabled={(this.props.params && (this.props.params.selLnkGrpId !== 'NEW') && ((this.props.params.displayMode === 'disabled' && row.linksDet.MNUCHKD === 'checked') || (row.linksDet.MNUCHKD !== 'checked')|| ((!this.state.selection.includes(row.index))))?((this.state.tabName === "PENDINGAPR")?true:false):false)}/>)	},
         { name: 'chkdel', title: 'Delete' ,getCellValue: row =>(((row.parentId === null)||(row.linksDet.PARENTOPERVAL === '5' || row.linksDet.PARENTOPERVAL === '1' || row.linksDet.PARENTOPERVAL === '4'))?'': <Checkbox onChange={ev => {
			 let { operationPerms,selection } = this.state;
  			  if(operationPerms){
					let addperms=operationPerms[row.linksDet.LINKID];
						addperms[3]=  (addperms[3] === 'checked')?'':'checked';
						if(this.props.params.selLnkGrpId !== 'NEW'){
						operationPerms[row.linksDet.LINKID]=addperms;
						 let parentparentlinkdet=this.props.selectedLinks.find((item) => item.LINKID === row.linksDet.PARENTID);
						selection=arrayRemove(selection,this.props.linkIndexdata[parentparentlinkdet.PARENTID]);
						selection=arrayRemove(selection,this.props.linkIndexdata[row.linksDet.PARENTID]);
						selection=arrayRemove(selection,this.props.linkIndexdata[row.linksDet.LINKID]);
						this.setState({operationPerms,selection});
						selection.push(this.props.linkIndexdata[parentparentlinkdet.PARENTID]);
						selection.push(this.props.linkIndexdata[row.linksDet.PARENTID]);
						selection.push(this.props.linkIndexdata[row.linksDet.LINKID]);
						this.setState({operationPerms,selection});
						}else {
							this.setState({operationPerms});
							this.changeSelection(this.state.selection);
						}


 		 	 } let linkdet=this.props.selectedLinks.find((item) => item.LINKID === row.linksDet.LINKID); linkdet.chkdel=this.props.operVec[1]}  } defaultChecked={this.state.operationPerms !== undefined && this.state.operationPerms[row.linksDet.LINKID] !== undefined && this.state.operationPerms[row.linksDet.LINKID][3] !== undefined && this.state.operationPerms[row.linksDet.LINKID][3] ==='checked'?true:false} value={this.props.operVec[1]} readOnly={row.linksDet.VWONLY!== 'true'?true:false} disabled={(this.props.params && (this.props.params.selLnkGrpId !== 'NEW') && ((this.props.params.displayMode === 'disabled' && row.linksDet.MNUCHKD === 'checked') || (row.linksDet.MNUCHKD !== 'checked')|| ((!this.state.selection.includes(row.index))))?((this.state.tabName === "PENDINGAPR")?true:false):false)} />)	},

      ],
      tableColumnExtensions: [
        { columnName: 'name', width: 300 },
      ],
      defaultExpandedRowIds: [0],
      data: [],
      viewChangesbtn:false,
        newgrpflag: false,
     };

    this.changeSelection = (selection) =>{
						//	console.log('selection :'+JSON.stringify(selection));
								let selectionValues= selection;
								this.props.selectedLinks && this.props.selectedLinks.map((link,index)=>{
								if(this.props.linkIndexdata[link.PARENTID] !== undefined && !selectionValues.includes(this.props.linkIndexdata[link.PARENTID])){
 									//console.log('link.id :'+link.id);
 									selectionValues=arrayRemove(selectionValues,link.id);
								}
								});
								//	console.log('selectionValues :'+JSON.stringify(selectionValues));
							 this.setState({ selection:selectionValues}) };

         this.checkboxComponent = () =>{ return  <Checkbox
                            disabled={true}
                            checked={true}
                            indeterminate={false}  />  };

		this.doViewChanges=this.doViewChanges.bind(this);
		this.doSave=this.doSave.bind(this);
		this.doApprove=this.doApprove.bind(this);
		this.doReject=this.doReject.bind(this);
		this.doCancel=this.doCancel.bind(this);
		this.doClose=this.doClose.bind(this);
		this.onGroupNameChange=this.onGroupNameChange.bind(this);

    }

	onGroupNameChange(e) {
		const groupName = e.target.value;
 		this.setState(() => ({ groupName: groupName }));
	}


  		componentWillMount() {
			loading=true;
				var bodyFormdata = new FormData();
			if(this.props.userLinksPermDet){
			bodyFormdata.append("grpName", this.props.userLinksPermDet.DESCR);
			bodyFormdata.append("selLnkGrpId", this.props.userLinksPermDet.LINKGROUPID);
			bodyFormdata.append("addFlag", "SHOW");
 			bodyFormdata.append("tabName", this.props.tabName);
			this.props.dispatch(AdministrationActions.fetchGroupUserLinksPermData(bodyFormdata,''));

		}
			this.timer = setInterval(this.progress, 500);
			this.setState({selection:this.props.prpsselection,groupName:this.props.userLinksPermDet?this.props.userLinksPermDet.DESCR:""});


	  }

      componentDidMount() {
   	  }

	  componentWillUnmount() {
		  loading=true;
	    clearInterval(this.timer);
	  }

	  progress = () => {
	    const { completed } = this.state;
	    if (completed > 100) {
	      this.setState({ completed: 0, buffer: 10 });
	    } else {
	      const diff = Math.random() * 10;
	      const diff2 = Math.random() * 10;
	      this.setState({ completed: completed + diff, buffer: completed + diff + diff2 });
	    }
  };
  doApprove(){
	  			if(confirm("Are you sure, you want to approve the data?"))
		 		{
					var bodyFormdata = new FormData();
	  			if(this.props.params){
	   		  			bodyFormdata.append("processId", this.props.params.processId);
	   		  			bodyFormdata.append("selLnkGrpId", this.props.userLinksPermDet.LINKGROUPID);
	   		  			bodyFormdata.append("userProcessId", "");
	   		  			bodyFormdata.append("actionFlag", "APPROVE");
	   		  			bodyFormdata.append("secondSave", "");
	   		  			bodyFormdata.append("tabName", "PENDINGAPR");
						this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));
 	   		  			this.props.doApproveReject("PENDINGAPR",'Approved');
	   			 }

			 }
  }

  doReject(){
  	  			if(confirm("Are you sure, you want to reject the data?"))
		 		{
					var bodyFormdata = new FormData();
					if(this.props.params){
							bodyFormdata.append("processId", this.props.params.processId);
							bodyFormdata.append("selLnkGrpId", this.props.userLinksPermDet.LINKGROUPID);
							bodyFormdata.append("userProcessId", "");
							bodyFormdata.append("actionFlag", "REJECT");
							bodyFormdata.append("secondSave", "");
							bodyFormdata.append("tabName", "PENDINGAPR");
							this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));
 							this.props.doApproveReject("PENDINGAPR",'Rejected');
					 }
				 }
  }
doSave(){
	const groupName = this.state.groupName
 		if(groupName == '' && groupName.length ==0){
 		alert("1.Group Name : Please enter group name.");

		return false;
		}
	const test = groupName.toUpperCase();
	var isChar = false;
	isChar = IsCharsInBag(test,"ABCDEFGHIJKLMNOPQRSTUVWXYZ");
 		if(!isChar)
		{
		alert("1.Group Name : Please use only alphabets for group name!");

		return false;
		}
//	 console.log('doSave userLinksPermDet:'+JSON.stringify(this.props.userLinksPermDet));
	       		var bodyFormdata = new FormData();
		  			bodyFormdata.append("selLnkGrpId", this.props.userLinksPermDet.LINKGROUPID);
 		  			bodyFormdata.append("grpName", this.state.groupName.toUpperCase());
		  			bodyFormdata.append("logedUserCompany",this.props.userLinksPermDet.COMPANYID);
 		  			bodyFormdata.append("actionFlag", "SAVE");
		  			bodyFormdata.append("addFlag", "SHOW");
		  			if(this.props.params){
 		  			bodyFormdata.append("processId", this.props.params.processId);
 		  			bodyFormdata.append("descr", this.props.params.descr);
 		  			bodyFormdata.append("secondSave", this.props.params.secondSave);

 				 }

		  			bodyFormdata.append("linkDetVectSize", this.props.selectedLinks.length);

		  			this.props.selectedLinks && this.props.selectedLinks.map((link,index)=>{
						 if(this.state.selection.includes(link.id)){
 							bodyFormdata.append("mnuChk"+index, link.LINKID);
							bodyFormdata.append("linkId"+index, link.LINKID);

							let permsdet=this.state.operationPerms[link.LINKID];
							if(permsdet[1] === 'checked')
							bodyFormdata.append("chkadd"+index,this.props.operVec[0]);
							if(permsdet[2] === 'checked')
							bodyFormdata.append("chkmod"+index,this.props.operVec[2]);
							if(permsdet[3] === 'checked')
							bodyFormdata.append("chkdel"+index,this.props.operVec[1]);
						 }else {
							  bodyFormdata.append("mnuChk"+index, "");
							  bodyFormdata.append("linkId"+index, link.LINKID);
						 }

					});
					if(this.props.userLinksPermDet.LINKGROUPID  === 'NEW'){
						 this.props.dispatch(AdministrationActions.fetchGroupUserLinksPermData(bodyFormdata,'NEW'));

					}else {

		   		  	this.props.dispatch(AdministrationActions.fetchGroupUserLinksPermData(bodyFormdata,''));

					}
					if(this.props.userLinksPermDet && this.props.userLinksPermDet.LINKGROUPID === 'NEW'){
					this.props.doTabChange("VIEWALL");
 					}
}
doCancel(){
				var bodyFormdata = new FormData();
	  				bodyFormdata.append("selLnkGrpId", this.props.userLinksPermDet.LINKGROUPID);
					bodyFormdata.append("grpName", this.props.userLinksPermDet.DESCR);
					bodyFormdata.append("logedUserCompany",this.props.userLinksPermDet.COMPANYID);
  					bodyFormdata.append("addFlag", "SHOW");
					if(this.props.params){
					bodyFormdata.append("processId", this.props.params.processId);
					bodyFormdata.append("descr", this.props.params.descr);
					bodyFormdata.append("secondSave", this.props.params.secondSave);
				   }

		  			bodyFormdata.append("linkDetVectSize", this.props.selectedLinks.length);
	   		    this.props.dispatch(AdministrationActions.fetchGroupUserLinksPermData(bodyFormdata,''));
	   		     	this.setState({selection:[]});
	   		     	loading=true;
}

doViewChanges(){
this.setState({ viewChangesbtn:true});
}
doClose(){
this.setState({ viewChangesbtn:false});
}

componentWillReceiveProps() {
   	this.setState({selection:[]});
}
componentDidUpdate(prevProps) {
  // Typical usage (don't forget to compare props):
//  console.log('prevProps userLinksPermDet :'+JSON.stringify(prevProps.userLinksPermDet));
//  console.log('this.userLinksPermDet :'+JSON.stringify(this.props.userLinksPermDet));
  //console.log('this.state.selection :'+JSON.stringify(this.state.selection));

  if (((this.props.userLinksPermDet &&  prevProps.userLinksPermDet &&
  (this.props.userLinksPermDet.tabName !== prevProps.userLinksPermDet.tabName
  || this.props.userLinksPermDet.LINKGROUPID !== prevProps.userLinksPermDet.LINKGROUPID))) || (this.props.userLinksPermDet && prevProps.userLinksPermDet === null)){
 loading=true;
				if(this.props.userLinksPermDet)
				  this.setState({selection:this.props.prpsselection,groupName:this.props.userLinksPermDet?this.props.userLinksPermDet.DESCR:""});

 	       		var bodyFormdata = new FormData();
 	       		if(this.props.userLinksPermDet){
 	  			bodyFormdata.append("grpName", this.props.userLinksPermDet.DESCR);
	  			bodyFormdata.append("selLnkGrpId", this.props.userLinksPermDet.LINKGROUPID);
				}
  	  			bodyFormdata.append("addFlag", "SHOW");
  	  			if(this.props.params)
	  			bodyFormdata.append("tabName", this.state.tabName);
 			   this.props.dispatch(AdministrationActions.fetchGroupUserLinksPermData(bodyFormdata,''));


  }
}
  render() {
 	   const { classes } = this.props;

    const {tabName,completed, buffer , data, columns, rows,selection,tableColumnExtensions, defaultExpandedRowIds,msg,msgType, } = this.state;
	let  savebtn= false;
	let  cancelbtn =false;
	let  approvebtn =false;
	let  rejectbtn =false;

	const { results,userlinkspermdata ,menuLinkData,prpsselection,expandIds,operVec,selectedLinks,params} = this.props;
	let {userLinksPermDet} = this.props;


	if(userLinksPermDet && userLinksPermDet.LINKGROUPID  && results){

	  if(this.state.selection.length === 0 && loading){
		this.setState({selection:this.props.prpsselection,
		operationPerms:this.props.operationPerms
		});
	}else {
		this.setState({ operationPerms:this.props.operationPerms });
	}

	if(tabName === "PENDINGAPR"){
					savebtn =false;
 					cancelbtn= false;
 					if(params && params.globalFlag === "false" && params.errMsg === ''){
 						if(params && params.dispPendRec !== undefined && params.checkerFlag !== undefined){

							approvebtn =true;
 							rejectbtn= true;
					 	}else {
							approvebtn =false;
 							rejectbtn= false;
						}


					}
		}else{

			if(tabName === "VIEWALL"){
				if(params && params.globalFlag === "false" && params.errMsg === '')
				{

						if(tabName ===  'VIEWALL' && params.saveMsg !== 'USERDELWATAPP' )
						{

							savebtn =true;
						}

				}else{
					if(params && params.tempStatusFlag !== null && params.tempStatusFlag === "YES"){
						if(params.createFlag !== undefined){
							savebtn =true;
						}
					}

				}

			}


		 if(tabName === "VIEWALL"){
			cancelbtn=true;

		}
	}

	if( tabName === "PENDINGAPR"){
			savebtn =false;
 			cancelbtn= false;
	}

			if(menuLinkData == null || (menuLinkData && menuLinkData.length ==0)){
				return ( 	<LinearProgress variant="buffer" value={completed} valueBuffer={buffer} />);

			}else {
				clearInterval(this.timer);


	 			return (
			  <Paper>

					{(this.props.msg && this.props.msg !== "") ?( <div style={{fontSize: 12, color: '#c30000'}}>
				 			   					<b>{this.props.msg}</b>
				 </div>):''}
				 <div>
				 				<TextField
				 				label="Group Name : " id="groupName"
				 				className={classes.textField}
				 				inputprops={{
				 				classes: {
				 				input: classes.resize,maxLength: 6,
				 				},
				 				}}
 				 				margin="normal"
				 				placeholder={this.state.groupName}
				 				value={this.state.groupName}
				 				onChange={this.onGroupNameChange}
				/>
				</div>
				 <MuiThemeProvider theme={this.getMuiTheme()}>
				<Grid
				  rows={menuLinkData}
				  columns={columns}
				>
				  <SelectionState
							   selection={selection.length === 0 && loading?this.props.prpsselection:selection }
 							   onSelectionChange={this.changeSelection}
 					 />
				  <TreeDataState
					defaultExpandedRowIds={defaultExpandedRowIds}
					//expandedRowIds={expandIds}
 				  />
				  <CustomTreeData
					getChildRows={getChildRows}
				  />
				  <IntegratedSelection />
				  <Table
					columnExtensions={tableColumnExtensions}

				  />
				  <TableHeaderRow />
				 { (this.props.params != null && this.props.params.displayMode === 'disabled')?
				  <TableTreeColumn
					for="name"
 				//	checkboxComponent={this.checkboxComponent}
 				  />: <TableTreeColumn
					for="name"
					showSelectionControls
					showSelectAll={false}
  				  /> }

				</Grid>
				{ loading=false}
				 <div style={{textAlign:'center'}}>
				 { approvebtn?(<button   color="primary" className="btn btn-primary btn-xs" onClick={this.doApprove} >
				 					Approve
					</button>) :"" }
					{ rejectbtn?(<button   color="primary" className="btn btn-primary btn-xs" onClick={this.doReject} >
										Reject
					</button>) :"" }
				 		{ savebtn?(<button   color="primary" className="btn btn-primary btn-xs" onClick={this.doSave} >
					Save
					</button>) :"" }
								{cancelbtn?(<button   color="primary" className="btn btn-primary btn-xs" onClick={this.doCancel} >
										Cancel
						</button>):""}

								{this.props.userLinksPermDet&& this.props.userLinksPermDet.selLnkGrpId !== 'NEW'?(<button   color="primary" className="btn btn-primary btn-xs" onClick={this.doViewChanges} >
										View Changes
						</button>):""}
								{this.state.viewChangesbtn ?(<UserGroupsMgmtViewChanges open={this.state.viewChangesbtn} doClose={this.doClose} selectedCompanyId={this.props.params?this.props.params.selectedCompanyId:''} 	selLinkGrpId={this.props.params?this.props.params.selLnkGrpId:''} selLoginId={this.props.params?this.props.params.userId:''} />):''}

						</div>
				</MuiThemeProvider>

			  </Paper>
			);

		}

		}else{
		return(<Typography gutterBottom noWrap>
			          {
			           tabName === 'VIEWALLL'?"Select a group to view, change or delete that group's access rights.":""
			         }
        </Typography>)

		}

  }
}

TableTreeColumn.CheckboxProps
{
	disabled:false;
}
function mapStateToProps(state) {
 	const { userlinkspermdata,tabName} = state;
 	let operVec=[];
 	let menuLinkData=[];
	let selectedLinks=[];
	let prpsselection=[];
	let expandIds=[];
	let linkIndexdata ={};
	let params = null;
	let msg="";
	let msgType="success";
	let results = [];
	let operationPerms = {};


	if(userlinkspermdata && userlinkspermdata.userlinkspermdata){
		const results1=userlinkspermdata.userlinkspermdata;

		if( results1)
			results1.map((item,index) => {
			if(item.name === "linkDetVect")
			results = item.values

			if(item.name === "operVec")
			operVec = item.values

			if(item.name === "Params" && item.values.length>0)
			params = item.values[0]





			if(item.type === "Message"){
			msg = item.name;
			msgType =item.label;
			}
		})


//   console.log('results :'+JSON.stringify(results));
		var   row=0;
		if(results !== undefined && results && results.length>0){
	 		results.map((link,pndex) => {
			//	console.log('link.MNUCHKD '+link.MNUCHKD)
				if(link.MNUCHKD === 'checked')
				 prpsselection.push(pndex)
				if(link.LVL !== '3')
				expandIds.push(pndex);
		     operationPerms[link.LINKID] =  [link.MNUCHKD,link.ADDCHKD , link.MODCHKD , link.DELCHKD];
			 linkIndexdata[link.LINKID]=pndex;
			 selectedLinks.push({id:pndex,LINKID:link.LINKID ,PARENTID:link.PARENTID ,chkadd:operVec[0] ,chkmod:operVec[2] ,chkdel:operVec[1],CHKFLAG:link.CHKFLAG,OPERVAL:link.OPERVAL,LVL:link.LVL,ENLINKID:link.ENLINKID,PROCESSID:link.PROCESSID,CREATEDBY:link.CREATEDBY,STATUS:link.STATUS,MCSTATUS:link.MCSTATUS});
	 		 menuLinkData.push({"id": link.LINKID, "index":pndex  ,"parentId": link.PARENTID==="0000"?null:link.PARENTID, "name":   link.DESCR ,chkadd:link.ADDCHKD ,chkmod:link.MODCHKD ,chkdel:link.DELCHKD,linksDet:link  });
		}); }
	}
//console.log('operationPerms :'+JSON.stringify(operationPerms));

    return {  results,operationPerms,userlinkspermdata,prpsselection,expandIds,selectedLinks,operVec,menuLinkData,params,msg,msgType,linkIndexdata};
}

 export default connect(mapStateToProps)((withStyles(styles))(GroupUserLinksPerm));