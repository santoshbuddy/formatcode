import React from "react";
import { render } from "react-dom";
import Paper from "@material-ui/core/Paper";
import { RowDetailState, DataTypeProvider } from "@devexpress/dx-react-grid";
import {
  Grid,
  Table,
  TableHeaderRow,
  TableRowDetail
} from "@devexpress/dx-react-grid-material-ui";
 import TextField from '@material-ui/core/TextField';
import { DragDropContext } from 'react-dnd';
import HTML5Backend from 'react-dnd-html5-backend';
import Container from './Container';
import { createMuiTheme, withStyles,MuiThemeProvider} from '@material-ui/core/styles';

const style = {
			display: "flex",
			justifyContent: "space-around",
			paddingTop: "20px"
		}
	const selected ={
			    border: '1px solid #cccccc',
			    backgroundColor: '#e2f0fd',
			     padding:  '0.5rem 1rem',
			     margin: '.5rem',
	}
		const empty ={
 				    backgroundColor: '#fff',
 	}
const styles = theme => ({
	 textField: {
		  marginLeft: theme.spacing.unit,
		  marginRight: theme.spacing.unit,
		  width: 200,
	  },
	  typography: {
	        useNextVariants: false,
    },
    paper: {
	      padding: theme.spacing.unit * 1,
	      textAlign: 'center',
	      color: theme.palette.text.secondary,
	      backgroundColor:'#fff',
  },
	  MuiPaperRounded: {
	     borderRadius: 0,
	},

	readonly: {
	    border: '1px solid #cccccc',
	    backgroundColor: '#afb1b0',
	     padding: theme.spacing.unit * 1, textAlign: 'center',
	}
});

class UserDisplay extends React.PureComponent {
	  getMuiTheme = () => createMuiTheme({
		 		  typography: {
		 							useNextVariants: true,
		 	 			 },
		 	    overrides: {
		 			   MuiPaperRounded: {
					  	     borderRadius: 0,
						},
						MuiPaperRoot: {
						   backgroundColor:'#afb1b0',
						}
						, TableNoDataCell: {
							cell: {
							   textAlign: 'center',
							}
						}
		 	    }
	   })

  constructor(props) {
    super(props);

    this.state = {
	selecteduser:'',
	selectedGrpId:'',
      columns: [
        {	 name: "name", title: "Groups" ,getCellValue: row =>
         (
			((row.lnkGroupDet.LINKGROUPID !== "NOTAGROUP")
 		? (
				(row.lnkGroupDet.EDITFLAG === "false")?(
				(row.lnkGroupDet.LINKGROUPID === this.props.params.selLnkGrpId && this.props.params.showFlag !== null)?
				(
					(row.lnkGroupDet.PROCESSID!==null && row.lnkGroupDet.PROCESSID && this.props.tabName === "VIEWALL")
					?(
					 	<a  style={(this.state.selectedGrpId === row.lnkGroupDet.LINKGROUPID?selected:empty)} key={row.id} href="javaScript:void(0)"  onClick={(ev)=>{ this.showGroupDetails(row.lnkGroupDet)}}  >
					 	{row.lnkGroupDet.DESCR}	</a>
					 )
					:(
					<a  style={(this.state.selectedGrpId === row.lnkGroupDet.LINKGROUPID?selected:empty)}  key={row.id}   href="javaScript:void(0)"  onClick={(ev)=>{ this.showGroupDetails(row.lnkGroupDet)}}  >
					 	{row.lnkGroupDet.DESCR}	</a>					 )
				)
				:(
					(row.lnkGroupDet.PROCESSID !== ""  && this.props.tabName === "VIEWALL")?
				  	 (
						<a  style={(this.state.selectedGrpId === row.lnkGroupDet.LINKGROUPID?selected:empty)}  key={row.id} href="javaScript:void(0)"  onClick={(ev)=>{ this.showGroupDetails(row.lnkGroupDet)}} >
					 	{row.lnkGroupDet.DESCR}	</a>					 )
					:
					(
						((row.lnkGroupDet.PROCESSID === undefined || row.lnkGroupDet.PROCESSID === '' && this.props.tabName === "PENDINGAPR"))
							? ( <a  style={(this.state.selectedGrpId === row.lnkGroupDet.LINKGROUPID?selected:empty)}  key={row.id}   href="javaScript:void(0)"  > {row.lnkGroupDet.DESCR}	</a>
							 )
							:(
								<a style={(this.state.selectedGrpId === row.lnkGroupDet.LINKGROUPID?selected:empty)}  key={row.id}   href="javaScript:void(0)"  onClick={(ev)=>{ this.showGroupDetails(row.lnkGroupDet)}}  >
								{row.lnkGroupDet.DESCR}	</a>						)
							)
				)
			):(
					<TextField label="Group Name : " id={'grpName'+row.id}
							 				className={classes.textField}
							 				inputprops={{
							 				classes: {
							 				input: classes.resize,
							 				},
							 				}}
							 				margin="normal"
							 				placeholder={row.lnkGroupDet.DESCR}
							 				onBlur={this.doGroupChange(row.id)}
				/>   )
		)
 		:(
			 <a style={(this.state.selectedGrpId === row.lnkGroupDet.LINKGROUPID?selected:empty)}  key={row.id}    href="javascript:void(0)"  >{row.lnkGroupDet.DESCR}</a>
		 )
		 ))
		 }
       ],
      rows: [
        { isExpand: true, name: "" }
      ]
    };
    this.showGroupDetails =this.showGroupDetails.bind(this)
        this.addmarked =this.addmarked.bind(this)
this.onClickUser=this.onClickUser.bind(this);
  }
  showGroupDetails(linkDet){

	//   console.log('showGroupDetails')
	 	if(linkDet != null && linkDet.ACTION === 'N')
	 	alert("New group waiting for approval. No details to show.");
	 	else {
 		 this.props.showGroupDetails(linkDet);
 		 this.setState({selecteduser:'',selectedGrpId:linkDet.LINKGROUPID});
	 }
     }

     addmarked(userDet,groupDet){
		 this.props.addmarked(userDet,groupDet);
	  }

	   onClickUser(user,group,groups){
	    		//  console.log('GRP DISPLAY : onClickUser'+JSON.stringify( user));
	    		  this.props.onClickUser(user,group,groups);
	    		  	 	 this.setState({selecteduser:user.LOGINID,selectedGrpId:''});

	}

  render() {
	  const { classes } = this.props;
    const { rows, columns, booleanColumns } = this.state;
	const RowDetail = ({ row }) => {
// console.log('GRPUP DISPLAY  :'+JSON.stringify(row));

		if(row.innerList.length>0){
			return (
				<Container  selecteduser={this.state.selecteduser}  addmarked={this.addmarked}  onClickUser={this.onClickUser} id={row.lnkGroupDet.LINKGROUPID} groups={this.props.linksdata} tabName={this.props.tabName} group={row.lnkGroupDet} list={row.innerList} />
				);
		// return row.innerList.map((linkDet,index) => {
		//	const rowDet= Object.assign({tabName:this.props.tabName}, linkDet);

			//return (
 			//  <Paper key={index} className={rowDet.STATUS === "P" ?(classes.readonly):classes.paper }>
			//	<a key={index} href="javaScript:void(0)"  >{rowDet.LOGINNAME}</a>
			//  </Paper>
			//)

		//	});
		}else {
			return(	 //<Paper key={0} className={classes.paper }>
						//		(Empty)
				 // </Paper>
				 <Container addmarked={this.addmarked}  onClickUser={this.onClickUser}  id={row.lnkGroupDet.LINKGROUPID}  groups={this.props.linksdata}  tabName={this.props.tabName} group={row.lnkGroupDet} list={[{ "LOGINID": "", "LOGINNAME": "Empty", "INTERPOLATION": false, "SECLEFTPANEL": {}, "LINKGROUPID": "", "PROCESSID": "", "CREATEDBY": "" }]} />
				 )
			}
		}


const ToggleCellComponent = ({ row, ...restProps }) => {
  if (row.isExpand)
    return <TableRowDetail.ToggleCell row={row} {...restProps} />;
  return (
    <TableRowDetail.ToggleCell
      style={{
        pointerEvents: "none",
        opacity: 0.5
      }}
    />
  );
};

let finalData=[];
const { linksdata,params } = this.props;


 //console.log('params :'+JSON.stringify(params));

    return (
		 <MuiThemeProvider theme={this.getMuiTheme()}>
      <Paper >
        <Grid rows={linksdata} columns={columns}>
          <RowDetailState />
          <Table />
          <TableHeaderRow />
          <TableRowDetail
            contentComponent={RowDetail}
            toggleCellComponent={ToggleCellComponent}
          />
        </Grid>
      </Paper>
      </MuiThemeProvider>
    );
  }
}

export default  DragDropContext(HTML5Backend) (withStyles(styles) (UserDisplay));