import React from 'react';
import { Route } from 'react-router-dom';
import { NavBar } from '../../../navbar/components/navbar';
 import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../../node_modules/react-table/react-table.css';
import '../../../user/css/App.css';
import FormData from 'form-data';
import MUIDataTable from "mui-datatables";
 import { connect } from 'react-redux';
import { AdministrationActions } from '../../actions/administration.actions';


import PropTypes from 'prop-types';
import {createMuiTheme, withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
 import PriorityIcon from "@material-ui/icons/PriorityHigh";
import IconButton from "@material-ui/core/IconButton";

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  tabsRoot: {
    borderBottom: '1px solid #e8e8e8',
  },
  tabsIndicator: {
    backgroundColor: '#1890ff',
  },
  tabRoot: {
    textTransform: 'initial',
    minWidth: 72,
    fontWeight: theme.typography.fontWeightRegular,
    marginRight: theme.spacing.unit * 4,
    // fontFamily: [
    //   '-apple-system',
    //   'BlinkMacSystemFont',
    //   '"Segoe UI"',
    //   'Roboto',
    //   '"Helvetica Neue"',
    //   'Arial',
    //   'sans-serif',
    //   '"Apple Color Emoji"',
    //   '"Segoe UI Emoji"',
    //   '"Segoe UI Symbol"',
    // ].join(','),
    '&:hover': {
      color: '#40a9ff',
      opacity: 1,
    },
    '&$tabSelected': {
      color: '#1890ff',
      fontWeight: theme.typography.fontWeightMedium,
    },
    '&:focus': {
      color: '#40a9ff',
    },
  },
  tabSelected: {},
  typography: {
    padding: theme.spacing.unit * 3,
  },
   root: {
      flexGrow: 1,
    },
    paper: {
      padding: theme.spacing.unit * 2,
      textAlign: 'center',
      color: theme.palette.text.secondary,
  },
    priorityIcon: {
  	      color: "#000",
  	},
  	iconButton: {
	    marginRight: "24px",
	    top: "50%",
	    display: "inline-block",
	    position: "relative",
	    transform: "translateY(-50%)",
  },
});
 class AddRemoveGroupUser extends React.Component {
	   getMuiTheme = () => createMuiTheme({
	 	 		  typography: {
	 	 							useNextVariants: true,
	 	 	 			 },
	 	 	    	overrides: {
	 	 			  MuiButtonBase: {
	 	 					  	        root: {
	 	 					   	           padding: '0px',
	 	 					   	        }
	 	 	      },
	 	 	    }
	 	   })

 constructor() {
    super();

    this.state = {
    value: 0,
    userdata:[],
    userLinksPermDet:null,
	}
   this.handleUserLinksPerm=this.handleUserLinksPerm.bind(this)
    this.doTabChange=this.doTabChange.bind(this)
  }
  handleUserLinksPerm(linkDetails){
		// console.log(' AddRemoveGroupUser handleUserLinksPerm :'+JSON.stringify(linkDetails));
		 this.setState({userLinksPermDet:linkDetails});
  }
  handleChange = (event, value) => {
    this.setState({ value });
    if(value === 0){
		 this.doTabChange("VIEWALL");
	}else if(value === 1){
		 this.doTabChange("PENDINGAPR");
	}
  };
 componentDidMount() {
          this.getUserData()
   }

    getUserData(){
	var bodyFormdata = new FormData();
    this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));
   }

   doTabChange(tabName){
		this.setState({ userLinksPermDet:null, });
	   	var bodyFormdata = new FormData();
		bodyFormdata.append("pageCount", "");
		bodyFormdata.append("rowsByPage", "");
		bodyFormdata.append("grpId", "");
		bodyFormdata.append("userId", "");
		bodyFormdata.append("groupId", "");
		bodyFormdata.append("tabName", tabName);

    	this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));
   }
  render() {
    const { classes ,userdata,finalData,params} = this.props;
    const { value } = this.state;



		//   console.log('finalData :'+JSON.stringify(finalData));

 return (
 <div>
    	<NavBar/>
    	<div className="panel panel-primary clearfix" style={{clear:'both'}}>
		<div className="panel-heading">
			<h4 className="panel-title">User Permissions Management</h4>
		</div>
		 <div className="clearfix"></div>
		 	 <div className={classes.root}>
    		<h4>User Permissions</h4>
    	   <div style={{marginRight:'10px'}}> <h6 >	{this.state.value===0?"! Records in grey are Pending Approval":"You will not be able to approve any records for which you performed the Maker action. These records are greyed out and cannot be selected."}</h6></div>

      <Grid container spacing={8} direction="row" item xs={12} >
     	<Grid item xs={9}>
    	<Paper>
       	<div className={classes.root} style={{float:'left'}}>
        <Tabs style={{ borderBottom: '1px solid transparent'}}
          value={value}
          onChange={this.handleChange}
          classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}
			>
			  <Tab
				disableRipple
				classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
				label="View All"
			  />
			  <Tab
				disableRipple
				classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
				label="Pending Approval"
			  />
        </Tabs>
			{value === 0 && <Grid container spacing={8} direction="row"
			  justify="flex-start"
			  alignItems="flex-start" item xs={12}><Grid item xs={3}>
			  Groups
			</Grid><Grid item xs={9}>permissions</Grid></Grid>}
			{value === 1 && <Grid container spacing={8} direction="row"
			  justify="flex-start"
			  alignItems="flex-start" item xs={12}><Grid item xs={3}>
			 Groups
			</Grid><Grid item xs={9}> permissions</Grid></Grid>}
       </div>
       </Paper>
        </Grid>
        <Grid item xs={3}>

	             <Typography variant="h5" component="h3">
	                User Groups
	             </Typography>
	             <Typography component="p">
	              	User Groups can be used to apply the same set of
				 	permissions to an entire group of users at once.
				For example, you can create a group for all the
				checkers and give them access to the same
				pages.
	     		<a>	Manage User Groups	</a>
	             </Typography>

        </Grid>
       </Grid>
       </div>
       </div>
        </div>
    );
  }
}


function mapStateToProps(state) {
 	const { userdata } = state;
 	let finalData=[];
		let params= null;
	if(userdata && userdata.userdata){
		const results1=userdata.userdata;
		let results = [];

		if( results1)
			results1.map((item,index) => {
			if(item.name === "dispList")
			results = item.values

				if(item.name === "Params" && item.values.length>0)
				params = item.values[0]
		})
		//console.log('results :'+JSON.stringify(results));
		var   row=0;
			results && results.map((parent,pndex) => {
			finalData.push({ isExpand: true, name:  parent.DESCR,ENCLINKGROUPID:parent.ENCLINKGROUPID,VIEWLNKGRPLST:parent.VIEWLNKGRPLST });
		});
}
    return { userdata,finalData,params};
}

 export default connect(mapStateToProps)((withStyles(styles))(AddRemoveGroupUser));