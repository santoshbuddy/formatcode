import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import MUIDataTable from "mui-datatables";
import FromData from 'form-data';
import { AdministrationActions } from '../../actions/administration.actions';
import { connect } from 'react-redux';

 import Paper from '@material-ui/core/Paper';

 const cols = [
       {
    name: "Group",
    options: {
     filter: true,
     sort: false,
    }
   },{
    name: "User",
    options: {
     filter: true,
     sort: false,
    }
   }, {
     name: "Submitted At",
     options: {
      filter: true,
      sort: false,
     }
   },
   {
    name: "Submitted By",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
    name: "Approved At",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
    name: "Approved By",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
    name: "Rejected At",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
    name: "Rejected By",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
    name: "Nature of Change",
    options: {
     filter: true,
     sort: false,
    }
   },
   {
    name: "Status",
    options: {
     filter: true,
     sort: false,
    }
   }
  ];


class GrpUserAssocViewChanges extends React.Component {


  constructor(props) {
 	    super(props);
 	    this.state = {
 		dialogopen: false,
 		screenName:'',
 		userapprovalviewchngsdata:[],
    };
}
doUserApprove = () => {
	if(confirm("Are you sure, you want to approve the data?")){
 		 this.props.doUserApprove(this.props.params.userProcessId,this.props.params.userLinkGroupId);
	}
}

doUserReject = () => {
	if(confirm("Are you sure, you want to reject the data?")){
		this.props.doUserReject(this.props.params.userProcessId);
	}

}
 doViewChanges = () => {

this.setState({ dialogopen: true });

  }

   componentWillMount() {
    				 var bodyFormData = new FromData();
  					bodyFormData.append("loginId",this.props.loginId);
  				   this.props.dispatch(AdministrationActions.fetchUserApprovalViewChangesData(bodyFormData));

 }

 componentDidUpdate(prevProps) {
    if (this.props.loginId &&  (prevProps == null) || (prevProps && this.props.loginId !== prevProps.loginId)) {
 				 var bodyFormData = new FromData();
					bodyFormData.append("loginId",this.props.loginId);
				  this.props.dispatch(AdministrationActions.fetchUserApprovalViewChangesData(bodyFormData));

}
}

  handleClose = () => {
    this.setState({ dialogopen: false });
   };

  render(){
	//  console.log('this.props.loginId :: '+this.props.loginId);
	let  approvebtn =false;
	let  rejectbtn =false;
	if(this.props.params && this.props.params.userButtons !== undefined){

	approvebtn =true;
	rejectbtn= true;
	}else {
	approvebtn =false;
	rejectbtn= false;
	}

	const options = {
		filter: true,
		filterType: 'dropdown',
		responsive: 'scroll',
		selectableRows:false,
    };

	let {changesVec} = this.props;
  	if(changesVec&&changesVec.length>0){
		changesVec=JSON.parse(JSON.stringify(changesVec).replace(/null/i, "\"\""));
}
    return (
      <div>
			 { approvebtn?(<button   color="primary" className="btn btn-primary btn-xs" onClick={this.doUserApprove} >
				 					Approve
					</button>) :"" }
					{ rejectbtn?(<button   color="primary" className="btn btn-primary btn-xs" onClick={this.doUserReject} >
										Reject
					</button>) :"" }

					<button   color="primary" className="btn btn-primary btn-xs" onClick={this.doViewChanges} >
					View Changes
					</button>
  		 <Dialog  fullWidth={true}
          maxWidth={'md'}
          open={this.state.dialogopen}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="form-dialog-title"> User Permissions Management View Changes</DialogTitle>
          <DialogContent>
           <Paper>

			<MUIDataTable
			data={changesVec}
			columns={cols} options={options} />



 			 </Paper>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>

          </DialogActions>
        </Dialog>
      </div>
    );


  }
}
function mapStateToProps(state) {
    const { userapprovalviewchngsdata } = state;
    let changesVec =[];


			let results=[];
 			let results1  =  userapprovalviewchngsdata.userapprovalviewchngsdata;

 				//    console.log('mapStateToProps : results1'+JSON.stringify( results1));

			let screenName="";
			let from="REFRESH";
	        if( results1 !==  undefined && results1.length>0)
	             results1.map((item,index) => {

		//			 console.log('item.type '+item.type);
    			if(item.type === "Title")
                 screenName = item.name

 //console.log('item.name '+item.name);

 					let MainaspVec=[];
	                if(item.name === "dataVec" && item.values){
	                 	results = item.values
						 results.map(row => {
							 let aspVec=[];
						 aspVec.push(row.DESCR);
						 aspVec.push(row.LOGINNAME);
 						 aspVec.push(row.MODIFIEDDATE);
						 aspVec.push(row.MODIFIEDBY);
						 aspVec.push(row.ACCEPTEDDATE);
						 aspVec.push(row.ACCEPTEDBY);
						 aspVec.push(row.REJECTEDDATE);
						 aspVec.push(row.REJECTEDBY);
						 aspVec.push(row.NATURE);
						 aspVec.push(row.STATUS);
						 MainaspVec.push(aspVec);

						})
					}
					 if(MainaspVec.length>0)
					 changesVec=MainaspVec;


	            });


    return { userapprovalviewchngsdata ,changesVec};
}

 export default connect(mapStateToProps)(GrpUserAssocViewChanges)  ;



