import React from 'react';
import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import { connect } from 'react-redux';
import { AdministrationActions } from '../actions/administration.actions';
import MuiTable from './MuiTable';
import EnterAcctDet from './EnterAcctDet';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepConnector from '@material-ui/core/StepConnector';
import PropTypes from 'prop-types';
import { history } from '../../_helpers';
import { withStyles, createMuiTheme, MuiThemeProvider} from "@material-ui/core/styles";

const styles = theme => ({
    root: {
      width: "90%"
    },
    button: {
      marginRight: theme.spacing.unit
    },
    instructions: {
      marginTop: theme.spacing.unit,
      marginBottom: theme.spacing.unit
    },
    connectorActive: {
        '& $connectorLine': {
        borderColor: "#00395c",
        borderWidth: '2px'
        },
    },
    connectorCompleted: {
        '& $connectorLine': {
        borderColor: "#00395c",
        borderWidth: '2px'
        },
    },
    connectorDisabled: {
        '& $connectorLine': {
        borderColor: theme.palette.grey[100],
        borderWidth: '2px'
        },
    },
    connectorLine: {
        transition: theme.transitions.create('border-color,border-size'),
    },
    stepIcon: {
      color: "#828384",
      fontSize: '19px',
      "&$active": {
        color: "#00395c",
        fontSize: '37px'
      },
      "&$completed": {
        color: "#00395c",
        fontSize: '19px'
      }
    },
    active: {},
    completed: {},
    typography: {
        useNextVariants: true,
    },
    iconContainer :{
        paddingRight: "0"
    },
    stepStyle:{
        paddingRight: "0",
        paddingLeft: "0"
    }
  });

class SelectIBA extends React.Component {
	constructor() {
		super();
		this.state ={
			selTradeVal:[],
			columns:[],
			activeStep: 0,
			tabIndex: 0,
			productId:'',
			productName:'',
			fundFamilyId:'',
			fundTypeId:'',
			currencyCode:''
		}

		this.selectTrade = this.selectTrade.bind(this);
	}

    selectTrade(obj1, obj2, obj3, obj4, obj5) {
		this.setState({productName: obj1});
		this.setState({currencyCode: obj2});
		this.setState({productId: obj3});
		this.setState({fundFamilyId: obj4});
		this.setState({fundTypeId: obj5});
		this.setState({ tabIndex:1 });

		history.push({
			pathname: '/administration/REVIEWPROS',
			state: {
				tabIndex: 1,
				activeStep: 0,
				product: obj3,
				productname: obj1,
				currency: obj2,
				fundTypeId: obj5,
				fundFamilyId: obj4
			}
		});
	}

	getSteps() {
	    return ['', '', ''];
  	}

	render() {
		const steps = this.getSteps();
		const { activeStep } = this.state;
		const { classes } = this.props;
		const connector = (
			<StepConnector
				classes={{
					active: classes.connectorActive,
					completed: classes.connectorCompleted,
					disabled: classes.connectorDisabled,
					line: classes.connectorLine,
				}}
			/>
		);

		console.log(this.props)
		var ProdVal = this.props.obj;
		var results = this.props.data;
		var result1=[];

		if(results !== undefined) {
			results.map((item,index) => {
				if(item.name === "data")
					result1	= item.values;
			});

			return(
				<div>
					<Stepper  className="col-md-6" activeStep={activeStep} connector={connector} style={{marginBottom: '5px'}}>
						{steps && steps.map((label, index) => {
							const props = {};
							const labelProps = {};
							return (
							<Step key={label} {...props} className={classes.stepStyle}>
								<StepLabel classes={{iconContainer:classes.iconContainer}}
									StepIconProps={{
										classes: { root: classes.stepIcon, active:classes.active, completed:classes.completed }
									}}>
								</StepLabel>
							</Step>
							);
						})}
					</Stepper>

					<MuiTable data={result1} method={this.selectTrade.bind(this)}/>
				</div>
			);
		}
		else
		{
			return(<div></div>)
		}
	}
}

SelectIBA.propTypes = {
	classes: PropTypes.object,
};

function mapStateToProps(state) {
    const { ibaacctdata } = state;
    console.log('ibaacctdata Det <><>:'+JSON.stringify( ibaacctdata ));
    return { ibaacctdata };
}

const connectedSelectIBA = connect(mapStateToProps)(withStyles(styles)(SelectIBA));
export { connectedSelectIBA as SelectIBA };