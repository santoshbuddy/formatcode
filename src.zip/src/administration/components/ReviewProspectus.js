import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { AdministrationActions } from '../actions/administration.actions';
import { withStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import DoneIcon from '@material-ui/icons/Done';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import { NavBar } from '../../navbar/components/navbar';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepConnector from '@material-ui/core/StepConnector';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import { history } from '../../_helpers';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import Loading from '../../common/Loading'

let prospectusStatus= '';
let fromwhere 		= '';
var prodId 			= '';
var CcyVal 			= '';
var FundTypeId		= '';
var FundFamilyId	= '';
var prodName 		= '';
let commonData 		= [];
var TaxStatus 		= [];
var TaxStateTxt 	= [];
var TaxCountryTxt 	= [];
var StateTxt 		= [];
var CountryTxt 		= [];
var InvestAccount 	= [];
var FundAccount 	= [];
var BranchID 		= [];
var linksArr 		= [];
var linksDispArr	= [];
var declareStr		= '';

let backButton;
let buttonsdata = '';

const styles = theme => ({
    root: {
      width: '100%',
    },
	paper: {
		padding:'15px',
		textAlign: 'right',
		marginBottom:'50px',
	},
    heading: {
      fontSize: theme.typography.pxToRem(15),
      fontWeight: theme.typography.fontWeightRegular,
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
        margin:'2px',
        display: 'inline',
    },
    statustxt: {
    	textAlign: 'center',
    	color: theme.palette.text.danger
  	},
	connectorActive: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorCompleted: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorDisabled: {
		'& $connectorLine': {
			borderColor: theme.palette.grey[100],
			borderWidth: '2px'
		},
	},
	connectorLine: {
		transition: theme.transitions.create('border-color,border-size'),
	},
	stepIcon: {
		color: "#828384",
		fontSize: '19px',
		"&$active": {
			color: "#00395c",
			fontSize: '37px'
		},
		"&$completed": {
			color: "#00395c",
			fontSize: '19px'
		}
	},
	active: {},
	completed: {},
	typography: {
		useNextVariants: true,
	},
	iconContainer :{
		paddingRight: "0"
	},
	stepStyle:{
		paddingRight: "0",
		paddingLeft: "0"
	},
	icon: {
	    margin: "2",
	    fontSize: 12,
	    color:"blue"
  	}
});

class ReviewProspectus extends React.Component {
    constructor(props) {
        super(props);
        this.state ={
            columns:[],
            activeStep: 1,
            name:''
        }

		this.externalWindow = null;
		this.handleChange = this.handleChange.bind(this);
		this.enterAccountDet = this.enterAccountDet.bind(this);
		this.doAccountCreate = this.doAccountCreate.bind(this);
		this.doTrade = this.doTrade.bind(this);
		this.doFundCardInfo = this.doFundCardInfo.bind(this);
    }

    doFundCardInfo(itm, e) {
		console.log('itm----itm---',itm);
		if(itm.phurl != null && (itm.phurl == 'NA' || itm.phurl == 'na')) {
			alert ("Information Not Available");
		} else {
			var bodyFormData = new FormData();
			bodyFormData.append("prodId", prodId)
			bodyFormData.append("factCardUrl", itm.phurl)
			bodyFormData.append("ccy", CcyVal);
			bodyFormData.append("currencyCode", CcyVal);
			bodyFormData.append("fundTypeId", FundTypeId);
			bodyFormData.append("fundFamilyId", FundFamilyId);

			if((this.props.cData.processing == '1000' && itm.phid == '102') || (this.props.cData.processing == '1001' && itm.phid == '103'))
			{
				bodyFormData.append("prospFlag", 'SAVE');
				this.props.dispatch(AdministrationActions.fetchMmfReviewProspectusData(bodyFormData));
			}

			this.externalWindow = window.open(itm.phurl, '', 'width=800,height=500,left=10,top=10');
		}
	}

    doAccountCreate() {
 	    let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

		if(prospectusStatus == 'Y')
		{
			console.log('this.props----',this.props);
			this.props.history.push({
				pathname: '/administration/MMFCREATEACCT',
				state: {
					tabIndex: 1,
					activeStep: 2,
					product: prodId,
					company: prodId,
					productname: prodName,
					currency: CcyVal,
					fundTypeId: FundTypeId,
					actionFlag: "FUNDACCTINFO",
					fundFamilyId: FundFamilyId
				}
			});
		} else  {
			alert(message["READPROSPECTUS"]);
		}
	}

    doTrade() {
		history.push("/DEALENT");
	}

	doBackConfirm() {
		if(fromwhere == '/administration/LOOKUP' || fromwhere == '/report/FUNDINFO'){
			history.push(fromwhere);
		}
		else{
			history.push("/administrationcreate/NEWMMDAACCT");
		}
    }

    componentWillMount(){
		var bodyFormData = new FormData();

		bodyFormData.append("prodId", this.props.location.state.product)
        bodyFormData.append("ccy", this.props.location.state.currency);
        bodyFormData.append("fundTypeId", this.props.location.state.fundTypeId);
        bodyFormData.append("fundFamilyId", this.props.location.state.fundFamilyId);

        this.props.dispatch(AdministrationActions.fetchMmfReviewProspectusData(bodyFormData));
	}

	enterAccountDet()
	{
		let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

		if(prospectusStatus == 'Y')
		{
			this.props.history.push({
				pathname: '/administration/MMFCREATEACCT',
				state: {
					tabIndex: 1,
					activeStep: 2,
					product: prodId,
					productname: prodName,
					currency: CcyVal,
					fundTypeId: FundTypeId,
					fundFamilyId: FundFamilyId
				}
			});
		} else  {
			alert(message["READPROSPECTUS"]);
		}
	}

    handleChange = name => event => {
        this.setState({
            [name]: event.target.value,
        });
    };

	getSteps() {
	    return ['', '', ''];
  	}

    render(){
//        const { data } = this.props;
		linksDispArr	= [];
		linksArr 		= [];
		declareStr		= '';
		const steps = this.getSteps();
		const { activeStep } = this.state;
        const { classes, cData } = this.props;
		const connector = (
			<StepConnector
				classes={{
					active: classes.connectorActive,
					completed: classes.connectorCompleted,
					disabled: classes.connectorDisabled,
					line: classes.connectorLine,
				}}
			/>
		);
    	backButton = <button className="btn btn-primary btn-xs mt" id="back" onClick={this.doBackConfirm.bind(this)}>Back</button>

       	if(this.props.location.state != undefined) {
       		prodId 		= this.props.location.state.product;
       		CcyVal 		= this.props.location.state.currency;
       		prodName 	= this.props.location.state.productname;
       		FundTypeId 	= this.props.location.state.fundTypeId;
       		FundFamilyId 	= this.props.location.state.fundFamilyId;

       		if(this.props.location.state.fromWhere != undefined)
       			fromwhere = this.props.location.state.fromWhere
		}

		if(fromwhere === '/report/FUNDINFO') {
			buttonsdata	= <span><button className="btn btn-primary btn-xs mt" id="createaccount" onClick={this.doAccountCreate.bind(this)}>Create Account</button>
			<button className="btn btn-primary btn-xs mt" id="tradefund" onClick={this.doTrade.bind(this)}>Trade in this Fund</button></span>
		} else {
			buttonsdata	= <div><button onClick={e => this.enterAccountDet()} className="btn btn-primary btn-xs mt pull-right">Next</button></div>
		}

		if(cData !== undefined && cData.toString().length > 0)
		{
			prospectusStatus	= cData.prospectusStatus;
			linksArr			= cData.fyieldList;

			if(linksArr != null && linksArr.length > 0) {
				linksArr.map((items, index) => {
					linksDispArr.push(<Grid style={{textAlign:'left',padding:'5px 0px 5px 0px'}} xs={4}><img src={require('../../images/icon_pdf.png')} width="18" height="18" /><a phurl={items.phurl} phid={items.phid} href="javascript:void(0);" onClick={e => this.doFundCardInfo(items, event)}>{items.phdescr}</a></Grid>);

					if(cData.processing === '1000')
					{
						if(items.phid === '102')
						{
							if(prospectusStatus !== 'Y') {
								declareStr 	= <Grid xs={12}>Please review the <a href="javascript:void(0);" onClick={e => this.doFundCardInfo(items, event)}>Fund prospectus</a> before proceeding</Grid>
							} else {
								declareStr	= <Grid xs={12}>I have reviewed the Fund prospectus</Grid>
							}
						}
					}
					else
					{
						if(items.phid === '103')
						{
							if(prospectusStatus !== 'Y') {
								declareStr	= <Grid xs={12}>Please review the <a href="javascript:void(0);" onClick={e => this.doFundCardInfo(items, event)}>KIID</a> before proceeding</Grid>
							} else {
								declareStr	= <Grid xs={12}><DoneIcon className={classes.icon} /> I have reviewed the KIID</Grid>
							}
						}
					}
				});
			}

			return  (
				<div className={classes.root}>
					<NavBar/>
					<div className="clearfix"></div>
					<div className="panel panel-primary">
						<div className="panel-heading">
							<h4 className="panel-title">Create New Money Fund Account</h4>
						</div>
						<div className="panel-body">
							<div className="col-md-12 col-sm-12">

								<Stepper  className="col-md-6" activeStep={activeStep} connector={connector}>
									{steps && steps.map((label, index) => {
										const props = {};
										const labelProps = {};
										return (
										<Step key={label} {...props} className={classes.stepStyle}>
											<StepLabel classes={{iconContainer:classes.iconContainer}}
												StepIconProps={{
													classes: { root: classes.stepIcon, active:classes.active, completed:classes.completed }
												}}>
											</StepLabel>
										</Step>
										);
									})}
								</Stepper>
								<div className="clearfix"></div>

								<h5 style={{fontWeight:'bold'}}>{prodName}</h5>

								<table className="table table-striped table-bordered" width="100%">
									<tbody>
										<tr>
											<td style={{width:'33%',padding:'5px 0px 5px 5px'}}>
												<label>CUSIP/ISIN:</label>
												<label className="TxtNrml"> {cData.CUSIPISIN}</label>
											</td>
											<td style={{width:'33%',padding:'5px 0px 5px 5px'}}>
												<label>Currency:</label>
												<label className="TxtNrml"> {cData.Currency} </label>
											</td>
											<td style={{padding:'5px 0px 5px 5px'}}>
												<label>Fund Type:</label>
												<label className="TxtNrml">{cData.FundType}</label>
											</td>
										</tr>
										<tr>
											<td style={{width:'33%',padding:'5px 0px 5px 5px'}}>
												<label>NAV:</label>
												<label className="TxtNrml"> {cData.NAV} </label>
											</td>
											<td style={{width:'33%',padding:'5px 0px 5px 5px'}}>
												<label>AUM(MM):</label>
												<label className="TxtNrml"> {cData.AUM} </label>
											</td>
											<td  style={{padding:'5px 0px 5px 5px'}}>
												<label>EOD Cut-Off Time:</label>
												<label className="TxtNrml">{cData.EODCutOffTime}</label>
											</td>
										</tr>
									</tbody>
								</table>

								<table className="table table-striped table-bordered" width="100%">
									<tbody>
										<tr>
											<td style={{width:'33%',padding:'5px 0px 5px 5px'}}>
												<label>Factor:</label>
												<label className="TxtNrml"> {cData.Factor} </label>
											</td>
											<td style={{width:'33%',padding:'5px 0px 5px 5px'}}>
												<label>Daily Yield:</label>
												<label className="TxtNrml"> {cData.DailyYield} </label>
											</td>
											<td  style={{padding:'5px 0px 5px 5px'}}>
												<label>7-Day Current Yield:</label>
												<label className="TxtNrml">{cData.DayCurrentYield7}</label>
											</td>
										</tr>
										<tr>
											<td style={{width:'33%',padding:'5px 0px 5px 5px'}}>
												<label>7-Day Effective Yield:</label>
												<label className="TxtNrml"> {cData.DayEffectiveYield7} </label>
											</td>
											<td  style={{padding:'5px 0px 5px 5px'}}>
												<label>30-day Yield:</label>
												<label className="TxtNrml"> {cData.DayYield30} </label>
											</td>
											<td>&nbsp;</td>
										</tr>
									</tbody>
								</table>

								<table className="table table-striped table-bordered" width="100%">
									<tbody>
										<tr>
											<td style={{width:'33%',padding:'5px 0px 5px 5px'}}>
												<label>S&P:</label>
												<label className="TxtNrml"> {cData.SP} </label>
											</td>
											<td style={{width:'33%',padding:'5px 0px 5px 5px'}}>
												<label>Moody's:</label>
												<label className="TxtNrml"> {cData.Moodys} </label>
											</td>
											<td  style={{padding:'5px 0px 5px 5px'}}>
												<label>Fitch:</label>
												<label className="TxtNrml">{cData.Fitch}</label>
											</td>
											</tr>
											<tr>
											<td  style={{padding:'5px 0px 5px 5px'}}>
												<label>NAIC:</label>
												<label className="TxtNrml">{cData.NAIC}</label>
											</td>
											<td>
											</td>
											<td>
											</td>
										</tr>
									</tbody>
								</table>

								<Paper className={classes.paper} elevation={1}>
									<Grid container spacing={24}>
										{linksDispArr}
									</Grid>
								</Paper>

								<Paper className={classes.paper} elevation={1}>
									<Grid container spacing={24}>
									{declareStr}
									</Grid>
								</Paper>

								<div style={{padding: '2px 15px'}}>
									{buttonsdata}
									{backButton}
								</div>
							</div>
						</div>
					</div>
				</div>

			)
		}
		else if(cData === undefined ){
		return(
		<div className={classes.root}>
							<NavBar/>
							<div className="clearfix"></div>
							<div className="panel panel-primary">
								<div className="panel-heading">
									<h4 className="panel-title">Create New Money Fund Account</h4>
								</div>
								<div className="panel-body">
									<div className="col-md-12 col-sm-12">

										<Stepper  className="col-md-6" activeStep={activeStep} connector={connector}>
											{steps && steps.map((label, index) => {
												const props = {};
												const labelProps = {};
												return (
												<Step key={label} {...props} className={classes.stepStyle}>
													<StepLabel classes={{iconContainer:classes.iconContainer}}
														StepIconProps={{
															classes: { root: classes.stepIcon, active:classes.active, completed:classes.completed }
														}}>
													</StepLabel>
												</Step>
												);
											})}
										</Stepper>
										<div className="clearfix"></div>

										<h5 style={{fontWeight:'bold'}}>{prodName}</h5>
										<div className="clearfix"></div>
										<Grid container spacing={24}>
											<Grid xs={12} className={classes.statustxt}>No data found</Grid>
											{backButton}
											</Grid>

									</div>
								</div>
							</div>
				</div>
				)
		}
		else
		{
			return(
				<Loading/>
 			)
		}
    }
}

ReviewProspectus.propTypes = {
    classes: PropTypes.object.isRequired,
};

function mapStateToProps(state) {
    const { mmfreviewPropDet } = state;
    let cData = [];

    if(mmfreviewPropDet != undefined)
    {
		 if(mmfreviewPropDet.mmfreviewPropDet != undefined ) {
    	    cData   = mmfreviewPropDet.mmfreviewPropDet.commonData;
		}
	}

    return { cData };
}

const connectedReviewProspectus = connect(mapStateToProps)(withStyles(styles)(ReviewProspectus));
export { connectedReviewProspectus as ReviewProspectus };