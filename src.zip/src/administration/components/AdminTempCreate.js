import React from 'react';
import 'react-tabs/style/react-tabs.css';
import { NavBar } from '../../navbar/components/navbar';
import { AdministrationActions } from '../actions/administration.actions';
import { connect } from 'react-redux';
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import Loading from '../../common/Loading'
import { SelectIBA } from './SelectIBA';

class AdminTempCreate extends React.Component {
    constructor(){
        super();
        this.state={
            tableData:[],
            tableData1:[],
            results:[],
            results1:[],
            reportdata:[],
            columns:[],
            screenName:'',
            tabIndex: 0
        }
        this.doChange = this.doChange.bind(this);
    }

	componentWillMount() {
		this.getFilter()
	}

	getFilter(){
		var filtObj = new FormData();
		this.props.dispatch(AdministrationActions.fetchReportData(filtObj));
	}

	doChange(fillObj){
		var bodyFormData = new FormData();
		for (name in fillObj) {
			bodyFormData.append(name, fillObj[name]);
		}

		this.props.dispatch(AdministrationActions.fetchReportTableData(bodyFormData));
	}

	render(){
		const { cData } = this.props;

		if(cData != undefined)
		{
        	this.state.results1  = cData;
			cData.map((item,index) => {
				if(item.type === "Title")
					this.state.screenName = item.name
			});

        	return (
            	<div>
                	<NavBar/>
					<div className="panel panel-primary clearfix" style={{clear:'both'}}>
						<div className="panel-heading">
							<h4 className="panel-title">{this.state.screenName}</h4>
						</div>
						<div className="panel-body">
							<div className="col-md-12 col-sm-12">
								<SelectIBA data={cData}/>
							</div>
						</div>
					</div>
				</div>
        	);
    	}
    	else
    	{
			return (<Loading />)
		}
	}
}

function mapStateToProps(state) {
    const { adminreportdata } = state;
    let cData = [];

    if(adminreportdata != undefined)
    {
		cData	= adminreportdata.adminreportdata;
	}
    return { cData };
}

const connectedAdminTempCreate = connect(mapStateToProps)(AdminTempCreate);
export { connectedAdminTempCreate as AdminTempCreate };
