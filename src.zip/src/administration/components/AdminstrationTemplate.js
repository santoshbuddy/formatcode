import React from 'react';
import PropTypes from 'prop-types';
import { Router, Route } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { AdministrationActions } from '../actions/administration.actions';
import { connect } from 'react-redux';
import AdmnFilters from './AdmnFilters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import FormData from 'form-data';
import MUIDataTable from "mui-datatables";
import {muiTableStyles} from '../../styles/muidatatableCss';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import ScrollDialogPopUp  from "./ScrollDialogPopUp";
import Loading from '../../common/Loading'
import { withStyles } from '@material-ui/core/styles';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import axios from 'axios';
import { alertConstants } from '../../common/constants/alert.constants';
import Button from "@material-ui/core/Button";
import Grid from '@material-ui/core/Grid';

Object.assign(ReactTableDefaults, {
	defaultPageSize: 5,
	minRows: 1
});

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
      marginTop:'0px',
    },
    table: {
      minWidth: 700,
    },

    tabsRoot: {
        borderBottom: '1px solid #e8e8e8',
      },
      tabsIndicator: {
        backgroundColor: '#1890ff',
      },
      tabRoot: {
        textTransform: 'initial',
        minWidth: 72,
        fontWeight: theme.typography.fontWeightRegular,
        marginRight: theme.spacing.unit * 4,
        // fontFamily: [
        //   '-apple-system',
        //   'BlinkMacSystemFont',
        //   '"Segoe UI"',
        //   'Roboto',
        //   '"Helvetica Neue"',
        //   'Arial',
        //   'sans-serif',
        //   '"Apple Color Emoji"',
        //   '"Segoe UI Emoji"',
        //   '"Segoe UI Symbol"',
        // ].join(','),
        '&:hover': {
          color: '#40a9ff',
          opacity: 1,
        },
        '&$tabSelected': {
          color: '#1890ff',
          fontWeight: theme.typography.fontWeightMedium,
        },
        '&:focus': {
          color: '#40a9ff',
        },
      },
      tabSelected: {},
      typography: {
        padding: theme.spacing.unit * 3,
      },

      label: {
        fontSize: '14px',
        fontWeight : 'bold',
      },
});

let pageName='';
let filterFlag=true;
let columns=[];
let data1=[];
let selRowsIndex;

let popUpData1;
let popUpColumns1;
let popUpMsg;
let errPopUpMsg;
let optionsPopUp;
var popUpData,fileds,title;

class AdministrationTemplate extends React.Component {
	constructor(){
		super();
		this.state={
			results:[],
			results1:[],
			reportdata:[],
			reportdatatable:[],
			value:0,
			openPopUp: false,
			screenName:''
		}

		this.doChange = this.doChange.bind(this);
		this.doFilterChange = this.doFilterChange.bind(this);
		this.checkClick = this.checkClick.bind(this);
		this.doRefresh = this.doRefresh.bind(this);
	}

	componentDidMount() {
		console.log("Report Template componentDidMount")
		pageName=this.props.location.pathname;
		this.coldata=[];
		this.getFilter()
	}

    handleChange = (event, value) => {
        this.setState({ value });
        var filtObj = new FormData();
        if(value == '1'){
            filtObj.append("tabName",'PENDINGAPR');
        }else{
            filtObj.append("tabName",'VIEWALL');
        }

        this.props.dispatch(AdministrationActions.fetchReportData(filtObj));
    };

	componentDidUpdate(){
		// alert("componentDidUpdate")
		console.log("page name",pageName)
		console.log("this.props.location.pathname",this.props.location.pathname)
		if(pageName.length!==0 && pageName!==this.props.location.pathname)
		{
			filterFlag	= true;
			this.state.reportdata=[];
			pageName	= this.props.location.pathname;
			console.log("Report Template componentDidUpdate",pageName)
			this.coldata=[];
			//this.setState({results:[]})
			this.getFilter()
		}
		else
			pageName=this.props.location.pathname;
	}

	getFilter() {
		var filtObj = new FormData();
		this.props.dispatch(AdministrationActions.fetchReportData(filtObj));
	}

selectedRows(selRows)
{
	console.log("selected rws ", selRows);
	selRowsIndex=selRows;
	selRows.forEach((row,index) => {
		console.log("target record data::", data1[row.dataIndex])
	});
}

doApprove(scroll) {
var cnt=0;
//alert("clicked approve button:");
var rowCnt=data1.length;
console.log("mar 25, 2019 in approve columns values ",columns);
//alert("approve .. rowCnt::"+rowCnt);
      var jsonBody = new FormData();
	if(selRowsIndex != undefined && selRowsIndex.length!=0)
	{
		selRowsIndex.forEach((row,i) => {
			console.log("mar 25, 2019 successfull filled");
			jsonBody.append("chk"+cnt,"on");
			jsonBody.append("acctNbr"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Acct Nbr")]);
			jsonBody.append("processId"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Process Id")]);
			jsonBody.append("actionVal"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Action")]);
			jsonBody.append("selectedProd"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Product Id")]);
			jsonBody.append("selectedAcctNature"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Account Nature")]);
			jsonBody.append("ddaAcct"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Parent Id")]);
			console.log("mar 25, 2019 approve block Account Number value ::",columns.findIndex(e => e.name === "Acct Nbr"))
			cnt++;
		})
	}

 if(cnt > 0)
 {
   var user = JSON.parse(sessionStorage.getItem('user'));
   jsonBody.append("token",user[0].token);
   jsonBody.append("tabName","PENDINGAPR");
   jsonBody.append("actionFlag","APPROVE");
   jsonBody.append("MCAcctVecSize",rowCnt);
   jsonBody.append("clientFirm",sessionStorage.getItem('clientFirm'));
    if(confirm("Are you sure, you want to approve the data?"))
    {
		var url=alertConstants.URL+"/LOOKUP.do";
		axios({
		method: 'post',
		url:url,
		data: jsonBody,
		config: { headers: {'Content-Type': 'multipart/form-data' }}
		}).then((response)=>{
		popUpData = response.data;
		console.log("mar 26, 2019 approve.. response.data===>",popUpData)
		this.setState({ openPopUp: true, scroll });
		//alert("approve submited successfully");
		});
	}
	}else{
		alert("Please check atleast one check box");
	}
  }

doReject(scroll) {
var cnt=0;
//alert("clicked reject button:");
var rowCnt=data1.length;
console.log("mar 25, 2019 in approve columns values ",columns);
//alert("approve .. rowCnt::"+rowCnt);
      var jsonBody = new FormData();
	if(selRowsIndex != undefined && selRowsIndex.length!=0)
	{
		selRowsIndex.forEach((row,i) => {
			console.log("mar 25, 2019 successfull filled");
			jsonBody.append("chk"+cnt,"on");
			jsonBody.append("acctNbr"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Acct Nbr")]);
			jsonBody.append("processId"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Process Id")]);
			jsonBody.append("actionVal"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Action")]);
			jsonBody.append("selectedProd"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Product Id")]);
			jsonBody.append("selectedAcctNature"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Account Nature")]);
			jsonBody.append("ddaAcct"+cnt,data1[row.dataIndex][columns.findIndex(e => e.name === "Parent Id")]);
			console.log("mar 25, 2019 reject block Account Number value ::",columns.findIndex(e => e.name === "Acct Nbr"))
			cnt++;
		})
	}

  if(cnt > 0)
  {
   var user = JSON.parse(sessionStorage.getItem('user'));
   jsonBody.append("token",user[0].token);
   jsonBody.append("tabName","PENDINGAPR");
   jsonBody.append("actionFlag","REJECT");
   jsonBody.append("MCAcctVecSize",rowCnt);
   jsonBody.append("clientFirm",sessionStorage.getItem('clientFirm'));
	if(confirm("Are you sure, you want to reject the data?"))
	{
		var url=alertConstants.URL+"/LOOKUP.do";
		axios({
		method: 'post',
		url:url,
		data: jsonBody,
		config: { headers: {'Content-Type': 'multipart/form-data' }}
		}).then((response)=>{
		popUpData = response.data;
		console.log("mar 26, 2019 .approve. response.data===>",popUpData)
		//alert("reject submited successfully");

		this.setState({ openPopUp: true, scroll });
		});
	}
    }else{
    		alert("Please check atleast one check box");
	}
    };

handlePopUpClose = () => {
       popUpMsg="";
       errPopUpMsg="";
      //alert("in main popup close popup ...");
      this.setState({ openPopUp: false });
	var filtObj = new FormData();
	filtObj.append("tabName", "PENDINGAPR");
	this.props.dispatch(AdministrationActions.fetchReportData(filtObj));
 };

	doRefresh(tbType) {
	        //alert("tbType:::"+tbType);
		var filtObj = new FormData();
		filtObj.append("tabName", tbType);
		this.props.dispatch(AdministrationActions.fetchReportData(filtObj));
	}

	checkClick(cData, paramVal) {
		if(paramVal == 'TRADEENTRY' || paramVal == 'CLOSEACCOUNT') {
			this.props.history.push({
				pathname: '/DEALENT',
				state: {
					tabIndex: 0,
					activeStep: 0,
					paramVal: paramVal,
					fromPage:'ViewChanges',
					fromLink: this.props.location.pathname,
					bformdata: cData
				}
			});
		} else if(paramVal == 'TRADEHISTORY') {
			this.props.history.push({
				pathname: '/report/TRDINQR',
				state: {
					fromPage:'ViewChanges',
					fromLink: this.props.location.pathname,
					product: 'ALL',
					issueChild: 'ALL',
					productName: cData.subprodname,
					clientFirmName: cData.clientFirmName,
					currencyCode: cData.currency
				}
			});
		} else if(paramVal == 'EDITACCOUNT') {
			this.props.history.push({
				pathname: '/administration/MMFEDITACCT',
				state: {
					fromPage:'ViewChanges',
					fromLink: this.props.location.pathname,
					mmmfAcct: cData.escrowacctnbr,
					clientFirm: cData.clientFirm,
					product: cData.subprodname,
					currency: cData.currency,
				}
			});
		}
	}

	doChange(fillObj) {
		var bodyFormData = new FormData();
		for (name in fillObj) {
			bodyFormData.append(name, fillObj[name]);
	}
		this.props.dispatch(AdministrationActions.fetchReportTableData(bodyFormData));
	}

	doFilterChange(fillObj) {
		//alert("chkStatus "+fillObj.get('chkStatus'));
		//alert("acctNature "+fillObj.get('acctNature'));
		this.props.dispatch(AdministrationActions.fetchReportData(fillObj));
	}
    render() {
    		let dataFlag=true;
		let tabName='VIEWALL';
		let msgTxt="";
		let msg="";
		let operVal="";
		let mcProcess="";
		const { classes } = this.props;
		const { value } = this.state;
		var commonData = [],checkPosition;
		console.log("this.props.adminreportdata===>",this.props.adminreportdata)

        this.state.reportdata = this.props.adminreportdata;
        this.state.reportdatatable = this.props.reportdatatable;
        var results=[];
				console.log("this.state.results1===>",this.state.results1)
        if( this.props.adminreportdata.adminreportdata !== undefined){
					this.state.results1  = this.state.reportdata.adminreportdata;
             this.state.results1.map((item,index) => {
                if(item.type === "Title")
                 this.state.screenName = item.name

		var mainList=this.state.results1.find(item =>item.name ==="commonData")// === listName)
		if(mainList!==undefined && mainList.commonData!==undefined)
			commonData = mainList.commonData;

	   mainList=this.state.results1.find(item =>item.name ==="checkPosition")// === listName)
           if(mainList!==undefined && mainList.value!==undefined){
              checkPosition = parseInt(mainList.value);
              //alert("checkPosition:::"+checkPosition);
           }
		tabName=commonData.TABNAME;
		msgTxt=commonData.Message;
		mcProcess=commonData.mcProcess;
        operVal=commonData.operVal;
        //console.log("operVal:::::::::::::;:",operVal);
                if(item.name === "DATA"){
                    results = item.DATA;
                    data1 = item.DATA;
                    //alert("mar 26, 2019 data1::"+data1);
                    //console.log("mar 26, 2019  .. data1::",data1);
                }
                if(item.name === "columns")
                    columns = item.COLUMNS
		})
		} else{
            return(
                <Loading />
            )
        }

		let screenLinkImage;
		if(this.props.location.pathname!== undefined && this.props.location.pathname.length!==0) {
			let pos=this.props.location.pathname.lastIndexOf('/');
			//console.log("position value::",pos);
			screenLinkImage=this.props.location.pathname;
			screenLinkImage=screenLinkImage.substring(pos+1,screenLinkImage.length)
			//alert("screenLinkImage::"+screenLinkImage)
			//console.log("screenLinkImage value::",screenLinkImage);
		}

		columns && columns.map((item,index)=> {
			if(item.options.hyperlink === "true" && (pageName === "/administration/LOOKUP" || pageName === "/administration/CRALKUP"))
			{
				//alert("before ScrollDialogPopUp");
				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
					return (
						<ScrollDialogPopUp
							onClick={e => this.openPopUp(e, tableMeta)}
							rowData={tableMeta}
							linkName={value}
							tabName={tabName}
							func ={this.checkClick }
							goback ={this.doRefresh }
							screenLinkImage={screenLinkImage} />
					);
				}
			}
		})

		var paginationFlag=true;


		let approveBtn="";
		let rejectBtn="";
		let createBtn="";
		let htmlMsg="";
		let filterMsg="";
		let headTxt="";
		let checkBoxFlag=false;

		if(tabName === 'PENDINGAPR')
		{
		  if(data1 !== undefined && data1.length > 0)
		  {
			approveBtn=<button onClick={e => this.doApprove("paper")} className="btn btn-primary btn-xs mt">Approve</button>
			rejectBtn=<button onClick={e => this.doReject("paper")} className="btn btn-primary btn-xs mt">Reject</button>
			checkBoxFlag=true;
			msg = <div style={{ color: 'red', textAlignVertical: "left",textAlign: "left", }}  className="col-md-12 col-sm-12">{msgTxt==="empty"?"":msgTxt}</div>
		}}else{

			createBtn=<Route render={({ history}) => (
				<button  className="btn btn-primary btn-xs"
					type='button'
					onClick={() => { history.push('/administrationcreate/NEWMMDAACCT') }}
				>
					Create New Account
				</button>
			)} />

			htmlMsg=<div className="panel">
			<div className="panel-heading clearfix">
			<h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
			<a className="pull-right" onClick={this.tottgleDisplay}>
			<i className="fa fa-caret-down"></i>
			</a>
			</div>
			</div>
			filterMsg="filter_div";
			headTxt="head-cls";
		}
		const options = {
			filterType: "dropdown",
			textLabels: {
				body: {
						noMatch: this.props.isLoading ?
								<Loader /> :
								'Sorry, there is no matching data to display',
				},
			},
			selectableRows: checkBoxFlag,
			isRowSelectable: (dataIndex) => {
				console.log("checkPosition .....", checkPosition);
				return data1[dataIndex][checkPosition] !== "disabled";
			},
			onRowsSelect: (rowsSelected, allRows) => {
				       this.selectedRows(allRows);
				      console.log("here" , rowsSelected);
			},
			responsive: "scroll",
			pagination:paginationFlag,
			// rowsPerPage:(paginationFlag===false)?data1.length:10,
			fixedHeader: false
		};

if( popUpData !== undefined && popUpData.toString().trim().length!==0){
     var commonPopUpData = [];
     let messageTxt = 'empty';
     let errMsg='empty';
     console.log("view changes popup  popUpData::",popUpData);

  	var popUpList=popUpData.find(item =>item.name ==="commonData")// === listName)

  	if(popUpList!==undefined && popUpList.commonData!==undefined)
  	  commonPopUpData = popUpList.commonData;
   	  title=commonPopUpData.screenName;
   	  messageTxt=commonPopUpData.Message;
   	  errMsg=commonPopUpData.errMsg;

  	popUpMsg = <div style={{ color: 'red', textAlignVertical: "left",textAlign: "left", }}  className="col-md-12 col-sm-12">{messageTxt === "empty"?"":messageTxt}</div>
  	errPopUpMsg = <div style={{ color: 'red', textAlignVertical: "left",textAlign: "left", }}  className="col-md-12 col-sm-12">{errMsg === "empty"?"":errMsg}</div>


  	var popUpList=popUpData.find(item =>item.name ==="columns")// === listName)
  	popUpColumns1 = popUpList.COLUMNS;

  	popUpList=popUpData.find(item =>item.name ==="DATA")// === listName)
  	popUpData1 = popUpList.DATA;

  	optionsPopUp = {
  		filterType: "dropdown",
  		selectableRows: false,
  		pagination: false,
          	rowsPerPage: 10,
  		responsive: "scroll",
  		fixedHeader: false,
  		filter:false,
  		search:false,
  		print:false,
  		download:false,
  		viewColumns:false,
  	};
      console.log("pendng approval mmf fund accounts field values::",commonPopUpData);
  }

  //console.log("mar 28, 2019 ... results :",results);
  let noDataFlag=false;
  if(results!== undefined && results.length!==0)
  {
    noDataFlag=true;
  }
		return(
			<div>
			<div>
				<NavBar/>
				<div className="panel panel-primary clearfix" style={{clear:'both'}}>
					<div className="panel-heading">
						<h4 className="panel-title">{this.state.screenName}</h4>
					</div>
					<div className="panel-body">
						{
							( mcProcess!== undefined && mcProcess === 'true') &&
							<div className={classes.root} style={{float:'left'}}>
								<Tabs value={value}
									onChange={this.handleChange}
									classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }} >
									<Tab
										disableRipple
										classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
										label="View All" />
									<Tab
										disableRipple
										classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
										label="Pending Approval" />
								</Tabs>
							</div>
						}

						{(filterMsg !== undefined && filterMsg.length >0) &&
						<div className="col-md-12 col-sm-12 head-cls">
							{htmlMsg}
							<div className={filterMsg} id={filterMsg} >
								<Grid container spacing={24}>
									<Grid item xs={10}>
										{
											tabName === 'VIEWALL'?
											<AdmnFilters method={this.doFilterChange} data={this.state.reportdata}/>:""
										}
									</Grid>
									<Grid item xs={2}>
										{createBtn}
									</Grid>
								</Grid>
							</div>
						</div>
						}

						<div className="clearfix"></div>
						<div className="col-md-12 col-sm-12 head-cls backwhite">
							<div className="panel">
								<div className="panel-heading clearfix">
									<h4 className="panel-title pull-left col-md-1">Search Results</h4>
								</div>
							</div>
							{/* <ReactTable showPagination={false} resizable={false} noDataText="No Data Found" data={this.state.results} columns={this.state.columns}  className="table table-striped" /> */}

							{
							noDataFlag === true ?
							(
							<div className="col-md-12 col-sm-12">
						 	{
								results !== undefined ?
								<div>
								<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
									<MUIDataTable
									data={results}
									columns={columns}
									options={options}
									/>
								</MuiThemeProvider>
								{msg}
								{approveBtn}
								{rejectBtn}
								</div>
								:
								<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
							}
							</div>
							)
							:
							<div style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">No Data Found</div>
							}
						</div>
					</div>
				</div>
			</div>
				<div>
				<Dialog
				open={this.state.openPopUp}
				onClose={this.handlePopUpClose}
				scroll={this.state.scroll}
				aria-labelledby="scroll-dialog-title"
				fullWidth={true}
				maxWidth = {'md'}
				>
				<DialogTitle id="scroll-dialog-title">

				</DialogTitle>
				<DialogContent>
				<DialogContentText>
				<div className="clearfix"></div>
				<div>
				{popUpMsg}
				</div>
				<div className="clearfix"></div>
				{
				dataFlag === true ?
				(
				popUpData1 !== undefined ?
				<MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
				  <MUIDataTable
				  data={popUpData1}
				  columns={popUpColumns1}
				  options={optionsPopUp}
				  />
				</MuiThemeProvider>
				:
				<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
				)
				:
				<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div></div>
				}
				</DialogContentText>

				</DialogContent>
				<DialogActions>
					<button onClick={this.handlePopUpClose} className="btn btn-primary btn-xs mt pull-center">Ok</button>
				</DialogActions>
				</Dialog>
			  </div>
			</div>
		);
	}
}

AdministrationTemplate.propTypes = {
    classes: PropTypes.object.isRequired,
};

function mapStateToProps(state) {
    const { adminreportdata,reportdatatable } = state;
    return { adminreportdata,reportdatatable };
}

const connectedAdministrationTemplate = connect(mapStateToProps)((withStyles(styles))(AdministrationTemplate));
export { connectedAdministrationTemplate as AdministrationTemplate };
