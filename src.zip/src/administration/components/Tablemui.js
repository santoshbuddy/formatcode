import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { Route , withRouter} from 'react-router-dom';


const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
});

let id = 0;
function createData(FundFamily, FundName, FundType, Currency, Action) {
  id += 1;
  return { id, FundFamily, FundName, FundType, Currency, Action };
}

class MuiTable extends React.Component{
    constructor(props) {
        super(props);
        this.state ={
            columns:[]
         }
          // this.routeChange = this.routeChange.bind(this);
          
      }

      doSelect(obj){
        this.props.method(obj);
      }
     
      
    

    render(){        
        const { classes } = this.props; 
        const {data} = this.props;
        console.log('data <><>:'+JSON.stringify( data ));

        console.log(this.props.data)

        if(data) {
            data.map((item,index) => {
                if(index === 0){
                    var s =  item;                     
                    for(var k in s) {
                        if(k === "Action"){
                            console.log('action')
                            
							this.state.columns.push({
								id: "btn",
								accessor: "",
								Cell: ({ original }) => { 
									return (
										<div>
											<button className="btn btn-primary btn-xs">Select</button>
										</div>
									);
								},
								Header: x => {
									return (
										 ""
									);
								} 
                            })
                        }
                        else {
                        this.state.columns.push({
                            Header: k,
                            accessor: k 
                            });
                        }
                    }
                }
            }); 
           
        }
         
        console.log('result1 columns<><>:'+JSON.stringify( this.state.columns	));   
        return  (
            <Paper className={classes.root}>
              <Table className={classes.table}>
                <TableHead>
                     <TableRow>
                           <TableCell>Fund Family</TableCell>
                           <TableCell align="right">Fund Name</TableCell>
                           <TableCell align="right">Fund Type </TableCell>
                           <TableCell align="right">Currency </TableCell>
                           <TableCell align="right">Action </TableCell>
                     </TableRow>
                </TableHead>
                <TableBody>
                  {data && data.map(row => {
                    return (
                      <TableRow key={row.id}>
                        <TableCell component="th" scope="row">
                          {row.FundFamily}
                        </TableCell>
                        <TableCell align="right">{row.FundName}</TableCell>
                        <TableCell align="right">{row.FundType}</TableCell>
                        <TableCell align="right">{row.Currency}</TableCell>
                        <TableCell align="right">
                       
                          <button className="btn btn-primary btn-xs" onClick={()=>this.doSelect(row.FundFamily)} >Select</button></TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </Paper>)
    }

}

export default (withStyles(styles))(MuiTable);