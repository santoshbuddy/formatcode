import React from 'react';
import { Router, Route, Link } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { AdministrationActions } from '../actions/administration.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import { createMuiTheme,MuiThemeProvider, withStyles } from '@material-ui/core/styles';
import '../../user/css/App.css';
import FormData from 'form-data';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import ViewAll from './ViewAll';
import Loading from '../../common/Loading';

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
      marginTop:'0px',
    },
    table: {
      minWidth: 700,
    },

    tabsRoot: {
        borderBottom: '1px solid #e8e8e8',
      },
      tabsIndicator: {
        backgroundColor: '#1890ff',
      },
      tabRoot: {
        textTransform: 'initial',
        minWidth: 72,
        fontWeight: theme.typography.fontWeightRegular,
        marginRight: theme.spacing.unit * 4,
        // fontFamily: [
        //   '-apple-system',
        //   'BlinkMacSystemFont',
        //   '"Segoe UI"',
        //   'Roboto',
        //   '"Helvetica Neue"',
        //   'Arial',
        //   'sans-serif',
        //   '"Apple Color Emoji"',
        //   '"Segoe UI Emoji"',
        //   '"Segoe UI Symbol"',
        // ].join(','),
        '&:hover': {
          color: '#40a9ff',
          opacity: 1,
        },
        '&$tabSelected': {
          color: '#1890ff',
          fontWeight: theme.typography.fontWeightMedium,
        },
        '&:focus': {
          color: '#40a9ff',
        },
      },
      tabSelected: {},
      typography: {
        padding: theme.spacing.unit * 3,
      },

      label: {
        fontSize: '14px',
        fontWeight : 'bold',
      },
});


    let selectdata;
    let data=[];
    let vecSize= '';
class AlertMgmtTemplate extends React.Component {
    getMuiTheme = () => createMuiTheme({
        typography: {
            useNextVariants: true,
        },
        overrides: {
            MuiFormControl: {
                marginNormal: {
                    marginTop: '0px',
                    marginBottom: '0px',
                }
            },
            MuiIconButton: {
                root: {
                    padding: '2px',
                }
            },
            MUIDataTableBodyCell: {
                root: {
                    whiteSpace: 'nowrap',
                    padding:'0px 56px 0px 24px'
                }
            },
            MUIDataTableBodyRow: {
                root: {
                    height: '20px',
                }
            },
        }
    })

    constructor() {
        super();
        this.state={
            results:[],
            reportdata:[],
            reportdatatable:[],
            results1:[],
            columns:[],
            clientFirm:'',
            screenName:'',
            open: false,
            value: 0,
            flag:'',
        }
        // this.doChange = this.doChange.bind(this);
        this.doShowLayer = this.doShowLayer.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.handleClientFChange = this.handleClientFChange.bind(this);
        this.doRefresh=this.doRefresh.bind(this);
     }

    componentDidMount() {
        this.getFilter()
    }
    getFilter(){
        //alert(this.state.value);
	var filtObj = new FormData();
        this.props.dispatch(AdministrationActions.fetchReportData(filtObj));
    }

    doShowLayer() {
        this.setState({ open: true });
    }

    handleClose() {
        this.setState({ open: false })
    }

    handleClientFChange(obj){
        this.setState({clientFirm:obj.target.value});
    }

    handleChange = (event, value) => {
        this.setState({ value });
	var filtObj = new FormData();
	if(value == '1'){
		filtObj.append("tabName",'PENDINGAPR');
	}else{
		filtObj.append("tabName",'VIEWALL');
	}

        this.props.dispatch(AdministrationActions.fetchReportData(filtObj));
    };

    doRefresh(jsonBody){
    	//var filtObj = new FormData();
    	jsonBody.append("tabName",'PENDINGAPR');
 	    this.props.dispatch(AdministrationActions.fetchReportData(jsonBody));
	}


    render(){
        const { classes } = this.props;
        const { value } = this.state;
        const options = {
            filter: true,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:false
        };

        var statusMsg	= '';

        this.state.reportdata = this.props.adminreportdata;
        this.state.reportdatatable = this.props.reportdatatable;
        this.state.results1  = this.state.reportdata.adminreportdata;

        // console.log("size0::::::>",this.state.results1  = this.state.reportdata)
        // if(this.state.reportdata.reportdata!==undefined)

        // console.log("size1::::::>",this.state.results1  = this.state.reportdata.reportdata)
        // console.log("size3::::::>",this.state.results1  = this.state.reportdata.reportdata.find(e =>))

        if( this.props.adminreportdata.adminreportdata !== undefined){
        this.state.results1 && this.state.results1.map((item,index) => {
            if(item.type === "Title"){
                 this.state.screenName = item.name
                 this.state.flag = item.flag
            }
                 if(item.name === "data")
                 this.state.results = item.values

                 if(item.name === "clientFirm")
                 selectdata = item.values

                 if(item.name === "message")
                 statusMsg = item.value;
                })


                if(vecSize !== undefined && vecSize.length>0)
                    vecSize = this.state.reportdata.adminreportdata.find(e=>e.commonData).commonData.dataVecSize;
        }else {
            return(
                <Loading />
            );
        }
            data=[];
            if(this.state.results !== undefined) {
                this.state.results.map((row,index) => {
                    let cdata=[];
                    cdata.push(row.TemplateName);
                    cdata.push(row.alertStatus);
                    cdata.push(row.ClientName);
                    cdata.push(row);
                    data.push(cdata);
                });
            }
            // console.log('data>>>>>>'+JSON.stringify(data));
        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{this.state.screenName}</h4>
                    </div>
                    <div className="panel-body">
                    	<div className="text-center displayTxt">{statusMsg}</div>
                        {
                            (this.state.flag === 'Checker' || this.state.flag === 'Maker') &&
                            <div className={classes.root} style={{float:'left'}}>
                                <Tabs
                                value={value}
                                onChange={this.handleChange}
                                classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}
                                >
                                <Tab
                                    disableRipple
                                    classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
                                    label="View All"
                                />
                                <Tab
                                    disableRipple
                                    classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
                                    label="Pending Approval"
                                />
                                </Tabs>
                                <div className="clearfix"></div>
                                {value === 0 &&
                                    <div>
                                        <ViewAll data={data} vecsize={vecSize} roleFlag={this.state.flag} TabType={this.state.value}/>
                                    </div>
                                }
                                {value === 1 &&
                                    <div>
                                        <ViewAll data={data} vecsize={vecSize} roleFlag={this.state.flag} doRefresh={this.doRefresh} TabType={this.state.value} data1={this.props.adminreportdata}/>
                                    </div>
                                }
                            </div>
                        }
                        {

                            (this.state.flag !== 'Checker' && this.state.flag !== 'Maker') &&
                            <ViewAll vecsize={vecSize} roleFlag={this.state.flag} data={data}/>
                        }
                    </div>
                </div>
            </div>
        );
    }
}
function mapStateToProps(state) {
    const { adminreportdata,reportdatatable } = state;

    return { adminreportdata,reportdatatable };
}

const connectedAlertMgmtTemplate = connect(mapStateToProps)((withStyles(styles))(AlertMgmtTemplate));
export { connectedAlertMgmtTemplate as AlertMgmtTemplate };
