import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { AdministrationActions } from '../actions/administration.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import '../../user/css/App.css';
import axios from 'axios';
import FormData from 'form-data';
import { alertConstants } from '../../common/constants/alert.constants';
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import MUIDataTable from "mui-datatables";
import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import NativeSelect from '@material-ui/core/NativeSelect';
import {addCommasAmntLocale,IsCharsInBag} from '../../tradeentry/components/amountValidations';
import Info from "@material-ui/icons/Info";
import Tooltip from '@material-ui/core/Tooltip';
import Loading from '../../common/Loading';
import infoIcon from '../../images/questionmark.png';

function arrayRemove(arr, value) {

    return arr.filter(function(ele){
        return ele != value;
    });

}

const Columns = [
    {
        name: 'Alert Frequency',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Time Interval (Hours)',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Alert When Amount is Greater Than',
        options: {
            filter: true,
            sort: false,
        }
    }
]

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
    tableheader: {
        background:'#ccc'
    },
    tabletheadtr: {
        height: '37px'
    },
    tabletheadth: {
        color:'#333',
        fontWeight:'bold',
        fontSize:'12px',
        paddingTop: '4px',
        paddingBottom: '4px'
    },
    tabletbodytr: {
        height: '32px'
    },
    tabletbodytd: {
        fontSize: '12px'
    }
});

let temp = [];
var results=[];
let value='';
let ClientFirm= '';
class NewAlertTemplate extends React.Component {
    getMuiTheme = () => createMuiTheme({
        typography: {
            useNextVariants: true,
        },
        overrides: {
             MuiFormControl: {
                                  marginNormal: {
                                      marginTop: '0px',
                                       marginBottom: '0px',
                                   }
          }, MuiIconButton: {
                                  root: {
                                      padding: '2px',
                                   }
          },
          MUIDataTableBodyCell: {
            root: {
                whiteSpace: 'nowrap',
                padding:'0px 56px 0px 24px'
             }
          },
          MUIDataTableBodyRow: {
                      root: {
                          height: '20px',
                       }
          }
        }
    })
    constructor(props){
        super(props);
        this.state={
            results1:[],
            reportdata:[],
            reportdatatable:[],
            alerttempdatadet:[],
            columns:[],
            screenName:'',
            selection:[],
            selectAll:false,
            templateName:'',
            clientFirm:'ALL',
            selectedValues:[],
            alertVal:'',
            msg:''
        }
        // this.doChange = this.doChange.bind(this);
        this.doCreate = this.doCreate.bind(this);
        this.doSelectAll = this.doSelectAll.bind(this);
        this.doCancel = this.doCancel.bind(this);
        this.fileTypeChange = this.fileTypeChange.bind(this);
        this.fileAmtChange = this.fileAmtChange.bind(this);
        this.toggleCheck = this.toggleCheck.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleClientFChange = this.handleClientFChange.bind(this);

    }

    // doChange(fillObj){
    //     var bodyFormData = new FormData();
    //     for (name in fillObj) {
    //         bodyFormData.append(name, fillObj[name]);
    //     }
    //     this.props.dispatch(AdministrationActions.fetchReportTableData(bodyFormData));
    // }

    componentWillMount(){
        var bodyFormData = new FormData();
        this.props.dispatch(AdministrationActions.fetchAlertTempData(bodyFormData));
    }
    doCancel(){
        window.scroll(0,0);
        const selectAll =this.state.selectAll === true ?false:true;
        this.setState({ selectAll:false,selection:[]});
        this.setState({ templateName:'' });
    }
    doSelectAll(){
        // console.log('itemp   '+JSON.stringify( temp ));
        const selectAll =this.state.selectAll === true ?false:true;
        if(selectAll){
            this.setState({ selectAll:selectAll,selection:temp})
        }else {
            this.setState({ selectAll:selectAll,selection:[]})
        }

    }
    toggleCheck(e) {
        let {selection} =this.state;
            // console.log("name",e.target.name)

        if(!selection.includes(e.target.name)){
            // console.log('<<IFFF>>>>'+JSON.stringify(selection));
            selection.push(e.target.name);
            // console.log('<<after>>>>'+JSON.stringify(selection));
            this.setState({ selectAll:false,selection:selection})
        }else {
            // console.log('<<Elseee>>>>'+JSON.stringify(selection));
            selection= arrayRemove(selection,(e.target.name));
            // console.log('<<after>>>>'+JSON.stringify(selection));
            this.setState({ selectAll:false,selection:selection})
            this.state.selection.length= this.selection.length-1;
        }

        if(this.state.selection.length === temp.length)
            this.setState({ selectAll:true})
      }
    handleChange(obj){
        this.setState({templateName:obj.target.value});
        // console.log(obj.target.value)
    }
    handleClientFChange(obj){
        this.setState({clientFirm:obj.target.value});
        // console.log("obj.target.value",this.refs["selclientFirms"])
    }

    alertType(obj, e) {
        this.setState({alertVal:e.target.value});
    }

	doCreate(filterdata)
	{
		var bodyFormData 	= new FormData();
        var myArray 		= [];

		if(this.state.templateName !== '')
		{
            if(!IsCharsInBag(this.state.templateName,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ")){
                alert('Please enter valid template name.')
            }
            else{
                if(this.state.selection.length>0)
                {
                    if(window.confirm('Are you sure, you want to save the data?')){
                        // console.log(temp.length)
                        temp && temp.map((value,index)=>{
                            if((this.refs['menuChk'+index] !== undefined) && (this.refs['menuChk'+index].props.checked))
                            {
                                myArray.push({id:'menuChk'+index, value:this.refs['menuChk'+index].props.value})
                                myArray.push({id:'selEventId'+index, value:this.refs['menuChk'+index].props.value})

                                if(this.refs['amountAlert'+index] !== undefined) {
                                    myArray.push({id:'amountAlert'+index, value:this.refs['amountAlert'+index].props.defaultValue})
                                }

                                if(this.refs['alertFrequency'+index] !== undefined) {
                                    myArray.push({id:'alertFrequency'+index, value:this.refs['alertFrequency'+index].props.defaultValue})
                                }

                                if(this.refs['timeInterval'+index] !== undefined) {
                                    myArray.push({id:'timeInterval'+index, value:this.refs['timeInterval'+index].props.defaultValue})
                                }

                                if(this.refs['fileType'+index] !== undefined) {
                                    myArray.push({id:'fileType'+index, value:this.refs['fileType'+index].props.defaultValue})
                                }
                            }
                        });

                        this.state.selectedValues && this.state.selectedValues.map((item, index) => {
                            let obj	= myArray.find(namevalue => namevalue.id === item.id);
                            if(obj!== undefined)
                            {
                                obj.value = item.value;
                            }
                        });

                        myArray && myArray.map((item, index) => {
                            bodyFormData.append(item.id, item.value);
                        });

                        var user = JSON.parse(sessionStorage.getItem('user'));
                        bodyFormData.append('newTemplate',this.state.templateName);
                        bodyFormData.append('size',temp.length);
                        bodyFormData.append('alertType',this.state.alertVal);
                        bodyFormData.append('clientFirm',document.getElementById("selclientFirms").value);

                        if(user[0].token !== undefined)
                        {
                            bodyFormData.append('token',user[0].token);
                        }

                        bodyFormData.append('actionFlag', "SAVE");
                        var data;
                        axios({
                            method: 'POST',
                            url:alertConstants.URL+"/CLEMAIL.do",
                            data: bodyFormData,
                            config: { headers: {'Content-Type': 'multipart/form-data' }}
                        }).then((response)=>{
                            data = response.data;
                            this.setState({msg:data.message})
                        });
                        window.scrollTo(0,0);
                    }
                }
                else
                {
                    alert("Please Check atleast one check box");
                }
            }
		}
		else
		{
		    alert('Please enter Template Name')
		}
	}

    fileTypeChange(e) {
        var temp = e.target.name;
        this.state.selectedValues.push({id:e.target.name,value:e.target.value})

        console.log('this.state.selectedValues <><>:'+JSON.stringify( this.state.selectedValues ));
        // console.log("--before--",+e.target.value.toString());
        // e.target.defaultValue = e.target.value;
        // this.setState({ Ck:0});
        // console.log("--after--",+e.target.defaultValue.toString());
        // console.log("--after--",+e.target.value.toString());
    }

    fileAmtChange(e) {
        let userLocale="";
        var user = JSON.parse(sessionStorage.getItem('user'));
        if(user[0].localeLang !== undefined){
            userLocale=user[0].localeLang;
        }
        addCommasAmntLocale(e,userLocale, true,this)
        var temp = e.target.name;
        this.state.selectedValues.push({id:e.target.name,value:e.target.value})

        // console.log('this.state.selectedValues <><>:'+JSON.stringify( this.state.selectedValues ));
    }
    render() {
        const { classes } = this.props;
        const { alerttempdatadet} = this.props;
        temp = [];
        this.state.reportdata = this.props.reportdata;
        this.state.results1 = this.state.reportdata.reportdata;

        var filterdata = alerttempdatadet.alerttempdatadet;

        if(filterdata !== undefined) {
            this.state.screenName = filterdata.Title.Title;
            results = filterdata.data;
        //    console.log('filterdataData--- <><>:'+JSON.stringify(filterdata));
          //  console.log('Data--rows <><>:'+JSON.stringify(this.state.results));
        let menuChk=0;
        let rowsdata
        let checkBox=[];
        const headerRow =
            <TableRow>
                <TableCell>
                    <Checkbox defaultChecked={false} checked={this.state.selectAll?true:false} onChange={this.doSelectAll} />Select All Alerts</TableCell>
                <TableCell>Alert Frequency</TableCell>
                <TableCell align="right">Time Inverval (Hours)</TableCell>
                <TableCell align="right">Alert When Amount is Greater Than</TableCell>
            </TableRow>;

            const Bodydata = results && results.map((row, index) => {
                  // console.log('rewwww'+row.rows)
                  rowsdata = row.rows && row.rows.map((rowdata, newindex) => {

                    temp.push("menuChk"+menuChk);
                    return (

                        <TableRow key={newindex} className={(newindex%2 ? 'even' : 'odd')}>
                            <TableCell style={{width:'500px'}} className={classes.tabletbodytd}>
                            <Checkbox ref={"menuChk"+menuChk} name={"menuChk"+menuChk} defaultChecked={false} checked={this.state.selection.includes("menuChk"+menuChk)?true:false} id={"check"+menuChk} value={rowdata.selEventId} onChange={this.toggleCheck}/>
                            {rowdata.alertName}
                                {
                                    (rowdata.fileTypeFlag === "true") &&
                                    <NativeSelect className={classes.select} ref={"fileType"+menuChk} defaultValue={rowdata.fileTypeId[0]} onChange={this.fileTypeChange.bind(this)} name={"fileType"+menuChk} style={{float:'right',marginTop:'7px'}}>
                                        {filterdata.fileType.values && filterdata.fileType.values.map((obj,index) => {
                                            return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                            </TableCell>
                            <TableCell className={classes.tabletbodytd}>
                                {
                                    (rowdata.frequencyFlag === "true") &&
                                    <NativeSelect className={classes.select} ref={"alertFrequency"+menuChk} defaultValue={rowdata.frequencyId[0]} onChange={this.fileTypeChange.bind(this)} name={"alertFrequency"+menuChk} style={{width:'200px'}} id={rowdata.alertName} >
                                        {filterdata.frequency.values && filterdata.frequency.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                            </TableCell>
                            <TableCell className={classes.tabletbodytd}>
                                {
                                    (rowdata.timeIntervalFlag === "true") &&
                                    <NativeSelect className={classes.select} ref={"timeInterval"+menuChk} defaultValue={rowdata.timeInterval[0]} onChange={this.fileTypeChange.bind(this)} name={"timeInterval"+menuChk}>
                                        {filterdata.intervalHash.values && filterdata.intervalHash.values.map((obj,index) => {
                                            return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                            </TableCell>
                            <TableCell className={classes.tabletbodytd}>
                                {
                                    (rowdata.amountAlertFlag === "true") &&
                                    <TextField className={classes.inputStyle} style={{width:'100px'}} type="text" onBlur={this.fileAmtChange.bind(this)} ref={"amountAlert"+menuChk} name={"amountAlert"+menuChk} defaultValue={rowdata.amountAlert} />
                                }
                            </TableCell>
                            <span style={{display:"none"}}>{menuChk++}</span>
                        </TableRow>

                    )

                    }
                    );
                    return (
                        <TableBody key={index}>
                            <TableRow key={index} className={classes.tabletheadtr} style={{background:'#ccc'}}>
                                <TableCell colSpan={4} className={classes.tabletheadth}>{row.name}</TableCell>
                            </TableRow>
                            {rowsdata}
                        </TableBody>
                    );
                })
        return(
            <div>
                <NavBar/>
                <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                    <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                        <div className="panel-heading">
                            <h4 className="panel-title">{this.state.screenName}</h4>
                        </div>
                        <div className="panel-body">
                        {
                            this.state.msg !== "" &&
                            <div className="text-center displayTxt">{this.state.msg}</div>
                        }
                            <div className="col-md-12 col-sm-12 head-cls">
                                <div className="panel">
                                    <div className="panel-heading clearfix">
                                        <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                        <a className="pull-right" onClick={this.tottgleDisplay}>
                                            <i className="fa fa-caret-down"></i>
                                        </a>
                                    </div>
                                </div>
                                <div className="filter_div" id="filter_div" >
                                    <InputLabel className={classes.labelStyle} required htmlFor="age-native-label-placeholder">
                                        Template Name:
                                    </InputLabel>
                                    <TextField className={classes.inputStyle} type="text" ref="templateName" onBlur={this.handleChange} defaultValue={this.state.templateName} style={{width:'140px'}} inputProps={{ maxLength: 50 }}/>
                                    <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
                                        Client:
                                    </InputLabel>
                                    {
                                        (filterdata !== undefined && filterdata.Client && filterdata.Client.values && filterdata.Client.values.length>0) &&
                                    <NativeSelect className={classes.select} ref="selclientFirms" name="selclientFirms" id="selclientFirms" value={this.state.clientFirm === "All"?filterdata.Client.values[0].id:this.state.clientFirm} onChange={this.handleClientFChange} style={{width:'200px'}}>
                                        {filterdata.Client.values && filterdata.Client.values.map((obj,index) => {
                                            return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                    }
                                    <span>
                                        <Tooltip title="Notifications will be generated only for the selected Entities" aria-label="Add">
                                             <img src={infoIcon} width="18" className={classes.info}/>
                                        </Tooltip>
                                    </span>
                                    {/* <Filters method={this.doChange} data={this.state.reportdata}/> */}
                                </div>
                            </div>

                            <div className="clearfix"></div>
                            <div className="col-md-12 col-sm-12 head-cls backwhite">
                                {/* <div className="col-md-12 col-sm-12 col-xs-12 text-center mt">
                                    <label className="radio-inline">
                                        <input type="radio" name="alertType" defaultValue="E" onChange={() => this.alertType("true", event)}/>Email
                                    </label>
                                    <label className="radio-inline">
                                        <input type="radio" name="alertType" defaultValue="P" onChange={() => this.alertType("true", event)}/>Phone
                                    </label>
                                    <label className="radio-inline">
                                        <input type="radio" name="alertType" defaultValue="S" onChange={() => this.alertType("true", event)}/>SMS
                                    </label>
                                </div> */}
                                <Paper className={classes.root}>
                                    <Table className={classes.table}>
                                        <TableHead className={classes.tableheader}>
                                            {headerRow}
                                        </TableHead>

                                        {Bodydata}

                                    </Table>
                                </Paper>
                            </div>
                            <div className="col-md-6">
                                <a title="Create" onClick={(e)=>{this.doCreate(filterdata);}} className="btn btn-primary btn-xs">Create</a>
                                <a title="Cancel" onClick={(e)=>{this.doCancel()}} className="btn btn-primary btn-xs">Cancel</a>
                                {/* <Link to="/administrationnew/CLEMAIL" title="Cancel">Cancel</Link> */}
                            </div>
                        </div>
                    </div>
                </MuiThemeProvider>
            </div>
        );
    }else{
        return (
            <Loading />
        )
    }
}
}
function mapStateToProps(state) {
    const { reportdata,reportdatatable, alerttempdatadet } = state;
        // console.log('------1----------',reportdata)
        // console.log('---------2------',reportdatatable)
        // console.log('----------3------',alerttempdatadet)
    return { reportdata,reportdatatable, alerttempdatadet };
}

const connectedNewAlertTemplate = connect(mapStateToProps)(withStyles(MuiStyles)(NewAlertTemplate));
export { connectedNewAlertTemplate as NewAlertTemplate };