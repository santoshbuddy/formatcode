import React from 'react';
import DatePicker from 'react-datepicker';
import { withStyles } from '@material-ui/core/styles';
import 'react-datepicker/dist/react-datepicker.css';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import Info from "@material-ui/icons/Info";
import Tooltip from '@material-ui/core/Tooltip';
import { MuiThemeProvider } from '@material-ui/core/styles';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import infoIcon from '../../images/questionmark.png';
const styles = theme => ({
  margin: {
    margin: theme.spacing.unit,
  },
});
var dateFormat = require('dateformat');
let selFirm="All";
class Filters extends React.Component {
    constructor () {
        super()
        this.state = {
          startDate: new Date(),
          endDate: new Date()
        };
        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.handleEndDateChange = this.handleEndDateChange.bind(this);

      }
      componentWillMount(){
        // this.doChange();
      }
      componentWillReceiveProps(){
        if(this.props.data.assignAlertRecipientsData !== undefined){
         this.props.data.assignAlertRecipientsData.map((filter,index) => {
          if(filter.type === "datepicker"){
            if(filter.name === "fromDate")
                this.state.startDate=new Date(filter.value)
          }
         });
        }

      }
      handleStartDateChange(date) {
         this.setState({startDate:date});
      }
      handleEndDateChange(date) {
        this.setState({endDate:date});
     }
     doChange(e){
      console.log(this.refs)
      var filtObj = {};
      var bodyFormData = new FormData();
     if(this.props.data.assignAlertRecipientsData !== undefined)
      for(var i =0; i<this.props.data.assignAlertRecipientsData.length; i++){
         var temp = this.props.data.assignAlertRecipientsData[i].name;

          if(this.props.data.assignAlertRecipientsData[i].type === "Select"){
            filtObj[this.props.data.assignAlertRecipientsData[i].name] = this.refs[temp].props.defaultValue;
          }

          if(this.props.data.assignAlertRecipientsData[i].type === "datepicker"){
              if(this.props.data.assignAlertRecipientsData[i].name === "fromDate")
                filtObj[this.props.data.assignAlertRecipientsData[i].name] = dateFormat(this.state.startDate,"mmm d, yyyy");
              if(this.props.data.assignAlertRecipientsData[i].name === "toDate")
                filtObj[this.props.data.assignAlertRecipientsData[i].name] = dateFormat(this.state.endDate,"mmm d, yyyy");
           }
          }
          selFirm=document.getElementById("selFirm").options[document.getElementById("selFirm").selectedIndex].value;
          //alert(document.getElementById("clientFirm").options[document.getElementById("clientFirm").selectedIndex].value);
           bodyFormData.append("reactJSActionFlag","GO");
           bodyFormData.append("selFirm",selFirm);
            this.props.method(bodyFormData, selFirm);
            //alert(bodyFormData);
     }

    render(){
      console.log(this.props)
      const { classes } = this.props;
        const { data } = this.props;
        let filetermarkup;

        if(data.assignAlertRecipientsData !== undefined){
        filetermarkup = data.assignAlertRecipientsData.map((filter,index) => {
            if(filter.type === "Select"){
             return(
                <Grid item  key={filter.id.toString()}>
		{
			filter.label !== "" &&
			  <InputLabel className={classes.labelStyle} shrink htmlFor="age-native-label-placeholder">
			    { filter.label } :
			  </InputLabel>
		}
                    <NativeSelect className={classes.select}
                      ref={ filter.name }  name={filter.name} id={filter.name} defaultValue={filter.value}
                      >
                        {filter.values && filter.values.map((obj,index) => {
					if(selFirm!==undefined && selFirm.replace(/"/g,"") === obj.id.toString()){
					    return <option key={index} value={obj.id} selected={obj.id}>{obj.name}</option>
					}else{
					    return <option key={index} value={obj.id}>{obj.name}</option>
					}


                            })}
                      </NativeSelect>
                      <span>
                          <Tooltip title="You can change the Client Name selection to filter the User list" aria-label="Add">
                             <img src={infoIcon} width="18" className={classes.info}/>
                          </Tooltip>
                      </span>
                </Grid>
               );
            }else if(filter.type === "datepicker"){
                if(filter.name === "fromDate"){
                 return (
                  <Grid item  key={filter.id.toString()}>
                       <InputLabel className={classes.labelStyle}> { filter.label }:</InputLabel>
                      <TextField type="date" ref={ filter.name } name={filter.name}     selected={this.state.startDate}  onChange={this.handleStartDateChange} />
                   </Grid>
                 );
                }else if(filter.name === "toDate"){
                 return (
                  <Grid item  key={filter.id.toString()}>
                       <InputLabel className={classes.labelStyle}> { filter.label }:</InputLabel>
                      <TextField type="date" ref={ filter.name } name={filter.name}   selected={this.state.endDate}   onChange={this.handleEndDateChange} />
                   </Grid>
                 );
                }
              }else if(filter.type === "Button"){
                return (
                <span>
                 <button size="small" style={{height: 30, margin: 12}} className="btn btn-primary btn-xs"  title="Go" onClick={(e)=>{this.doChange();}} key={filter.id.toString()}>
                 { filter.name }
                </button>
                </span>
               );
              }else if(filter.type === "input"){
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle}> { filter.label } :</InputLabel>
                     <TextField ref={filter.name}  defaultValue={filter.name}/>
                  </Grid>
               );
              }else if(filter.type === "checkbox"){
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle}> { filter.label } :</InputLabel>
                     <TextField type="checkbox" ref={filter.name}/>
                  </Grid>
               );
              }else if(filter.type === "radio"){
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle}> { filter.label } :</InputLabel>
                     <TextField type="radio" ref={filter.name}/>
                  </Grid>
               );
              }else if(filter.type === "textarea"){
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle}> { filter.label } :</InputLabel>
                     <TextField type="textarea"   ref={filter.name} />
                  </Grid>
               );
              }else if(filter.type === "newline"){
                return  <div key="newline" className="clearfix"></div>
              }
        });
    }

        return(
          <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
            <Grid container spacing={24} >
                {filetermarkup}
            </Grid>
          </MuiThemeProvider>
        );
    }
}

export default withStyles(MuiStyles)(Filters);