import { administrationConstants } from '../constants/administration.constants';
import { administrationService } from '../services/administration.service';

export const AdministrationActions = {
    fetchReportData,
    fetchReportTableData,
    fetchUserData,
    fetchUserLinksPermData,
   fetchUserLinksViewChangesData,
   fetchUserApprovalViewChangesData,
   fetchUserApprovalData,
   fetchUserGroupsMgmtViewChangesData,
   fetchUserRolesTradeApprovalProcessViewChangesData,
   fetchUserRolesViewChangesData,
   fetchUserRolesEmailAddMaintainceViewChangesData,
   fetchAcctData,
   fetchGroupUserLinksPermData,
    fetchCNMFAccount,
    fetchMakerCheckerParams,
    saveCheckerParamsData,
    fetchAdminmfrevprosdata,
    fetchAssociatedUserDetPopUpData,
    fetchtempUserData,
    fetchIBAAcctData,
    fetchAlertTempData,
    fetchMmfeditAcctData,
    fetchViewChangeHistoryPopUpData,
    fetchMmfReviewProspectusData,
    fetchMmfcreateAcctData,
    fetchAssignAlertRecipientsData,
fetchassignAlertRecipientsTableData,
fetchFundAccountsData,
fetchResearchMoneyData
};

function fetchAdminmfrevprosdata(bodyFormData) {
   //alert("in actions");
    return dispatch => {
        dispatch(request());

        administrationService.fetchAdminmfrevpros(bodyFormData)
            .then(
                adminmfrevprosdata => dispatch(success(adminmfrevprosdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETADMINMFREVPROSDATA_REQUEST } }
    function success(adminmfrevprosdata) { return { type: administrationConstants.GETADMINMFREVPROSDATA_SUCCESS, adminmfrevprosdata } }
    function failure(error) { return { type: administrationConstants.GETADMINMFREVPROSDATA_FAILURE, error } }
}

function fetchCNMFAccount(bodyFormData) {
   //alert("in actions");
    return dispatch => {
        dispatch(request());

        administrationService.fetchCNMFAcct(bodyFormData)
            .then(
                cnmfaccountdata => dispatch(success(cnmfaccountdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETCNMFACCOUNTDATA_REQUEST } }
    function success(cnmfaccountdata) { return { type: administrationConstants.GETCNMFACCOUNTDATA_SUCCESS, cnmfaccountdata } }
    function failure(error) { return { type: administrationConstants.GETCNMFACCOUNTDATA_FAILURE, error } }
}

function fetchReportData(filtObj) {
    return dispatch => {
        dispatch(request());

        administrationService.fetchReport(filtObj)
            .then(
                adminreportdata => dispatch(success(adminreportdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETREPORTDATA_REQUEST } }
    function success(adminreportdata) { return { type: administrationConstants.GETREPORTDATA_SUCCESS, adminreportdata } }
    function failure(error) { return { type: administrationConstants.GETREPORTDATA_FAILURE, error } }
}

function fetchReportTableData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchReportTable(bodyFormData)
            .then(
                reportdatatable => dispatch(success(reportdatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETREPORTTBLDATA_REQUEST } }
    function success(reportdatatable) { return { type: administrationConstants.GETREPORTTBLDATA_SUCCESS, reportdatatable } }
    function failure(error) { return { type: administrationConstants.GETREPORTTBLDATA_FAILURE, error } }

}function fetchUserData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchUserData(bodyFormData)
            .then(
                userdata => dispatch(success(userdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERDATA_REQUEST } }
    function success(userdata) { return { type: administrationConstants.GETUSERDATA_SUCCESS, userdata } }
    function failure(error) { return { type: administrationConstants.GETUSERDATA_FAILURE, error } }

}
function fetchUserLinksPermData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchUserLinksPermData(bodyFormData)
            .then(
                userlinkspermdata => dispatch(success(userlinkspermdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERLIKSPERMDATA_REQUEST } }
    function success(userlinkspermdata) { return { type: administrationConstants.GETUSERLIKSPERMDATA_SUCCESS, userlinkspermdata } }
    function failure(error) { return { type: administrationConstants.GETUSERLIKSPERMDATA_FAILURE, error } }

}
function fetchGroupUserLinksPermData(bodyFormData,actionFlag){
    return dispatch => {
        dispatch(request());

        administrationService.fetchGroupUserLinksPermData(bodyFormData,actionFlag)
            .then(
                userlinkspermdata => dispatch(success(userlinkspermdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERLIKSPERMDATA_REQUEST } }
    function success(userlinkspermdata) { return { type: administrationConstants.GETUSERLIKSPERMDATA_SUCCESS, userlinkspermdata } }
    function failure(error) { return { type: administrationConstants.GETUSERLIKSPERMDATA_FAILURE, error } }

}


function fetchUserLinksViewChangesData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchUserLinksViewChangesData(bodyFormData)
            .then(
                userlinksviewchngsdata => dispatch(success(userlinksviewchngsdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERVIEWCHGSDATA_REQUEST } }
    function success(userlinksviewchngsdata) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_SUCCESS, userlinksviewchngsdata } }
    function failure(error) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_FAILURE, error } }

}
function fetchUserApprovalData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchUserApprovalData(bodyFormData)
            .then(
                userapprovaldata => dispatch(success(userapprovaldata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERAPPRVLDATA_REQUEST } }
    function success(userapprovaldata) { return { type: administrationConstants.GETUSERAPPRVLDATA_SUCCESS, userapprovaldata } }
    function failure(error) { return { type: administrationConstants.GETUSERAPPRVLDATA_FAILURE, error } }

}
function fetchUserApprovalViewChangesData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchUserApprovalViewChangesData(bodyFormData)
            .then(
                userapprovalviewchngsdata => dispatch(success(userapprovalviewchngsdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERAPPRVLVIEWCHGSDATA_REQUEST } }
    function success(userapprovalviewchngsdata) { return { type: administrationConstants.GETUSERAPPRVLVIEWCHGSDATA_SUCCESS, userapprovalviewchngsdata } }
    function failure(error) { return { type: administrationConstants.GETUSERAPPRVLVIEWCHGSDATA_FAILURE, error } }

}
function fetchUserGroupsMgmtViewChangesData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchUserGroupsMgmtViewChangesData(bodyFormData)
            .then(
                userlinksviewchngsdata => dispatch(success(userlinksviewchngsdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERVIEWCHGSDATA_REQUEST } }
    function success(userlinksviewchngsdata) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_SUCCESS, userlinksviewchngsdata } }
    function failure(error) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_FAILURE, error } }

}
function fetchUserRolesTradeApprovalProcessViewChangesData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchUserRolesTradeApprovalProcessViewChangesData(bodyFormData)
            .then(
                userlinksviewchngsdata => dispatch(success(userlinksviewchngsdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERVIEWCHGSDATA_REQUEST } }
    function success(userlinksviewchngsdata) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_SUCCESS, userlinksviewchngsdata } }
    function failure(error) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_FAILURE, error } }

}
function fetchUserRolesViewChangesData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchUserRolesViewChangesData(bodyFormData)
            .then(
                userlinksviewchngsdata => dispatch(success(userlinksviewchngsdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERVIEWCHGSDATA_REQUEST } }
    function success(userlinksviewchngsdata) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_SUCCESS, userlinksviewchngsdata } }
    function failure(error) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_FAILURE, error } }

}
function fetchUserRolesEmailAddMaintainceViewChangesData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchUserRolesEmailAddMaintainceViewChangesData(bodyFormData)
            .then(
                userlinksviewchngsdata => dispatch(success(userlinksviewchngsdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETUSERVIEWCHGSDATA_REQUEST } }
    function success(userlinksviewchngsdata) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_SUCCESS, userlinksviewchngsdata } }
    function failure(error) { return { type: administrationConstants.GETUSERVIEWCHGSDATA_FAILURE, error } }

}
function fetchMakerCheckerParams(bodyFormData, actionName){
    return dispatch => {
        dispatch(request());

        administrationService.fetchMakerCheckerParams(bodyFormData, actionName)
            .then(
                makercheckerdata => dispatch(success(makercheckerdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETMAKERCHECKERDATA_REQUEST } }
    function success(makercheckerdata) { return { type: administrationConstants.GETMAKERCHECKERDATA_SUCCESS, makercheckerdata } }
    function failure(error) { return { type: administrationConstants.GETMAKERCHECKERDATA_FAILURE, error } }

}
function saveCheckerParamsData(bodyFormData, actionName){
    return dispatch => {
        dispatch(request());

        administrationService.saveCheckerParamsData(bodyFormData, actionName)
            .then(
                makercheckerdata => dispatch(success(makercheckerdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETMAKERCHECKERDATA_REQUEST } }
    function success(makercheckerdata) { return { type: administrationConstants.GETMAKERCHECKERDATA_SUCCESS, makercheckerdata } }
    function failure(error) { return { type: administrationConstants.GETMAKERCHECKERDATA_FAILURE, error } }

}

function fetchAcctData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        administrationService.fetchAcctDet(bodyFormData)
            .then(
                acctdata => dispatch(success(acctdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETACCTDETDATA_REQUEST } }
    function success(acctdata) { return { type: administrationConstants.GETACCTDETDATA_SUCCESS, acctdata } }
    function failure(error) { return { type: administrationConstants.GETACCTDETDATA_FAILURE, error } }
}

function fetchIBAAcctData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        administrationService.fetchIBAAcctDetData(bodyFormData)
            .then(
                ibaacctdata => dispatch(success(ibaacctdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETIBAACCOUNTDATA_REQUEST } }
    function success(ibaacctdata) { return { type: administrationConstants.GETIBAACCOUNTDATA_SUCCESS, ibaacctdata } }
    function failure(error) { return { type: administrationConstants.GETIBAACCOUNTDATA_FAILURE, error } }
}

function fetchAssociatedUserDetPopUpData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        administrationService.fetchAssociatedUserDetPopData(bodyFormData)
            .then(
                associateduserdata => dispatch(success(associateduserdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETASSOCIATEUSERDATA_REQUEST } }
    function success(associateduserdata) { return { type: administrationConstants.GETASSOCIATEUSERDATA_SUCCESS, associateduserdata } }
    function failure(error) { return { type: administrationConstants.GETASSOCIATEUSERDATA_FAILURE, error } }
}

function fetchtempUserData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        administrationService.fetchtempUserAccData(bodyFormData)
            .then(
                tempuserdata => dispatch(success(tempuserdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETTEMPUSERACCDATA_REQUEST } }
    function success(tempuserdata) { return { type: administrationConstants.GETTEMPUSERACCDATA_SUCCESS, tempuserdata } }
    function failure(error) { return { type: administrationConstants.GETTEMPUSERACCDATA_FAILURE, error } }
}

function fetchAlertTempData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        administrationService.fetchAlertTempDataDet(bodyFormData)
            .then(
                alerttempdatadet => dispatch(success(alerttempdatadet)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETALERTTEMPDATADET_REQUEST } }
    function success(alerttempdatadet) { return { type: administrationConstants.GETALERTTEMPDATADET_SUCCESS, alerttempdatadet } }
    function failure(error) { return { type: administrationConstants.GETALERTTEMPDATADET_FAILURE, error } }
}

function fetchMmfReviewProspectusData(bodyFormData) {
	return dispatch => {
		dispatch(request());
		administrationService.fetchMmfReviewProspectus(bodyFormData).then(
			mmfreviewPropDet => dispatch(success(mmfreviewPropDet)),
			error => dispatch(failure(error))
		);
	};

	function request() { return { type: administrationConstants.GETMMFREVIEWACCT_REQUEST } }
	function success(mmfcreateAcctDet) { return { type: administrationConstants.GETMMFREVIEWACCT_SUCCESS, mmfcreateAcctDet } }
	function failure(error) { return { type: administrationConstants.GETMMFREVIEWACCT_FAILURE, error } }
}

function fetchMmfcreateAcctData(bodyFormData) {
	return dispatch => {
		dispatch(request());

		administrationService.fetchMmfcreateAcctDet(bodyFormData).then(
			mmfcreateAcctDet => dispatch(success(mmfcreateAcctDet)),
			error => dispatch(failure(error))
		);
	};

	function request() { return { type: administrationConstants.GETMMFCREATEACCT_REQUEST } }
	function success(mmfcreateAcctDet) { return { type: administrationConstants.GETMMFCREATEACCT_SUCCESS, mmfcreateAcctDet } }
	function failure(error) { return { type: administrationConstants.GETMMFCREATEACCT_FAILURE, error } }
}

function fetchMmfeditAcctData(bodyFormData) {
	return dispatch => {
		dispatch(request());

		administrationService.fetchMmfeditAcctDet(bodyFormData).then(
			mmfeditAcctDet => dispatch(success(mmfeditAcctDet)),
			error => dispatch(failure(error))
		);
	};

	function request() { return { type: administrationConstants.GETMMFEDITACCT_REQUEST } }
	function success(mmfeditAcctDet) { return { type: administrationConstants.GETMMFEDITACCT_SUCCESS, mmfeditAcctDet } }
	function failure(error) { return { type: administrationConstants.GETMMFEDITACCT_FAILURE, error } }
}

// View Change Hisory Popup
function fetchViewChangeHistoryPopUpData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        administrationService.fetchViewChangeHistoryPopUp(bodyFormData)
            .then(
                viewchangehistory => dispatch(success(viewchangehistory)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETVIEWCHANGESHISTORY_REQUEST } }
    function success(viewchangehistory) { return { type: administrationConstants.GETVIEWCHANGESHISTORY_SUCCESS, viewchangehistory } }
    function failure(error) { return { type: administrationConstants.GETVIEWCHANGESHISTORY_FAILURE, error } }
}
function fetchassignAlertRecipientsTableData(bodyFormData){
    return dispatch => {
        dispatch(request());

        administrationService.fetchassignAlertRecipientsTableData(bodyFormData)
            .then(
                assignAlertRecipientsTableData => dispatch(success(assignAlertRecipientsTableData)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETREPORTTBLDATA_REQUEST } }
    function success(assignAlertRecipientsTableData) { return { type: administrationConstants.GETREPORTTBLDATA_SUCCESS, assignAlertRecipientsTableData } }
    function failure(error) { return { type: administrationConstants.GETREPORTTBLDATA_FAILURE, error } }

}

function fetchAssignAlertRecipientsData(bodyFormData, selFirm) {
    return dispatch => {
        dispatch(request());

        administrationService.fetchAssignAlertRecipients(bodyFormData, selFirm)
            .then(
                assignAlertRecipientsData => dispatch(success(assignAlertRecipientsData)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETREPORTDATA_REQUEST } }
    function success(assignAlertRecipientsData) { return { type: administrationConstants.GETREPORTDATA_SUCCESS, assignAlertRecipientsData } }
    function failure(error) { return { type: administrationConstants.GETREPORTDATA_FAILURE, error } }
}

function fetchFundAccountsData(filtObj)
{
    return dispatch => {
        dispatch(request());

        administrationService.fetchFundAccounts(filtObj)
            .then(
                adminreportdata => dispatch(success(adminreportdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETREPORTDATA_REQUEST } }
    function success(adminreportdata) { return { type: administrationConstants.GETREPORTDATA_SUCCESS, adminreportdata } }
    function failure(error) { return { type: administrationConstants.GETREPORTDATA_FAILURE, error } }
}
function fetchResearchMoneyData(filtObj)
{
    return dispatch => {
        dispatch(request());

        administrationService.fetchResearchMoney(filtObj)
            .then(
                adminreportdata => dispatch(success(adminreportdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: administrationConstants.GETREPORTDATA_REQUEST } }
    function success(adminreportdata) { return { type: administrationConstants.GETREPORTDATA_SUCCESS, adminreportdata } }
    function failure(error) { return { type: administrationConstants.GETREPORTDATA_FAILURE, error } }
}