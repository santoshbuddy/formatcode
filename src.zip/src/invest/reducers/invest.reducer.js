import { investConstants } from '../constants/invest.constants';

export function investdata(state = {}, action) {
    switch (action.type) {
      case investConstants.GETINVESTDATA_REQUEST:
        return {
          loading: true
        };
      case investConstants.GETINVESTDATA_SUCCESS:
        return {
            investdata: action.investdata
        };
      case investConstants.GETINVESTDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }

  export function investdatatable(state = {}, action) { 
      switch (action.type) {
      case investConstants.GETINVESTTBLDATA_REQUEST:
        return {
          loading: true
        };
      case investConstants.GETINVESTTBLDATA_SUCCESS: 
        return {         
          investdatatable: action.investdatatable
        };
      case investConstants.GETINVESTTBLDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }