import { investConstants } from '../constants/invest.constants';
import { investService } from '../services/invest.service';

export const investActions = {
    fetchInvestData,
    fetchInvestTableData
};

function fetchInvestData(bodyFormData) {
    return dispatch => {
        dispatch(request());

        investService.fetchInvest(bodyFormData)
            .then(
                investdata => dispatch(success(investdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: investConstants.GETINVESTDATA_REQUEST } }
    function success(investdata) { return { type: investConstants.GETINVESTDATA_SUCCESS, investdata } }
    function failure(error) { return { type: investConstants.GETINVESTDATA_FAILURE, error } }
}

function fetchInvestTableData(bodyFormData){  
    return dispatch => {
        dispatch(request());

        investService.fetchInvestTable(bodyFormData)
            .then(
                investdatatable => dispatch(success(investdatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: investConstants.GETINVESTTBLDATA_REQUEST } }
    function success(investdatatable) { return { type: investConstants.GETINVESTTBLDATA_SUCCESS, investdatatable } }
    function failure(error) { return { type: investConstants.GETINVESTTBLDATA_FAILURE, error } }
 
}