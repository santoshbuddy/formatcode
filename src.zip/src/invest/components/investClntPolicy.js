import { messageUS } from '../../common/javascript/i18N/en_US/alerts'
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts'
import {addComma} from '../../tradeentry/components/amountValidations';
import {addCommasAmt} from '../../tradeentry/components/amountValidations';
import {removeCommas} from '../../common/amountValidations';

export const IsCharsInBag =  function (s,bag) {
	var i;
	var c;

	for(i=0;i<s.length;i++)
	{
		c = s.charAt(i);
		if(bag.indexOf(c) == -1)
		return false;
	}
	return true;
  }

export const doVerify =  function () {
let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
	var invpolicyName= document.getElementById("policyName").value;
	var errMsg;
	if(invpolicyName == "") {
		alert (message["POLICYNME"]);
		errMsg = "<span class='colTxt'>"+message["INVPOLN"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["POLICYNME"]+"</span>";
    	  	showErrorMessage(errMsg);
		window.document.getElementById("policyName").focus();
		return false;
	}
	if(invpolicyName.length > 0) {
		if(!IsCharsInBag(invpolicyName,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 "))
		{
			alert (message["VPOLICYNME"]);
			errMsg = "<span class='colTxt'>"+message["INVPOLN"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["VPOLICYNME"]+"</span>";
			showErrorMessage(errMsg);
			window.document.getElementById("policyName").focus();
			return false;
		}
	}
	return true;
}

export const isValidAllAmtLmt =  function () {
    let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
    var amtLmt;
   	amtLmt=document.getElementById("amtLmtAll").value;
   	if(amtLmt != "No Limit")
   	{
		if(IsCharsInBag(amtLmt,"1234567890,.-") == false)
		{
			alert(message["ENVLDAMT"]);
			window.document.getElementById("amtLmtAll").focus();
			return false;
		}
		if(parseFloat(removeCommas(amtLmt)) > 100000000000){
			//alert(message["AMTRGNOTVA"]);
			errMsg = "<span class='colTxt'>"+message["INVAMT"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["AMTRGNOTVA"]+"</span>";
			showErrorMessage(errMsg);
			document.getElementById("amtLmtAll").value="";
			window.document.getElementById("amtLmtAll").focus();
			return false;
		}
	}
   return true;
}

export const isValidAllPermAmtLmt =  function () {
    let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
    var amtLmt;
   	amtLmt=document.getElementById("permLmtAll").value;
   	if(amtLmt != "No Limit")
   	{
		if(IsCharsInBag(amtLmt,"1234567890,.-") == false)
		{
			alert(message["EVALIDAUM"]);
			window.document.getElementById("permLmtAll").focus();
			return false;
		}
		if(parseFloat(amtLmt) < 0 || parseFloat(removeCommas(amtLmt))>100){
			alert(message["FUNAUMBW"]);
			window.document.getElementById("permLmtAll").focus();
			return false;
		}
	}
   return true;
}

export const isValidAmountLmt =  function (e,i) {
    let userLocale=sessionStorage.getItem('userLocaleTxt');
    let message = (userLocale==="en_US")?messageUS:messageTr;
	showErrorMessage("");
	showProdErrorMsg("");
        var amtLmt;
        var errMsg;
       	amtLmt=e.target.value;
    	if(amtLmt == "") {
    	  //alert(message["PLSENAMTLMT"]);
    	  errMsg = "<span class='colTxt'>"+message["INVAMT"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["PLSENAMTLMT"]+"</span>";
    	  showErrorMessage(errMsg);
    	  document.getElementById("amtLmt"+i).value="";
    	  document.getElementById("amtLmt"+i).focus();
    	  return false;
    	}
    	if(amtLmt != "No Limit")
    	{
	if(IsCharsInBag(amtLmt,"0123456789.,MMmmKKkk") == false)
	{
		//alert(message["ENVLDAMT"]);
		errMsg = "<span class='colTxt'>"+message["INVAMT"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["ENVLDAMT"]+"</span>";
		showErrorMessage(errMsg);
		document.getElementById("amtLmt"+i).value="";
		window.document.getElementById("amtLmt"+i).focus();
		return false;
	}
	if(parseFloat(removeCommas(amtLmt)) > 100000000000){
		//alert(message["AMTRGNOTVA"]);
		errMsg = "<span class='colTxt'>"+message["INVAMT"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["AMTRGNOTVA"]+"</span>";
		showErrorMessage(errMsg);
		document.getElementById("amtLmt"+i).value="";
		window.document.getElementById("amtLmt"+i).focus();
		return false;
	}
	if(amtLmt!="" && amtLmt!="0.00" && amtLmt != undefined && amtLmt.length>0 && parseFloat(amtLmt) > 0){
	  addCommasAmt(e,userLocale,true);
	}
      }
   return true;
}

export const isValidPerAumLmt =  function (cnt,i) {
    let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
        var perAumLmt;
	showErrorMessage("");
	showProdErrorMsg("");
        var errMsg;
    	perAumLmt=document.getElementById("perAumLmt"+i).value;
    	if(perAumLmt == "") {
    	  alert(message["PLSENAMTLMT"]);
    	  errMsg = "<span class='colTxt'>"+message["INVAUM"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["PLSENAMTLMT"]+"</span>";
    	  showErrorMessage(errMsg);
    	  document.getElementById("perAumLmt"+i).value="";
    	  window.document.getElementById("perAumLmt"+i).focus();
    	  return false;
    	}
    	if(perAumLmt != "No Limit")
    	{
    	if(IsCharsInBag(perAumLmt,"0123456789.,MMmmKKkk") == false)
    	{
    		alert(message["EVALIDAUM"]);
    		errMsg = "<span class='colTxt'>"+message["INVAUM"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["EVALIDAUM"]+"</span>";
    		showErrorMessage(errMsg);
    		document.getElementById("perAumLmt"+i).value="";
    		window.document.getElementById("perAumLmt"+i).focus();
    		return false;
    	}
    	if(parseFloat(perAumLmt) > 100){
    		alert(message["FUNAUMBW"]);
    		errMsg = "<span class='colTxt'>"+message["INVAUM"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["FUNAUMBW"]+"</span>";
    		showErrorMessage(errMsg);
    		document.getElementById("perAumLmt"+i).value="";
    		window.document.getElementById("perAumLmt"+i).focus();
    		return false;
	}
      }
   return true;
}

export const validateEmail =  function (i,obj)
{
    let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
    //var obj;
	//obj=document.getElementById("email"+i).value;
	//alert("obj::"+obj);

	if(obj != null && obj.length > 0) {
			var str = obj;
			var dotFirstStr = str.substring(0, str.lastIndexOf('@'));
			var dotLastStr = str.substring(str.lastIndexOf('@') + 1, str.length);
			if (str.indexOf('@')==-1)
			{
				alert(message["EMAILVALID"]);
				//obj.focus();
				return false;
			}
			else if(!IsCharsInBag(str,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_@-."))
			{
				alert(message["VLDEMAIL"]);
				//obj.focus();
				return false;
			}

			else
			if (str.indexOf('@') != str.lastIndexOf('@'))
			{
				alert(message["NVEMAILADDR"]);
				//obj.focus();
				return false;
			}
			else
			if (str.indexOf(' ') != -1)
			{
				alert(message["SPACENALLOW"]);
				//obj.focus();
				return false;
			}
			else if (dotLastStr.indexOf('.')==-1)
			{
				alert(message["NVWODOT"]);
				//obj.focus();
				return false;
			}
		}
	return true;
}

export const isValidAmtLmts =  function (fld1,fld2,i) {
    let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
    var amtLmt="";
    var perAumLmt="";

    showErrorMessage("");
    showProdErrorMsg("");
    var errMsg;
   	if(fld1!=null)
   	  amtLmt=fld1.value;

   	if(fld2!=null)
   	  perAumLmt=fld2.value;

   	//alert("amtLmt::"+amtLmt+",perAumLmt:"+perAumLmt);
	 if(amtLmt == "No Limit")
	   amtLmt="";
	if(perAumLmt == "No Limit")
	  perAumLmt="";

	if(amtLmt == "" && perAumLmt == "") {
	  alert(message["PLSENAMTLMT"]);
	  errMsg = "<span class='colTxt'>"+message["INVAMT"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["PLSENAMTLMT"]+"</span>";
    	  showErrorMessage(errMsg);
    	  document.getElementById("amtLmt"+i).value="No Limit";
	  window.document.getElementById("amtLmt"+i).focus();
	  return false;
	}
	if(amtLmt != "" && amtLmt != "No Limit")
	{
		if(IsCharsInBag(amtLmt,"0123456789.,MMmmKKkk") == false)
		{
			alert(message["ENVLDAMT"]);
			errMsg = "<span class='colTxt'>"+message["INVAMT"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["ENVLDAMT"]+"</span>";
			showErrorMessage(errMsg);
			document.getElementById("amtLmt"+i).value="No Limit";
			window.document.getElementById("amtLmt"+i).focus();
			return false;
		}
		if(parseFloat(removeCommas(amtLmt)) > 100000000000){
			alert(message["AMTRGNOTVA"]);
			document.getElementById("amtLmt"+i).value="No Limit";
			window.document.getElementById("amtLmt"+i).focus();
			return false;
		}
       }
       if(perAumLmt != "" && perAumLmt != "No Limit")
       {
       if(IsCharsInBag(perAumLmt,"1234567890,.-") == false)
       	{
       		alert(message["EVALIDAUM"]);
       		errMsg = "<span class='colTxt'>"+message["INVAUM"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["EVALIDAUM"]+"</span>";
    		showErrorMessage(errMsg);
       		document.getElementById("perAumLmt"+i).value="";
       		window.document.getElementById("perAumLmt"+i).focus();
       		return false;
       	}
       	if(parseFloat(perAumLmt) > 100){
       		alert(message["FUNAUMBW"]);
       		errMsg = "<span class='colTxt'>"+message["INVAUM"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["FUNAUMBW"]+"</span>";
    		showErrorMessage(errMsg);
       		document.getElementById("perAumLmt"+i).value="";
       		window.document.getElementById("perAumLmt"+i).focus();
       		return false;
	}
       }
   return true;
}

export const showErrorMessage=function(errMsg)
{
	if(document.getElementById("errorId")!=null)
	{
		var errorId=document.getElementById("errorId");
		if(errMsg!=""){
		  errorId.style.display="";
		}else{
		  errorId.style.display="none";
		  showProdErrorMsg("");
		}
	}
	if(document.getElementById("errorMsgId")!=null)
	{
	  var errorMsgId=document.getElementById("errorMsgId");
	  errorMsgId.innerHTML=errMsg;
	}
}

export const showProdErrorMsg=function(errMsg)
{
	if(document.getElementById("warnId")!=null)
	{
	  var warnId=document.getElementById("warnId");
	  if(errMsg!=""){
	    warnId.style.display="";
	  }else{
	    warnId.style.display="none";
	  }
	}
	if(document.getElementById("warnMsgId")!=null)
	{
	  var warnMsgId=document.getElementById("warnMsgId");
	  warnMsgId.innerHTML="<table class='field paddedL40'><span class='fieldtxt'>"+errMsg+"</span></table>";
	}
}
export const isVAmtLmt =  function (e) {
	showErrorMessage("");
	showProdErrorMsg("");
        let userLocale=sessionStorage.getItem('userLocaleTxt');
        let message = (userLocale==="en_US")?messageUS:messageTr;

        var amtLmt=e.target.value;
        //alert("apr 10, 2019 amtLmt::"+amtLmt);
        var errMsg;
       	if(amtLmt != "No Limit")
       	{
		if(IsCharsInBag(amtLmt,"0123456789.,MMmmKKkk") == false)
		{
			//alert(message["ENVLDAMT"]);
			errMsg = "<span class='colTxt'>"+message["INVAMT"]+"</span><span class='fieldtxt fntsz fntclr'>"+message["ENVLDAMT"]+"</span>";
			showErrorMessage(errMsg);
			document.getElementById("amtLmtAll").value="";
			window.document.getElementById("amtLmtAll").focus();
			return false;
		}
		if(amtLmt!="" && amtLmt!="0.00" && amtLmt!="No Limit" && amtLmt != undefined && amtLmt.length>0 && parseFloat(amtLmt) > 0){
		  addCommasAmt(e,userLocale,true);
		}
	}
   return true;
  }
