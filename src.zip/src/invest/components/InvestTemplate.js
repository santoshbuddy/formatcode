import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { investActions } from '../actions/invest.actions';
import { tradeActions } from '../../tradeentry/actions/trade.actions';
import { connect } from 'react-redux';
import ReactTable, { ReactTableDefaults } from "react-table";
import { Route , Redirect } from 'react-router-dom';
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import 'react-tabs/style/react-tabs.css';
import Dialog from '@material-ui/core/Dialog';
import DialogContent from '@material-ui/core/DialogContent';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import DialogTitle from '@material-ui/core/DialogTitle';
import Paper from '@material-ui/core/Paper';
import { Link } from 'react-router-dom';
import Loading from '../../common/Loading'
import MUIDataTable from "mui-datatables";
import ScrollDialogPopUp  from "./ScrollDialogPopUp";
import ActionPopUp  from "./ActionPopUp";
import CreateActionPopUp  from "./CreateActionPopUp";
import {muiTableStyles} from '../../styles/muidatatableCss';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import { alertConstants } from '../../common/constants/alert.constants';
import { createMuiTheme, MuiThemeProvider,withStyles } from "@material-ui/core/styles";
import DialogContentText from "@material-ui/core/DialogContentText";
import axios from 'axios';
import { history } from '../../_helpers';
import EditActionPopUp from './EditActionPopUp';
import CustomToolbarSelect from "../../navbar/components/CustomToolbarSelect";
import {validateEmail} from './investClntPolicy';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Info from "@material-ui/icons/Info";
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import FormData from 'form-data';

const styles = theme => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
    },
    paper: {
      padding: theme.spacing.unit * 2,
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    tabsRoot: {
        borderBottom: '1px solid #e8e8e8',
      },
      tabsIndicator: {
        backgroundColor: '#1890ff',
      },
      tabRoot: {
        textTransform: 'initial',
        minWidth: 72,
        fontWeight: theme.typography.fontWeightRegular,
        marginRight: theme.spacing.unit * 4,
        // fontFamily: [
        //   '-apple-system',
        //   'BlinkMacSystemFont',
        //   '"Segoe UI"',
        //   'Roboto',
        //   '"Helvetica Neue"',
        //   'Arial',
        //   'sans-serif',
        //   '"Apple Color Emoji"',
        //   '"Segoe UI Emoji"',
        //   '"Segoe UI Symbol"',
        // ].join(','),
        '&:hover': {
          color: '#40a9ff',
          opacity: 1,
        },
        '&$tabSelected': {
          color: '#1890ff',
          fontWeight: theme.typography.fontWeightMedium,
        },
        '&:focus': {
          color: '#40a9ff',
        },
      },
      tabSelected: {},
      typography: {
        padding: theme.spacing.unit * 3,
      },

      label: {
        fontSize: '14px',
        fontWeight : 'bold',
      },
      tablerow:{
        height : '20px',
      },
      margin: {
        marginRight: '0px',
        marginLeft: '0px',
      },
      insrt:{
        fontSize:'12px',
        color: '#666666',
        fontFamily: 'arial,helvetica,sans-serif',
      },
      checkboxstyle:{padding:'0px !important',
      height: 18}

  });

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });
  let buttonFlag=true;
  let pageName='';
  let msg="";
  let loading=true
  let selRowsIndex;
  let rowCnt=0;
  let saveBlk,cancelBlk,viewChgBlk,approveBlk,rejectBlk;
  var popUpData,fileds,title;
  var data1 = [] //this.props[3].DATA;
  var columns1 = []
  let popUpColumns1;
  let popUpData1;
  let optionsPopUp;
  let filterFlag,searchFlag,printFlag,downloadFlag,viewColumnsFlag;
  let paginationFlag=true;
  let localEditRowData=[];
 class InvestTemplate extends React.Component {
    getMuiTheme = () =>
        createMuiTheme({
          overrides: {
						MUIDataTableToolbar: {
							root: {
								 display: 'none'
						 }
						}	,
            MUIDataTableHeadCell: {
              root: {
                background: '#eaeaea !important',
                color: '#0066b2 !important',
                textTransform: 'uppercase',
                whiteSpace: 'nowrap',
                fontWeight:'bold',
                borderRight: '1px solid #b3b3b3 !important',
                borderTop: '1px solid #b3b3b3',
                borderBottom: '1px solid #b3b3b3',
                '&:first-child':{
                  borderLeft: '1px solid #b3b3b3'
                },
                '&:last-child':{
                  paddingRight: '4px'
                }
              }
            },
            MUIDataTableBodyRow: {
              root: {
                '&:nth-child(odd)': {
                  backgroundColor: '#f7f8f9'
                }
              }
             },
             MuiTableCell: {
               root: {
                whiteSpace: 'nowrap',
                padding: '7px 5px',
                borderRight: '1px solid #f3ebeb',
                borderTop: '1px solid #c3c3c3',
                borderBottom: '1px solid #f3ebeb',
                '&:last-child':{
                  borderRight:'0px'
                },
                '&:first-child':{
                  borderLeft: '1px solid #f3ebeb'
                }
               }
             },
             MuiTableRow: {
               root:{
                 height:'auto'
               },
               head: {
                 height:'auto',
               }
						 },

            }
          });


    constructor(){
        super();
        this.state={
            flag:true,
            results:[],
            results1:[],
            investdata:[],
            columns:[],
            screenName:'',
            checkFlag:'',
            open: false,
            messageTxt:'',
            TradeType:'',
            valuetab: 0,
            editInvestFlag: false,
            scroll: "paper",
						parentFlag: false,
						tabIndex:0,
						activeStep: 0,
						fromPage:''
        }
        this.coldata=[];
        this.routeChange = this.routeChange.bind(this);
        this.editInvestChange = this.editInvestChange.bind(this);
        this.doSave = this.doSave.bind(this);
        this.doRevoke = this.doRevoke.bind(this);
        this.doReject = this.doReject.bind(this);
        this.doViewChange = this.doViewChange.bind(this);
	this.doRefresh = this.doRefresh.bind(this);
	this.checkClick = this.checkClick.bind(this);
	this.doApprove = this.doApprove.bind(this);
	this.doRejectMRCR = this.doRejectMRCR.bind(this);
	this.doClose = this.doClose.bind(this);

     }
   doReject(bodyFormData){
           //alert("reject block ::"+bodyFormData.get("actionFlag"));
           bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
           this.props.dispatch(investActions.fetchInvestData(bodyFormData));
   }
   doRevoke(bodyFormData){
        //alert(bodyFormData.get("actionFlag"));
        bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
        this.props.dispatch(investActions.fetchInvestData(bodyFormData));
   }

    componentDidMount() {
        console.log("invest Template componentDidMount")
        pageName=this.props.location.pathname;
        this.coldata=[];
        this.getFilter()
        loading=true
   }
   componentDidUpdate(){
    // alert("componentDidUpdate")
      console.log("page name",pageName)
      console.log("this.props.location.pathname",this.props.location.pathname)
      if(pageName.length!==0 && pageName!==this.props.location.pathname)
      {
        pageName=this.props.location.pathname;
        console.log("invest Template componentDidUpdate",pageName)
        this.coldata=[];
        //this.setState({results:[]})
        this.getFilter()
       }
       else
         pageName=this.props.location.pathname;
       }

       handleChange = (event, valuetab) => {
               this.setState({ valuetab });
               var actionName;
               var bodyFormdata = new FormData();

               actionName =  "MMFRECRE";
               bodyFormdata.append("tabName", "CHKPARAM");
               if(valuetab == 0) {
                   this.doTabChange("VIEWALL");
               }else if(valuetab == 1){
                 this.doTabChange("PENDAPPR");
               }
    };

    doTabChange(tabName){
	msg='';
	this.setState({ userLinksPermDet:null, });
	var bodyFormdata = new FormData();
	bodyFormdata.append("clientFirm", sessionStorage.getItem('clientFirm'));
	bodyFormdata.append("selLnkGrpId", "");
	bodyFormdata.append("grpMsg", "");
	bodyFormdata.append("viewTab", tabName);
	this.props.dispatch(investActions.fetchInvestData(bodyFormdata));

    }

   getFilter(){
    this.state.messageTxt="empty";
    console.log("invest Template getFilter")
    var bodyFormData = new FormData();
    bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
    bodyFormData.append("reactJSActionFlag","")
    this.props.dispatch(investActions.fetchInvestData(bodyFormData));

   }

doRefresh()
{
	this.getFilter();
	loading=true
}

 doViewChange(scroll){
             var jsonBody = new FormData();
	     var url;
    	     var user = JSON.parse(sessionStorage.getItem('user'));
    	     jsonBody.append("clientFirm",sessionStorage.getItem('clientFirm'));
    	     jsonBody.append("token",user[0].token);
    	     jsonBody.append("actionFlag","ViewChanges");
    	     jsonBody.append("fromPage","ViewChanges");
    	     jsonBody.append("fundFamilyId","ALL");//testing
    	     jsonBody.append("prodId","ALL");//testing
    	     jsonBody.append("currencyCode","ALL");//testing
    	     jsonBody.append("refAcct","ALL");//testing
    	     jsonBody.append("makerLogin","false");//testing

	     url=alertConstants.URL+"/MMFRECRE.do";
    	    loading=true;
    	    axios({
	             method: 'post',
	             url:url,
	             data: jsonBody,
	             config: { headers: {'Content-Type': 'multipart/form-data' }}
	           }).then((response)=>{
	             popUpData = response.data;
	             this.setState({ open: true, scroll });
            });
   }

		doSave()
		{
			var jsonBody 	= new FormData();
			var cnt			= 0;
			var validFlag	= true;
			let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

			if(selRowsIndex != undefined)
			{
				var emptyEmail = false;
				selRowsIndex.forEach((row,index) => {
					cnt++;
					var email	= document.getElementById("email"+row.index).value;
					var ccEmail	= document.getElementById("ccEmail"+row.index).value;

					if(email.length === 0) {
						emptyEmail = true;
					}

					if(validateEmail(row.index,email) == true)
					{
						if(validateEmail(row.index,ccEmail) == true)
						{
							var oldEmail	= document.getElementById("oldEmail"+row.index).value;
							var oldccEmail	= document.getElementById("oldccEmail"+row.index).value;

							data1 && data1.map((item,i)=>{
								jsonBody.append("ccycode"+i,data1[i][columns1.findIndex(e => e.name === "currency code")]);
								jsonBody.append("mmmfAcctNo"+i,data1[i][columns1.findIndex(e => e.name === "Acct Nbr")]);
								jsonBody.append("clientId"+i,data1[i][columns1.findIndex(e => e.name === "Client Company Id")]);
								jsonBody.append("funddesc"+i,data1[i][columns1.findIndex(e => e.name === "Fund Description")]);
								jsonBody.append("groupid"+i,data1[i][columns1.findIndex(e => e.name === "Group Id")]);
								jsonBody.append("deskgroupid"+i,data1[i][columns1.findIndex(e => e.name === "Desk Group Id")]);
								jsonBody.append("procid"+i,data1[i][columns1.findIndex(e => e.name === "Process Id")]);
							});
/*
							jsonBody.append("ccycode"+row.index,data1[row.index][4]);
							jsonBody.append("mmmfAcctNo"+row.index,data1[row.index][8]);
							jsonBody.append("clientId"+row.index,data1[row.index][9]);
							jsonBody.append("funddesc"+row.index,data1[row.index][10]);
							jsonBody.append("groupid"+row.index,data1[row.index][11]);
							jsonBody.append("deskgroupid"+row.index,data1[row.index][12]);
							jsonBody.append("procid"+row.index,data1[row.index][13]);
*/
							jsonBody.append("email"+row.index,email);
							jsonBody.append("ccEmail"+row.index,ccEmail);
							jsonBody.append("oldEmail"+row.index,oldEmail);
							jsonBody.append("oldccEmail"+row.index,oldccEmail);
							jsonBody.append("check"+row.index,"on");

							console.log("save block  email::",email+"::ccEmail",ccEmail+",cnt::",cnt);
						}
						else
						{
							validFlag=false;
						}
					}
					else
					{
						validFlag=false;
					}
				});

				if(emptyEmail) {
					alert(message["EMAILMANDY"]);
					validFlag=false;
					return false;
				}
			}

			//alert("validFlag::"+validFlag);
			if(validFlag==true)
			{
				if(cnt > 0)
				{
					if(window.confirm('Are you sure, you want to save the data?'))
					{
						var user = JSON.parse(sessionStorage.getItem('user'));
						jsonBody.append("clientFirm",sessionStorage.getItem('clientFirm'));
						jsonBody.append("token",user[0].token);
						jsonBody.append("Vecsize",rowCnt);
						jsonBody.append("actionFlag","SAVE");

						console.log("save block rowCnt::",rowCnt);
						loading=true;
						this.props.dispatch(investActions.fetchInvestData(jsonBody));
					}
				}
				else
				{
					alert("Please check atleast one check box");
				}
			}
		}

    doApprove(){
           var jsonBody = new FormData();
           var cnt=0;
           var validFlag=true;
           if(selRowsIndex != undefined){
   	  selRowsIndex.forEach((row,index) => {
   	   cnt++;
   	   var email=document.getElementById("email"+row.index).value;
   	   var ccEmail=document.getElementById("ccEmail"+row.index).value;
	   	   if(validateEmail(row.index,email) == true){
	   	   if(validateEmail(row.index,ccEmail) == true){
   	   var oldEmail=document.getElementById("oldEmail"+row.index).value;
   	   var oldccEmail=document.getElementById("oldccEmail"+row.index).value;

   	    data1 && data1.map((item,i)=>{
		  jsonBody.append("ccycode"+i,data1[i][columns1.findIndex(e => e.name === "currency code")]);
		  jsonBody.append("mmmfAcctNo"+i,data1[i][columns1.findIndex(e => e.name === "Acct Nbr")]);
		  jsonBody.append("clientId"+i,data1[i][columns1.findIndex(e => e.name === "Client Company Id")]);
		  jsonBody.append("funddesc"+i,data1[i][columns1.findIndex(e => e.name === "Fund Description")]);
		  jsonBody.append("groupid"+i,data1[i][columns1.findIndex(e => e.name === "Group Id")]);
		  jsonBody.append("deskgroupid"+i,data1[i][columns1.findIndex(e => e.name === "Desk Group Id")]);
		  jsonBody.append("procid"+i,data1[i][columns1.findIndex(e => e.name === "Process Id")]);

	  })

   	  /*jsonBody.append("ccycode"+row.index,data1[row.index][4]);
   	  jsonBody.append("mmmfAcctNo"+row.index,data1[row.index][8]);
   	  jsonBody.append("clientId"+row.index,data1[row.index][9]);
   	  jsonBody.append("funddesc"+row.index,data1[row.index][10]);
   	  jsonBody.append("groupid"+row.index,data1[row.index][11]);
   	  jsonBody.append("deskgroupid"+row.index,data1[row.index][12]);
   	  jsonBody.append("procid"+row.index,data1[row.index][13]);*/

   	  jsonBody.append("email"+row.index,email);
	  jsonBody.append("ccEmail"+row.index,ccEmail);
	  jsonBody.append("oldEmail"+row.index,oldEmail);
	  jsonBody.append("oldccEmail"+row.index,oldccEmail);
   	  jsonBody.append("check"+row.index,"on");
	   	   console.log("approve block  email::",email+"::ccEmail",ccEmail+",cnt::",cnt);
	   	   }else{
	   	     validFlag=false;
	   	   }
	   	   }else{
	   	     validFlag=false;
	   	   }
   	  })
   	  }
   	  if(validFlag==true)
   	  {
   	  if(cnt > 0)
   	  {
   	   if(window.confirm('Are you sure, you want to approve the data?'))
   	   {
       	     var user = JSON.parse(sessionStorage.getItem('user'));
       	     jsonBody.append("clientFirm",sessionStorage.getItem('clientFirm'));
       	     jsonBody.append("token",user[0].token);
       	     jsonBody.append("Vecsize",rowCnt);
       	     if(this.state.valuetab === 0)
       	     	jsonBody.append("viewTab","VIEWALL");
       	     else
       	     	jsonBody.append("viewTab","PENDAPPR");
       	     jsonBody.append("actionFlag","APPROVE");

       	    console.log("APPROVE block rowCnt::",rowCnt);
       	    loading=true;
       	    this.props.dispatch(investActions.fetchInvestData(jsonBody));
       	   }
   	  }else{
               alert("Please check atleast one check box");
             }
   }
   }

   doRejectMRCR(){
              var jsonBody = new FormData();
              var cnt=0;
              var validFlag=true;
              if(selRowsIndex != undefined){
      	  selRowsIndex.forEach((row,index) => {
      	   cnt++;
      	   var email=document.getElementById("email"+row.index).value;
      	   var ccEmail=document.getElementById("ccEmail"+row.index).value;
			   if(validateEmail(row.index,email) == true){
			   if(validateEmail(row.index,ccEmail) == true){
      	   var oldEmail=document.getElementById("oldEmail"+row.index).value;
      	   var oldccEmail=document.getElementById("oldccEmail"+row.index).value;

      	   data1 && data1.map((item,i)=>{
		  jsonBody.append("ccycode"+i,data1[i][columns1.findIndex(e => e.name === "currency code")]);
		  jsonBody.append("mmmfAcctNo"+i,data1[i][columns1.findIndex(e => e.name === "Acct Nbr")]);
		  jsonBody.append("clientId"+i,data1[i][columns1.findIndex(e => e.name === "Client Company Id")]);
		  jsonBody.append("funddesc"+i,data1[i][columns1.findIndex(e => e.name === "Fund Description")]);
		  jsonBody.append("groupid"+i,data1[i][columns1.findIndex(e => e.name === "Group Id")]);
		  jsonBody.append("deskgroupid"+i,data1[i][columns1.findIndex(e => e.name === "Desk Group Id")]);
		  jsonBody.append("procid"+i,data1[i][columns1.findIndex(e => e.name === "Process Id")]);

	  })

      	  /*jsonBody.append("ccycode"+row.index,data1[row.index][4]);
      	  jsonBody.append("mmmfAcctNo"+row.index,data1[row.index][8]);
      	  jsonBody.append("clientId"+row.index,data1[row.index][9]);
      	  jsonBody.append("funddesc"+row.index,data1[row.index][10]);
      	  jsonBody.append("groupid"+row.index,data1[row.index][11]);
      	  jsonBody.append("deskgroupid"+row.index,data1[row.index][12]);
      	  jsonBody.append("procid"+row.index,data1[row.index][13]);*/

			   jsonBody.append("email"+row.index,email);
			   jsonBody.append("ccEmail"+row.index,ccEmail);
			   jsonBody.append("oldEmail"+row.index,oldEmail);
			   jsonBody.append("oldccEmail"+row.index,oldccEmail);
      	   jsonBody.append("check"+row.index,"on");
			   console.log("reject block  email::",email+"::ccEmail",ccEmail+",cnt::",cnt);
			   }else{
			     validFlag=false;
			   }
			   }else{
			     validFlag=false;
			   }
      	  })
      	  }

      	  if(validFlag==true)
      	  {
      	  if(cnt > 0)
      	  {
      	   if(window.confirm('Are you sure, you want to reject the data?')){
          	     var user = JSON.parse(sessionStorage.getItem('user'));
          	     jsonBody.append("clientFirm",sessionStorage.getItem('clientFirm'));
          	     jsonBody.append("token",user[0].token);
          	     jsonBody.append("Vecsize",rowCnt);
          	     jsonBody.append("actionFlag","REJECT");
          	     if(this.state.valuetab === 0)
			jsonBody.append("viewTab","VIEWALL");
		     else
       	     		jsonBody.append("viewTab","PENDAPPR");

          	    console.log("REJECT block rowCnt::",rowCnt);
          	    loading=true;
          	    this.props.dispatch(investActions.fetchInvestData(jsonBody));
          	  }
      	  }else{
                  alert("Please check atleast one check box");
                }
   }
   }

   routeChange(){
        let path = `/reportM/INVPOREP`;
        this.props.history.push(path);
    }

    editInvestChange(editRowData){
      localEditRowData=editRowData;
      //console.log("called parent invest template component:editRowData:"+localEditRowData);
      this.setState({editInvestFlag:true})
    }
    handleClose = () => {
        this.setState({ open: false });
		 };

		 checkClick(cData, paramVal) {

			if(paramVal == 'TRADEENTRY' || paramVal == 'CLOSEACCOUNT') {
				this.props.history.push({
					pathname: '/DEALENT',
					state: {
						tabIndex: 1,
						activeStep: 1,
						paramVal: paramVal,
						fromPage:'ViewChanges',
						bformdata: cData
					}
				});
			} else if(paramVal == 'TRADEHISTORY') {
				this.props.history.push({
					pathname: '/report/TRDINQR',
					state: {
						fromPage:'ViewChanges',
						product: cData.parentprodid,
						issueChild: cData.prodid
					}
				});
			} else if(paramVal == 'EDITACCOUNT') {
				this.props.history.push({
					pathname: '/administration/MMFEDITACCT',
					state: {
						acctNbr: cData.acctnbr,
						clCompanyId: cData.ecompanyid,
						prId: cData.parentprodid,
						subProd:cData.prodid,
						currency: cData.currency,
						ecompanyid: cData.ecompanyid,
						refFundNbr: cData.refacctnbr,
						mmmfAcct: cData.escrowacctnbr,
						escAcctNbr: cData.escrowacctnbr,
						lookUpFlag:'YES',
						format:'MMM dd, yyyy',
						fromPage:'ViewChanges',
						product: cData.subprodname,
						clientName:cData.clientName,
						pageFrom:'MMFREL',
					}
				});
			}

		}

selectedRows(selRows)
{
	console.log("selected rws ", selRows);
	selRowsIndex=selRows;
}
selectedMMFRows(selRows)
{
 	console.log("selected rws ", selRows);
	selRowsIndex=selRows;
	selRows.forEach((row,index) => {
		console.log("target record data::", data1[row.index])

		if(document.getElementById("email"+row.dataIndex)!=undefined)
		{
			if(this.state.valuetab === 0){
		     		document.getElementById("email"+row.dataIndex).disabled = false;
		     	}
		 }
		if(document.getElementById("ccEmail"+row.dataIndex)!=undefined)
		{
			if(this.state.valuetab === 0){
		     		document.getElementById("ccEmail"+row.dataIndex).disabled = false;
		     	}
		 }
	});

	  if(selRows.length == 0 ){
	 	 data1 && data1.map((row,index)=>{
		if(document.getElementById("email"+index)!=undefined)
		{
		       document.getElementById("email"+index).disabled = true;
		 }
		if(document.getElementById("ccEmail"+index)!=undefined)
		{
		       document.getElementById("ccEmail"+index).disabled = true;
		}
	  })
	}
}
doClose(){
	this.setState({editInvestFlag:false})
}
render() {
	let dataFlag=true;
            let fromDate,toDate;
            var newdata ;
            var popuptitle,popupvalue;
            const {classes,  checkerFlag,loginId, clientFirm, processId, respMsg} = this.props
            const { valuetab } = this.state;
            //const { investdata } = this.props;
            //var columns1 = [] //this.props[3].COLUMNS;
		//var data1 = [] //this.props[3].DATA;
            var data,columns,screenName,checkFlag,mcProcess,repoFlag,results1=[],checkboxFlag=false,checkPosition;
            console.log(" this.props.investdata--->", this.props.investdata.investdata)

            this.state.investdata = this.props.investdata.investdata;
            if(this.state.investdata!==undefined){
            results1  = Array.from(this.state.investdata);
            console.log("target results1 block :::",results1)
            }
            else{
		return(
		    <Loading />
		)
        }


    console.log("result1 " , results1);
    let screenLinkImage;
    if(this.props.location.pathname!== undefined && this.props.location.pathname.length!==0){
         let pos=this.props.location.pathname.lastIndexOf('/');
         //console.log("position value::",pos);
         screenLinkImage=this.props.location.pathname;
         screenLinkImage=screenLinkImage.substring(pos+1,screenLinkImage.length)
         //alert("screenLinkImage::"+screenLinkImage)
         //console.log("screenLinkImage value::",screenLinkImage);
    }
		if( results1 !== undefined && results1.toString().trim().length!==0)
		{
			 results1.map((item,index) => {
			    if(item.type === "Title"){
			       screenName = item.name;
 			    }
			    if(item.type === "Message"){
			        this.state.messageTxt = item.name
			    }
			    if(item.paginationFlag === "false"){
			          paginationFlag = false;
			    }
			if(item.type === "datepicker"){
			   if(item.name === "fromDate"){
			     fromDate=item.value;
			   }
			   if(item.name === "toDate"){
			        toDate=item.value;
			   }
			}
		    //if(item.name === "data")
		      //results = item.values

		      if(item.type === "checkerFlag"){
			checkFlag = item.checkerFlag;
 		      }
 		      if(item.type === "mcProcess"){
		      	mcProcess = item.mcProcess;
  		      }
  		      if(item.type === "repoFlag"){
		      	repoFlag = item.repoFlag;
  		      }

		})
		var mainList=results1.find(item =>item.name ==="columns")// === listName)
		if(mainList!==undefined && mainList.COLUMNS!==undefined)
 	     	 columns1 = mainList.COLUMNS;

	     	mainList=results1.find(item =>item.name ==="DATA")// === listName)
	     	if(mainList!==undefined && mainList.DATA!==undefined){
          		data1 = mainList.DATA;
          		rowCnt=data1.length;
          		loading=false
          	}
		mainList=results1.find(item =>item.name ==="checkPosition")// === listName)
		if(mainList!==undefined && mainList.value!==undefined){
			checkPosition = parseInt(mainList.value);
		}
		if(pageName === "/invest/MMFRECRE"){
		   checkboxFlag=true;
		   saveBlk = <button className="btn btn-xs btn-primary" onClick={this.doSave.bind(this,"paper")}> Save</button>
		   cancelBlk = <button className="btn btn-xs btn-primary" onClick={this.doRefresh} >Cancel</button>
		   viewChgBlk = <button className="btn btn-xs btn-primary" onClick={this.doViewChange.bind(this,"paper")}> View Changes</button>
		   approveBlk = <button className="btn btn-xs btn-primary" onClick={this.doApprove.bind(this,"paper")}> Approve</button>
		   rejectBlk = <button className="btn btn-xs btn-primary" onClick={this.doRejectMRCR} >Reject</button>

			filterFlag=true;
			searchFlag=true;
			printFlag=true;
			downloadFlag=true;
			viewColumnsFlag=true;
			paginationFlag=true;
		}else{
		  saveBlk="";
		  cancelBlk="";
		  viewChgBlk="";
		  approveBlk="";
		  rejectBlk="";
		  filterFlag=false;
		  searchFlag=false;
		  printFlag=false;
		  downloadFlag=false;
		  viewColumnsFlag=false;
		  paginationFlag=false;
		}
if(columns1!== undefined && columns1.length !==0){
         columns1.map((item,index)=>{
      	   if(pageName === "/invest/MMFRECRE"){
	 	       //console.log("mar02,2019  item.name:::::",item.name)
			if(item.name === "Account Number"){
				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
				 return (
					<ScrollDialogPopUp
					onClick={e => this.openPopUp(e, tableMeta)}
					rowData={tableMeta}
					linkName={value}
					screenLinkImage={screenLinkImage}
					fromDate={fromDate}
					toDate={toDate}
					func ={this.checkClick }
					/>
				  );
				 }
			}
	 		if(item.name === "To Email Address"){
	 			item.options["sort"]=false;
      				item.options["searchable"]=false;
	 			item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
	 			 return (
	 			  <div>
	 			  	<input type="text" disabled={true} name={"email"+tableMeta.rowIndex} id={"email"+tableMeta.rowIndex} onChange={event => updateValue(event.target.value, tableMeta.rowIndex)} value={value} />
	 			   <input type="hidden" name={"oldEmail"+tableMeta.rowIndex} id={"oldEmail"+tableMeta.rowIndex} defaultValue={value} />
	 			  </div>
	 			  );
	 			 }
	 		}
	 		if(item.name === "CC Email Address"){
	 			item.options["sort"]=false;
      				item.options["searchable"]=false;
	 			item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
	 			 return (
	 			   <div>
	 			  <input type="text" disabled={true} name={"ccEmail"+tableMeta.rowIndex} id={"ccEmail"+tableMeta.rowIndex} onChange={event => updateValue(event.target.value, tableMeta.rowIndex)} value={value} />
	 			  <input type="hidden" name={"oldccEmail"+tableMeta.rowIndex} id={"oldccEmail"+tableMeta.rowIndex} defaultValue={value} />
	 			  </div>
	 			);
	 			}
	 		}
	   }else if(pageName === "/invest/CLINVPOL" && item.options.hyperlink === "true"){
	     //alert("CLINVPOL ScrollDialogPopUp");
	      if(item.name==="Actions"){
                item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
               if(value !== undefined && value.length !== 0 && value === "Edit")
               {
                return (
		 <ActionPopUp
			onClick={e => this.openPopUp(e, tableMeta)}
			rowData={tableMeta}
			goback={this.doRefresh.bind(this)}
			method={this.doRevoke}
			linkName={value}
			screenLinkImage={screenLinkImage}
		    />
                    );
                  }else if(value !== undefined && value.length !== 0 && value === "Create")
                  {
		                  return (
		  		 <CreateActionPopUp
		  			onClick={e => this.openPopUp(e, tableMeta)}
		  			rowData={tableMeta}
		  			goback={this.doRefresh.bind(this)}
		  			method={this.doRevoke}
		  			linkName={value}
		  			screenLinkImage={screenLinkImage}
		  		    />
		              );
                  }
                  else
		  {
			return (
			""
			);
                  }
                }
               }
           if(item.name==="Investment Policy Name"){
               item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
		  return (
		  (value === "No Investment Policy")?(<label className='TxtNrml'>{value}</label>):(
			<ScrollDialogPopUp
			onClick={e => this.openPopUp(e, tableMeta)}
			rowData={tableMeta}
			goInvestRpt={this.routeChange.bind(this)}
			goback={this.doRefresh.bind(this)}
			editInvest={this.editInvestChange.bind(this)}
			linkName={value}
			screenLinkImage={screenLinkImage}
			fromDate={fromDate}
			method={this.doReject}
			toDate={toDate}
			/>)
	         );
	        }
             }
	   }

         })
         }
	}

if(loading)
      return( <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div> );

msg = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">{this.state.messageTxt==="empty"?"":this.state.messageTxt}</div>

let relatedLinkBlk="";
let styleDiv="col-md-12 col-sm-12";
if(screenLinkImage === "CLINVPOL"){
   styleDiv="col-md-9 col-sm-9";
   relatedLinkBlk=<div className="col-md-3 col-sm-3"><Table style={{border:"1px solid #d5d5d6"}}><TableHead style={{ background: '#E4EAED' , background: '-moz-linear-gradient(top, #E4EAED 0%, #F7F9FA 100%)',background: '-webkit-linear-gradient(top, #E4EAED 0%,#F7F9FA 100%)', background: 'linear-gradient(to bottom, #E4EAED 0%,#F7F9FA 100%)', font: '18px', }}>
   <TableRow>
   <TableCell>Related Links</TableCell>
   </TableRow>
   </TableHead>
   <TableBody>
   <TableRow >
   <TableCell ><a href="#" onClick={e => this.routeChange()}>Investment Policy Report</a></TableCell>
   </TableRow>
   </TableBody>
   </Table>
   </div>
}
      const options = {
	filterType: "dropdown",
	selectableRows: checkboxFlag,
	onRowsSelect: (rowsSelected, allRows) => {
	  this.selectedRows(allRows);
	  //console.log("here index--->" , rowsSelected[0].index);
	},
	responsive: "scroll",
	pagination:paginationFlag,
	rowsPerPage:(paginationFlag===false)?data1.length:10,
	fixedHeader: false,
	filter:filterFlag,
	search:searchFlag,
	print:printFlag,
	download:downloadFlag,
	viewColumns:viewColumnsFlag,
	customToolbarSelect: (selectedRows, displayData, setSelectedRows) => (
		<CustomToolbarSelect selectedRows={selectedRows} displayData={displayData} setSelectedRows={setSelectedRows} />
),
      };
const options1 = {
	filterType: "dropdown",
	selectableRows: checkboxFlag,
	isRowSelectable: (dataIndex) => {
		console.log("checkPosition .....", checkPosition);
		return data1[dataIndex][checkPosition] !== "disabled";
	},
	onRowsSelect: (rowsSelected, allRows) => {

	       data1 && data1.map((row,index)=>{
		if(document.getElementById("email"+index)!=undefined)
		{
		       document.getElementById("email"+index).disabled = true;
		 }
		if(document.getElementById("ccEmail"+index)!=undefined)
		{
		       document.getElementById("ccEmail"+index).disabled = true;
		}
	      })

	        console.log("mar 19, 2019 ... allRows::",allRows)
	       this.selectedMMFRows(allRows);

	},
	responsive: "scroll",
	pagination:paginationFlag,
	rowsPerPage:(paginationFlag===false)?data1.length:10,
	fixedHeader: false,
	filter:true,
	search:true,
	print:true,
	download:true,
	viewColumns:true,
      };

 if( popUpData !== undefined && popUpData.toString().trim().length!==0){
   var commonPopUpData = [];
   console.log("view changes popup  popUpData::",popUpData);

	var popUpList=popUpData.find(item =>item.name ==="commonData")// === listName)

	if(popUpList!==undefined && popUpList.commonData!==undefined)
	  commonPopUpData = popUpList.commonData;
 	  title=commonPopUpData.screenName;

	var popUpList=popUpData.find(item =>item.name ==="columns")// === listName)
	popUpColumns1 = popUpList.COLUMNS;

	popUpList=popUpData.find(item =>item.name ==="DATA")// === listName)
	popUpData1 = popUpList.DATA;

	optionsPopUp = {
		filterType: "dropdown",
		selectableRows: (pageName === "/invest/MMFRECRE")?false:true,
		pagination: true,
        	rowsPerPage: 10,
		responsive: "scroll",
		fixedHeader: true,
		filter:true,
		search:true,
		print:true,
		download:true,
		viewColumns:true,
	};
    console.log("view changes popup  field values::",commonPopUpData);

  }

            return (
                <div>
                    <NavBar/>
			<div className="clearfix"></div>
                    <div className="col-md-12 col-sm-12">
                        <div className="clearfix"></div>
			<div>
				<h4>{screenName}</h4>
			</div>

			{(screenName === 'MMF Relationship Credit Reporting')? (<div>

			{( mcProcess!== undefined && mcProcess === 'true')? (<div>

			<Tabs
			            value={valuetab}
			            onChange={this.handleChange}
			            classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}
			            >
			            <Tab
			                disableRipple
			                classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
			                label="View All"
			            />
			            <Tab
			                disableRipple
			                classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
			                label="Pending Approval"
			            />
            		</Tabs>


             		{(valuetab === 0 && repoFlag!== undefined && repoFlag === 'true') ? (<div>
 				<div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> <Info className={classes.info} style={{float:'left'}}/><h6 style={{marginTop:'7px',float:'left'}}>{"Records in grey are Pending Approval"}</h6></div>
				</div>):''
			}
			{(valuetab === 1 && repoFlag!== undefined && repoFlag === 'true') ? (<div>
				<div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> <Info className={classes.info} style={{float:'left'}}/><h6 style={{marginTop:'7px',float:'left'}}>{"You will not be able to approve any records for which you performed the Maker action. These records are greyed out and cannot be selected."}</h6></div>
				</div>):''
			}
			<div className="clearfix"></div>



			{valuetab === 0 &&
				<div>
					<div>
								{msg}
								{console.log("editInvestFlag=111=>",this.state.editInvestFlag)}
							  {this.state.editInvestFlag === true ?(<EditActionPopUp method={this.doRevoke} localEditRowData={localEditRowData} editInvestFlag={this.state.editInvestFlag}  doClose={this.doClose} />):''}
							</div>
							<div className="clearfix"></div>
							<div className={styleDiv}>
							{
							 (pageName!== undefined && pageName === "/invest/CLINVPOL") ?
							 (
							 data1 !== undefined ?
							<MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
							    <MUIDataTable
							    data={data1}
							    columns={columns1}
							    options={options}
							    />
							</MuiThemeProvider>
							:
							<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
							):
							(
							data1 !== undefined ?
							<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
							    <MUIDataTable
							    data={data1}
							    columns={columns1}
							    options={options1}
							    />
							</MuiThemeProvider>
							:
							<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
							)
						      }
						      {saveBlk}
						      {cancelBlk}
						      {viewChgBlk}
					</div>
			       </div>
            		}



            		{valuetab === 1 &&
				<div>
					<div>
								{msg}
								{console.log("editInvestFlag=2222=>",this.state.editInvestFlag)}
							  {this.state.editInvestFlag === true ?(<EditActionPopUp  method={this.doRevoke} localEditRowData={localEditRowData} editInvestFlag={this.state.editInvestFlag}  doClose={this.doClose} />):''}
							</div>
							<div className="clearfix"></div>
							<div className={styleDiv}>
							{
							 (pageName!== undefined && pageName === "/invest/CLINVPOL") ?
							 (
							 data1 !== undefined ?
							<MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
							    <MUIDataTable
							    data={data1}
							    columns={columns1}
							    options={options}
							    />
							</MuiThemeProvider>
							:
							<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
							):
							(
							data1 !== undefined ?
							<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
							    <MUIDataTable
							    data={data1}
							    columns={columns1}
							    options={options1}
							    />
							</MuiThemeProvider>
							:
							<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
							)
						      }
						      {(checkFlag!== undefined && checkFlag === 'Y') ? (<div>
							{approveBlk}
							{rejectBlk}
						        {viewChgBlk}
						        </div>):''
						        }
				      </div>
				</div>
            		}
</div>):

(<div>
				<div>
						{msg}
						{console.log("editInvestFlag=333=>",this.state.editInvestFlag)}
					  {this.state.editInvestFlag === true ?(<EditActionPopUp method={this.doRevoke} localEditRowData={localEditRowData} editInvestFlag={this.state.editInvestFlag}  doClose={this.doClose} />):''}
					</div>
					<div className="clearfix"></div>
					<div className={styleDiv}>
					{
					 (pageName!== undefined && pageName === "/invest/CLINVPOL") ?
					 (
					 data1 !== undefined ?
					<MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
					    <MUIDataTable
					    data={data1}
					    columns={columns1}
					    options={options}
					    />
					</MuiThemeProvider>
					:
					<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
					):
					(
					data1 !== undefined ?
					<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
					    <MUIDataTable
					    data={data1}
					    columns={columns1}
					    options={options1}
					    />
					</MuiThemeProvider>
					:
					<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
					)
				      }
				     {saveBlk}
				     {cancelBlk}
				     {viewChgBlk}
			      </div>

			</div>)

}
			</div>):
			(<div>
				<div>
						{msg}
						{console.log("editInvestFlag=444=>",this.state.editInvestFlag)}
					  {this.state.editInvestFlag === true ?(<EditActionPopUp method={this.doRevoke} localEditRowData={localEditRowData} editInvestFlag={this.state.editInvestFlag} goback={this.doRefresh.bind(this)} doClose={this.doClose} />):''}
					</div>
					<div className="clearfix"></div>
					<div className={styleDiv}>
					{
					 (pageName!== undefined && pageName === "/invest/CLINVPOL") ?
					 (
					 data1 !== undefined ?
					<MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
					    <MUIDataTable
					    data={data1}
					    columns={columns1}
					    options={options}
					    />
					</MuiThemeProvider>
					:
					<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
					):
					(
					data1 !== undefined ?
					<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
					    <MUIDataTable
					    data={data1}
					    columns={columns1}
					    options={options1}
					    />
					</MuiThemeProvider>
					:
					<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
					)
					}

			      </div>

			</div>)
			}



                         {relatedLinkBlk}
                    </div>
                    <div>
		            <Dialog
		              open={this.state.open}
		              onClose={this.handleClose}
		              scroll={this.state.scroll}
		              aria-labelledby="scroll-dialog-title"
		              fullWidth={true}
		              maxWidth = {'md'}
		            >
		              <DialogTitle id="scroll-dialog-title"> {title}

		              </DialogTitle>
		              <DialogContent>
		                <DialogContentText>
		    	       {
		    		dataFlag === true ?
		    		(
		    		data1 !== undefined ?
		    		<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
		    		  <MUIDataTable
		    		  data={popUpData1}
		    		  columns={popUpColumns1}
		    		  options={optionsPopUp}
		    		  />
		    		</MuiThemeProvider>
		    		:
		    		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
		    		)
		    		:
		    		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div></div>
		    		}
		                </DialogContentText>
		              </DialogContent>
		              <DialogActions>
		                <Button onClick={this.handleClose} color="primary">
		                  Close
		                </Button>
		              </DialogActions>
		            </Dialog>
		          </div>
                </div>
            );
        }
}
function mapStateToProps(state) {
    const { investdata } = state;
    return { investdata };
}

const connectedInvestTemplate = connect(mapStateToProps)(withStyles(styles)(InvestTemplate));
export { connectedInvestTemplate as InvestTemplate };