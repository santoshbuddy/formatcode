import React from 'react';
import { Link } from 'react-router-dom';
import { alertConstants } from '../../common/constants/alert.constants';

class NavBarItem extends React.Component {
    constructor(props){
        super(props);

        this.handleLink = this.handleLink.bind(this);
    }

    handleLink(e,linkItem){
        // e.preventDefault();
        // console.log("11111111111111")
        // console.log(linkItem)
    }
    CreateNavLinks(){
        let user = JSON.parse(sessionStorage.getItem('user'));

        const { classname,  item } = this.props;
        if(classname !== "dropdown" || item.subitem === undefined){
            // console.log("navbaritem=>",item)
           if(item.label === "Home")
                    return(
                        <li onClick={(e) => this.handleLink(item)}><Link to={"/"+alertConstants.homePage}>{item.label}</Link></li>
                    );
            if(item.image.toString() === "DESETST"){
              return <li key={item.image.toString()} id={item.image.toString()} ><Link to={"/report/"+item.image}> {item.label} </Link> </li>;
            }else{
                return <li key={item.image.toString()} id={item.image.toString()} ><Link to={"/"+item.image}> {item.label} </Link> </li>;
                }
        }else{
            let arr = item.subitem;
            let element = arr && arr.map((link,index) =>{
                if(link.subitem !== undefined){
                     let arr_sub = link.subitem;
                    let element_sub = arr_sub && arr_sub.map((link,index) =>{
                        //console.log("link.image===>",link.image.toString())
                        if(link.image.toString() === "INVPOREP" || link.image.toString() === "MMDASTMT" || link.image.toString() === "MMTDASRE"){
                          return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/reportM/"+link.image}> {link.label} </Link> </li>;
                        }
                        else if(link.image.toString() === "LOOKUP" || link.image.toString() === "CRALKUP" || link.image.toString() === "USERPROP" || link.image.toString() === "ADDREMOV" || link.image.toString() === "MCMAINT" || link.image.toString() === "EAUACL" || link.image.toString() === "BEAUACL" || link.image.toString() === "CLALERT")
                            return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/administration/"+link.image}> {link.label} </Link> </li>;
                        else if(link.image.toString() === "CLINVPOL" || link.image.toString() === "MMFRECRE"){
                          return <li onClick={(e) => this.handleLink(e,item)} key={link.image.toString()} id={link.image.toString()} ><Link to={"/invest/"+link.image}> {link.label} </Link> </li>;
                        }else if(link.image.toString() === "COMPART" || link.image.toString() === "INDICAT"){
                            return <li onClick={(e) => this.handleLink(e,item)} key={link.image.toString()} id={link.image.toString()} ><Link to={"/reportC/"+link.image}> {link.label} </Link> </li>;
                        }
                        else if(link.image.toString() === "REVTRDUP" || link.image.toString() === "APRTRDUP" || link.image.toString() === "FUDEAPRL" || link.image.toString() === "WATFRAPP"){
                            return <li onClick={(e) => this.handleLink(e,item)} key={link.image.toString()} id={link.image.toString()} ><Link to={"/reportCheck/"+link.image}> {link.label} </Link> </li>;
                        }
                        else  if(link.label === "Client List Report")
                        return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/client/"+link.image}> {link.label} </Link> </li>;
                        else
                          return <li onClick={(e) => this.handleLink(e,item)} key={link.image.toString()} id={link.image.toString()} ><Link to={"/report/"+link.image}> {link.label} </Link> </li>;
                    });
                    return <li className="dropdown dropdown-submenu" key={link.image.toString()} id={link.image.toString()}><a className="dropdown-toggle" data-toggle="dropdown">{link.label}<span className="glyphicon glyphicon-menu-right"></span></a><ul className="dropdown-menu"  key={link.image.toString()}  >{element_sub}</ul></li>;
                }
                else{

                    if(link.label === "Trade Entry")
                        return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/"+link.image}> {link.label} </Link> </li>;
                    else if(link.image.toString() === "REQFORQT")
                        return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/requestforquote/"+link.image}> {link.label} </Link> </li>;
                    else{
                       if(link.label === "Treasury Policy Compliance Report" || link.image.toString() === "RECREPDT" || link.image.toString() === "CFBAHREP")
                            return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/reportM/"+link.image}> {link.label} </Link> </li>;
                     else if(link.image.toString() === "ACTCLONE")
                        return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/accountclone/"+link.image}> {link.label} </Link> </li>;
                     else if(link.image.toString() === "ACCTGRP")
                        return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/pool/"+link.image}> {link.label} </Link> </li>;
                     else  if(link.image.toString() === "USERCLNE")
                        return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/treasury/"+link.image}> {link.label} </Link> </li>;
                     else  if(link.label === "Treasury Policy")
                            return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/treasury/"+link.image}> {link.label} </Link> </li>;
                     else if(link.image.toString() === "EDTDLACK"){
		        		  return <li onClick={(e) => this.handleLink(e,item)} key={link.image.toString()} id={link.image.toString()} ><Link to={"/reportCheck/"+link.image}> {link.label} </Link> </li>;
                        }
					else if(link.image.toString() === "MMFMTDRA"){
                        return <li onClick={(e) => this.handleLink(e,item)} key={link.image.toString()} id={link.image.toString()} ><Link to={"/reportCheck/"+link.image}> {link.label} </Link> </li>;
					}else if(link.image.toString() === "BEAUACL" || link.image.toString() === "BUEMAIL" || link.image.toString() === "EALERT" || link.image.toString() === "EAUATR") {
                        return <li onClick={(e) => this.handleLink(e,item)} key={link.image.toString()} id={link.image.toString()} ><Link to={"/bmalerts/"+link.image}> {link.label} </Link> </li>;
					}
                    else
                            return <li key={link.image.toString()} id={link.image.toString()} ><Link to={"/report/"+link.image}> {link.label} </Link> </li>;
                    }

                }
            });
            return(
                <li  className={classname}><a className="dropdown-toggle" data-toggle="dropdown">{item.label}<span className="glyphicon glyphicon-menu-down"></span></a><ul className="dropdown-menu"  key={item.id.toString()}  id={item.id.toString()} >{element}</ul></li>
            );
        }
    }
    render(){
        return(this.CreateNavLinks());
    }
}

export default NavBarItem;