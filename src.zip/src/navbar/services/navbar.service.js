import { authHeader,fetchHelper } from '../../_helpers';
import { alertConstants } from '../../common/constants/alert.constants';
import FormData from 'form-data';
export const navbarService = {
    fetchNavbar
};


function fetchNavbar() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var client = JSON.parse(sessionStorage.getItem('clientFirm')) === null ? "" : JSON.parse(sessionStorage.getItem('clientFirm'));
    var bodyFormData = new FormData();
    bodyFormData.append("token",user[0].token)
    bodyFormData.append("clientFirm",client)

    let _navLinks = fetchHelper.httpFormPost(alertConstants.URL+'/reactjs/reactJSUtil.jsp?actionFlag=TOPPANEL',bodyFormData);
    return _navLinks;
}