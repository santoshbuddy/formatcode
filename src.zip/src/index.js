// import "@babel/polyfill";
import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import {IntlProvider} from "react-intl";

import { store } from './_helpers';
import { App } from './App';
import { addLocaleData } from "react-intl";
import locale_en from 'react-intl/locale-data/en';
import locale_de from 'react-intl/locale-data/de';

addLocaleData([...locale_en, ...locale_de]);
const formats = {
    time: {
      '24hour': {hour12: false,hour:'numeric',minute:'numeric',second:'numeric'}
    }
  };

render(
    <Provider store={store}>
        <IntlProvider locale='en' formats={formats}>
        <App />
        </IntlProvider>
    </Provider>,
    document.getElementById('root')
);