export const MuiStyles = theme => ({
    root: {
        flexGrow: 1,
        // background:'#e9f0f7',
    },
    TabStyle: {
        flexGrow: 1,
        backgroundColor: '#007eb6'
    },
    AppBar: {
        backgroundColor: '#4e8fcc',
        boxShadow: 'none',
        border: '1px solid #cccccc',
    },
    NavTextLeft: {
        fontSize: '17px',
        fontWeight: 'bold',
        color: 'white',
        textShadow: '1px 1px 1px black',
        flexGrow: 1,
    },
    NavTextRight: {
        fontSize: '17px',
        fontWeight: 'bold',
        color: 'white',
        textShadow: '1px 1px 1px black',
        flexGrow: 1,
        textAlign: 'right'
    },
    MainContent: {
        padding: '5px 15px'
    },
    ContentTitle:{
        fontSize: '16px',
        color: '#007eb6',
        fontWeight: 'bold',
        borderBottom: '2px solid #0074A6'
    },
    ContentTitleStyle:{
        background: 'linear-gradient(to bottom, #7fbeda 0%,#bfdfed 100%)',
        border: '1px, solid #d9ecf4',
        fontSize: '16px',
        color: '#007eb6',
        fontWeight: 'bold',
        paddingLeft: 20,
        marginBottom: 5
    },
    ContentBorderStyle:{
        border: '1px solid #99cbe2',
        padding: 10,
    },
    Filter: {
        padding: '10px 5px',
        fontSize: '16px',
    },
    input: {
        width: '100%',
        borderRadius: 6,
        backgroundColor: 'white',
        border: '1px solid #ced4da',
        height: '30px',
        padding: '9px',
        fontSize: 14,
    },
    inputFocused: {
        borderColor: '#80bdff',
        boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)',
    },
    displayFlex:{
        display: 'flex',
        alignItems: 'center',
    },
    tabFromStyle:{
        display: 'flex',
        alignItems: 'center',
    },
    tabFromStyle1:{
        display: 'flex',
        alignItems: 'center',
        height:40,
    },
    tabFromStyle2:{
        display: 'flex',
        alignItems: 'center',
        border: '1px solid white'
    },
    displayFlex1:{
        display: 'flex',
        alignItems: 'center',
        height: 30,
    },
    typoStyle:{
        fontSize: 16,
    },
    Text: {
        fontSize: '14px',
        fontWeight: 'bold',
        color: '#0072b6'
    },
    Checkbox: {
        margin: '0px',
        padding: '0 2px'
    },
    select: {
        borderRadius: 6,
        background: 'linear-gradient(to bottom, #f2f2f2 0%,#ffffff 100%)',
        border: '1px solid #ced4da',
        height: '30px',
        padding: '9px',
        fontSize: 12,
        '&:hover':{
            background: 'linear-gradient(to bottom, #f5f7fa 0%,#e2e9f0 100%)',
        },
        '&:active': {
            background: 'linear-gradient(to bottom, #99cbe1 0%,#eff6fa 100%)',
        },
    },

    select1: {
        borderRadius: 6,
        background: 'linear-gradient(to bottom, #f2f2f2 0%,#ffffff 100%)',
        border: '1px solid #ced4da',
        height: '30px',
        padding: '9px',
        fontSize: 14,
        '&:hover':{
            background: 'linear-gradient(to bottom, #f5f7fa 0%,#e2e9f0 100%)',
        },
        '&:active': {
            background: 'linear-gradient(to bottom, #99cbe1 0%,#eff6fa 100%)',
        }
    },
    radioStyle: {
        display: 'flex',
        alignItems: 'flex-start',
    },
    radio: {
        marginLeft: 6,
        padding:0,
        '&:hover':{
            color: '#E5F1F6',
            border: '1px solid #0074a6'
        },
        '&$checked': {
            color: '#0074A6'
        }
    },
    checked: {},
    checkContent: {
        marginTop: 10,
    },
    OutputBar: {
        backgroundColor:'#d7e7f7',
        padding: '8px 5px',
        fontSize:'12px',
        height: 30
    },
    OutputBarLeft: {
        display: 'flex',
        justifyContent: 'flex-start',
        alignItems: 'center',
        fontSize: '14px',
        fontWeight: 'bold',
        height: 30,
        color: '#007eb6',
        background: '#bfdfed',
        border: 'none',
        borderRadius: '0px',
        boxShadow: 'none',
        marginRight: 5,
        paddingLeft:5,
    },
    btnFill: {
        color: '#fff',
        backgroundColor: '#0074A6',
        padding: '6px 12px',
        fontSize: '12px',
        textTransform: 'capitalize',
        marginLeft: '10px',
        borderRadius: '6px',
        '&:hover':{
            backgroundColor: '#00618C',
        },
        '&:active':{
            backgroundColor: '#00395D',
        }
    },
    labelText: {
        display: 'flex',
        justifyContent: 'left',
        alignItems: 'center',
        fontSize: 14,
        height: 30,
    },
    inputRate: {
        width: '20%',
        borderRadius: 6,
        backgroundColor: 'white',
        border: '1px solid #ced4da',
        height: '30px',
        padding: '9px',
        fontSize: 14,
        '&::placeholder':{
            color: '#abacad'
        }
    },
    menustyle: {
      background: 'white',
        '&:hover':  {
            background: '#e5f2f8',
            border: '1px solid #d5d5d6',
        },
        '&:active':  {
            background: '#bfdfed',
        },
        opacity: 1,
        boxShadow: '0px 1px 2px rgb(88,89,91,0.15)',
        maxHeight: 320,
        height: 30,
    },
    CheckboxStyle: {
        padding: 6,
        align: 'left',
        '&:hover':{
            color: '#d5d5d6',
        },
        '&:active': {
            color: '#0074a6'
        },
        '&$checked': {
            color: '#0074a6'
        }
    },
    footer: {
        marginTop: '20px',
        textAlign: 'center',
        marginBottom: '20px'
    },
    requireStyle: {
        color: 'red'
    },
    menustyle1: {
        background: 'red',
        color: 'red',
        fontSize: 50,
    },
    labelStyle: {
      fontSize: '14px',
      fontWeight: 'normal',
      color: '#00395D',
      paddingLeft: '7px',
      paddingRight: '7px',
      paddingTop: '11px',
    },
    labelvalue: {
        color: '#333',
        paddingLeft: '5px',
        fontSize: '13px',
        fontWeight: 'normal'
    },
    Label:{
        fontSize: '12px',
        color: '#333',
        paddingLeft: '7px',
        paddingRight: '7px',
        paddingTop: '11px',
        fontWeight: 'normal'
    },
    inputStyle: {
        border: '1px solid #d5d5d6',
        paddingLeft: '9px',
        borderRadius: '6px',
        fontSize: '12px',
        // color:'red'
    },
    input_style:{
        padding:'6px 9px',
        verticalAlign:'bottom',
        height:'30px',
        marginRight:'5px',
    },
    input_style1:{
        padding:'6px 9px',
        verticalAlign:'bottom',
        height:'30px',
        marginRight:'0px',
    },
    floatright:{
        float:'right'
    },
    w50: {
        weight: '50%',
    },
    inputSearchStyle: {
        border: '1px solid #d5d5d6',
        paddingLeft: '9px',
        borderRadius: '6px',
        fontSize: '14px',
    },
    info:{
        position: 'absolute',
        marginLeft: '5px',
        marginTop: '3px',
    },
    table: {
        minWidth: 700,
      },
    tableheader: {
        background: '#E4EAED', /* Old browsers */
        background: '-moz-linear-gradient(top, #E4EAED 0%, #F7F9FA 100%)', /* FF3.6-15 */
        background: '-webkit-linear-gradient(top, #E4EAED 0%,#F7F9FA 100%)', /* Chrome10-25,Safari5.1-6 */
        background: 'linear-gradient(to bottom, #E4EAED 0%,#F7F9FA 100%)', /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
        filter: 'progid:DXImageTransform.Microsoft.gradient( startColorstr="#E4EAED", endColorstr="#F7F9FA",GradientType=0 )', /* IE6-9 */
        color: '#00395D',
        fontSize: '12px',
        textAlign: 'center',
        whiteSpace: 'nowrap',
        verticalAlign: 'middle',
        height: '48px !important',
        borderRight: '1px solid #d5d5d6',
        borderTop: '1px solid #d5d5d6',
        padding: '0px 15px !important',
        '&:first-child':{
          borderLeft: '1px solid #d5d5d6'
        },
    },
    tabletheadtr: {
          height: '37px !important'
    },
    tabletheadth: {
          color:'#333',
          fontWeight:'bold',
          fontSize:'12px',
          paddingTop: '4px',
          paddingBottom: '4px'
    },
    tabletbodytr: {
        height: '32px'
    },
    tabletbodytd: {
        fontSize: '12px',
    },
    mrgnRgt: {
        marginTop: '1px',
        marginRight: '33px',
        marginLeft: '-11px',
    },

	connectorActive: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorCompleted: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorDisabled: {
		'& $connectorLine': {
			borderColor: theme.palette.grey[100],
			borderWidth: '2px'
		},
	},
	connectorLine: {
		transition: theme.transitions.create('border-color,border-size'),
	},
	stepIcon: {
		color: "#828384",
		fontSize: '19px',
		"&$active": {
			color: "#00395c",
			fontSize: '37px'
		},
		"&$completed": {
			color: "#00395c",
			fontSize: '19px'
		}
	},
	active: {},
	completed: {},
	typography: {
		useNextVariants: true,
	},
	iconContainer :{
		paddingRight: "0"
	},
	stepStyle:{
		paddingRight: "0",
		paddingLeft: "0"
	},
	readonly: {
		    border: '1px solid #cccccc',
		    backgroundColor: '#afb1b0',
     },
     requireLabel: {
        fontSize: 16,
        textAlign: 'center',
        color: 'red'
    },
    Text: {
      fontSize: '12px',
      fontWeight: 'bold',
      color: '#00395D'
    },
    headerPanel: {
        height: '62px',
        display: 'flex',
        justifyContent: 'space-between'
    },
    headerFlex: {
        display: 'inline-flex',
        alignItems :'center',
        height: '100%'
    },
    headerTitle: {
        paddingLeft: '15px',
        fontSize: '24px',
        color: '#fff'
    },
    headerLogo:{
        height: '100%'
    },
    headerRightcontent: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        paddingRight: 0,
    },
    lblSelect: {
        display: 'inline-flex'
    },
    headerusername: {
        color: '#fff',
        fontSize: '16px',
        textTransform: 'capitalize',
        lineHeight: '1'
        // fontFamily: 'expert-sans'
    },
    headerdate: {
        fontSize: '11px',
        color: '#fff',
    },
    userdet: {
        marginLeft: '20px',
        paddingLeft: '20px',
        paddingRight: '20px',
        borderLeft: '1px solid #fff',
    },
    headerlabelstyle:{
        color: 'rgb(255, 255, 255)',
        marginTop: '5px',
        fontSize: '16px',
        fontWeight: 'normal',
        paddingRight: '10px',
    },
    navBar: {
        padding: '26px 32px 10px'
    }
})