import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { treasuryActions } from '../actions/treasury.actions';
import { connect } from 'react-redux';
import '../../user/css/App.css';
import FormData from 'form-data';
import MUITable from './MUITable';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';

const newdata={
	"id": 7,
	"type": "data",
	"data":[{
		"rowNumber": "0",
		"chktype": "false",
		"priority": "",
		"thresholdAmt": "",
		"minAmount": "",
		"maxAmount": "",
		"productType": "",
		"fundVector": "",
		"subProduct": "",
		"term": "",
		"maxInvestment": "",
		"counterParty": "1001",
		"concentrationLimit": "",
	"entiySel": "19687983",
	"investType": "AMOUNT",
	"ploicyName": "",
	"policyId": "",
	"rating": "",
	"recordId": "",
	"rowCount": 1,
	"sheduleType": "",
}]
};

class TreasuryEditTemplate extends React.Component {
    constructor(props){
        super(props);
        this.state={
			specday: 'none',
			specdate: 'none',
			message:'',
			count:''
		}

		this.doChange = this.doChange.bind(this);
		this.dosave = this.dosave.bind(this);
		this.dodelte = this.dodelte.bind(this);
		this.specDay = this.specDay.bind(this);
		this.specDate = this.specDate.bind(this);
    }
    componentDidMount() {
		this.getFilter()
		this.state.message='';
		this.state.count='';
		console.log("componentDidMount")
   }
   getFilter(){

	sessionStorage.setItem('actionFlag', JSON.stringify(this.props.location.state.actionFlag));
	sessionStorage.setItem('policyId', JSON.stringify(this.props.location.state.policyId));
	sessionStorage.setItem('entiySel', JSON.stringify(this.props.location.state.entiySel));
    this.props.dispatch(treasuryActions.fetchTreasuryEditData());
   }

   doChange(fillObj){
        var bodyFormData = new FormData();
        for (name in fillObj) {
            bodyFormData.append(name, fillObj[name]);
        }
        this.props.dispatch(treasuryActions.fetchReportTableData(bodyFormData));
   }

	evryday(obj, e) {
		this.setState({specday:'none'})
		this.setState({specdate:'none'})
	}

	specDay(obj, e) {
		this.setState({specdate:'none'})
		if(obj === "true"){
			this.setState({specday:'block'})
		}else{
			this.setState({specday:'none'})
		}
	}

	specDate(obj, e) {
		this.setState({specday:'none'})
		if(obj === "true"){
			this.setState({specdate:'block'})
		}else{
			this.setState({specdate:'none'})
		}

	}
	dosave(obj){

		obj.append("acctGrp",document.getElementById("acctGrp").options[document.getElementById("acctGrp").selectedIndex].value);
		var inputs = document.getElementsByTagName("input");
		var eles = [];
        for(var i = 0; i < inputs.length; i++) {
            if(inputs[i].name.indexOf('specDate') == 0) {
                if(inputs[i].checked === true){
					console.log(inputs[i].checked)
					obj.append(inputs[i].name,inputs[i].value);
				}
            }
        }

		this.props.dispatch(treasuryActions.fetchTreasurySaveData(obj));
	}
	dodelte(obj,rows){
		this.props.dispatch(treasuryActions.fetchTreasuryDeleteData(obj));
		this.state.count = rows;
	}
	componentWillReceiveProps(nextProps){
		if(nextProps.treasurysavedata.treasurysavedata !== undefined){
				this.setState({message:nextProps.treasurysavedata.treasurysavedata.message})
		}
		if(nextProps.treasurydeletedata.treasurydeletedata !== undefined){
			this.setState({message:nextProps.treasurydeletedata.treasurydeletedata.message})
		}
	}
    render(){

		let specificFilter =
			<div className="form-group col-md-12 col-sm-12 mt">
				<label className="col-md-2 col-sm-2 col-xs-2"> Schedule Type:</label>
				<div className="col-md-10 col-sm-10 col-xs-10">
					<label className="radio-inline">
						<input type="radio" name="sheduleType" defaultValue="100" onChange={() => this.evryday("true", event)}/>Everyday
					</label>
					<label className="radio-inline">
						<input type="radio" name="sheduleType" defaultValue="101" onChange={() => this.evryday("true", event)}/>Weekly
					</label>
					<label className="radio-inline">
						<input type="radio" name="sheduleType" defaultValue="102" onChange={() => this.evryday("true", event)}/>Bi-Weekly
					</label>
					<label className="radio-inline">
						<input type="radio" name="sheduleType" defaultValue="103" onChange={() => this.evryday("true", event)}/>First Day of the Month
					</label>
					<label className="radio-inline">
						<input type="radio" name="sheduleType" defaultValue="104" onChange={() => this.evryday("true", event)}/>Last Day of the Month
					</label>

					<div className="clearfix"></div>

					<label className="radio-inline" style={{marginRight: '5px', float:'left'}}>
						<input type="radio" name="sheduleType" defaultValue="105" onBlur={() => this.specDay("true", event)} onChange={() => this.specDay("true", event)}/>Specific Day
					</label>
					<div id="specday" style={{display:this.state.specday,float:'left'}}>
						<label className="checkbox-inline">
							<input type="checkbox" name="specDay0" />Sunday
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" name="specDay1" />Monday
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" name="specDay2" />Tuesday
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" name="specDay3" />Wednesday
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" name="specDay4" />Thursday
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" name="specDay5" />Friday
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" name="specDay6" />Saturday
						</label>
					</div>
					<div className="clearfix"></div>

					<label className="radio-inline" style={{marginRight: '5px'}}>
						<input type="radio" name="sheduleType" onBlur={() => this.specDate("true", event)} onChange={() => this.specDate("true", event)} />Specific Date
					</label>
					<div className="clearfix"></div>
					<div id="specdate" style={{display:this.state.specdate}}>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="0" name="specDate0" />1
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="1" name="specDate1" />2
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="2" name="specDate2" />3
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="3" name="specDate3" />4
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="4" name="specDate4" />5
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="5" name="specDate5" />6
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="6" name="specDate6" />7
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="7" name="specDate7" />8
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="8" name="specDate8" />9
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="9" name="specDate9" />10
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="10" name="specDate10" />11
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="11" name="specDate11" />12
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="12" name="specDate12" />13
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="13" name="specDate13" />14
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="14" name="specDate14" />15
						</label>
						<div className="clearfix"></div>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="15" name="specDate15" />16
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="16" name="specDate16" />17
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="17" name="specDate17" />18
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="18" name="specDate18" />19
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="19" name="specDate19" />20
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="20" name="specDate20" />21
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="21" name="specDate21" />22
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="22" name="specDate22" />23
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="23" name="specDate23" />24
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="24" name="specDate24" />25
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="25" name="specDate25" />26
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="26" name="specDate26" />27
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="27" name="specDate27" />28
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="28" name="specDate28" />29
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="29" name="specDate29" />30
						</label>
						<label className="checkbox-inline">
							<input type="checkbox" defaultValue="30" name="specDate30" />31
						</label>
					</div>
				</div>
			</div>;
let muitable="";
let filters="";
let msg="",screenName;
let results=[],results1=[];
	 if(this.props.treasuryeditdata.treasuryeditdata !== undefined){
		results = this.props.treasuryeditdata.treasuryeditdata;
		results1.push(this.props.treasuryeditdata.treasuryeditdata.ClientFirms);
		results1.push(this.props.treasuryeditdata.treasuryeditdata.AccountGroups);
		results1.push(this.props.treasuryeditdata.treasuryeditdata.PolicyData);
		if(this.props.location.state.from === "Edit")
			muitable = <MUITable count={this.state.count} message={this.state.message} deletemethod={this.dodelte} savemethod={this.dosave} counterParties={results.counterParties} InvestmentTypes={results.InvestmentTypes} Terms={results.Terms} FundProduct={results.FundProduct} ProductType={results.ProductType} FundFamily={results.FundFamily} PolicyRules={results.PolicyRules} DataColumns={results.DataColumns}/>
		else
			muitable = <MUITable count={this.state.count} message={this.state.message} deletemethod={this.dodelte} savemethod={this.dosave} counterParties={results.counterParties} InvestmentTypes={results.InvestmentTypes} Terms={results.Terms} FundProduct={results.FundProduct} ProductType={results.ProductType} FundFamily={results.FundFamily} PolicyRules={newdata} DataColumns={results.DataColumns}/>
		let filetermarkup = results1 && results1.map((filter,index) => {
			if(filter.type === "Select"){
				return(
					<Grid item  key={index}>
						<InputLabel> { filter.label } :</InputLabel>
						<NativeSelect ref={ filter.name } id={filter.name}  name={filter.name}>
							{
								filter.values && filter.values.map((obj,index) => {
									return <option key={index} value={obj.id}>{obj.name}</option>
								})
							}
						</NativeSelect>
					</Grid>
				);
			}else if(filter.type === "input"){
				return (
				 <Grid item  key={index}>
					   <InputLabel> { filter.label } :</InputLabel>
					  <TextField  style={{width:'100px'}} type="text" ref={filter.name} defaultValue={filter.value} className="form-control input-sm" ref={filter.name}/>
				   </Grid>
				);
			   }
		})
		filters =  <Grid container spacing={24} >
						  {filetermarkup}
					</Grid>
	 }

	if( results1 !== undefined)
	results1.map((item,index) => {
			if(item.type === "Title")
				screenName = item.name
	})

	msg = <div className="col-md-12 col-sm-12">{this.state.message}</div>

        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{screenName}</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
							<div className="col-md-12 col-sm-12">{filters}</div>
								<div className="clearfix"></div>
								{specificFilter}
                            </div>
                        </div>

                        <div className="clearfix"></div>
						{msg}
                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                                </div>
                            </div>
 							{muitable}

                        </div>
                    </div>
                </div>
            </div>
		);

    }
}
function mapStateToProps(state) {
    const { treasuryeditdata,treasurysavedata,treasurydeletedata } = state;
    return { treasuryeditdata,treasurysavedata,treasurydeletedata };
}

const connectedTreasuryEditTemplate = connect(mapStateToProps)(TreasuryEditTemplate);
export { connectedTreasuryEditTemplate as TreasuryEditTemplate };
