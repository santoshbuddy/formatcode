import React from 'react'; 
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead'; 
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import TextField from '@material-ui/core/TextField';
import NativeSelect from '@material-ui/core/NativeSelect';
import FormData from 'form-data';
import { Link } from 'react-router-dom';
let rowdata=[];
class MUITable extends React.Component {
    constructor(props){
        super(props);
        this.state={ 
            ck:''
        }
    }
    componentWillMount(){ 
        rowdata=[]
        console.log(this.props)
        if(this.props.PolicyRules !== undefined){
            this.props.PolicyRules.data.map((item,index) =>{
                rowdata.push(item) 
            });
        }
    }
    prodOnChange(e){ 
        var indexval = e.target.name.replace("productType","") 
        if(document.getElementById("rowNumber"+indexval).checked===false){   
            rowdata[indexval].chktype="true";
        } 
            var prodval = e.target.value.toString();  
            rowdata[indexval].productType = prodval;
            this.setState({ck:indexval}) 
    }
    fundfamilyOnChange(e){ 
        var indexval = e.target.name.replace("fundVector","")
        if(document.getElementById("rowNumber"+indexval).checked===false){  
            rowdata[indexval].chktype="true";
        } 
            var prodval = e.target.value.toString();
            rowdata[indexval].fundVector = prodval;
            this.setState({ck:indexval}) 
    }
    handleChange(e,index,name) { 
        if(document.getElementById("rowNumber"+index).checked===false){  
            rowdata[index].chktype="true";
        } 
            var singlerow = rowdata[index];
            singlerow[name]=e.target.value; 
            rowdata[index] = singlerow;
            this.setState({ck:index}) 
      }
    doSave(){
        var eles = [];
        var inputs = document.getElementsByTagName("input");
        
        for(var i = 0; i < inputs.length; i++) {
            if(inputs[i].name.indexOf('rowNumber') == 0) {
                if(inputs[i].checked === true)
                    eles.push(inputs[i].name.replace("rowNumber",""));
            }
        }

        var bodyFormdata = new FormData();
        bodyFormdata.append("actionFlag","save");  

        for(var i = 0; i < eles.length; i++) {
            bodyFormdata.append("chk"+eles[i],eles[i]);
            for(var k in rowdata[eles[i]]){ 
                var singlerow = rowdata[eles[i]]; 
                 
                if(k==="policyId" || k==="entiySel" || k==="ploicyName" || k==="ploicyName" || k==="specDateCnt" ||k==="rowCount" ||k==="sheduleType")
                    bodyFormdata.append(k,singlerow[k])
                else
                    bodyFormdata.append(k+eles[i],singlerow[k])
            }
        }
        for (var pair of bodyFormdata.entries()) {
            console.log(pair[0]+ ', ' + pair[1]); 
        }

        this.props.savemethod(bodyFormdata);
        this.setState({ck:0}) 
    }
    doDelete(){
        var eles = [];
        var inputs = document.getElementsByTagName("input");
        
        for(var i = 0; i < inputs.length; i++) {
            if(inputs[i].name.indexOf('rowNumber') == 0) {
                if(inputs[i].checked === true)
                    eles.push(inputs[i].name.replace("rowNumber",""));
            }
        }

        var bodyFormdata = new FormData();
 
        bodyFormdata.append("actionFlag","DELETE");
       

        for(var i = 0; i < eles.length; i++) {
            bodyFormdata.append("chk"+eles[i],eles[i]);
            for(var k in rowdata[eles[i]]){ 
                var singlerow = rowdata[eles[i]]; 
                 
                if(k==="rowCount" )
                    bodyFormdata.append(k,singlerow[k])
                if(k==="policyId")
                    bodyFormdata.append(k,singlerow[k])
                if(k==="priority")
                    bodyFormdata.append("priority"+eles[i],singlerow[k])
            }
        }
        for (var pair of bodyFormdata.entries()) {
            console.log(pair[0]+ ', ' + pair[1]); 
        }
        this.props.deletemethod(bodyFormdata,eles);
        this.setState({ck:0}) 
    }
    checkClick(index){ 
        if(rowdata[index].chktype==="false"){  
            rowdata[index].chktype="true";
        } else{
            rowdata[index].chktype="false";
        }
        this.setState({ck:1}) 
    }
    doAddRow(){ 
        var len = rowdata.length;
        const tempObj = Object.assign({}, rowdata[rowdata.length-1]); 
        rowdata.push(tempObj) 
        
        rowdata && rowdata.map((item,index) =>{
            if(index === len){
                item.rowNumber = len.toString(); 
                item.rowCount = (len+1).toString(); 
            }
        })
        
        rowdata && rowdata.map((item,index) =>{
            var rows=[];
            
            if(index === len)
             {
                var rows=[];
                for(var k in item) 
                if(k === "rowNumber")
                    item[k] = len;
                  else rows.push(k); 

                        rows && rows.map((item1,index1) =>{ 
                            if(index1 === 1 || index1 === 2 || index1 === 3 ||  index1 === 4 || index1 === 11){
                                item[item1]="";
                            }
                        })
                rowdata[len]=item;
             }
        })
        this.setState({ck:1}) 
        
    }
    render(){  
        
        if(this.props.message === "Deleted Successfully"){

           this.props.count && this.props.count.map((item,index)=>{ 
               delete rowdata[parseInt(item)]
           })
        }
        var columns=[]; 
        if(this.props.PolicyRules.data !== undefined){
            var temp = this.props.PolicyRules.data[0];
            for(var k in temp){ 
                if(k !== "rowNumber"){
                    if(k === "chktype")
                        columns.push(<Checkbox />);
                    else
                        columns.push(k);
                }
            }
        }
        let productTypeSelect;
        if(this.props.ProductType !== undefined){
            productTypeSelect = this.props.ProductType.values && this.props.ProductType.values.map((item,index) =>{
                return <option key={index} value={item.id}>{item.name}</option>
            })
        }

        let tableheadermarkup = columns && columns.map((item,index) =>{
            if(index === 0)
                return   <TableCell key={index}>{item}</TableCell>
            else 
             return this.props.DataColumns.map((colname,ind)=>{
                if(colname.value === item)
                return   <TableCell key={index}>{colname.id}</TableCell>
            })
        })

        let tablebodymarkup;
        if(this.props.PolicyRules.data !== undefined){
            tablebodymarkup = rowdata && rowdata.map((item1,index1) =>{
                var prodtype,termprodtype;
                var rows=[];
                for(var k in item1)
                    if(k !== "rowNumber")
                        rows.push(item1[k]); 
                      var objdata = Object.keys(item1); 
                   let row = rows && rows.map((item,index) =>{ 
                                if(index === 0)
                                    return   <TableCell key={index}>
                                                    <Checkbox id={"rowNumber"+index1.toString()} name={"rowNumber"+index1.toString()} checked={item==="true"?true:false} onClick={(e)=>this.checkClick(index1)}/>
                                             </TableCell>
                                else if(index === 1 || index === 2 || index === 3 ||  index === 4 || index === 11)
                                    return  ( <TableCell key={index}>
                                                    <TextField name={objdata[index+1]+index1} defaultValue={item} onChange={(e)=>this.handleChange(e,index1,objdata[index+1])}/>
                                                </TableCell>)
                                else if(index === 5 ){ 
                                    prodtype = item;
                                    termprodtype = item;
                                    return   <TableCell key={index}>
                                                <NativeSelect ref={ this.props.ProductType.name +index1.toString()  }  name={ this.props.ProductType.name +index1.toString()  } children={productTypeSelect} defaultValue={item} onChange={(e)=>this.prodOnChange(e)} />
                                            </TableCell>
                                } 
                                else if(index === 6 ){ 
                                    let fundFamilySelect;
                                    var name;
                                    var result = this.props.FundFamily.find(e => e.id===prodtype);
                                    
                                    if(result !== undefined){ 
                                            name = result.name;
                                            console.log(name)
                                            
                                                fundFamilySelect = result.values && result.values.map((item,index) =>{ 
                                                    prodtype = item.id;                                                     
                                                    return <option key={index} value={item.id}>{item.name}</option>
                                                })
                                        
                                    }else{
                                        fundFamilySelect = <option key={index} value="">None</option>
                                    }
                                    
                                    let fundselect = <NativeSelect ref={name + index1.toString() }  name={ name + index1.toString()  } children={fundFamilySelect} defaultValue={item} onChange={(e)=>this.fundfamilyOnChange(e)} />
                                      if(termprodtype !== "1700")
                                        fundselect="";
                                    return   <TableCell key={index}>
                                              {fundselect}  
                                            </TableCell>
                                }
                                else if(index === 7 ){  
                                    let fundProductSelect;
                                    var name;  
                                    
                                    var result= this.props.FundProduct.find(e => e.id===prodtype)
                                    
                                    if(result !== undefined){
                                        name = result.name;
                                        if(name !== undefined && result.id!=="1700"){
                                            fundProductSelect = result.values && result.values.map((item,index) =>{   
                                                return <option key={index} value={item.id}>{item.name}</option>
                                            })
                                        }else{
                                            fundProductSelect =  <option key={index} value="">None</option>
                                        }
                                    }
                                       
                                    return   <TableCell key={index}>
                                                <NativeSelect ref={name + index1.toString() }  name={ name + index1.toString()  } children={fundProductSelect}   />
                                            </TableCell>
                                }
                                else if(index === 8 ){ 
                                    let termSelect;
                                     if(termprodtype === "1700"){
                                        termSelect = <NativeSelect ref={this.props.Terms.name + index1.toString()} name={this.props.Terms.name + index1.toString()}>
                                            {this.props.Terms.values && this.props.Terms.values.map((item,index) =>{   
                                                return <option key={index} value={item.id}>{item.name}</option>
                                            })}
                                        </NativeSelect>
                                    }else{
                                        termSelect = <TextField ref={this.props.Terms.name + index1.toString()} value={item}/>
                                    }
                                    return   <TableCell key={index}>
                                               {termSelect}
                                            </TableCell>
                                }
                                else if(index === 9 ){ 
                                    let maxInvSelect;
                                        maxInvSelect = <div>
                                                <TextField  value={item}/>
                                                <NativeSelect ref={this.props.InvestmentTypes.name + index1.toString()} name={this.props.InvestmentTypes.name + index1.toString()}>
                                                    {this.props.InvestmentTypes.values && this.props.InvestmentTypes.values.map((item,index) =>{   
                                                        return <option key={index} value={item.id}>{item.name}</option>
                                                    })}
                                                </NativeSelect>
                                        </div>
                                        
                                
                                    return   <TableCell key={index}>
                                               {maxInvSelect}
                                            </TableCell>
                                }
                                else if(index === 10 ){ 
                                    let counterPartiesSelect;
                                     var name;
                                    if(termprodtype === "1700"){
                                        var result = this.props.FundFamily.find(e => e.id===termprodtype);
                                        if(result !== undefined){
                                                name = result.name;
                                                counterPartiesSelect = result.values && result.values.map((item,index) =>{ 
                                                        prodtype = item.id;
                                                        return <option key={index} value={item.id}>{item.name}</option>
                                                    })
                                                }
                                        return   <TableCell key={index}>
                                                    <NativeSelect  ref={ name + index1.toString()  }  name={ name + index1.toString()  } children={counterPartiesSelect} defaultValue={item} />
                                                </TableCell>
                                    }else{
                                        counterPartiesSelect =  
                                               
                                                <NativeSelect ref={this.props.counterParties.name + index1.toString()} name={this.props.counterParties.name + index1.toString()} defaultValue={item}>
                                                    {this.props.counterParties.values && this.props.counterParties.values.map((item,index) =>{   
                                                        return <option key={index} value={item.id}>{item.name}</option>
                                                    })}
                                                </NativeSelect>
                                       
                                    }
                                        
                                
                                    return   <TableCell key={index}>
                                               {counterPartiesSelect}
                                            </TableCell>
                                } 
                    })
                    return (
                        <TableRow key={index1}>
                            {row}
                        </TableRow>
                    )
            });
        }

        return(
            <div>
                <Paper style={{overflow:'auto'}}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                {tableheadermarkup}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                                {tablebodymarkup}
                        </TableBody>
                    </Table>
                </Paper>
                <div className="col-md-6">
                    <a title="AddRow" onClick={(e)=>{this.doAddRow();}} className="btn btn-primary btn-xs">Add Row</a> 
                    <a title="Save" onClick={(e)=>{this.doSave();}} className="btn btn-primary btn-xs">Save</a> 
                    <a title="Delete" onClick={(e)=>{this.doDelete();}} className="btn btn-primary btn-xs">Delete</a> 
                    <a title="Clear" onClick={(e)=>{this.doClear();}} className="btn btn-primary btn-xs">Clear</a> 
                    <Link  className="btn btn-primary btn-xs"  to={{ pathname: '/treasury/TREAPLCY', state: {actionFlag:"edit" }}} >Return</Link>
                 </div>
            </div>
        );
    }
}

export default MUITable;