import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Grid from '@material-ui/core/Grid';
import InputLabel from '@material-ui/core/InputLabel';
import { treasuryActions } from '../actions/treasury.actions';

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
});

let id = 0;

function createData(Product, Currency, Action) {
    id += 1;
    return { id, Product, Currency, Action };
}
class MTable extends React.Component{
    constructor(props) {
        super(props);
        this.state ={
         open: false,
         subTitle:'',
            columns:[]
         }
      }
      
handleClickOpen = () => {
	 this.setState({ open: true });
       };

       
      handleSend(obj) {
        var bodyFormData = new FormData();
        for(var i =0; i<obj.length; i++){
          var temp = obj[i].name;
           //alert(obj[i].name);
           if((obj[i].name === "traders") || (obj[i].name === "currency") || (obj[i].name === "rfqTradeAmount")){
             //alert(obj[i].name+"--"+this.refs[temp].value);
             bodyFormData.append(obj[i].name, this.refs[temp].value);
           }
         }
        
        bodyFormData.append("actionFlag", "CLIENTSAVE");
        bodyFormData.append("tdPRoducts", "2001");
        bodyFormData.append("tdTenors", "1");
        // alert(bodyFormData.get('traders'));
        // alert(bodyFormData.get('currency'));
        // alert(bodyFormData.get('rfqTradeAmount'));
        // alert(bodyFormData.get('actionFlag'));
          // alert("clicked handle send .. ");
          this.props.dispatch(treasuryActions.fetchRFQReportData(bodyFormData)); 
          this.setState({ open: false });
      };

       handleClose = () => {
        //alert("clicked handle cancel .. ");
	      this.setState({ open: false });
      };
    render(){        
        const { classes } = this.props; 
        const {data} = this.props;
        
        
    //     if(this.props.tableData !== undefined){
    //       console.log("begin....");
    //       console.log(this.props.tableData);
	  //       this.props.tableData.map((item,index) => {
		//       if(item.type === "SubTitle")
		//           this.state.subTitle = item.name

		
    //   })
    //   console.log("end....");
	  // }

    let filters="";
    if(this.props.tableData !== undefined){
      console.log("begin....");
    let filetermarkup = this.props.tableData && this.props.tableData.map((filter,index) => { 
		
			if(filter.type === "SubTitle")
		          this.state.subTitle = filter.name
			else if(filter.type === "Select"){
				return(    
					<Grid item  key={index}>
						<InputLabel> { filter.label } :</InputLabel>
					  <select ref={ filter.name }  name={filter.name} className="form-control input-sm" >
                      {
                           filter.values && filter.values.map((obj,index) => { 
                                return <option key={index} value={obj.id}>{obj.name}</option>
                          })
                       } 
                   </select>
					</Grid>
				);
			}else if(filter.type === "input"){
				return (
				 <Grid item  key={index}>
					   <InputLabel> { filter.label } :</InputLabel>
					  <input ref={filter.name} defaultValue={filter.value} className="form-control input-sm" ref={filter.name}/>
				   </Grid>
				 );      
			}
    })
    filters =  <Grid container spacing={24} >
				  {filetermarkup}
			</Grid>
  }
      
        
        
        //console.log('data <><>:'+JSON.stringify( data ));

        console.log(this.props.data)

        if(data!== undefined) {
            data.map((item,index) => {
                if(index === 0){
                    var s =  item;                     
                    for(var k in s) {
                        if(k === "Action"){
                            console.log('action')
							this.state.columns.push({
								id: "btn",
								accessor: "",
								Cell: ({ original }) => { 
									return (
										<div>
											<button className="btn btn-primary btn-xs">Select</button>
										</div>
									);
								},
								Header: x => {
									return (
										 ""
									);
								} 
                            })
                        }
                        else {
                        this.state.columns.push({
                            Header: k,
                            accessor: k 
                            });
                        }
                    }
                }
            }); 
           
        }
         
        console.log('result1 columns<><>:'+JSON.stringify( this.state.columns	));   
        return  (
            <Paper className={classes.root}>
              <Table className={classes.table}>
                <TableHead>
                  <TableRow>
                    <TableCell>Reference ID</TableCell>
                    <TableCell align="center">Trader</TableCell>
                    <TableCell align="right">Currency</TableCell>
                    <TableCell align="center">Date</TableCell>
                    <TableCell align="right">Amount</TableCell>
                    <TableCell align="right">Rate</TableCell>
                    <TableCell align="right"></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {data && data.map(row => {
                    return (
                      <TableRow key={row.id}>
                        <TableCell component="th" scope="row">
                          {row.ReferenceID}
                        </TableCell>
                        <TableCell align="center">{row.Trader}</TableCell>
                        <TableCell align="right">{row.Currency}</TableCell>
                        <TableCell align="center">{row.Date}</TableCell>
                        <TableCell align="right">{row.Amount}</TableCell>
                        <TableCell align="right">{row.Rate}</TableCell>
                        <TableCell align="right"><button className="btn btn-primary btn-xs" onClick={this.handleClickOpen}>Request For Quote</button></TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
	<Dialog
	open={this.state.open}
	onClose={this.handleClose}
	aria-labelledby="alert-dialog-title"
	aria-describedby="alert-dialog-description"
	>
	<DialogTitle id="alert-dialog-title">{this.state.subTitle}</DialogTitle>
	<DialogContent>
	  <DialogContentText id="alert-dialog-description">
     {filters}
	  </DialogContentText>
	</DialogContent>
	<DialogActions>
    <Button  className="btn btn-primary btn-xs" type='button'  onClick={(e)=>{this.handleSend(this.props.tableData);}}>
                Send
          </Button>
	  
	  <Button className="btn btn-primary btn-xs" onClick={this.handleClose} color="primary" autoFocus> Cancel</Button>
	</DialogActions>
	</Dialog> 
              
            </Paper>)
    }

}

export default (withStyles(styles))(MTable);