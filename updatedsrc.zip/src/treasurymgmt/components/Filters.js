import React from 'react';  
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { Route } from 'react-router-dom';

const styles = theme => ({
  margin: {
    margin: theme.spacing.unit,
  } 
});
var dateFormat = require('dateformat');

class Filters extends React.Component {
    constructor () { 
        super() 
        this.state = { 
          startDate: new Date(),
          endDate: new Date()
        }; 
        this.handleStartDateChange = this.handleStartDateChange.bind(this); 
        this.handleEndDateChange = this.handleEndDateChange.bind(this); 
        
      } 
      componentWillMount(){
        //this.doChange();
      }
      componentWillReceiveProps(){
        if(this.props.data !== undefined){            
         this.props.data.map((filter,index) => { 
          if(filter.type === "datepicker"){
            if(filter.name === "fromDate")
                this.state.startDate=new Date(filter.value)
          }
         });
        }
             
      }
      handleStartDateChange(date) {  
         this.setState({startDate:date});
      }
      handleEndDateChange(date) {  
        this.setState({endDate:date});
     }
     doChange(e){ 
      
      var filtObj = {};
     if(this.props.data.reportdata !== undefined)      
      for(var i =0; i<this.props.data.reportdata.length; i++){
         var temp = this.props.data.reportdata[i].name; 
         
          if((this.props.data.reportdata[i].type !== "data") && (this.props.data.reportdata[i].type !== "Title") && (this.props.data.reportdata[i].type !== "datepicker") && (this.props.data.reportdata[i].type !== "Button") && (this.props.data.reportdata[i].type !== "newline")){
            filtObj[this.props.data.reportdata[i].name] = this.refs[temp].value; 
          }
 
          if(this.props.data.reportdata[i].type === "datepicker"){ 
              if(this.props.data.reportdata[i].name === "fromDate")
                filtObj[this.props.data.reportdata[i].name] = dateFormat(this.state.startDate,"mmm d, yyyy");  
              if(this.props.data.reportdata[i].name === "toDate")
                filtObj[this.props.data.reportdata[i].name] = dateFormat(this.state.endDate,"mmm d, yyyy");  
           }
          }  
            this.props.method(filtObj);
     }
      
    render(){  
        const { data } = this.props;
        const { classes } = this.props;
        let filetermarkup;  
          
        if(data !== undefined){            
        filetermarkup = data.map((filter,index) => { 
            if(filter.type === "Select"){
             return(    
              <Grid item  key={index}>
                   <InputLabel> { filter.label } :</InputLabel>
                   <NativeSelect ref={ filter.name }  name={filter.name}>
                      {
                           filter.values && filter.values.map((obj,index) => { 
                              return <option key={index} value={obj.id}>{obj.name}</option>
                          })
                       } 
                   </NativeSelect>
               </Grid>
               );
            }else if(filter.type === "datepicker"){
                if(filter.name === "fromDate"){
                 return (
                  <Grid item  key={index}>
                       <InputLabel> { filter.label }:</InputLabel>
                      <TextField type="date" ref={ filter.name } name={filter.name}  selected={this.state.startDate}  onChange={this.handleStartDateChange} />
                   </Grid>
                 );
                }else if(filter.name === "toDate"){
                 return (
                  <Grid item  key={index}>
                       <InputLabel> { filter.label }:</InputLabel>
                      <TextField type="date" ref={ filter.name } name={filter.name}  selected={this.state.endDate}   onChange={this.handleEndDateChange} />
                   </Grid>
                 );
                }
              }else if((filter.type === "Button") && (filter.flag === "USERCLNE")){
                return (
                  <Grid item  key={index}>
                  <Route render={({ history}) => (
		      	        <Button size="small" variant="outlined" className={classes.margin}  title={ filter.name } onClick={() => { history.push('/userprofile/TREASMGMTUSERCLONE') }} key={filter.id.toString()}>
	      		          { filter.name }
		      	        </Button>
			            )} />
                </Grid>
               );
              }else if(filter.type === "Button"){
                return (
                  <Grid item  key={index}>
                      <Button size="small" variant="outlined" className={classes.margin}  title="Go" onClick={(e)=>{this.doChange();}}>{ filter.name }</Button> 
                  </Grid>
               );
              }else if(filter.type === "input"){
               return (
                <Grid item  key={index}>
                      <InputLabel> { filter.label } :</InputLabel>
                     <TextField  style={{width:'100px'}} type="text" ref={filter.name} defaultValue={filter.value} className="form-control input-sm" ref={filter.name}/>
                  </Grid>
               );      
              }else if(filter.type === "checkbox"){
               return (
                <Grid item  key={index}>
                      <InputLabel> { filter.label } :</InputLabel>
                     <TextField type="checkbox" ref={filter.name}/>
                  </Grid>
               );      
              }else if(filter.type === "radio"){
               return (
                <Grid item  key={index}>
                      <InputLabel> { filter.label } :</InputLabel>
                     <TextField type="radio" ref={filter.name}/>
                  </Grid>
               );     
              }else if(filter.type === "textarea"){
               return (
                <Grid item xs  key={index}>
                      <InputLabel> { filter.label } :</InputLabel>
                     <TextField  type="textarea" rows="5" cols="15" ref={filter.name} />
                  </Grid>
               );      
              }else if(filter.type === "newline"){
                return  <div key="newline" className="clearfix"></div>        
              } 
        });
    }
 
        return(
            <Grid container spacing={24} >
                {filetermarkup}
            </Grid>
        );
    }
}

export default  withStyles(styles)(Filters);