import React from 'react'; 
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Radio from '@material-ui/core/Radio';
import TextField from '@material-ui/core/TextField';
import NativeSelect from '@material-ui/core/NativeSelect';
import FormData from 'form-data';

const styles = theme => ({
    selectWidth: {
        fontSize: '12px',
        width: 99,
        height: 20
      }
});
class RFQMUITable extends React.Component {
    
    constructor(props){
        super(props);
        this.state={
            result1:'',
            ck:''
        }
         this.rowdata=[];

    }
    componentWillMount(){
        //console.log("in component will mount")
        //console.log(this.props.RFQData)
        // if(this.props.RFQData !== undefined){
        //     this.props.RFQData.data.map((item,index) =>{
        //         rowdata.push(item) 
        //     });
        // }
    }

    componentDidUpdate(){
        //console.log("in component update mount")
        //console.log(this.props.RFQData)
       
        //this.setState({ck:"1"});
    }
    prodOnChange(e){ 
    }
   
    
    checkClick(index){ 
        if(this.rowdata[index].chktype==="false"){  
            this.rowdata[index].chktype="true";
            } else{
            this.rowdata[index].chktype="false";
            }
        this.setState({ck:1}) 
    }
   
    render(){  
        const {classes} = this.props
        var columns=[]; 
        
        //console.log("::AccountType ........."+this.props.AccountType)
        //console.log("subblock .........")
        //console.log(this.props.RFQData)
        if(this.props.RFQData !== undefined && this.rowdata.length===0){
            this.props.RFQData.data.map((item,index) =>{
                this.rowdata.push(item) 
            });
        }

        if(this.props.RFQData !== undefined){
            var temp = this.props.RFQData.data[0];
            for(var k in temp){ 
                if(k !== "rowNumber"){
                    if(k === "chktype")
                        columns.push(<Radio />);
                    else
                        columns.push(k);
                }
            }
        }
        let accountTypeSelect;
        if(this.props.AccountType !== undefined){
            accountTypeSelect = this.props.AccountType.values.map((item,index) =>{
                return <option key={index} value={item.id}>{item.name}</option>
            })
        }

        let cusipListSelect;
        if(this.props.CusipList !== undefined){
            cusipListSelect = this.props.CusipList.values.map((item,index) =>{
                return <option key={index} value={item.id}>{item.name}</option>
            })
        }

        let tradeModeListSelect;
        if(this.props.TradeModeList !== undefined){
            tradeModeListSelect = this.props.TradeModeList.values.map((item,index) =>{
                return <option key={index} value={item.id}>{item.name}</option>
            })
        }

        let tableheadermarkup = columns && columns.map((item,index) =>{
            if(index === 0)
            return   <TableCell key={index}>{item}</TableCell>
            else 
             return this.props.DataColumns.map((colname,ind)=>{
                if(colname.value === item)
                return   <TableCell key={index}>{colname.id}</TableCell>
            })
             
        })

        let tablebodymarkup;
        if(this.props.RFQData !== undefined){
            tablebodymarkup = this.rowdata && this.rowdata.map((item1,index1) =>{
                var prodtype,termprodtype;
                var cusiptype,cusipIdtype;
                var rows=[];
                for(var k in item1)
                    if(k !== "rowNumber")
                        rows.push(item1[k]); 
                      var objdata = Object.keys(item1); 
                   let row = rows && rows.map((item,index) =>{ 
                                if(index === 0)
                                    return   <TableCell key={index}>
                                                    <Radio id={"rowNumber"+index1.toString()} name={"rowNumber"+index1.toString()} checked={item==="true"?true:false} onClick={(e)=>this.checkClick(index1)}/>
                                             </TableCell>
                                else if(index === 1 ){ 
                                    prodtype = item;
                                    termprodtype = item;
                                    return   <TableCell key={index}>
                                        <NativeSelect className={classes.selectWidth} ref={ this.props.AccountType.name +index1.toString()  }  name={ this.props.AccountType.name +index1.toString()  } children={accountTypeSelect} defaultValue={item} onChange={(e)=>this.prodOnChange(e)} />
                                        </TableCell>
                                }
                                else if(index === 2 ){ 
                                    cusiptype = item;
                                    cusipIdtype = item;
                                    return   <TableCell key={index}>
                                        <NativeSelect className={classes.selectWidth} ref={ this.props.CusipList.name +index1.toString()  }  name={ this.props.CusipList.name +index1.toString()  } children={cusipListSelect} defaultValue={item}  />
                                        </TableCell>
                                }
                                else if(index === 7 ){ 
                                    cusiptype = item;
                                    cusipIdtype = item;
                                    return   <TableCell key={index}>
                                        <NativeSelect className={classes.selectWidth}ref={ this.props.TradeModeList.name +index1.toString()  }  name={ this.props.TradeModeList.name +index1.toString()  } children={tradeModeListSelect} defaultValue={item}  />
                                        </TableCell>
                                }                                
                                else 
                                    return   <TableCell key={index}>{item}</TableCell>
                    })
                    return (
                        
                            <TableRow key={index1}>
                                {row}
                            </TableRow>
                    )
            });
        }
        

        return(
            <div>
                <Paper style={{overflow:'auto'}}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                {tableheadermarkup}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                                {tablebodymarkup}
                        </TableBody>
                    </Table>
                </Paper>
                
            </div>

        );
    }
}

export default withStyles(styles)(RFQMUITable);