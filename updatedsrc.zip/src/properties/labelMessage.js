import { labelUS } from '../properties/LabelBundle_en_US';
import { labelTr } from '../properties/LabelBundle_tr_TR';

let message = (sessionStorage.getItem('userLocaleTxt') === null || sessionStorage.getItem('userLocaleTxt') === "en_US") ? labelUS : labelTr;

export const labelMsg = {
	getLabel,
};

function getLabel(msgkey) {
	return message[msgkey];
}
