import React from "react";
import PropTypes from 'prop-types';
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import axios from 'axios';
import FormData from 'form-data';
import Loading from '../../common/Loading';
import { alertConstants } from '../../common/constants/alert.constants';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import FiltersPopUp from './FiltersPopUp';
import Grid from '@material-ui/core/Grid';
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import {muiTableStyles} from '../../styles/muidatatableCss';

// import {addCommaDV} from '../../tradeentry/components/amountValidations';

var data,fileds,title;
let screenLinkImage;
let fromDate;
let toDate;
let data1;
let columns1;
let options;
let filterFlag=true;
let acctLocalNbr;
let policyName;
let statusTxt;
var commonData = [];
var actionsList = [];
var actionbtns = [];
let popUpData1;
let popUpColumns1;
let popUpMsg;
let errPopUpMsg;
let optionsPopUp;
var popUpData,fileds,title;
var mmmfAcct,selCompanyId,currencyCode,prId,subProd,processId,investAccount,refFundNbr,resData;

const styles = theme => ({
	paper: {
		padding:'5px',
		textAlign: 'left',
		color: 'rgb(255,0,0)',
		marginBottom:'10px'
	}
});

class AcctScrollDialogPopUp extends React.Component {

getMuiTheme = () =>
	        createMuiTheme({
	          overrides: {
	            MUIDataTableHeadCell: {
	              root: {
	                background: '#eaeaea !important',
	                color: '#0066b2 !important',
	                textTransform: 'uppercase',
	                whiteSpace: 'nowrap',
	                fontWeight:'bold',
	                borderRight: '1px solid #b3b3b3',
	                borderTop: '1px solid #b3b3b3',
	                borderBottom: '1px solid #b3b3b3',
	                '&:first-child':{
	                  borderLeft: '1px solid #b3b3b3'
	                },
	                '&:last-child':{
	                  paddingRight: '4px'
	                }
	              }
	            },
	            MUIDataTableBodyRow: {
	              root: {
	                '&:nth-child(odd)': {
	                  backgroundColor: '#f7f8f9'
	                }
	              }
	             },
	             MuiTableCell: {
	               root: {
	                whiteSpace: 'nowrap',
	                padding: '7px 5px',
	                borderRight: '1px solid #f3ebeb',
	                // borderTop: '1px solid #c3c3c3',
	                borderBottom: '1px solid #f3ebeb',
	                '&:last-child':{
	                  borderRight:'0px'
	                },
	                '&:first-child':{
	                  borderLeft: '1px solid #f3ebeb'
	                }
	               }
	             },
	             MuiTableRow: {
	               root:{
	                 height:'auto'
	               },
	               head: {
	                 height:'auto',
	               }
	             }
	            }
	          });

  constructor(props){
    super(props);
    this.state = {
    open: false,
    openPopUp: false,
    scroll: "paper",
    alertmsg:false,
    updateFlag: false,
  };
  this.handleClickOpen = this.handleClickOpen.bind(this);
  this.doChange = this.doChange.bind(this);
  this.doRevoke = this.doRevoke.bind(this);
}

 //doChange (scroll,rowData) {
 doChange(filterNameValueArray) {
	 var jsonBody = new FormData();
	 if(filterNameValueArray !== undefined){
      for(var i =0; i<filterNameValueArray.length; i++){
		  var temp = filterNameValueArray[i];
		  if(temp.id == "eventHistory" && temp.value == "1"){
			  //alert("event history block");
		  }else{
			  jsonBody.append(temp.id, temp.value);
		  }
		  //alert(temp.id+" ,value:"+temp.value);
	  }}
	 filterFlag=false;
	 //alert("in dochange block .acctLocalNbr.."+acctLocalNbr);

    var url;
    var user = JSON.parse(sessionStorage.getItem('user'));
    jsonBody.append("token",user[0].token);
    jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
    // console.log('screenLinkImage:'+screenLinkImage);
//console.log("fromdate ::"+JSON.parse(sessionStorage.getItem('fromDate')));
//console.log("todate ::"+JSON.parse(sessionStorage.getItem('toDate')));
jsonBody.append("actionFlag","GO");

     if(screenLinkImage === "ACCPOREP"){
		//alert("ACCPOREP::acctnbr:"+rowData.rowData[17]);
		jsonBody.append("chkStatus","ALL");
		jsonBody.append("subSource","ACCPOREP");
		jsonBody.append("acctNbr",acctLocalNbr);
		//jsonBody.append("acctNbr","1686536897283335");//acctLocalNbr
		jsonBody.append("issueChild","ALL");
		jsonBody.append("eventHistory","ALL");
		jsonBody.append("accountList","ALL");
		jsonBody.append("acctnature","All");
		//jsonBody.append("fromDate",JSON.parse(sessionStorage.getItem('fromDate')));
    	//jsonBody.append("toDate",JSON.parse(sessionStorage.getItem('toDate')));
		url=alertConstants.URL+"/MMMFACCNOPOS.do";
	}else if(screenLinkImage === "MMDAACC"){
		//alert("MMDAACC::acctnbr:"+rowData.rowData[6]);
		jsonBody.append("chkStatus","ALL");
		jsonBody.append("subSource","MMDAACC");
		jsonBody.append("acctNbr",acctLocalNbr);
		//jsonBody.append("acctNbr","1686536897283335");//acctLocalNbr
		jsonBody.append("issueChild","ALL");
		jsonBody.append("eventHistory","ALL");
		jsonBody.append("accountList","ALL");
		jsonBody.append("acctnature","All");
		//jsonBody.append("fromDate",JSON.parse(sessionStorage.getItem('fromDate')));
    	//jsonBody.append("toDate",JSON.parse(sessionStorage.getItem('toDate')));
		url=alertConstants.URL+"/MMDAACCNOPOS.do";
	}
	// console.log("scrolldialog .... url info::"+url+",jsonBody:"+jsonBody);

    //jsonBody.append("transId",rowData.rowData[9]);
    axios({
      method: 'post',
      url:url,
      data: jsonBody,
      config: { headers: {'Content-Type': 'multipart/form-data' }}
    }).then((response)=>{
      data = response.data;
      this.setState({ updateFlag: true });
      //this.setState({ open: true, scroll });
      });
    };


	enterTrade(e) {
		var paramVal = e.target.id;
		// console.log('In SCrollDialog---->commonData--',commonData);
		if(paramVal == 'CLOSEACCOUNT') {
			if(commonData.terminateFlag == 'true') {
				this.setState({ alertmsg: true });
			} else {
				this.props.func(commonData, paramVal);
			}

		}
		else {
			this.props.func(commonData, paramVal);
		}

		//this.props.dispatch(tradeActions.fetchTradeReviewData(bodyFormdata));
		//return <Redirect to={{ pathname: '/DEALENT' }} />
	}

	handleClickOpen (scroll,rowData,tabName) {
		var jsonBody = new FormData();
		var url;
		var user = JSON.parse(sessionStorage.getItem('user'));
		jsonBody.append("token",user[0].token);
 		if(screenLinkImage === "LOOKUP")
		{
			//console.log("mar 26, 2019 rowData values::",rowData);
			if(tabName != undefined && tabName == 'PENDINGAPR')
			{
				title		= this.props.rowData.rowData[3]+"("+this.props.rowData.rowData[2]+")";
				mmmfAcct	= rowData.rowData[8];
				selCompanyId= rowData.rowData[11];
				currencyCode= rowData.rowData[4];
				prId		= rowData.rowData[15];
			 processId=rowData.rowData[9];
				subProd		= rowData.rowData[12];
				investAccount= rowData.rowData[16];
				refFundNbr	= rowData.rowData[2];
				//console.log("mar 26, 2019 mmmfAcct:",mmmfAcct+",selCompanyId:",selCompanyId+",currencyCode:",currencyCode+",parent prod id:::",prId+",subProd::",subProd+",investAccount::",investAccount+",refFundNbr::",refFundNbr);
				jsonBody.append("mmmfAcct",mmmfAcct);
				jsonBody.append("clientFirm",selCompanyId);
			 jsonBody.append("processId",processId);
				jsonBody.append("clCompanyId", selCompanyId);
				jsonBody.append("currencyCode", currencyCode);
				jsonBody.append("prId", prId);
				jsonBody.append("subProd", subProd);
				jsonBody.append("selectedProd", subProd);
				jsonBody.append("acctNbr", mmmfAcct);
				jsonBody.append("investAccount", investAccount);
				jsonBody.append("refFundNbr", refFundNbr);
				jsonBody.append("lookUpFlag","YES");
				jsonBody.append("format", 'MMM dd, yyyy');
			} else {
				title=this.props.rowData.rowData[3]+"("+this.props.rowData.rowData[2]+")";
				jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
				jsonBody.append("mmmfAcct",rowData.rowData[15]);
				jsonBody.append("selectedProd",rowData.rowData[9]);
				jsonBody.append("currencyCode",rowData.rowData[4]);
				jsonBody.append("tabName","VIEWALL");
			}
			url=alertConstants.URL+"/MMMFACCTLOOKUP.do";
		}else if(screenLinkImage === "NOTIFICATIONS"){
	     //   alert("before submiting in popup block.rowData.rowData[1]::"+JSON.stringify(rowData.rowData));

	        	if(rowData.rowData[0] === 'MMFACCT' || rowData.rowData[1] === 'MMFACCT'){
					//alert("in handle click opent ...");
					jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
					//alert("MMFRECRE::acctnbr:"+rowData.rowData[1]);
					if(rowData.rowData[0] === 'MMFACCT')
					jsonBody.append("mmmfAcct",rowData.rowData[1]);
					else
					jsonBody.append("mmmfAcct",rowData.rowData[2]);
  					jsonBody.append("tabName","VIEWALL");

				url=alertConstants.URL+"/MMMFACCTLOOKUP.do";
				} else {
				//alert("in handle click opent ...");
					jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));


				jsonBody.append("mmmfAcct",rowData.rowData[9]);
 				jsonBody.append("tabName","VIEWALL");

				url=alertConstants.URL+"/MMMFACCTLOOKUP.do";
			}
		}else if(screenLinkImage === "HOME"){
	     //   alert("before submiting in popup block.rowData.rowData[1]::"+JSON.stringify(rowData.rowData));


				//alert("in handle click opent ...");
				 jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));


				jsonBody.append("mmmfAcct",rowData.rowData[9]);
 				jsonBody.append("tabName","VIEWALL");

				url=alertConstants.URL+"/MMMFACCTLOOKUP.do";

		}else if(screenLinkImage === "CRALKUP")
		{
			title=this.props.rowData.rowData[2]+"("+this.props.rowData.rowData[1]+")";
			jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
			jsonBody.append("lookUpFlag","YES");
			jsonBody.append("cra",rowData.rowData[9]);
			url=alertConstants.URL+"/CRAACCTLKUP.do";
		}

		//jsonBody.append("transId",rowData.rowData[9]);
		axios({
			method: 'post',
			url:url,
			data: jsonBody,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
		}).then((response)=>{
			data = response.data;
			// console.log("response.data===>",response.data)
			this.setState({ open: true, scroll });
		});
	};

	doRevoke() {
		if(window.confirm('Are you sure, you want to revoke this account?')){
		var bodyFormdata 	= new FormData();
		var user 			= JSON.parse(sessionStorage.getItem('user'));

		bodyFormdata.append("token",user[0].token);
		bodyFormdata.append("lookUpFlag",'YES');
		bodyFormdata.append("actionFlag",'REVOKE');
		bodyFormdata.append("mmmfAcct",commonData['Account Number']);
		bodyFormdata.append("processId",commonData['processId']);
		bodyFormdata.append("tabName",this.props.tabName);

		axios({
			method: 'post',
			url:alertConstants.URL +"/MMMFACCTLOOKUP.do",
			data: bodyFormdata,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
		}).then((response)=>{
			this.handleClose();
			this.props.goback(this.props.tabName);
		});
	}
}

approveDetails(scroll) {
	//alert("in approve block .. ");
	var url;
	var bodyFormdata = new FormData();
	var user 		= JSON.parse(sessionStorage.getItem('user'));
		bodyFormdata.append("token",user[0].token);
		// console.log("mar 26, 2019 approve block  mmmfAcct:",mmmfAcct+",selCompanyId:",selCompanyId+",currencyCode:",currencyCode+",parent prod id:::",prId+",subProd::",subProd+",investAccount::",investAccount+",refFundNbr::",refFundNbr);
		bodyFormdata.append("mmmfAcct",mmmfAcct);
		bodyFormdata.append("clientFirm",selCompanyId);
		bodyFormdata.append("processId",processId);
		bodyFormdata.append("clCompanyId", selCompanyId);
		bodyFormdata.append("currencyCode", currencyCode);
		bodyFormdata.append("prId", prId);
		bodyFormdata.append("subProd", subProd);
		bodyFormdata.append("selectedProd", subProd);
		bodyFormdata.append("acctNbr", mmmfAcct);
		bodyFormdata.append("investAccount", investAccount);
		bodyFormdata.append("refFundNbr", refFundNbr);
		bodyFormdata.append("lookUpFlag","YES");
		bodyFormdata.append("format", 'MMM dd, yyyy');
		bodyFormdata.append("actionFlag", "APPROVE");
		bodyFormdata.append("mmfSrch", "Y");
		bodyFormdata.append("chkStatus", "Y");
		bodyFormdata.append("lookUpFlag", "YES");
		bodyFormdata.append("actionVal", "");

		if(confirm("Are you sure, you want to approve the data?"))
		{
			url=alertConstants.URL+"/MMMFACCTLOOKUP.do";
			axios({
			method: 'post',
			url:url,
			data: bodyFormdata,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
			}).then((response)=>{
			popUpData = response.data;
			// console.log("mar 26, 2019 .approve. response.data===>",resData)
			//alert("approve submited successfully");
			this.handleClose();
			this.setState({ openPopUp: true, scroll });
			});
		}
	}

rejectDetails(scroll) {
var url;
	//alert("in reject block .. ");
	var bodyFormdata = new FormData();
	var user 		= JSON.parse(sessionStorage.getItem('user'));
		bodyFormdata.append("token",user[0].token);
		// console.log("mar 26, 2019 approve block  mmmfAcct:",mmmfAcct+",selCompanyId:",selCompanyId+",currencyCode:",currencyCode+",parent prod id:::",prId+",subProd::",subProd+",investAccount::",investAccount+",refFundNbr::",refFundNbr);
		bodyFormdata.append("mmmfAcct",mmmfAcct);
		bodyFormdata.append("clientFirm",selCompanyId);
		bodyFormdata.append("clCompanyId", selCompanyId);
		bodyFormdata.append("processId",processId);
		bodyFormdata.append("currencyCode", currencyCode);
		bodyFormdata.append("prId", prId);
		bodyFormdata.append("subProd", subProd);
		bodyFormdata.append("selectedProd", subProd);
		bodyFormdata.append("acctNbr", mmmfAcct);
		bodyFormdata.append("investAccount", investAccount);
		bodyFormdata.append("refFundNbr", refFundNbr);
		bodyFormdata.append("lookUpFlag","YES");
		bodyFormdata.append("format", 'MMM dd, yyyy');
		bodyFormdata.append("actionFlag", "REJECT");
		bodyFormdata.append("mmfSrch", "Y");
		bodyFormdata.append("chkStatus", "Y");
		bodyFormdata.append("lookUpFlag", "YES");
		bodyFormdata.append("actionVal", "");

		if(confirm("Are you sure, you want to reject the data?"))
		{
			url=alertConstants.URL+"/MMMFACCTLOOKUP.do";
			axios({
			method: 'post',
			url:url,
			data: bodyFormdata,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
			}).then((response)=>{
			popUpData = response.data;
			// console.log("mar 26, 2019 reject.. response.data===>",resData)
			this.handleClose();
			this.setState({ openPopUp: true, scroll });
			//alert("reject submited successfully");
			});
		}
	}

  handleClose = () => {
    this.setState({ open: false });
  };

handlePopUpClose = () => {
       popUpMsg="";
       errPopUpMsg="";
      //alert("popup close popup ...");
      this.setState({ openPopUp: false });
      this.props.goback("PENDINGAPR");
 };
  render() {
	  	const { classes } = this.props;

	let messageTxt = 'empty';
	let errMsg='empty';
	let approveBtn="";
	let revokeBtn = '';
	let rejectBtn="";
    let linkName;
    let tabName;
    let dataFlag=true;
    if (this.props.tabName !== undefined)
      tabName = this.props.tabName;

if (this.props.linkName !== undefined)
      linkName = this.props.linkName;

    if (this.props.screenLinkImage !== undefined){
      screenLinkImage = this.props.screenLinkImage;
      // console.log("feb2019 screenLinkImage",screenLinkImage);
    }

    let userLocale="";
	var user = JSON.parse(sessionStorage.getItem('user'));
	if(user[0].localeLang !== undefined){
		userLocale=user[0].localeLang;
	}
    if (this.props.fromDate !== undefined){
      fromDate = this.props.fromDate;
    //  console.log("feb2019 fromDate",fromDate);
    }

    if (this.props.toDate !== undefined){
      toDate = this.props.toDate;
    //  console.log("feb2019 toDate",toDate);
    }

  let tbody="";
  let alertdiv = '';
  let subBlk;
   if( data !== undefined && data.toString().trim().length!==0){
   // console.log("Money Fund Account Position data::",data);

	var mainList=data//.find(item =>item.name ==="commonData")// === listName)
	if(mainList!==undefined && mainList.commonData!==undefined)
	commonData = mainList.commonData;

	actionsList =  mainList.ACTIONS;

	// var mainList=data.find(item =>item.name ==="columns")// === listName)
	// columns1 = mainList.COLUMNS;

	// mainList=data.find(item =>item.name ==="DATA")// === listName)
	// data1 = mainList.DATA;

	// options = {
	// 	filterType: "dropdown",
	// 	selectableRows: false,
	// 	pagination: true,
  //       rowsPerPage: 10,
	// 	responsive: "scroll",
	// 	fixedHeader: false
	// };
    // console.log("Money Fund Account Position field values::",commonData);

    if(commonData !== undefined && commonData.length !== 0 )
    {

		if(actionsList != undefined)
		{
			actionbtns = [];
			actionsList && actionsList.map((item, index) => {
				actionbtns.push(<button id={item.JSFUNCTION} onClick={e => this.enterTrade(event)} className="btn btn-primary btn-xs mt pull-right">{item.label}</button>);
			});
		}

		// subBlk = <FiltersPopUp method={this.doChange} data={data} filterFlag={filterFlag}/>

if(screenLinkImage!== undefined && screenLinkImage === "MMDAACC")
{
   tbody = <table className="table" width="100%">
    <tbody>
          <tr>
            <td>
                <label> Client Name: </label>
                <label className="TxtNrml"> {commonData.clientName} </label>
            </td>
            <td>
                <label> Product: </label>
                <label className="TxtNrml"> {commonData.product} </label>
            </td>
			<td>
				<label> Account: </label>
				<label className="TxtNrml"> {commonData.account} </label>
			</td>
          </tr>
          <tr>
				<td>
				  <label> Currency : </label>
				  <label className="TxtNrml"> {commonData.currency} </label>
				</td>
	              <td>
	                  <label> Balance: </label>
	                  {/* <label className="TxtNrml">{commonData.balance === "Pending"?commonData.balance:addCommaDV(commonData.balance,userLocale,"2","2")} </label> */}

	              </td>
	              <td>
	                  <label> &nbsp; </label>
	                  <label className="TxtNrml"> &nbsp; </label>
	              </td>
            </tr>

            <tr>
	    	              <td>
	    	                  <label> Rate : </label>
	    	                  <label className="TxtNrml"> {commonData.rate} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Posted Date: </label>
	    	                  <label className="TxtNrml"> {commonData.postedDate} </label>
	    	              </td>
	    	              <td>
	    	                  <label> &nbsp; </label>
	    	                  <label className="TxtNrml"> &nbsp; </label>
	    	              </td>
            </tr>
     </tbody>
  </table>
}else{
let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
		if(this.state.alertmsg) {
			alertdiv = <Grid container spacing={24}>
        				<Grid item xs={12}>
          					<Paper className={classes.paper}>{message["RECTIFY_PROCEED"]}<br/>{message["CLOSEBALAM"]}</Paper>
        				</Grid>
        			</Grid>
		}

		 //alert("mar 26, 2019 .. commonData.checkerFlag::"+commonData.checkerFlag);
		 if(commonData.checkerFlag !== undefined && commonData.checkerFlag === 'true')
		 {
		 	approveBtn=<button onClick={e => this.approveDetails("paper")} className="btn btn-primary btn-xs mt pull-right">Approve</button>
		 	rejectBtn=<button onClick={e => this.rejectDetails("paper")} className="btn btn-primary btn-xs mt pull-right">Reject</button>
		 }

		 if(commonData.makerFlag !== undefined && commonData.makerFlag === 'makerFlag') {
			revokeBtn=<button onClick={e => this.doRevoke()} className="btn btn-primary btn-xs mt pull-right">Revoke Changes</button>
		 }

		tbody =
		<div>
		<table className="table" width="100%">
    <tbody>
          <tr>
            <td>
                <label> Account Number: </label>
                <label className="TxtNrml"> {commonData['refacctnbr']} </label>

            </td>
            <td>
                <label> Status: </label>
                <label className="TxtNrml"> {commonData.Status} </label>
            </td>
            <td>
                <label>  Creation Date: </label>
                <label className="TxtNrml"> {commonData.acctOpened} </label>
            </td>
          </tr>
			</tbody>
		</table>
		<div className="panel panel-primary clearfix" >
			<div className="panel-heading"><h4 className="panel-title">Description </h4></div>
		<div className="panel-body">
		<table className="table" width="100%">

    <tbody>


          <tr>
	              <td>
	                  <label> Short Name : </label>
	                  <label className="TxtNrml"> {commonData['Short Name']} </label>
	              </td>
	              <td>
	                  <label> Long Name : </label>
	                  <label className="TxtNrml"> {commonData['Long Name']} </label>
	              </td>
	              <td>
	                  <label> Client Identifier: </label>
	                  <label className="TxtNrml"> {commonData['Client Identifier']} </label>
	              </td>
            </tr>
					</tbody>
					</table>
				</div>
				</div>
				<div className="panel panel-primary clearfix" >
			<div className="panel-heading"><h4 className="panel-title">Accounts & Dividend Options </h4></div>
		<div className="panel-body">
					<table className="table" width="100%">

    <tbody>
            <tr>
	              <td>
	                  <label> Investment Account : </label>
	                  <label className="TxtNrml"> {commonData['Investment Account']} </label>
	              </td>
	              <td>
	                  <label> Account Structure : </label>
	                  <label className="TxtNrml"> {commonData['Account Structure']} </label>
	              </td>
	              <td>
	                  <label> Subscription DDA Number: </label>
	                  <label className="TxtNrml"> {commonData['Subscription DDA Number']} </label>
	              </td>
            </tr>
            <tr>
	    	              <td>
	    	                  <label> Settle Type : </label>
	    	                  <label className="TxtNrml"> {commonData['dvndStleType']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Dividend Account: </label>
	    	                  <label className="TxtNrml"> {commonData['Dividend Account']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Dividend Type  : </label>
	    	                  <label className="TxtNrml"> {commonData['Dividend Type']} </label>
	    	              </td>
            </tr>
					</tbody>
					</table>
					</div>
					</div>
					<div className="panel panel-primary clearfix" >
			<div className="panel-heading"><h4 className="panel-title">Tax Information  </h4></div>
		<div className="panel-body">
					<table className="table" width="100%">

    <tbody>
						<tr>
	    	              <td>
	    	                  <label> Tax ID  : </label>
	    	                  <label className="TxtNrml"> {commonData['Tax ID']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Taxpayer Type : </label>
	    	                  <label className="TxtNrml"> {commonData['Taxpayer Type']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Acc Social Code : </label>
	    	                  <label className="TxtNrml"> {commonData['Acc Social Code']} </label>
	    	              </td>
            </tr>
						<tr>

	    	              <td colSpan="3">
	    	                  <label> FATCA Compliant  : </label>
	    	                  <label className="TxtNrml"> {commonData['FATCA Compliant']} </label>
	    	              </td>
            </tr>
						</tbody>
					</table>
					</div>
					</div>
					<div className="panel panel-primary clearfix" >
			<div className="panel-heading"><h4 className="panel-title">Primary Legal Address  </h4></div>
		<div className="panel-body">
					<table className="table" width="100%">

    <tbody>
						<tr>
	    	              <td>
	    	                  <label> Company Name : </label>
	    	                  <label className="TxtNrml"> {commonData['Company Name']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> City : </label>
	    	                  <label className="TxtNrml"> {commonData['City']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Zip  : </label>
	    	                  <label className="TxtNrml"> {commonData['Zip']} </label>
	    	              </td>
            </tr>
						<tr>
	    	              <td>
	    	                  <label> Address : </label>
	    	                  <label className="TxtNrml"> {commonData['stmtAddr1']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> State : </label>
	    	                  <label className="TxtNrml"> {commonData['State']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Country  : </label>
	    	                  <label className="TxtNrml"> {commonData['Country']} </label>
	    	              </td>
            </tr>
						</tbody>
					</table>
					</div>
					</div>
					<div className="panel panel-primary clearfix" >
			<div className="panel-heading"><h4 className="panel-title">Statement Mailing Address  </h4></div>
		<div className="panel-body">
					<table className="table" width="100%">

    <tbody>
						<tr>
	    	              <td>
	    	                  <label> Company Name : </label>
	    	                  <label className="TxtNrml"> {commonData['stmtComp']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> City : </label>
	    	                  <label className="TxtNrml"> {commonData['stmtCity']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Zip  : </label>
	    	                  <label className="TxtNrml"> {commonData['stmtZip']} </label>
	    	              </td>
            </tr>
						<tr>
	    	              <td>
	    	                  <label> Address : </label>
	    	                  <label className="TxtNrml"> {commonData['stmtAddr1']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> State : </label>
	    	                  <label className="TxtNrml"> {commonData['stmtStateDesc']} </label>
	    	              </td>
	    	              <td>
	    	                  <label> Country  : </label>
	    	                  <label className="TxtNrml"> {commonData['stmtCountryDesc']} </label>
	    	              </td>
            </tr>
						</tbody>
					</table>
					</div>
					</div>
					<div className="panel panel-primary clearfix" >
			<div className="panel-heading"><h4 className="panel-title">Remarks </h4></div>
		<div className="panel-body">
					<table className="table" width="100%">

    <tbody>
						<tr>
	    	              <td colSpan="3">
	    	                  <label> Remarks  : </label>
	    	                  <label className="TxtNrml"> {commonData['Remarks']} </label>
	    	              </td>
            </tr>
     </tbody>
  </table>
	</div>
	</div>
	</div>


    }
    }else{
		dataFlag=false;
		tbody = <table className="table" width="100%">
		    <tbody>
		          <tr>
		            <td style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">No Data Found
		            </td>
            </tr>
           </tbody>
           </table>
	}
  }

  if( popUpData !== undefined && popUpData.toString().trim().length!==0){
     var commonPopUpData = [];
     // console.log("view changes popup  popUpData::",popUpData);

  	var popUpList=popUpData.find(item =>item.name ==="commonData")// === listName)

  	if(popUpList!==undefined && popUpList.commonData!==undefined)
  	  commonPopUpData = popUpList.commonData;
   	  title=commonPopUpData.screenName;
   	  messageTxt=commonPopUpData.Message;
   	  errMsg=commonPopUpData.errMsg;

  	// console.log("mar 27, 2019 errMsg:",errMsg);
	popUpMsg = <div style={{ color: 'red', textAlignVertical: "left",textAlign: "left", }}  className="col-md-12 col-sm-12">{messageTxt === "empty"?"":messageTxt}</div>
	errPopUpMsg = <div style={{ color: 'red', textAlignVertical: "left",textAlign: "left", }}  className="col-md-12 col-sm-12">{errMsg === "empty"?"":errMsg}</div>

    	var popUpList=popUpData.find(item =>item.name ==="columns")// === listName)
  	popUpColumns1 = popUpList.COLUMNS;

  	popUpList=popUpData.find(item =>item.name ==="DATA")// === listName)
  	popUpData1 = popUpList.DATA;

  	optionsPopUp = {
  		filterType: "dropdown",
  		selectableRows: false,
  		pagination: false,
          	rowsPerPage: 10,
  		responsive: "scroll",
  		fixedHeader: false,
  		filter:false,
  		search:false,
  		print:false,
  		download:false,
  		viewColumns:false,
  	};
      // console.log("view changes popup  field values::",commonPopUpData);
  }

    return (
    <div>
      <div>
        <a href="#" onClick={this.handleClickOpen.bind(this,"paper",this.props.rowData,this.props.tabName)}>
          {linkName}
        </a>
        <Dialog
          open={this.state.open}
          onClose={this.handleClose}
          scroll={this.state.scroll}
          aria-labelledby="scroll-dialog-title"
          fullWidth={true}
          maxWidth = {'md'}
        >

          <DialogTitle id="scroll-dialog-title"> {title}
			{actionbtns}
{/*
					<button onClick={e => this.enterTrade('TRADEENTRY')} className="btn btn-primary btn-xs mt pull-right">
					Enter Trade
          </button>
					<button onClick={e => this.enterTrade('CLOSEACCOUNT')} className="btn btn-primary btn-xs mt pull-right">
					Close this account
          </button>
					<button onClick={e => this.enterTrade('TRADEHISTORY')} className="btn btn-primary btn-xs mt pull-right">
					Trade History
          </button>
					<button onClick={e => this.enterTrade('EDITACCOUNT')} className="btn btn-primary btn-xs mt pull-right">
					Edit Account Details
          </button>
*/}
				</DialogTitle>
          <DialogContent>
            <DialogContentText>
            	{alertdiv}
              {tbody}
              {subBlk}
	      {/* {
		dataFlag === true ?
		(
		data1 !== undefined ?
		<MuiThemeProvider theme={this.getMuiTheme()}>
		  <MUIDataTable
		  title=''
		  data={data1}
		  columns={columns1}
		  options={options}
		  />
		</MuiThemeProvider>
		:
		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
		)
		:
		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div></div>
		} */}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
		{approveBtn}
		{rejectBtn}
		{revokeBtn}
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </div>
	<div>
	<Dialog
	open={this.state.openPopUp}
	onClose={this.handlePopUpClose}
	scroll={this.state.scroll}
	aria-labelledby="scroll-dialog-title"
	fullWidth={true}
	maxWidth = {'md'}
	>
	<DialogTitle id="scroll-dialog-title">

	</DialogTitle>
	<DialogContent>
	<DialogContentText>
	<div className="clearfix"></div>
	<div>
	{popUpMsg}
	</div>
	<div className="clearfix"></div>
	{
	dataFlag === true ?
	(
	popUpData1 !== undefined ?
	<MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
	  <MUIDataTable
	  data={popUpData1}
	  columns={popUpColumns1}
	  options={optionsPopUp}
	  />
	</MuiThemeProvider>
	:
	<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
	)
	:
	<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div></div>
	}
	</DialogContentText>

	</DialogContent>
	<DialogActions>
	<button onClick={this.handlePopUpClose} className="btn btn-primary btn-xs mt pull-center">Ok</button>
	</DialogActions>
	</Dialog>
	</div>
     </div>
    );
  }

}

AcctScrollDialogPopUp.propTypes = {
    classes: PropTypes.object.isRequired,
};

//export default AcctScrollDialogPopUp;
export default withStyles(styles)(AcctScrollDialogPopUp);