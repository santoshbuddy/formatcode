import React from 'react';
import DatePicker from 'react-datepicker';
import { withStyles } from '@material-ui/core/styles';
import 'react-datepicker/dist/react-datepicker.css';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { MuiThemeProvider } from '@material-ui/core/styles';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import CustomDatePickerInput from '../../styles/CustomDatePickerInput';
import { ReactDatePicker } from '../../styles/ReactDatePicker';

let dateChange=false;
let listChange=false;
const styles = theme => ({
  margin: {
    margin: theme.spacing.unit,
  },
});
var dateFormat = require('dateformat');
let filterNameValueArray=[];
let filterData=[];
class Filters extends React.Component {
    constructor () {
        super(),
        this.state = {
					newChangeList:[],
					inputValue:''
        },
        this.doChange = this.doChange.bind(this);
        this.inputHandle = this.inputHandle.bind(this);
        //this.handleChange = this.handleChange.bind(this);
      }
      componentWillMount(){
      //   this.doChange();
      }
      componentDidUpdate(){
        //alert("filter. dateChange.."+dateChange);
        //listChange=false;
        if(dateChange === false){
           filterNameValueArray=[];
        }
      }
      handleDateChange(name,value) {
        dateChange=true;
        //console.log("dateChange:",dateChange);
        filterNameValueArray.find(namevalue => namevalue.id === name).value=dateFormat(value,"mmm dd, yyyy");
        filterData.find(namevalue => namevalue.name === name).value=dateFormat(value,"mmm dd, yyyy");
        this.forceUpdate();
      }
			inputHandle(e){
				this.setState({inputValue:e.target.value})
			}
      handleChange(e,onChangeFlag,subListName)
      {
         //e.preventDefault();
	      	//alert(onChangeFlag)
	      	dateChange=false;
	      	var listName=e.target.name;
	      	var listValue=e.target.value;
	      	//alert(listValue)
	      	//var subListName;
	      	//alert(e);
	      	listChange=true;
	      	if(onChangeFlag==="true"){
	      	  //var temp = e.target.value;
	      	  //console.log("listName::",listName)
	      	  //console.log("subListName::",subListName)
	      	  //console.log("listValue::",listValue)

	      	      var subList;
	      	      var subSubList;
	      	      let secondList=[];
	      	      let thirdList=[];
	      	      let fourthList=[];
	      	      let subSubListName;
	      	      let third =  "false";
	      	      let flagAll=true;
	      	      let subFlagAll=true;
	      	      let flag=false;
	      	      let mainFlag="100";
	      	      let flagOther=true;

			if(listValue === "All" || listValue === "ALL"){
			   mainFlag="200";
			}

	      	      filterData && filterData.map((item,rowid) => {
	      		  //begin sub list block for All scenario
	      		  if(item.name!== undefined && item.name === listName && mainFlag === "200"){
	      		      //alert("first")
	      		      var mainList=filterData.find(item =>item.name === listName)
	      		      let mainListObj=mainList.values;
	      		      if(mainListObj !== undefined){
	      		         mainListObj.map((m,index) => {
	      		              //console.log("target .mainList::",mainList.values);
	      		              //console.log("target main id value::",m.id);
	      		              if(m.id !== "All" || m.id !== "ALL"){
	      		                 flag=true;
	      		              }
	      		              if(flag) {
	      		               filterData && filterData.map((item,rowid) => {
					if(item.parentname !== undefined && item.parentname === listName){
						subList = item.rows.find(e => e.id === m.id)
						//console.log("...Sub List...::",subList);
						if(subList !== undefined && (subList.id === "All" || subList.id === "ALL")){
						   //alert("target");
						}
						else if(subList !== undefined){
						  //console.log("m.rows::",m.rows);
						  subList.rows.map((s,row) =>{
						     //alert("value:"+s.id);
						     if(s !== undefined && s.name !== undefined && (s.id === "All" || s.id === "ALL" || s.id === "None")){
						        //alert("value:"+s.id);
						        if(flagAll){
						          //console.log("target111 .. s.id:"+s.id+",s.name:"+s.name);
						          secondList.push({id:s.id,name:s.name});
						          flagAll=false;
						         }
						     }
						     else if(s !== undefined && s.id !== undefined && s.name !== undefined ){
						       //console.log("s.id::",s.id+",s.name:",s.name);
						       //console.log("first block... ");
						       if(s.name.length > 0){
						         //console.log("target22 .. s.id:"+s.id+",s.name:"+s.name);
						         secondList.push({id:s.id,name:s.name});
						        }
						     }
						  })

					      }
					      //console.log("target newChangeList..Sub List name::",subList.name);
					    }
					})
				     }
	      		         })
	      		      }
	      		  }
	      		//end sub list block for All scenario

	      		//begin sub list block for other then All scenario

	      		if(item.parentname!== undefined && item.parentname === listName && mainFlag === "100"){
			      		  //alert("second....")
			      		    var subList = item.rows.find(e => e.id===listValue)
						if(subList !== undefined){
						  if(subList.rows !== undefined){
						    //console.log("subList.rows.::",subList.rows);
						    let subListObj=subList.rows;
						    if(subListObj !== undefined){
						       //console.log("target sublistobj.::",subListObj);
						       subListObj.map((e,index) => {
							 //console.log("e.id:",e.id);
							       if(flagAll && e !== undefined && (e.id === "All" || e.id === "ALL")){
							         //alert("value:"+e.id);
							         if(flagAll){
							          if(e.name.length > 0)
							            secondList.push({id:e.id,name:e.name});
							            flagAll=false;
							         }
							       }
							       else if(e !== undefined && e.name !== undefined){
							         //console.log("second block... ");
							         //console.log("e.id::",e.id+",e.name:",e.name);
								 if(e.name.length > 0)
								   secondList.push({id:e.id,name:e.name});
								}
							    })
						     }
						  }
						}
	      	           }
	      	         //end sub list block for other then All scenario

	      	        //begin sub sub list block
	      	        if(item.parentname!== undefined && item.parentname === subListName){
			    third="true";
			    //alert("third....")
			    //console.log("list data:",secondList);
			    if(secondList !== undefined){
	      		         secondList.map((m,index) => {
	      		           if(m !== undefined && m.name !== "All"){
	      		             //console.log("sublist m.id::",m.id+",m.name:",m.name);
	      		             var subSubList = item.rows.find(e => e.id === m.id)
	      		             //console.log("target subSubList::",subSubList);
	      		             //console.log("target subSubList name::",subSubList.name);
	      		             subSubListName=subSubList.name;
					if(subSubList !== undefined){
					  subSubList.rows.map((s,row) =>{
					     if(s !== undefined && s.name !== undefined && s.name === "All"){
					       //alert();
					       if(subFlagAll){

					         thirdList.push({id:s.id,name:s.name});
					         subFlagAll=false;
					         //console.log("1111 thirdList:",thirdList);
					       }
					     }
					     if(s !== undefined && s.name !== undefined && s.name !== "All"){
					       //console.log("s.id::",s.id+",s.name:",s.name);
					       //console.log("third block... ");
					       thirdList.push({id:s.id,name:s.name});
					       //console.log("2222 thirdList:",thirdList);
					     }
					  })
					}
	      		           }
	      		         })
	      		      }

	      		   }
	      		 //end sub sub list block
	      		 //for audit trial report
			if(item.parentname!== undefined && item.parentname === "Sub List" && mainFlag === "100"){
			    //alert("fourth....")

			    var subList = item.rows.find(e => e.id === listValue)
				if(subList !== undefined){
				  if(subList.rows !== undefined){
				    //console.log("subList.rows.::",subList.rows);
				    let subListObj=subList.rows;
				    if(subListObj !== undefined){
				       //console.log("target sublistobj.::",subListObj);
				       subListObj.map((e,index) => {
					 //console.log("e.id:",e.id);
					       if(flagAll && e !== undefined && (e.id === "All" || e.id === "ALL")){
						 //alert("value:"+e.id);
						 if(flagAll){
						  if(e.name.length > 0)
						    fourthList.push({id:e.id,name:e.name});
						    flagAll=false;
						 }
					       }
					       else if(e !== undefined && e.name !== undefined){
						 //console.log("second block... ");
						 //console.log("e.id::",e.id+",e.name:",e.name);
						 if(e.name.length > 0)
						   fourthList.push({id:e.id,name:e.name});
						}
					    })
				     }
				  }
				}
			}

	      		})

	      		//console.log("secondList:",secondList);
			if(secondList!==undefined && secondList.length>0){
			    filterData.find(item =>item.name === subListName).values=secondList;
			        //console.log("country code:"+e.target.elements.subListName);
				secondList.map((e,index) => {
				   if(index === 0){
				      //console.log("second list: e.id:",e.id+",e.name:"+e.name);
					var obj=filterNameValueArray.find(item =>item.id === subListName);
					if(obj!== undefined){
					  obj.value=e.id;
					}
				   }
				})
			    //alert("assigned list second .")
			}
			//console.log("thirdList:",thirdList);
			if(third === "true" && thirdList!==undefined && thirdList.length>0){
			    filterData.find(item =>item.name === subSubListName).values=thirdList;
			    //console.log("thirdList:",thirdList);
			    //console.log("subSubListName:",subSubListName);
				thirdList.map((e,index) => {
				   if(index === 0){
				      //console.log("third list : e.id:",e.id+",e.name:"+e.name);
					var obj=filterNameValueArray.find(item =>item.id === subSubListName);
					if(obj!== undefined){
					  obj.value=e.id;
					}
			           }
				})
			    //alert("assigned list third .")
			}
			if(fourthList!==undefined && fourthList.length>0){
				var newListName = "acctNbr";
				filterData.find(item =>item.name === newListName).values=fourthList;

				fourthList.map((e,index) => {
				   if(index === 0){
				      //console.log("second list: e.id:",e.id+",e.name:"+e.name);
					var obj=filterNameValueArray.find(item =>item.id === newListName);
					if(obj!== undefined){
					  obj.value=e.id;
					}
				   }
				})
				//alert("assigned list second .")
			}

	       	  }

		if(filterNameValueArray!== undefined && filterNameValueArray.length>0){
			let obj=filterNameValueArray.find(namevalue => namevalue.id === listName);
			if(obj!== undefined){
			  obj.value=listValue;
			}
		}
		console.log("onchange filterNameValueArray::",filterNameValueArray);
		console.log("onchange subList::",subList);
		this.setState({ newChangeList: subList });
		 this.doChange();
     }

     doChange(e){

       //alert("filterNameValueArray data:"+filterNameValueArray);
      //console.log("filterNameValueArray---->")
      //alert(filterNameValueArray.length);
      console.log(filterNameValueArray)
      var filtObj = {};
      var bodyFormData = new FormData();
      var selectedId='';
     if(filterNameValueArray !== undefined)
      for(var i =0; i<filterNameValueArray.length; i++){
         var temp = filterNameValueArray[i];
					  console.log("11111",temp.id+" ,value:"+temp.value);
					  selectedId =temp.id;
					if(temp.id==="amtText")
					bodyFormData.append("amtText",this.state.inputValue);
					else
          bodyFormData.append(temp.id, temp.value);
          }
        bodyFormData.append("reactJSActionFlag","GO")
         bodyFormData.append("selectedTabSrc",this.props.selectedTabSrc)
          bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
         this.props.method(bodyFormData);
         listChange=true;
     }

    render(){

      //console.log("filter filterFlag::"+this.props.filterFlag);
      //console.log("filterData::"+filterData+",filterFlag:"+this.props.filterFlag);
     console.log("filterFlag:::"+this.props.filterFlag)
      const { classes } = this.props;
        const { data } = this.props;
        let filetermarkup;


        if(data.userhomepagedata !== undefined && this.props.filterFlag === true){
          filterData=data.userhomepagedata;
          if(listChange ===false){
           // filterNameValueArray=[];
            }
        }
     //   console.log("after filterData::"+filterData+",this.props.filterFlag:"+this.props.filterFlag);
         if(this.props.filterFlag == true)
        	listChange = false;
        if(filterData !== undefined && filterData.length>0){
           filetermarkup = filterData.map((filter,index) => {

            if(filter.type === "Select"){
			if(filter.values !== undefined && this.props.filterFlag === true && listChange === false)
                	filterNameValueArray.push({id:filter.name,value:filter.values[0].id})

                //alert(filterNameValueArray.find(namevalue => namevalue.id === filter.name).value);
                //alert(filterData.find(namevalue => namevalue.name === filter.name).values[index].id)
             var listValue="";
              if(listChange === true){
               if(filterNameValueArray!== undefined && filterNameValueArray.length>0){
			let obj=filterNameValueArray.find(namevalue => namevalue.id === filter.name);
		    //console.log(obj);
			if(obj!== undefined){
			  listValue=obj.value;
		        }
				}
             }else{
               listValue=filterNameValueArray.find(namevalue => namevalue.id === filter.name)!== undefined && filterNameValueArray.find(namevalue => namevalue.id === filter.name).value
              }
              //alert("list value ::"+listValue+",index:"+index+",listChange:"+listChange);

             var selectList="";
			selectList=<NativeSelect className={classes.select}
		   ref={ filter.name }  name={filter.name}  onChange={(e)=>{this.handleChange(e,filter.onChangeFlag,filter.subListName)}} defaultValue={filter.fieldValue}>
		     {filter.values !== undefined && filter.values.map((obj,index) => {
			     return <option key={index} value={obj.id}>{obj.name}</option>
			 })}
		</NativeSelect>
             return(
                <Grid item  key={filter.id.toString()}>
                  <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
                    { filter.label } :
                  </InputLabel>
                    {selectList}
                </Grid>
               );
            }else if(filter.type === "hidden"){
							if(filterNameValueArray.find(namevalue => namevalue.id === filter.name))
							filterNameValueArray.find(namevalue => namevalue.id === filter.name).value=filter.value;
						else
												filterNameValueArray.push({id:filter.name,value:filter.value})
						}else if(filter.type === "datepicker"){
            if(filterNameValueArray.find(namevalue => namevalue.id === filter.name))
			filterNameValueArray.find(namevalue => namevalue.id === filter.name).value=filter.value;
	else
              filterNameValueArray.push({id:filter.name,value:filter.value})
                 return (
                  <Grid item  key={filter.id.toString()}>
                       <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
                       { filter.label }:</InputLabel>
											 <ReactDatePicker>
                      	<DatePicker dateFormat="MMM dd, YYYY" ref={ filter.name } autoOk={true} name={filter.name} className="form-control"  selected={new Date(filterData.find(namevalue => namevalue.name === filter.name).value)}  onChange={this.handleDateChange.bind(this, filter.name)} customInput={(<CustomDatePickerInput/>)} />
												</ReactDatePicker>
                   </Grid>
                 );
              }else if(filter.type === "Button"){
                return (
                <span>
					  <button size="small" style={{height: 30, margin: 12}} className="btn btn-primary btn-xs" title="Go" onClick={(e)=>{this.doChange();}} key={filter.id.toString()}>
						{ filter.name }
					  </button>
					  {
						((this.props.PageName == "/reportC/COMPART") || (this.props.PageName == "/reportC/INDICAT")) &&
						<span className="displayTxt">Please Click on Go button</span>
					  }
                </span>
               );
              }else if(filter.type === "input"){
              if(filterNameValueArray.find(namevalue => namevalue.id === filter.name))
			filterNameValueArray.find(namevalue => namevalue.id === filter.name).value=filter.value;
		else
                filterNameValueArray.push({id:filter.name,value:filter.value})
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
                     <TextField refs={filter.name}  value={this.state.inputValue===''?filter.value:this.state.inputValue} onChange={this.inputHandle}/>
                  </Grid>
               );
              }else if(filter.type === "checkbox"){
               if(filterNameValueArray.find(namevalue => namevalue.id === filter.name))
	      			filterNameValueArray.find(namevalue => namevalue.id === filter.name).value=filter.value;
		else
                filterNameValueArray.push({id:filter.name,value:filter.value})
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
                     <TextField type="checkbox" ref={filter.name}/>
                  </Grid>
               );
              }else if(filter.type === "radio"){
               if(filterNameValueArray.find(namevalue => namevalue.id === filter.name))
	      			filterNameValueArray.find(namevalue => namevalue.id === filter.name).value=filter.value;
		else
                filterNameValueArray.push({id:filter.name,value:filter.value})
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
                     <TextField type="radio" ref={filter.name}/>
                  </Grid>
               );
              }else if(filter.type === "textarea"){
               if(filterNameValueArray.find(namevalue => namevalue.id === filter.name))
	      			filterNameValueArray.find(namevalue => namevalue.id === filter.name).value=filter.value;
		else
                filterNameValueArray.push({id:filter.name,value:filter.value})
               return (
                <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
                     <TextField type="textarea"   ref={filter.name} />
                  </Grid>
               );
              }else if(filter.type === "label"){
               return (
                  <Grid item  key={filter.id.toString()} >
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
                      <InputLabel style={{paddingTop: '11px', fontSize: '12px'}} > { filter.value }</InputLabel>
                  </Grid>
               );
              }else if(filter.type === "newline"){
                return  <div key="newline" className="clearfix"></div>
              }
        });
        dateChange=true;
        console.log("after filter block called ... filterNameValueArray::",filterNameValueArray);
        //console.log("after filter block called ... filterFlag::",this.props.filterFlag);

       }

        return(
					<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
            <Grid container spacing={24} >
                {filetermarkup}
            </Grid>
					</MuiThemeProvider>
        );
    }
}

export default withStyles(MuiStyles)(Filters);