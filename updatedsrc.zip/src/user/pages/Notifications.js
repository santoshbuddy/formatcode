

import React from 'react';
import { Route } from 'react-router-dom';
import { MuiThemeProvider } from '@material-ui/core/styles';
import MUIDataTable from "mui-datatables";
import { muiTableStyles } from '../../styles/muidatatableCss';
import TableLoader from '../../common/TableLoader';
import { Link } from 'react-router-dom';
import Typography from '@material-ui/core/Typography';
import ScrollDialog from "../../reports/components/ScrollDialog";
import axios from 'axios';
import { alertConstants } from '../../common/constants/alert.constants';
import {updateMenubarRefreshElem,updateBottomHomeRefreshElem} from './HIddenRefresh';

import ScrollDialogPopUp  from "../../invest/components/ScrollDialogPopUp";
import AcctScrollDialogPopUp  from "./AcctScrollDialogPopUp";
import ViewAllNotifications  from "./ViewAllNotifications";

import {createMuiTheme,withStyles } from '@material-ui/core/styles';

import { connect } from 'react-redux';
import { userActions } from '../actions/user.actions';
import { history } from '../../_helpers';

let notificationId='';
let refreshData={ "notificationCnt":"0"};

const styles = theme => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
    },
    paper: {
      padding: theme.spacing.unit * 2,
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    tabsRoot: {
        borderBottom: '1px solid #e8e8e8',
      },
      tabsIndicator: {
        backgroundColor: '#1890ff',
      },
      tabRoot: {
        textTransform: 'initial',
        minWidth: 72,
        fontWeight: theme.typography.fontWeightRegular,
        marginRight: theme.spacing.unit * 4,
        // fontFamily: [
        //   '-apple-system',
        //   'BlinkMacSystemFont',
        //   '"Segoe UI"',
        //   'Roboto',
        //   '"Helvetica Neue"',
        //   'Arial',
        //   'sans-serif',
        //   '"Apple Color Emoji"',
        //   '"Segoe UI Emoji"',
        //   '"Segoe UI Symbol"',
        // ].join(','),
        '&:hover': {
          color: '#40a9ff',
          opacity: 1,
        },
        '&$tabSelected': {
          color: '#1890ff',
          fontWeight: theme.typography.fontWeightMedium,
        },
        '&:focus': {
          color: '#40a9ff',
        },
      },
      tabSelected: {},
      typography: {
        padding: theme.spacing.unit * 3,
      },

      label: {
        fontSize: '14px',
        fontWeight : 'bold',
      },
      tablerow:{
        height : '20px',
      },
      margin: {
        marginRight: '0px',
        marginLeft: '0px',
      },
      insrt:{
        fontSize:'12px',
        color: '#666666',
        fontFamily: 'arial,helvetica,sans-serif',
      },
      checkboxstyle:{padding:'0px !important',
      height: 18}

  });
class NotificationsCls extends React.Component{

	   getMuiTheme = () => createMuiTheme({
		 	 		  typography: {
		 	 							useNextVariants: true,
		 	 	 			 },
		 	 	    	overrides: {
		 	 			  MuiButtonBase: {
		 	 					  	        root: {
		 	 					   	           padding: '0px',
		 	 					   	        }
		 	 	      },
		 	 	    }
	 	   })

    constructor(props) {
        super(props);
        this.state={
			dataVec:[],
			updateFlag:false,
         }
		this.doTrade=this.doTrade.bind(this);
		this.doTradeDetails=this.doTradeDetails.bind(this);
		this.checkNotifications = this.checkNotifications.bind(this);
		this.closeThisNotification = this.closeThisNotification.bind(this);
		this.closeNotification = this.closeNotification.bind(this);
		 this.checkClick = this.checkClick.bind(this);


     };
		 checkClick(cData, paramVal) {

					if(paramVal == 'TRADEENTRY' || paramVal == 'CLOSEACCOUNT') {
						 history.push({
							pathname: '/DEALENT',
							state: {
								tabIndex: 1,
								activeStep: 1,
								paramVal: paramVal,
								fromPage:'ViewChanges',
								bformdata: cData
							}
						});
					} else if(paramVal == 'TRADEHISTORY') {
						 history.push({
							pathname: '/report/TRDINQR',
							state: {
								fromPage:'ViewChanges',
								product: cData.parentprodid,
								issueChild: cData.prodid
							}
						});
					} else if(paramVal == 'EDITACCOUNT') {
						 history.push({
							pathname: '/administration/MMFEDITACCT',
							state: {
								fromPage:'ViewChanges',
								mmmfAcct: cData.escrowacctnbr,
								clientFirm: cData.clientFirm,
								product: cData.subprodname,
								currency: cData.currency,
							}
						});
					}

			}
 doTrade() {

   }
    doTradeDetails(tradId) {
   //alert(tradId)
   }
   closeThisNotification(tableId, nttype, notifyId, acctTypeId, prcd) {
	 //  alert(notifyId);
      var bodyFormData = new FormData();
	 			var data;
	 					var user = JSON.parse(sessionStorage.getItem('user'));

	 					bodyFormData.append("token",user[0].token)
	 					bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
	 					bodyFormData.append("ajaxFlag",'true')
	 					bodyFormData.append("nttype",nttype)
	 					bodyFormData.append("notifyId",notifyId)
	 					bodyFormData.append("acctTypeId",acctTypeId)
	 					bodyFormData.append("prcd",prcd)
	 					axios({
	 						method: 'POST',
	 						url:alertConstants.URL+"/HOME.do",
	 						data: bodyFormData,
	 						config: { headers: {'Content-Type': 'application/x-www-form-urlencoded' }}
	 					  }).then((response)=>{
	 					   // data = response.data;
	 				 	  // console.log('response.data? closeNotification >>>'+JSON.stringify(response.data));
	 					   let xml = new DOMParser().parseFromString(response.data.msg, 'application/xml');
							var updateNtFlag = "";
							if(xml.getElementsByTagName("UPDATENTFLAG")[0]!=null) {
							updateNtFlag = xml.getElementsByTagName("UPDATENTFLAG")[0].firstChild.nodeValue;
							}
							if (updateNtFlag == "true") {
								this.closeNotification(prcd, tableId);
							}

				});
   }

	closeNotification(prcd, tableId) {
		notificationId=prcd;
		this.setState({notificationId:true});

	}
	componentDidMount() {
 	this.checkNotifications();
	}


	componentWillUnmount() {
	  clearInterval(this.interval);
	}
	checkNotifications(bodyFormData){
		 this.setState({dataVec:[]})
	  // after 5 seconds stop
		 this.interval = setInterval(() => {
			//clearInterval(timerId);
			 //alert('HI');
			var bodyFormData = new FormData();
			var data;
					var user = JSON.parse(sessionStorage.getItem('user'));

					bodyFormData.append("token",user[0].token)
					bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
					bodyFormData.append("ajaxFlag",'true')
					bodyFormData.append("subSource",'HOME')
					axios({
						method: 'POST',
						url:alertConstants.URL+"/HiddenTradeRefreshServlet",
						data: bodyFormData,
						config: { headers: {'Content-Type': 'application/x-www-form-urlencoded' }}
					  }).then((response)=>{
					   // data = response.data;
					 //  console.log('response.data? >>>'+response.data);
					  let xml = new DOMParser().parseFromString(response.data.notifications, 'application/xml');
					  updateMenubarRefreshElem(response.data.notifications,refreshData);
						let notificationData= [];
						updateBottomHomeRefreshElem(response.data.notifications ,notificationData);
						// console.log('notificationData .......'+JSON.stringify(notificationData));
						/*if(notificationData && notificationData.length>0){
							let newarry=notificationData;
							 newarry.sort((d1, d2) => new Date(d1[3]).getTime() < new Date(d2[3]).getTime());
							 console.log('newarry:22<<<<<<<<<<>....:'+JSON.stringify(newarry));

						}*/


						  this.setState({dataVec:notificationData})
						 // console.log('dataVec:22<<<<<<<<<<>....:'+this.state.dataVec.length);
				});


			}, 5000);
	}

    render() {
        const {classes,	 notificationCnt,dataVec ,latestnotificationData } = this.props;

 		let finalData = dataVec;
 		// console.log('finalData:11:'+finalData.length);
 		if(this.state.dataVec && this.state.dataVec.length>0){
			finalData =[];
 			/*	this.state.dataVec.map((item,index)=>{
					   		 finalData.push(item);
			  });*/
			  finalData = this.state.dataVec;
   		}else {
			refreshData.notificationCnt = notificationCnt;
		}

  		// console.log('finalData:22:'+finalData.length);
  		if(notificationId !== undefined && notificationId !== ''){
 			finalData && finalData.map((item,index)=>{
				if(item[1] === notificationId || item[6] === notificationId){
					// console.log(' find  ');
				finalData.splice(item.index, 1);
				 notificationId='';
				 }
			});

		}
		// console.log('notificationId::'+notificationId);
           const options = {
            filter: false,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:false,
            rowsPerPage: 5,
			responsive: "scroll",
			fixedHeader: false,
			filter:false,
			search:false,
			print:false,
			download:false,
      		viewColumns:false,
      		pagination: false,
            textLabels: {
                body: {
                     noMatch: this.props.userhomepagedata.loading ?<TableLoader />:'No data found',
                },
            }
        };

const columns = [

   {
     name: " ",
     	display: true,
     options: {
      filter: true,
      sort: true,
       customBodyRender: (value, tableMeta, updateValue) => {

		   if(tableMeta && tableMeta !== undefined){
 		    let tradeLabel='Trade Deal';
 		    let id =tableMeta.rowData[1];
		    if(tableMeta.rowData[0] === 'FTRADE')
		  	  tradeLabel='Future Trade Deal';
		    else if(tableMeta.rowData[0] === 'MMFACCT')
		    tradeLabel='Money Fund Account';

		     else if(tableMeta.rowData[0] === 'MSG')
		    tradeLabel='Message from';
		       else if(tableMeta.rowData[0] === 'TEMPLATE')
		    tradeLabel='Email Alert Template';

		      else if(tableMeta.rowData[0] === 'POLICY')
		    tradeLabel='Investment Policy';
		  //  console.log('tableMeta.rowData[2]::'+tableMeta.rowData[2]);

				if(tableMeta.rowData[4] && parseInt(tableMeta.rowData[4])>0 && tableMeta.rowData[0] === 'TRADE'){
						  return   <div><img src='src/images/amber_alert.gif' style={{    position: 'absolute'}}/>
						  	<div style={{paddingLeft:'40px'}}> {tradeLabel}:
						  	<a href='#'
							onClick={(e)=>this.closeThisNotification('NotifyTradeTable', '10000013', id, '', id)}>
							<img style={{float: 'right'}} src='src/images/delete_icon_grey.gif'/>  </a><br/>
						  	<ScrollDialog 		onClick={(e) => this.openPopUp(e, tableMeta)}
						  					rowData={tableMeta}
						  					linkName={tableMeta.rowData[2]}
						  					screenLinkImage={'NOTIFICATIONS'}
							/> is waiting for Checker Approval<br/>{tableMeta.rowData[3]}
							</div> </div>

				}else if(tableMeta.rowData[4] && parseInt(tableMeta.rowData[4])>0 && tableMeta.rowData[0] === 'FTRADE'){

						  return   <div><img src='src/images/amber_alert.gif' style={{    position: 'absolute'}}/>
						  <div style={{paddingLeft:'40px'}}> {tradeLabel}:
						   <a href='#' onClick={(e)=>this.closeThisNotification('NotifyFutureTradeTable', '10000014', id, '', id)}>
						   <img style={{float: 'right'}} src='src/images/delete_icon_grey.gif'/>
						   </a>
						  <br/> <ScrollDialog 		onClick={(e) => this.openPopUp(e, tableMeta)}
						  					rowData={tableMeta}
						  					linkName={tableMeta.rowData[2]}
						  					screenLinkImage={'NOTIFICATIONS'}
							/>is waiting for Checker Approval<br/>{tableMeta.rowData[3]}
							</div></div>

				}else if(tableMeta.rowData[0] === 'MMFACCT'){
 						if(tableMeta.rowData[4] && parseInt(tableMeta.rowData[4])>0){
						  return   <div><img src='src/images/amber_alert.gif' style={{    position: 'absolute'}}/>
						  <div style={{paddingLeft:'40px'}}> {tradeLabel}:
						   <a href='#' onClick={(e)=>this.closeThisNotification('NotifyMMFTable', '10000001', id, tableMeta.rowData[5], tableMeta.rowData[6])}>
							 <img  style={{float: 'right'}} src='src/images/delete_icon_grey.gif'/>   </a>
							<br/>
						  <AcctScrollDialogPopUp
						  										onClick={e => this.openPopUp(e, tableMeta)}
						  										rowData={tableMeta}
						  										linkName={tableMeta.rowData[2]}
						  										screenLinkImage={'NOTIFICATIONS'}
						  										func={this.checkClick }

										/>

							 is waiting for Checker Approval<br/>{tableMeta.rowData[3]}
							</div></div>
						}
				   }else if(tableMeta.rowData[0] === 'TEMPLATE'){
 						if(tableMeta.rowData[4] && parseInt(tableMeta.rowData[4])>0){
						  return   <div><img src='src/images/amber_alert.gif' style={{    position: 'absolute'}}/>
						  <div style={{paddingLeft:'40px'}}> {tradeLabel} :
						  <a href='#' onClick={(e)=>this.closeThisNotification('NotifyTemplateTable', '10000009', id, tableMeta.rowData[1], tableMeta.rowData[6])}>
							 <img style={{float: 'right'}}  src='src/images/delete_icon_grey.gif'/>   </a>
							<br/>
						  <Link to={{ pathname:"/administration/EDITEMAILTEMP",
						  	state: { processId: tableMeta.rowData[6],
						  	selTemplate:tableMeta.rowData[1],
						  	tempclientFirm: '',
						  	mcFlag:'',
						  	vecsize:'1'} }}>{tableMeta.rowData[2]}</Link><br/>
						  	 is waiting for Checker Approval<br/>{tableMeta.rowData[3]}
							</div></div>
						}
				   }else if(tableMeta.rowData[0] === 'POLICY'){
 						if(tableMeta.rowData[4] && parseInt(tableMeta.rowData[4])>0){
						  return   <div><img src='src/images/amber_alert.gif' style={{    position: 'absolute'}}/>
						  <div style={{paddingLeft:'40px'}}> {tradeLabel}:
						  <a href='#' onClick={(e)=>this.closeThisNotification('NotifyInvPolicyTable', '10000006', id, tableMeta.rowData[1], tableMeta.rowData[6])}>
							 <img  style={{float: 'right'}} src='src/images/delete_icon_grey.gif'/>   </a>
							<br/>

		    				<ScrollDialogPopUp
										onClick={(e) => this.openPopUp(e, tableMeta)}
										rowData={tableMeta}
									 	linkName={tableMeta.rowData[2]}
										screenLinkImage={'NOTIFICATIONS'}

							/>

							is waiting for Checker Approval<br/>{tableMeta.rowData[3]}
							</div> </div>
						}


				}else if( tableMeta.rowData[0] === 'MSG'){
						  return   <div><img src='src/images/amber_alert.gif' style={{    position: 'absolute'}}/>
						  <div style={{paddingLeft:'40px'}}> {tradeLabel}:
						   <a href='#' onClick={(e)=>this.closeThisNotification('NotifyEmessageTable', '10000012', id, tableMeta.rowData[1], tableMeta.rowData[1])}>
							 <img style={{float: 'right'}}  src='src/images/delete_icon_grey.gif'/>   </a>
							 <br/>{tableMeta.rowData[2]}<br/>{tableMeta.rowData[4]}
						  <Link to={{ pathname: '/reportCheck/WATFRAPP', state: { transId: tableMeta.rowData[1]} }}
					   id="palceanot"  >View Message</Link><br/>{tableMeta.rowData[3]}
					  </div> </div>

				}else {
					return  <div>Trade Deal:<br/>{tableMeta.rowData[2]}<br/>is waiting for Checker Approval<br/>{tableMeta.rowData[3]}</div>
				}
		  }else {
			  return <div></div>
		  }
     }
  	}
   },{  name: "TRANSID",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   },{  name: "WEBREFERENCE",
    options: {
	display: false,
	sort: false,
	download: false,
	filter: false,
    }
   }
   ,{  name: "TRANSDATE",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   } ,{  name: "watFrAppOperval",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   },{  name: "ACCTTYPEID",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   },{  name: "COMPANYID",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   },{  name: "COMPANYNAME",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   } ,{  name: "PROCESSID",
       options: {
   	display: false,
   	sort: false,
   	download: false,
   	filter: false,
       }
   }
];
         return(
            <div>
                 <div className="clearfix"></div>
                <div className="col-md-12 col-sm-12">

                     <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                            <MUIDataTable title= {(refreshData.notificationCnt !==  undefined && parseInt(refreshData.notificationCnt)>0?
							<div> <Typography variant="h6" component="h6" style={{whiteSpace: 'nowrap'}}>
									Unread Notifications ({refreshData.notificationCnt})
								 </Typography>
								 </div>:<div>
								 <Typography variant="h6" component="h6">
									Notifications (0)
								 </Typography>
								  <Typography component="p"> No new notifications at the moment
								 </Typography>
								 </div>)}
                            data={finalData}
                            columns={columns} options={options}  />
                        </MuiThemeProvider>

                          <div style={{paddingTop:'10px'}}> <ViewAllNotifications /></div>


                </div>
            </div>
        )
    }
}

function mapStateToProps(state) {
    const { userhomepagedata } = state;
    return { userhomepagedata };
}

const Notifications = connect(mapStateToProps)(withStyles(styles)(NotificationsCls));
export default Notifications;
