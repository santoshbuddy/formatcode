import React from 'react';
import '../css/App.css'; 
import '../css/index.css';
import '../css/custom.css';
import '../css/layout.css';  
import { connect } from 'react-redux';
import { NavBar } from '../../navbar/components/navbar';
import { userActions } from '../actions/user.actions';
import Typography from '@material-ui/core/Typography';
import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import DashBoard from './DashBoard';
import MutualFund from './MutualFund';
import Loading from '../../common/Loading';

import MUIDataTable from "mui-datatables";
import Card from "./Card";
import ScrollDialog from "./ScrollDialog";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";  
import {muiTableStyles} from '../../styles/muidatatableCss';

class HomePage extends React.Component {

    constructor() {
        super()
        this.state = { loading:true,tabIndex: 0, enterdata: '',fixed:'' };
    }

    componentDidMount() {
      // if(this.props.mmmfdata === undefined || this.props.mmmfdata === "")
        this.props.dispatch(userActions.getMMMFData()); 
    }
   
    render() { 
        const { user, users,mmmfdata } = this.props;
        var data,columns;
         
        if(mmmfdata.mmmfdata !== undefined){
         mmmfdata.mmmfdata.map((item,index)=>{
            if(item.name === "columns")
              columns = item.COLUMNS;
            if(item.name === "DATA")
            data = item.DATA;

         })
        }
         
          const options = {
            filterType: "dropdown",
            selectableRows: false,
            responsive: "scroll",
            fixedHeader: false,
          };
        return (
            <div>
                <NavBar/>
              <div className="mainContent">          
                      {
                          data !== undefined ?
                      <div>
                      <Typography variant="h5" component="h3" className="screenTitle">Legal Caveat</Typography>
                      {/*
                        <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>                        
                            <MUIDataTable
                            title={"Research Money Funds"}
                            data={data}
                            columns={columns}
                            options={options}
                            />                         
                        </MuiThemeProvider>
                        */}
                          {/*<div style={{paddingTop: '220px'}}>
                            <label style={{fontSize:'14px'}}>Legal Caveat</label>
                          </div>*/}
                        </div>
                        :
                        <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
                      }
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    const { users,mmmfdata } = state;
     return {
        users, 
        mmmfdata
    };
}
 
const connectedHomePage = connect(mapStateToProps)(HomePage);
export { connectedHomePage as HomePage };