import React from 'react';
import { Route } from 'react-router-dom';
import { MuiThemeProvider } from '@material-ui/core/styles';
import MUIDataTable from "mui-datatables";
import { muiTableStyles } from '../../styles/muidatatableCss';
import TableLoader from '../../common/TableLoader';
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';



class LastestTrades extends React.Component{

	   getMuiTheme = () => createMuiTheme({
		 	 		  typography: {
		 	 							useNextVariants: true,
		 	 	 			 },
		 	 	    	overrides: {
		 	 			  MuiButtonBase: {
		 	 					  	        root: {
		 	 					   	           padding: '0px',
		 	 					   	        }
		 	 	      },
		 	 	    }
	 	   })

    constructor(props) {
        super(props);
        this.state={
         }
     };

    render() {
        const { data,columns,tradeinqOperval} = this.props;

         const options = {
            filter: false,
            filterType: 'dropdown',
            responsive: 'stacked',
            selectableRows:false,
            rowsPerPage: 10,
            pagination:(data && data.length>0 )?true:false,
			responsive: "scroll",
			fixedHeader: false,
			filter:false,
			search:false,
			print:false,
			download:false,
      		viewColumns:false,
            textLabels: {
                body: {
                     noMatch: this.props.userhomepagedata.loading ?<TableLoader />:<div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No data found</b></div>,
                },
            }
        };


         return(
            <div>
                 <div className="clearfix"></div>
                <div className="col-md-12 col-sm-12">

                     <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                            <MUIDataTable  title={'Last 5 Trades'}
                            data={data}
                            columns={columns} options={options}  />
                        </MuiThemeProvider>
						{(this.props.tradeinqOperval != ''  &&  parseInt(this.props.tradeinqOperval)>0)?
						<div style={{paddingTop:10, textAlign:'right'}}>
						<Route render={({ history}) => (
										  	     		<a   onClick={() => { history.push('/report/TRDINQR') }}>	View Trade History	</a>
	     				)} />
						</div>:''}
                </div>
            </div>
        )
    }
}

export default LastestTrades;