import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import '../css/LoginStyle.css';
import { userActions } from '../actions/user.actions';

class LogOutPage extends React.Component {
    constructor(props) {
        super(props);

        // reset login status
        this.loginAgain = this.loginAgain.bind(this);
        this.props.dispatch(userActions.logout());
    }

	loginAgain() {
		this.props.history.push({
			pathname: '/login',
		});
	}

	handleLogOutClose = () => {
	   window.close();
	   //window.top.close();
	};


    render() {

        return (
			<div >
				<div  className="col-md-12 col-sm-12 clearfix" style={{background: '#00395C',padding:'12px',height:'64px'}}>
					<div style={{paddingLeft:'15px',paddingRight:'15px',float:'left'}}>
						<img src="/src/images/header_logo.png" width="35px" />
					</div>
				</div>

				<div className="col-md-12 col-sm-12" style={{textAlign:'center',paddingTop:'100px',paddingBottom:'10px',fontSize:'18px',fontWeight:'bold'}}>
					Thank you for using our services.
				</div>
				<div className="clearfix"></div>
				<div className="col-md-12 col-sm-12" style={{textAlign:'center',fontSize:'14px',fontWeight:'bold'}}>
					We look forward to serving you again
				</div>
				<div className="clearfix"></div>
				<div style={{textAlign:'center'}}>
					<button className="btn btn-primary btn-xs mt" id="reviewTrade" onClick={this.loginAgain.bind(this)}>Login Again!</button>
				</div>
			</div>
        );
    }
}

function mapStateToProps(state) {
    const { loggingIn } = state.authentication;
    return {
        loggingIn
    };
}

const connectedLogOutPage = connect(mapStateToProps)(LogOutPage);
export { connectedLogOutPage as LogOutPage };