import React from 'react';

class Footer extends React.Component {
    render() {    	
        return (        	
            <div className="clearfix"> 
            <div className="footer mt10"> 
                <a target="_blank" href="https://www.corporatebankingsupport.uk.barclays/digitalchannels/important-information.html">Important Information</a>
                <a target="_blank" href="https://www.corporatebankingsupport.uk.barclays/digitalchannels/privacy.html">Privacy</a>
                <a target="_blank" href="https://www.corporatebankingsupport.uk.barclays/digitalchannels/cookie-policy.html">Cookie Policy</a>
                <a target="_blank" href="https://www.corporatebankingsupport.uk.barclays/digitalchannels/digital-channels-help-centre/security.html">Security</a>
                <a target="_blank" href="https://www.corporatebankingsupport.uk.barclays/digitalchannels/accessibility.html">Accessibility</a>          
            </div>
            <div className="BText">
            Barclays offers private and overseas banking, credit and investment solutions to its clients through Barclays Bank PLC and its subsidiary companies. Barclays Bank PLC is authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority (Financial Services Register No.122702) and is a member of the London Stock Exchange and NEX. Registered in England. Registered No. 1026167. Registered Office: 1 Churchill Place, London E14 5HP.
            </div>
             
            </div>            
        )
    }
    
}

export default Footer;