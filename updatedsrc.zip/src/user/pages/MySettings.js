import React from 'react';
import { Link } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { userActions } from '../actions/user.actions';
import { connect } from 'react-redux';
import '../../user/css/App.css';
import axios from 'axios';
import FormData from 'form-data';
import { alertConstants } from '../../common/constants/alert.constants';
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import NativeSelect from '@material-ui/core/NativeSelect';
import {addCommasAmntLocale} from '../../tradeentry/components/amountValidations';
import Loading from '../../common/Loading';
import {muiTableStyles} from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';

function arrayRemove(arr, value) {
    return arr.filter(function(ele){
        return ele != value;
    });

}

const Columns = [
    {
        name: 'Alert Frequency',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Time Interval (Hours)',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Alert When Amount is Greater Than',
        options: {
            filter: true,
            sort: false,
        }
    }
]

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
    tableheader: {
        background:'#ccc'
    },
    tabletheadtr: {
        height: '37px'
    },
    tabletheadth: {
        color:'#333',
        fontWeight:'bold',
        fontSize:'12px',
        paddingTop: '4px',
        paddingBottom: '4px'
    },
    tabletbodytr: {
        height: '32px'
    },
    tabletbodytd: {
        fontSize: '12px'
    },
    label: {
        width: '25%',
        fontSize: '12px',
        fontWeight:'bold'
    },
    labelvalue: {
        fontSize: '12px',
        fontWeight: 'normal'
    },
});

let selTemplate;
let templateName;
let ClientName;
let status;
let temp = [],selection=[];
let fromPage;

class MySettings extends React.Component {
    constructor(props){
        super(props);
        this.state={
            results:[],
            mysettings:[],
            alerttempdatadet:[],
            selection:[],
            selectAll:false,
            selectedValues:[],
            columns:[],
            screenName:'',
            msg:''
        }
        // this.doChange = this.doChange.bind(this);
        this.doSave = this.doSave.bind(this);
        this.doSelectAll = this.doSelectAll.bind(this);
        this.fileTypeChange = this.fileTypeChange.bind(this);
        this.toggleCheck = this.toggleCheck.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.doCancel = this.doCancel.bind(this);

    }
    componentWillMount(){
        this.props.dispatch(userActions.fetchMysettingsData());
    }
    doSelectAll(){
        // console.log('itemp   '+JSON.stringify( temp ));
        const selectAll =this.state.selectAll === true ?false:true;
        if(selectAll){
            this.setState({ selectAll:selectAll,selection:temp})
        }else {
            this.setState({ selectAll:selectAll,selection:[]})
        }

    }
    toggleCheck(e) {
        selection =this.state.selection;
            // console.log("name",e.target.name)

        if(!selection.includes(e.target.name)){
            // console.log('<<IFFF>>>>'+JSON.stringify(selection));
            selection.push(e.target.name);
            // console.log('<<after>>>>'+JSON.stringify(selection));
            this.setState({ selectAll:false,selection:selection})
        }else {
            // console.log('<<Elseee>>>>'+JSON.stringify(selection));
            selection= arrayRemove(selection,(e.target.name));
            // console.log('<<after>>>>'+JSON.stringify(selection));
            this.setState({ selectAll:false,selection:selection})
            this.state.selection.length= this.state.selection.length-1;
        }

        if(this.state.selection.length === temp.length)
            this.setState({ selectAll:true})
    }

    handleChange(obj){
        this.setState({templateName:obj.target.value});
        // console.log(obj.target.value)
    }

    fileTypeChange(e) {

        var temp = e.target.name;
        this.state.selectedValues.push({id:e.target.name,value:e.target.value})
        // console.log("--before--",+e.target.value.toString());
        // e.target.defaultValue = e.target.value;
        // this.setState({ Ck:0});
        // console.log("--after--",+e.target.defaultValue.toString());
        // console.log("--after--",+e.target.value.toString());
    }

    fileAmtChange(e) {
        let userLocale="";
        var user = JSON.parse(sessionStorage.getItem('user'));
        if(user[0].localeLang !== undefined){
            userLocale=user[0].localeLang;
        }
        addCommasAmntLocale(e,userLocale, true,this)
        var temp = e.target.name;
        this.state.selectedValues.push({id:e.target.name,value:e.target.value})

        // console.log('this.state.selectedValues <><>:'+JSON.stringify( this.state.selectedValues ));
        // console.log("--before--",+e.target.value.toString());
        // e.target.defaultValue = e.target.value;
        // this.setState({ Ck:0});
        // console.log("--after--",+e.target.defaultValue.toString());
        // console.log("--after--",+e.target.value.toString());
    }

    doCancel(){
        window.scroll(0,0);
        const selectAll =this.state.selectAll === true ?false:true;
        this.setState({ selectAll:false,selection:[]});
        this.componentWillMount();
    }

    doSave(idx)
    {
        var bodyFormData 	= new FormData();
        var myArray 		= [];

        temp && temp.map((value,index)=>{

            if((this.refs['menuChk'+index] !== undefined) && (this.refs['menuChk'+index].props.checked))
            {
				myArray.push({id:'menuChk'+index, value:this.refs['menuChk'+index].props.value})
				myArray.push({id:'selEventId'+index, value:this.refs['menuChk'+index].props.value})

                if(this.refs['amountAlert'+index] !== undefined) {
                    myArray.push({id:'amountAlert'+index, value:this.refs['amountAlert'+index].props.defaultValue})
                }

                if(this.refs['alertFrequency'+index] !== undefined) {
                    myArray.push({id:'alertFrequency'+index, value:this.refs['alertFrequency'+index].props.defaultValue})
                }

                if(this.refs['timeInterval'+index] !== undefined){
                    myArray.push({id:'timeInterval'+index, value:this.refs['timeInterval'+index].props.defaultValue})
                }

                if(this.refs['fileType'+index] !== undefined){
                    myArray.push({id:'fileType'+index, value:this.refs['fileType'+index].props.defaultValue})
                }
            }
        });

		this.state.selectedValues && this.state.selectedValues.map((item, index) => {
			let obj	= myArray.find(namevalue => namevalue.id === item.id);
			if(obj!== undefined)
			{
				obj.value = item.value;
			}
		});

		myArray && myArray.map((item, index) => {
			bodyFormData.append(item.id, item.value);
		});

        var user = JSON.parse(sessionStorage.getItem('user'));
        bodyFormData.append('size','26');
        bodyFormData.append('selTemplateName',templateName);
        bodyFormData.append('clientFirm',JSON.parse(sessionStorage.getItem('clientFirm')));

        if(user[0].token !== undefined) {
            bodyFormData.append('token',user[0].token);
        }

        bodyFormData.append('actionFlag', "SAVE");
        var data;
		axios({
			method: 'POST',
			url:alertConstants.URL+"/MYSETTINGS.do",
			data: bodyFormData,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
		}).then((response)=>{
			data = response.data;
			console.log(data);
			this.setState({msg:data.Message.message})
		});

       	window.scrollTo(0,0);
    }

    render() {
        const { classes } = this.props;
        const { mysettings } = this.props;

        this.state.mysettings = mysettings;
        this.state.results = this.state.mysettings.mysettings;

        var filterdata = mysettings.mysettings;
        // console.log('editdatatable <><>:'+JSON.stringify(filterdata));

        if(filterdata !== undefined) {
            this.state.screenName = filterdata.Title.Title;
            this.state.results = filterdata.data;
            // console.log('Data--- <><>:'+JSON.stringify(filterdata));
            // console.log('filterdata <><>:'+JSON.stringify(this.state.results));

        let menuChk=0;
        let rowsdata
        const headerRow =
            <TableRow>
                <TableCell>
                    <Checkbox defaultChecked={false} checked={this.state.selectAll?true:false} onChange={this.doSelectAll} />Select All Alerts</TableCell>
                <TableCell>Alert Frequency</TableCell>
                <TableCell align="right">Time Inverval (Hours)</TableCell>
                <TableCell align="right">Alert When Amount is Greater Than</TableCell>
            </TableRow>;
			if(this.state.results != undefined && this.state.results.length > 0) {
            const Bodydata = this.state.results && this.state.results.map((row, index) => {
                rowsdata = row.rows && row.rows.map((rowdata, newindex) => {
                    if(rowdata.ischecked === "checked"){
                        this.state.selection.push("menuChk"+menuChk);
                        selection.push("menuChk"+menuChk);
                        rowdata.ischecked = "";
                        // console.log("selection==>",this.state.selection)
                    }
                    temp.push("menuChk"+menuChk);
                    return (
                        <TableRow key={newindex} className={classes.tabletheadtr}>
                            <TableCell style={{width:'500px'}} className={classes.tabletbodytd}>
                            {/* {console.log(rowdata.ischecked)} */}
                                <Checkbox ref={"menuChk"+menuChk} name={"menuChk"+menuChk} defaultChecked={false} checked={(this.state.selection.includes("menuChk"+menuChk))?true:false} id={"check"+menuChk} value={rowdata.selEventId} onChange={this.toggleCheck}/>
                                {rowdata.alertName}
                                {
                                    (rowdata.fileTypeFlag === "true") &&
                                    <NativeSelect className={classes.select} ref={"fileType"+menuChk} defaultValue={rowdata.fileTypeValue} onChange={this.fileTypeChange.bind(this)} name={"fileType"+menuChk} style={{float:'right',marginTop:'7px'}}>
                                        {filterdata.fileType.values && filterdata.fileType.values.map((obj,index) => {
                                            return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                            </TableCell>
                            <TableCell className={classes.tabletbodytd}>
                                {
                                    (rowdata.frequencyType === "frequency") &&
                                    <NativeSelect className={classes.select} ref={"alertFrequency"+menuChk} defaultValue={rowdata.frequencyValue} onChange={this.fileTypeChange.bind(this)} name={"alertFrequency"+menuChk} style={{width:'200px'}} id={rowdata.alertName} >
                                        {filterdata.frequency.values && filterdata.frequency.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "timeZone") &&
                                    <NativeSelect className={classes.select} ref={"timeZone"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}} id={rowdata.alertName}  name={"timeZone"+menuChk} >
                                        {filterdata.timeZone.values && filterdata.timeZone.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "language") &&
                                    <NativeSelect className={classes.select} ref={"language"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}}
                                    id={rowdata.alertName}  name={"language"+menuChk} >
                                        {filterdata.language.values && filterdata.language.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "amtFormat") &&
                                    <NativeSelect className={classes.select} ref={"amtFormat"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}} id={rowdata.alertName}  name={"amtFormat"+menuChk} >
                                        {filterdata.amtFormat.values && filterdata.amtFormat.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "dateFormat") &&
                                    <NativeSelect className={classes.select} ref={"dateFormat"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}} id={rowdata.alertName}  name={"dateFormat"+menuChk} >
                                        {filterdata.dateFormat.values && filterdata.dateFormat.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "timeFormat") &&
                                    <NativeSelect className={classes.select} ref={"timeFormat"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}} id={rowdata.alertName}  name={"timeFormat"+menuChk} >
                                        {filterdata.timeFormat.values && filterdata.timeFormat.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }

                            </TableCell>
                            <TableCell className={classes.tabletbodytd}>
                                {
                                    (rowdata.timeIntervalFlag === "true") &&
                                    <NativeSelect className={classes.select} ref={"timeInterval"+menuChk} defaultValue={rowdata.timeIntervalValue} onChange={this.fileTypeChange.bind(this)} name={"timeInterval"+menuChk}>
                                        {filterdata.intervalHash.values && filterdata.intervalHash.values.map((obj,index) => {
                                            return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                            </TableCell>
                            <TableCell className={classes.tabletbodytd}>
                                {
                                    (rowdata.amountAlertFlag === "true") &&
                                    <TextField className={classes.inputStyle} style={{width:'100px'}} type="text" onBlur={this.fileAmtChange.bind(this)} ref={"amountAlert"+menuChk} name={"amountAlert"+menuChk} defaultValue={rowdata.amountAlert} />
                                }
                            </TableCell>
                            <span style={{display:"none"}}>{menuChk++}</span>
                        </TableRow>
                    )
                });
                return (
                    <TableBody key={index}>
                        <TableRow key={index} className={classes.tabletheadtr} style={{background:'#ccc'}}>
                            <TableCell colSpan={4} className={classes.tabletheadth}>{row.name}</TableCell>
                        </TableRow>
                        {rowsdata}
                    </TableBody>
                );
            });
        return(
            <div>
                <NavBar/>
                <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{this.state.screenName}</h4>
                    </div>
                    <div className="panel-body">
                    <h5>My Email Alerts</h5>
                    {
                        this.state.msg !== "" &&
                        <div className="text-center displayTxt">{this.state.msg}</div>
                    }
                            <Paper className={classes.root}>
                                <Table className={classes.table}>
                                    <TableHead className={classes.tableheader}>
                                        {headerRow}
                                    </TableHead>

                                    {Bodydata}

                                </Table>
                            </Paper>
                        </div>
                        <div className="col-md-6">
                            <a title="Save" onClick={(e)=>{this.doSave();}} className="btn btn-primary btn-xs">Save</a>
                            <a title="Cancel" onClick={(e)=>{this.doCancel();}} className="btn btn-primary btn-xs">Cancel</a>
                        </div>
                    </div>
                    </MuiThemeProvider>
                </div>
            // </div>
        );
		}
		else {
       	 return(
            <div>
						<NavBar/>
						<div className="panel panel-primary clearfix" style={{clear:'both'}}>
						                    <div className="panel-heading">
						                        <h4 className="panel-title">{this.state.screenName}</h4>
						                    </div>
						                    <div className="panel-body">
						                    <h5>My Email Alerts</h5>
						                       <div className="text-center displayTxt">No Template is associated to this user.</div>
						                </div>
                </div>
                </div>
        	)

		}
    }else {
        return(
            <Loading />
        )
    }
}
}
function mapStateToProps(state) {
    const { mysettings } = state;
    return { mysettings };
}

const connectedMySettings = connect(mapStateToProps)(withStyles(MuiStyles)(MySettings));
export { connectedMySettings as MySettings };
