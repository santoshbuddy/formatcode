import React from 'react';
import { Route } from 'react-router-dom';
import { MuiThemeProvider } from '@material-ui/core/styles';
import MUIDataTable from "mui-datatables";
import { muiTableStyles } from '../../styles/muidatatableCss';
import TableLoader from '../../common/TableLoader';
import Filters from './Filters';

import ScrollDialogPopUp from "../../invest/components/ScrollDialogPopUp";


class AccountSummary extends React.Component{
    constructor(props) {
        super(props);
        this.state={
         }
           this.doChange = this.doChange.bind(this);
           this.checkClick = this.checkClick.bind(this);
     };
	doChange(bodyFormData){
 	 this.props.doChange(bodyFormData);
   }
	 checkClick(cData, paramVal) {

				if(paramVal == 'TRADEENTRY' || paramVal == 'CLOSEACCOUNT') {
					this.props.history.push({
						pathname: '/DEALENT',
						state: {
							tabIndex: 1,
							activeStep: 1,
							paramVal: paramVal,
							fromPage:'ViewChanges',
							bformdata: cData
						}
					});
				} else if(paramVal == 'TRADEHISTORY') {
					this.props.history.push({
						pathname: '/report/TRDINQR',
						state: {
							fromPage:'ViewChanges',
							product: cData.parentprodid,
							issueChild: cData.prodid
						}
					});
				} else if(paramVal == 'EDITACCOUNT') {
					this.props.history.push({
						pathname: '/administration/MMFEDITACCT',
						state: {
							fromPage:'ViewChanges',
							mmmfAcct: cData.escrowacctnbr,
							clientFirm: cData.clientFirm,
							product: cData.subprodname,
							currency: cData.currency,
						}
					});
				}

		}
    render() {
        const { data,columns,tabType,checkPosition} = this.props;

        console.log('columns :: '+JSON.stringify(columns))
         console.log('data :: '+JSON.stringify(data))
         console.log('tabType :: '+tabType)

		let screenLinkImage = 'HOME';
		if(tabType === 'MMF') screenLinkImage = 'HOME';
		else if(tabType === 'MMDA') screenLinkImage = 'HOMEINBA';
		else if(tabType === 'TERM') screenLinkImage = 'HOME';

         columns && columns.map((item,index)=>{
		  	 	       //console.log("mar02,2019  item.name:::::",item.name)
		 			if(item.name === "Account Number"){
		 				item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
		 				 return (
		 					<ScrollDialogPopUp
		 					onClick={e => this.openPopUp(e, tableMeta)}
		 					rowData={tableMeta}
		 					linkName={value}
		 					screenLinkImage={screenLinkImage}
		 				 	func={this.checkClick.bind(this) }

		 					/>
		 				  );
		 				 }
		 			}
		 		});


         const options = {
            filter: false,
            filterType: 'dropdown',
            rowsPerPage: (data && data.length>0 )?10:0,
			responsive: "scroll",
			fixedHeader: false,
			filter:false,
			search:false,
			print:false,
			download:false,
      		viewColumns:false,
            selectableRows: (data && data.length>0 )?true:false,
            isRowSelectable: (dataIndex) => {
				//	console.log("checkPosition .....", checkPosition);
					return data[dataIndex][checkPosition] !== "disabled";
			},
             customToolbarSelect: (selectedRows, displayData, setSelectedRows) => <div></div>,
            textLabels: {
                body: {
                     noMatch: this.props.userhomepagedata.loading?<TableLoader />:
                     (<div>

                       	 {(tabType === 'MMF'?<div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No MMF Data Available</b></div>:'')}

                         {(tabType === 'MMDA'?<div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No Interest Bearing Account Data Available</b></div>:'')}

                        {(tabType === 'TERM'? <div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No Fixed Term Data Available</b></div>:'')}
                       </div>   ),
                },
            }
        };


         return(
            <div>
                 <div className="clearfix"></div>
                <div className="col-md-12 col-sm-12 head-cls backwhite">

                    <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                            <MUIDataTable title={'Account Summmary'}
                            data={data}
                            columns={columns} options={options}  />
                        </MuiThemeProvider>
                 </div>
            </div>
        )
    }
}

export default AccountSummary;