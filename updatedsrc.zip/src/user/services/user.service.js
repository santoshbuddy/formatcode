import { authHeader,fetchHelper } from '../../_helpers';
import FromData from 'form-data';
import { alertConstants } from '../../common/constants/alert.constants';

export const userService = {
    login,
    logout,
    register,
    getMMMFData,
    fetchUserHomePageData,
    getById,
    update,
    fetchMysettings,
    delete: _delete
};

function login(username, password) {
	return fetchHelper.login(username, password);
}
function getMMMFData() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var bodyFormData = new FromData();
    let getMMMFData;
    //  var pathname = window.location.pathname.replace("/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);

 		if(sessionStorage.getItem('clientFirm') === null )
        bodyFormData.append("clientFirm",user[0].companyId);
		else
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

        getMMMFData = fetchHelper.httpFormPost(alertConstants.URL+'/FUNDINFO.do',bodyFormData);

    }
    return getMMMFData;
}


function fetchUserHomePageData(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let userHomePageData;
    //  var pathname = window.location.pathname.replace("/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);

 		if(sessionStorage.getItem('clientFirm') === null )
        bodyFormData.append("clientFirm",user[0].companyId);
		else
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        if(user[0].memberCatId === "4")
            userHomePageData = fetchHelper.httpFormPost(alertConstants.URL+'/HOME.do',bodyFormData);
        else if(user[0].memberCatId === "3")
            userHomePageData = fetchHelper.httpFormPost(alertConstants.URL+'/ADMNHOME.do',bodyFormData);

    }
    return userHomePageData;
}

function fetchMysettings() {
    var user = JSON.parse(sessionStorage.getItem('user'));
    var bodyFormData = new FromData();
    let mysettings;
    //  var pathname = window.location.pathname.replace("/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token);

 		// if(sessionStorage.getItem('clientFirm') === null )
        // bodyFormData.append("clientFirm",user[0].companyId);
		// else
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

        mysettings = fetchHelper.httpFormPost(alertConstants.URL+'/MYSETTINGS.do',bodyFormData);

    }
    return mysettings;
}

function getById(id) {
    let _getById = fetchHelper.httpGet('/users/${id}');
    return _getById;
}

function register(user) {
    return fetchHelper.httpPost('/users/register',user);
}

function update(user) {
    return fetchHelper.httpPut('/users/${user.id}',user);
}

// prefixed function name with underscore because delete is a reserved word in javascript
function _delete(id) {
	return fetchHelper.httpDelete('/users/${id}');
}

function logout() {
	fetchHelper.logout();
}
