import React from 'react'; 
import DatePicker from 'react-datepicker'; 
import 'react-datepicker/dist/react-datepicker.css'; 
var dateFormat = require('dateformat');
class Filters extends React.Component {
    constructor () { 
        super() 
        this.state = { 
          startDate: new Date(),
          endDate: new Date(),
          repdatatable:[]          
        }; 
        this.handleStartDateChange = this.handleStartDateChange.bind(this); 
        this.handleEndDateChange = this.handleEndDateChange.bind(this); 
      } 
      componentWillMount(){
        // this.doChange();
      }
      componentWillReceiveProps(){
        if(this.props.data !== undefined){            
         this.props.data.map((filter,index) => { 
          if(filter.type === "datepicker"){
            if(filter.name === "fromDate")
                this.state.startDate=new Date(filter.value)
          }
         });
        }      
      }
      handleStartDateChange(date) {  
         this.setState({startDate:date});
      }
      handleEndDateChange(date) {  
        this.setState({endDate:date});
     }
     doChange(e){
      //console.log("in do change method ..."); 
      var filtObj = {};
      var selRefActNbr;
     if(this.props.data !== undefined)      
      for(var i =0; i<this.props.data.length; i++){
         var temp = this.props.data[i].name;
         if((this.props.data[i].type === "Select") && (this.props.data[i].flag === "ACTCLONE")){
           if(i===0){
            filtObj[3]="5100629896880681";//acctnbr
            filtObj[4]="3984069654642598";//taxid
            filtObj[5]="81837075";//companyid
            filtObj[6]="33969052";//deskid
            filtObj[7]="6008233958668745";//fromacctnbr
            filtObj[8]="28029897";//productid
           }
           //console.log("select block ... ");
           selRefActNbr = this.refs[temp].value; 
           //console.log(selRefActNbr);
         }
          if((this.props.data[i].type === "data")){
            //console.log("in data for loop...");
            //console.log(this.props.data[i].values);
            this.state.repdatatable=this.props.data[i].values;
          }
          if((this.props.data[i].type !== "data") && this.props.data[i].type !== "message" && (this.props.data[i].type !== "Title")  && (this.props.data[i].type !== "Button") && (this.props.data[i].type !== "newline")){
            filtObj[this.props.data[i].name] = this.refs[temp].value; 
            }
          }
          
          if(this.state.repdatatable !== undefined) { 
            //console.log(this.state.repdatatable); 
            this.state.repdatatable.map((item,index) => {
                    var tabRefActNbr =  item["Ref Account Number"];
                    //console.log("in table data for map...");
                    //console.log("selected value:"+selRefActNbr);
                    //console.log("table value:"+tabRefActNbr);
                    if(selRefActNbr === tabRefActNbr){
                      filtObj[3]=item["acctnbr"];
                      filtObj[4]=item["taxId"];
                      filtObj[5]=item["companyid"];
                      filtObj[6]=item["deskId"];
                      filtObj[7]=item["fromacctnbr"];
                      filtObj[8]=item["productId"];
                      //var acctnbr=item["acctnbr"];
                      //var taxId=item["taxId"];
                      //this.props.taxId=item["taxId"];
                      //this.props.acctNbr=item["acctnbr"];
                      //console.log("success block .acctNbr::"+acctnbr);                     
                    }
            });                
        }
        this.props.method(filtObj);
     }

    render(){ 

        //console.log(this.props)
         var data;
        let filetermarkup; 
     
        if(this.props.data !== undefined){           
          data = this.props.data
        filetermarkup = data.map((filter,index) => { 
       
            if(filter.type === "Select"){
             return(    
              <div className="form-group col-md-2 col-sm-2" key={filter.id.toString()} >
                   <label> { filter.label } :</label>
                   <select ref={ filter.name }  name={filter.name} className="form-control input-sm" >
                      {
                           filter.values && filter.values.map((obj,index) => { 
                                return <option key={index} value={obj.id}>{obj.name}</option>
                          })
                       } 
                   </select>
               </div>
               );
            }else if(filter.type === "datepicker"){
                if(filter.name === "fromDate"){         
                  
                  
                 return (
                   <div className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                       <label> { filter.label }:</label>
                      <DatePicker dateFormat="MMM dd, YYYY" ref={ filter.name } name={filter.name} className="form-control"   selected={this.state.startDate}  onChange={this.handleStartDateChange} />
                   </div>
                 );
                }else if(filter.name === "toDate"){
                
                 return (
                   <div className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                       <label> { filter.label }:</label>
                      <DatePicker dateFormat="MMM dd, YYYY" ref={ filter.name } name={filter.name} className="form-control"  selected={this.state.endDate}   onChange={this.handleEndDateChange} />
                   </div>
                 );
                }
              }else if(filter.type === "Button"){                
                return (
                 <div  className="form-group col-md-2 col-sm-2 mt" key={filter.id.toString()}>
                      <a title={ filter.label } onClick={(e)=>{this.doChange();}} className="btn btn-primary btn-xs">{ filter.name }</a> 
                  </div>
                );                
              }else if(filter.type === "input"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input ref={filter.name} defaultValue={filter.value} className="form-control input-sm" ref={filter.name}/>
                  </div>
               );      
              }else if(filter.type === "hidden"){
                return (
                  <div  key={filter.id.toString()}>
                      <input type="hidden" ref={filter.name} name={filter.name} defaultValue={filter.value} className="form-control input-sm" />
                   </div>
                );      
               }else if(filter.type === "checkbox"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input type="checkbox" ref={filter.name}/>
                  </div>
               );      
              }else if(filter.type === "radio"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <input type="radio" ref={filter.name}/>
                  </div>
               );     
              }else if(filter.type === "textarea"){
               return (
                 <div  className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                      <label> { filter.label } :</label>
                     <textarea rows="5" cols="15" className="form-control input-sm" ref={filter.name} />
                    </div>
               );      
              }else if(filter.type === "newline"){
                return  <div key="newline" className="clearfix"></div>        
              } 
        });
    }
 
        return(
            <div>
                {filetermarkup}                
            </div>
        );
    }
}

export default Filters;