import { accountcloneConstants } from '../constants/accountclone.constants';
import { accountcloneService } from '../services/accountclone.service';

export const accountcloneActions = {
    fetchReportData,
    fetchReportTableData
};

function fetchReportData() {
    //alert("actions fetch report")
    return dispatch => {
        dispatch(request());

        accountcloneService.fetchReport()
            .then(
                accountclonedata => dispatch(success(accountclonedata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: accountcloneConstants.GETACCOUNTCLONEDATA_REQUEST } }
    function success(accountclonedata) { return { type: accountcloneConstants.GETACCOUNTCLONEDATA_SUCCESS, accountclonedata } }
    function failure(error) { return { type: accountcloneConstants.GETACCOUNTCLONEDATA_FAILURE, error } }
}
function fetchReportTableData(bodyFormData){  
    return dispatch => {
        dispatch(request());

        accountcloneService.fetchReportTable(bodyFormData)
            .then(
                accountclonedatatable => dispatch(success(accountclonedatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: accountcloneConstants.GETACCOUNTCLONETBLDATA_REQUEST } }
    function success(accountclonedatatable) { return { type: accountcloneConstants.GETACCOUNTCLONETBLDATA_SUCCESS, accountclonedatatable } }
    function failure(error) { return { type: accountcloneConstants.GETACCOUNTCLONETBLDATA_FAILURE, error } }
 
} 