import { accountcloneConstants } from '../constants/accountclone.constants';

export function accountclonedata(state = {}, action) {
    switch (action.type) {
      case accountcloneConstants.GETACCOUNTCLONEDATA_REQUEST:
        return {
          loading: true
        };
      case accountcloneConstants.GETACCOUNTCLONEDATA_SUCCESS:
        return {
          accountclonedata: action.accountclonedata
        };
      case accountcloneConstants.GETACCOUNTCLONEDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }

  export function accountclonedatatable(state = {}, action) { 
    switch (action.type) {
      case accountcloneConstants.GETACCOUNTCLONETBLDATA_REQUEST:
        return {
          loading: true
        };
      case accountcloneConstants.GETACCOUNTCLONETBLDATA_SUCCESS: 
        return {
          accountclonedatatable: action.accountclonedatatable
        };
      case accountcloneConstants.GETACCOUNTCLONETBLDATA_FAILURE:
        return { 
          error: action.error
        };
         default:
        return state
    }
  } 