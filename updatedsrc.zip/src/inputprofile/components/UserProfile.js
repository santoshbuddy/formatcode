import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { inputprofileActions } from '../actions/inputprofile.actions';
import { connect } from 'react-redux';
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import FormData from 'form-data';
import { Route } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';

class UserProfile extends React.Component {
    constructor(){
        super();
        this.state={
            ssoCategoryList: [{
                "id": "300",
                "label": "",
                "name": "Site Minder",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "100",
                "label": "",
                "name": "FO2 Direct",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "200",
                "label": "",
                "name": "CMG",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "600",
                "label": "",
                "name": "CDS",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "435",
                "label": "",
                "name": "Treasury Vision New",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "500",
                "label": "",
                "name": "EMEA FO2 Direct",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "400",
                "label": "",
                "name": "Treasury Vision",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "700",
                "label": "",
                "name": "Poland FO2 Direct",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "999",
                "label": "",
                "name": "NONE",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "329",
                "label": "",
                "name": "FO2 Direct BE",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }, {
                "id": "800",
                "label": "",
                "name": "BE Treasury Vision",
                "value": "",
                "flag": "",
                "image": "",
                "parentImage": "",
                "toppanelImage": "",
                "token": "",
                "href": "",
                "onclick": "",
                "checked": "",
                "fieldValue": "",
                "loginId": "",
                "companyId": "",
                "action": "",
                "link": "",
                "type": ""
            }]
		}
        this.doChange = this.doChange.bind(this);
    }

    componentDidMount() {
        //this.getFilter()
   }
//    getFilter(){
//     this.props.dispatch(inputprofileActions.fetchReportData());
//    }

   doChange(e){
    var adminId = JSON.parse(sessionStorage.getItem('adminId'));
    //alert(adminId);
    var firstName = JSON.parse(sessionStorage.getItem('firstName'));
    //alert(firstName);
     var middleName = JSON.parse(sessionStorage.getItem('middleName'));
    //alert(middleName);
    var lastName = JSON.parse(sessionStorage.getItem('lastName'));
    //alert(lastName);
     var tele = JSON.parse(sessionStorage.getItem('tele'));
    //alert(tele);
     var email = JSON.parse(sessionStorage.getItem('email'));
    //alert(email);
     var ssologid = JSON.parse(sessionStorage.getItem('ssologid'));
    //alert(ssologid);
    var ssoid = JSON.parse(sessionStorage.getItem('ssoCatId'));
    alert(ssoid);
    var bodyFormData = new FormData();
    bodyFormData.append('adminId', adminId);
    bodyFormData.append('firstName', firstName);
    bodyFormData.append('middleName', middleName);
    bodyFormData.append('lastName', lastName);
    bodyFormData.append('tele', tele);
    bodyFormData.append('email', email);
    bodyFormData.append('ssologid', ssologid);
    bodyFormData.append('ssoCatId', ssoid);
    bodyFormData.append('actionFlag', "save");
    bodyFormData.append('isClone', "clone");
    bodyFormData.append('loginName', "84487861");//11070D

    this.props.dispatch(inputprofileActions.fetchReportTableData(bodyFormData));
   }

   doLoginName(e){
    sessionStorage.setItem('adminId', JSON.stringify(e.target.value));
   }
   doFirstName(e){
       sessionStorage.setItem('firstName', JSON.stringify(e.target.value));
   }
   doMiddleName(e){
       sessionStorage.setItem('middleName', JSON.stringify(e.target.value));
   }
   doLastName(e){
       sessionStorage.setItem('lastName', JSON.stringify(e.target.value));
   }
   doPhone(e){
       sessionStorage.setItem('tele', JSON.stringify(e.target.value));
   }
   doEmail(e){
       sessionStorage.setItem('email', JSON.stringify(e.target.value));
   }
   doSsoLoginId(e){
       sessionStorage.setItem('ssologid', JSON.stringify(e.target.value));
   }

   dossoId(e){
    sessionStorage.setItem('ssoCatId', JSON.stringify(e.target.value));
   }
    render(){
        let clonebtn;
        clonebtn =
        <Route render={({ history}) => (
            <button  className="btn btn-primary btn-xs"
                type='button'
                onClick={(e)=>{this.doChange();}}
                >
                Clone
          </button>
        )} />

        let returnbtn;
        returnbtn =
        <Route render={({ history}) => (
            <button  className="btn btn-primary btn-xs"
                type='button'
                onClick={() => { history.push('/inputprofile/USERCLNE') }}
            >
                Return
          </button>
        )} />


        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        {/* <h4 className="panel-title">{this.state.screenName}</h4> */}
                        <h4 className="panel-title">User Profile</h4>
                    </div>
                    <div className="panel-body">
                    <div className="col-md-12 col-sm-12 head-cls backwhite">
                    <div className="panel">
	                     <div className="panel-heading clearfix">
	                     <h4 className="panel-title pull-left col-md-1">Add New :</h4>
	                        <a className="pull-right" onClick={this.tottgleDisplay}>
		                         <i className="fa fa-caret-down"></i>
	                        </a>
	                    </div>
                    </div>
	            <Grid item  key="0">
	                    <InputLabel> Login Name :</InputLabel>
	                    <TextField ref="adminId" name="adminId"  onChange={this.doLoginName}/>
                </Grid>

                 <Grid item  key="1">
		            <InputLabel> First Name :</InputLabel>
		            <TextField ref="firstName" name="firstName"  onChange={this.doFirstName}/>
                </Grid>
                <Grid item  key="2">
		            <InputLabel> Middle Name :</InputLabel>
                             <TextField ref="middleName" name="middleName" onChange={this.doMiddleName}/>
                 </Grid>
	            <Grid item  key="3">
	                <InputLabel> Last Name :</InputLabel>
	                <TextField ref="lastName" name="lastName" onChange={this.doLastName}/>
	            </Grid>

	            <Grid item  key="4">
	                <InputLabel> Phone :</InputLabel>
	                <TextField ref="tele" name="tele" onChange={this.doPhone}/>
	            </Grid>

	            <Grid item  key="5">
	                <InputLabel> Email :</InputLabel>
	                 <TextField ref="email" name="email" onChange={this.doEmail}/>
	            </Grid>
            </div>
                        <div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">SSO User Mapping</h4>
                                </div>
                             </div>
                                <Grid item  key="6">
                            <InputLabel> SSO Login Id :</InputLabel>
                             <TextField ref="ssologid" name="ssologid"  onChange={this.doSsoLoginId}/>
                            </Grid>

                            <Grid item  key="7">
                                <InputLabel>
                                 SSO Category :
                             </InputLabel>

                             <NativeSelect
                            ref="ssoid"  name="ssoid" onChange={this.dossoId}
                             >
                             {this.state.ssoCategoryList && this.state.ssoCategoryList.map((obj,index) => {
                                return <option key={index} value={obj.id}>{obj.name}</option>
                            })}
                             </NativeSelect>
                             </Grid>
                        </div>
                            {clonebtn}
                            {returnbtn}
				       </div>
                    </div>
                </div>
        );
    }
  }

function mapStateToProps(state) {
	const { inputprofiledata,inputprofiledatatable } = state;
    return { inputprofiledata,inputprofiledatatable };
}

const connectedUserProfile = connect(mapStateToProps)(UserProfile);
export { connectedUserProfile as UserProfile };
