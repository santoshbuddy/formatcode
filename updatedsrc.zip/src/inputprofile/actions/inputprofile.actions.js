import { inputprofileConstants } from '../constants/inputprofile.constants';
import { inputprofileService } from '../services/inputprofile.service';

export const inputprofileActions = {
    fetchReportData,
    fetchReportTableData
};

function fetchReportData() {
    //alert("actions fetch report")
    return dispatch => {
        dispatch(request());

        inputprofileService.fetchReport()
            .then(
                inputprofiledata => dispatch(success(inputprofiledata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: inputprofileConstants.GETINPUTPROFILEDATA_REQUEST } }
    function success(inputprofiledata) { return { type: inputprofileConstants.GETINPUTPROFILEDATA_SUCCESS, inputprofiledata } }
    function failure(error) { return { type: inputprofileConstants.GETINPUTPROFILEDATA_FAILURE, error } }
}
function fetchReportTableData(bodyFormData){  
    return dispatch => {
        dispatch(request());

        inputprofileService.fetchReportTable(bodyFormData)
            .then(
                inputprofiledatatable => dispatch(success(inputprofiledatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: inputprofileConstants.GETINPUTPROFILETBLDATA_REQUEST } }
    function success(inputprofiledatatable) { return { type: inputprofileConstants.GETINPUTPROFILETBLDATA_SUCCESS, inputprofiledatatable } }
    function failure(error) { return { type: inputprofileConstants.GETINPUTPROFILETBLDATA_FAILURE, error } }
 
} 