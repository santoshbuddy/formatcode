import { inputprofileConstants } from '../constants/inputprofile.constants';

export function inputprofiledata(state = {}, action) {
    switch (action.type) {
      case inputprofileConstants.GETINPUTPROFILEDATA_REQUEST:
        return {
          loading: true
        };
      case inputprofileConstants.GETINPUTPROFILEDATA_SUCCESS:
        return {
          inputprofiledata: action.inputprofiledata
        };
      case inputprofileConstants.GETINPUTPROFILEDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }

  export function inputprofiledatatable(state = {}, action) { 
    switch (action.type) {
      case inputprofileConstants.GETINPUTPROFILETBLDATA_REQUEST:
        return {
          loading: true
        };
      case inputprofileConstants.GETINPUTPROFILETBLDATA_SUCCESS: 
        return {
          inputprofiledatatable: action.inputprofiledatatable
        };
      case inputprofileConstants.GETINPUTPROFILETBLDATA_FAILURE:
        return { 
          error: action.error
        };
         default:
        return state
    }
  } 