import { reportConstants } from '../constants/report.constants';

export function reportdata(state = {}, action) {
    switch (action.type) {
      case reportConstants.GETREPORTDATA_REQUEST:
        return {
          loading: true
        };
      case reportConstants.GETREPORTDATA_SUCCESS:
        return {
            reportdata: action.reportdata
        };
      case reportConstants.GETREPORTDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
  // export function clientreportdata(state = {}, action) {
  //   switch (action.type) {
  //     case reportConstants.GETCLIENTREPORTDATA_REQUEST:
  //       return {
  //         loading: true
  //       };
  //     case reportConstants.GETCLIENTREPORTDATA_SUCCESS:
  //       return {
  //         clientreportdata: action.clientreportdata
  //       };
  //     case reportConstants.GETCLIENTREPORTDATA_FAILURE:
  //       return { 
  //         error: action.error
  //       };
      
  //     default:
  //       return state
  //   }
  // }
  export function reportcdata(state = {}, action) {
    switch (action.type) {
      case reportConstants.GETREPORTCOMPDATA_REQUEST:
        return {
          loading: true
        };
      case reportConstants.GETREPORTCOMPDATA_SUCCESS:
        return {
            reportcdata: action.reportcdata
        };
      case reportConstants.GETREPORTCOMPDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
  export function reportdatatable(state = {}, action) { 
      switch (action.type) {
      case reportConstants.GETREPORTTBLDATA_REQUEST:
        return {
          loading: true
        };
      case reportConstants.GETREPORTTBLDATA_SUCCESS: 
        return {         
          reportdatatable: action.reportdatatable
        };
      case reportConstants.GETREPORTTBLDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }