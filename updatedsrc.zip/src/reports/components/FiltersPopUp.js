import React from 'react';
import DatePicker from 'react-datepicker';
import { withStyles, MuiThemeProvider } from '@material-ui/core/styles';
import 'react-datepicker/dist/react-datepicker.css';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import CustomDatePickerInput from '../../styles/CustomDatePickerInput';
import { ReactDatePicker } from '../../styles/ReactDatePicker';


let dateChange=false;
let listChange=false;
const styles = theme => ({
  margin: {
    margin: theme.spacing.unit,
  },
});
var dateFormat = require('dateformat');
let filterNameValueArray=[];
let filterData=[];
let tempFromDateValue;
class FiltersPopUp extends React.Component {
    constructor () {
        super(),
        this.state = {
          newChangeList:false
        },
        this.doListChange = this.doListChange.bind(this);
        this.doChange = this.doChange.bind(this);
      }
      componentWillMount(){
        // this.doChange();
      }
      componentDidUpdate(){
        //alert("filter. dateChange.."+dateChange);
        //listChange=false;
        if(dateChange === false){
           filterNameValueArray=[];
        }
      }
      handleDateChange(name,value) {
        dateChange=true;
        //console.log("dateChange:",dateChange);
        filterNameValueArray.find(namevalue => namevalue.id === name).value=dateFormat(value,"mmm dd, yyyy");
        filterData.find(namevalue => namevalue.name === name).value=dateFormat(value,"mmm dd, yyyy");
        this.forceUpdate();
      }
 

doListChange(e){
    //alert("in doListChange... ");
      let eventHistory;
      if(document.getElementById("eventHistory")!=null){
        eventHistory = document.getElementById("eventHistory").value;
        //alert("may 09, 2019 eventHistory::"+eventHistory);
	if (filterNameValueArray.find(e => e.id === "eventHistory") !== undefined){
		filterNameValueArray.find(namevalue => namevalue.id === "eventHistory").value=eventHistory;
	}else{
		filterNameValueArray.push({id:"eventHistory",value:eventHistory});
	  }
      }
        
      //console.log("may 09 filterNameValueArray::",filterNameValueArray)
      this.props.method(filterNameValueArray);
     }
     
     doChange(e){
      //alert("filterNameValueArray data:"+filterNameValueArray);
      //console.log("filterNameValueArray---->")
      //alert(filterNameValueArray.length);
      console.log(filterNameValueArray)
      this.props.method(filterNameValueArray);

     }

    render(){

      //console.log("filter filterFlag::"+this.props.filterFlag);
      //console.log("filterData::"+filterData+",filterFlag:"+this.props.filterFlag);
      //console.log("filterFlag:::"+this.props.filterFlag)
      const { classes } = this.props;
        const { data } = this.props;
        let filetermarkup;
		console.log("target ... data:::",data);
		filterData=data;
        
         //console.log("feb_25_2019after filterData::"+filterData);
        if(filterData !== undefined && filterData.length>0){
           filetermarkup = filterData.map((filter,index) => {
            if(filter.type === "Select"){
			                 console.log("feb_25_2019 select block ...");
             return(
                <Grid item  key={filter.id.toString()}>
                  <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
                    { filter.label } :
                  </InputLabel>
			                        <NativeSelect className={classes.select}
			                          ref={ filter.name }  name={filter.name} id={filter.name} onChange={(e)=>{this.doListChange();}}>
			                            {filter.values && filter.values.map((obj,index) => {
			                                    return <option key={index} value={obj.id}>{obj.name}</option>
			                                })}
			                          </NativeSelect>
                </Grid>
               );
            }else if(filter.type === "datepicker"){
			if(filter.name === "toDate"){
				tempFromDateValue=filter.value;
			}
            if(filterNameValueArray.find(namevalue => namevalue.id === filter.name))
			filterNameValueArray.find(namevalue => namevalue.id === filter.name).value=filter.value;
	else
              filterNameValueArray.push({id:filter.name,value:filter.value})
                 return (
                  <Grid item  key={filter.id.toString()}>
                       <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">
                       { filter.label }:</InputLabel>
                       <ReactDatePicker style={{width:'140px'}}>
                          <DatePicker  dateFormat="MMM dd, YYYY" ref={ filter.name } id={filter.name} autoOk={true} name={filter.name} className="form-control"  selected={new Date(filterData.find(namevalue => namevalue.name === filter.name).value)}  onChange={this.handleDateChange.bind(this, filter.name)} customInput={(<CustomDatePickerInput/>)} />
                        </ReactDatePicker>
                   </Grid>
                 );
              }else if(filter.type === "Button"){
                return (
                <button size="small" style={{height: 30, margin: 12}} className="btn btn-primary btn-xs"  title="Go" onClick={(e)=>{this.doChange();}} key={filter.id.toString()}>
                  { filter.name }
                </button>
               );
              }else if(filter.type === "label"){
               return (
                  <Grid item  key={filter.id.toString()}>
                      <InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
                      <InputLabel> { filter.value }</InputLabel>
                  </Grid>
               );
              }else if(filter.type === "newline"){
                return  <div key="newline" className="clearfix"></div>
              }
        });
        dateChange=true;
        //console.log("after filter block called ... filterNameValueArray::",filterNameValueArray);
        //console.log("after filter block called ... filterFlag::",this.props.filterFlag);

       }

        return(
          <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
            <Grid container spacing={24} style={{marginBottom: '6px'}} >
                {filetermarkup}
                <input type="hidden" ref="tempFromDate" id="tempFromDate" name="tempFromDate" defaultValue={tempFromDateValue} className="form-control input-sm" />
            </Grid>
          </MuiThemeProvider>
        );
    }
}

export default withStyles(MuiStyles)(FiltersPopUp);