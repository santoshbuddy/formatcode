import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import axios from 'axios';
import FormData from 'form-data';
import { alertConstants } from '../../common/constants/alert.constants';
import ScrollDialogPopUp from "./ScrollDialogPopUp";
import { history } from '../../_helpers';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import Grid from '@material-ui/core/Grid';
import Formatter from '../../formats/Formatters';

var data,fileds,title;
let screenLinkImage;
let fromDate;
let buttonsdata = '';
let toDate;
let btn,scrolldialogpopup ;
var linksArr 		= [];
var linksDispArr	= [];
var declareStr		= '';
class ScrollDialog extends React.Component {
  constructor(props){
    super(props);
    this.state = {
    open: false,
    scroll: "paper"
  };
  this.handleClickOpen = this.handleClickOpen.bind(this);
  this.doAccountPos = this.doAccountPos.bind(this);
  this.requestCancel = this.requestCancel.bind(this);
  this.checkClick = this.checkClick.bind(this);
  this.doAccountCreate = this.doAccountCreate.bind(this);
  this.doTrade = this.doTrade.bind(this);
  this.doFundCardInfo = this.doFundCardInfo.bind(this);
}
doFundCardInfo(itm, e) {
//console.log('itm----itm---',itm);
if(itm.phurl != null && (itm.phurl == 'NA' || itm.phurl == 'na')) {
	alert ("Information Not Available");
} else {
	var bodyFormData = new FormData();
	//bodyFormData.append("prodId", itm.PRODID)
	bodyFormData.append("factCardUrl", itm.phurl)
	bodyFormData.append("currencyCode", itm.Currency);
	if((itm.processing == '1000' && itm.phid == '102') || (itm.processing == '1001' && itm.phid == '103'))
	{
		bodyFormData.append("prospFlag", 'SAVE');
		this.props.dispatch(AdministrationActions.fetchResearchMoneyData(bodyFormData));
	}

	this.externalWindow = window.open(itm.phurl, '', 'width=800,height=500,left=10,top=10');
 }
}
    doTrade() {
		history.push("/DEALENT");
	}

    doAccountCreate() {
		console.log('rowData--rowData--',this.props.rowData);
		let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
		//if(prospectusStatus == 'Y')
		//{
			console.log('this.props----',this.props);
			history.push({
				pathname: '/administration/MMFCREATEACCT',
				state: {
					tabIndex: 1,
					activeStep: 2,
					product: this.props.rowData.rowData[13],
					company: this.props.rowData.rowData[13],
					productname: this.props.rowData.rowData[0],
					currency: this.props.rowData.rowData[2],
					fundTypeId: this.props.rowData.rowData[14],
					actionFlag: "FUNDACCTINFO",
					fundFamilyId: this.props.rowData.rowData[15]
				}
			});
		//} else  {
		//	alert(message["READPROSPECTUS"]);
		//}
	}

componentDidUpdate(){
   scrolldialogpopup='';
}
//  componentWillMount(){
//   var jsonBody = new FormData();
//   var user = JSON.parse(sessionStorage.getItem('user'));
//   jsonBody.append("token",user[0].token);
//   jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
//   jsonBody.append("transId","201901073649455");

//   axios({
//     method: 'post',
//     url:alertConstants.URL+"/INVCONF.do",
//     data: jsonBody,
//     config: { headers: {'Content-Type': 'multipart/form-data' }}
//     }).then((response)=>{
//       data = response.data;
//     });
//  }
checkClick(cData, paramVal) {
  console.log("cDataaaa=>",cData)
  if(paramVal == 'TRADEENTRY' || paramVal == 'CLOSEACCOUNT') {
    history.push({
      pathname: '/DEALENT',
      state: {
        tabIndex: 1,
        activeStep: 1,
        paramVal: paramVal,
        fromPage:'ViewChanges',
        bformdata: cData
      }
    });
  } else if(paramVal == 'TRADEHISTORY') {
    history.push({
      pathname: '/report/TRDINQR',
      state: {
        fromPage:'ViewChanges',
        product: 'ALL',
        issueChild: 'ALL',
		productName: cData.subprodname==undefined?"":cData.subprodname,
		clientFirmName: cData.clientName==undefined?"":cData.clientName,
		currencyCode: cData.currency==undefined?"":cData.currency
      }
    });
  } else if(paramVal == 'EDITACCOUNT') {
    history.push({
      pathname: '/administration/MMFEDITACCT',
      state: {
        fromPage:'ViewChanges',
        mmmfAcct: cData.escrowacctnbr,
        clientFirm: cData.clientFirm,
        product: cData.subprodname,
        currency: cData.currency,
      }
    });
  }
}
   doAccountPos(acctNbr,issueChild,prodId){

	var url = '';
	   console.log('--acctNbr-->'+acctNbr);
	   console.log('--issueChild-->'+issueChild);
	   console.log('--prodId-->'+prodId);

	       var user = JSON.parse(sessionStorage.getItem('user'));


        var bodyFormData = new FormData();

            bodyFormData.append('acctNbr',acctNbr);
            bodyFormData.append('issueChild', issueChild);
            bodyFormData.append('prodId',prodId);
    		bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
	        bodyFormData.append("token",user[0].token);

            console.log('--bodyFormData-->'+bodyFormData);

            if(prodId === "1700"){
 				url=alertConstants.URL+"/MMMFACCNOPOS.do";

			}else{
 				url=alertConstants.URL+"/MMDAACCNOPOS.do";
 			}
var data1;
			axios({
			  method: 'post',
			  url:url,
			  data: bodyFormData,
			  config: { headers: {'Content-Type': 'multipart/form-data' }}
			}).then((response)=>{

        data1 = response.data;
        console.log("data--1111--->",data1)
        scrolldialogpopup =
                            <ScrollDialogPopUp
                              open={true}
                              data={data1}
                              func ={this.checkClick }
                               />
        this.setState({ open: false });
			  });

     //   this.props.dispatch(treasuryActions.fetchReportTableData(bodyFormData));

   }

  handleClickOpen (scroll,rowData) {
    var jsonBody = new FormData();
    var url;
    var user = JSON.parse(sessionStorage.getItem('user'));
    jsonBody.append("token",user[0].token);
    jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

    console.log('screenLinkImage:'+screenLinkImage);

    if(screenLinkImage==="AUDTRREP"){
		// alert("AUDTRREP");

			jsonBody.append("popUpFlag","POPUP");
			jsonBody.append("selAcctNbr",rowData.rowData[35]);
			jsonBody.append("fromDate",fromDate);
			jsonBody.append("toDate",toDate);
			url=alertConstants.URL+"/auditTrailPopUp.do";

  }  else if(screenLinkImage === "FUNDINFO"){
		//alert("MMDAACC::acctnbr:"+rowData.rowData[6]);
		jsonBody.append("prodId",rowData.rowData[15]);
		jsonBody.append("accountBuffer",rowData.rowData[17]);
		//jsonBody.append("fromDate",JSON.parse(sessionStorage.getItem('fromDate')));
    	//jsonBody.append("toDate",JSON.parse(sessionStorage.getItem('toDate')));
		url=alertConstants.URL+"/fundInfoPopUp.do";
	}else if(screenLinkImage==="FUDEAPRL"){

  		jsonBody.append("webreference",rowData.rowData[0]);
  		jsonBody.append("fromPage","futureTradeDisplay");
  		jsonBody.append("parentProduct",rowData.rowData[18]);
		url=alertConstants.URL+"/FUDEAPRL.do";

	}else if(screenLinkImage === "WATFRAPP"){
		jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
		jsonBody.append("transId",rowData.rowData[11]);
    jsonBody.append("parentProdId",rowData.rowData[12]);
    jsonBody.append("whereTo","TRADEDETAILS");
		//alert(rowData.rowData[0]);
		//alert(rowData.rowData[9]);
		// alert("MMDAACC::acctnbr:"+rowData.rowData[6]);

//		url=alertConstants.URL+"/WATFRAPP.do";
 		url=alertConstants.URL+"/INVCONF.do";
	}else if(screenLinkImage==="TRDINQR"){
    console.log("samepage--->",this.props.samepage)

    if(this.props.samepage === "true")
      jsonBody.append("transId",rowData["Trans ID"]);
    else{
		// this code is added to handle transid, after the units are added in trade history.
     		jsonBody.append("transId",rowData.rowData[10]);
	}
		url=alertConstants.URL+"/INVCONF.do";

	}else if(screenLinkImage==="HOME" || screenLinkImage==="WATAPPRL"){
  	//	console.log('rowData:: '+JSON.stringify(rowData));
	//	alert("HOME" +rowData.rowData[8]);
		if(screenLinkImage==="WATAPPRL")
  		jsonBody.append("transId",rowData.rowData[1]);
  		else jsonBody.append("transId",rowData.rowData[8]);
		url=alertConstants.URL+"/INVCONF.do";

	}else if(screenLinkImage==="LATESTFIVETRDS"){
  	//	console.log('rowData:: '+JSON.stringify(rowData));
   		jsonBody.append("transId",rowData.rowData[8]);
		url=alertConstants.URL+"/INVCONF.do";

	}else if(screenLinkImage==="FUDTDRAC"){
  	//	console.log('rowData:: '+JSON.stringify(rowData));
	 //	alert("FUDTDRAC" +rowData.rowData[2]);
  		jsonBody.append("webreference",rowData.rowData[2]);
		url=alertConstants.URL+"/FTradeDateStatusPopUp.do";

	}else if(screenLinkImage==="NOTIFICATIONS"){

	//	console.log('rowData:: '+JSON.stringify(rowData));
		if(rowData.rowData[0] === 'FTRADE'){
				 jsonBody.append("webreference",rowData.rowData[1]);
				 url=alertConstants.URL+"/FTradeDateStatusPopUp.do";

		}else if(rowData.rowData[1] === 'FTRADE'){
				 jsonBody.append("webreference",rowData.rowData[3]);
				 url=alertConstants.URL+"/FTradeDateStatusPopUp.do";

		} else if(rowData.rowData[0] === 'TRADE' || rowData.rowData[1] === 'TRADE'){
 		if(rowData.rowData[0] === 'TRADE')
		    jsonBody.append("transId",rowData.rowData[1]);
		    else
		     jsonBody.append("transId",rowData.rowData[2]);
			url=alertConstants.URL+"/INVCONF.do";
		 } else if(rowData.rowData[0] === 'MMFACCT'){
		       jsonBody.append("mmmfAcct",rowData.rowData[1]);
      			url=alertConstants.URL+"/MMMFACCTLOOKUP.do";
		 }else {

			jsonBody.append("transId",rowData.rowData[8]);
 			url=alertConstants.URL+"/INVCONF.do";
		}

	}else if(screenLinkImage==="FUTTRD" || screenLinkImage==="BMFUTTRD"){

	//	alert("FUTTRD");
  if(this.props.samepage === "true")
    jsonBody.append("webreference",rowData["Reference ID"]);
  else
 		jsonBody.append("webreference",rowData.rowData[1]);
		url=alertConstants.URL+"/FTradeDateStatusPopUp.do";

	}else if(screenLinkImage==="LOOKUP"){

    //	alert("FUTTRD");

       jsonBody.append("mmmfAcct",rowData.rowData[2]);
      url=alertConstants.URL+"/MMMFACCTLOOKUP.do";

    }
    else if(screenLinkImage==="FUNDINFO"){
//      console.log('rowData--rowData--rowData--',this.props.rowData);
      this.props.func(rowData.rowData, screenLinkImage);
    }
    else if(screenLinkImage==="CLFBHREP"){
		this.props.func(rowData.rowData, screenLinkImage);
	}


		//jsonBody.append("transId",rowData.rowData[9]);
		  axios({
			method: 'post',
			url:url,
			data: jsonBody,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
		  }).then((response)=>{
			data = response.data;
			this.setState({ open: true, scroll });
			});
    };

  handleClose = () => {
    this.setState({ open: false });
  };
  requestCancel(){
    if(confirm("Are you sure, you want to delete this trade?")){

      var jsonBody = new FormData();
    var url;
    var user = JSON.parse(sessionStorage.getItem('user'));
    jsonBody.append("token",user[0].token);
    jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

			jsonBody.append("webreference",fileds["Reference ID"]);
			jsonBody.append("actionFlag","CANCEL");
       url=alertConstants.URL+"/FTradeDateStatusPopUp.do";
       var data;
       axios({
        method: 'post',
        url:url,
        data: jsonBody,
        config: { headers: {'Content-Type': 'multipart/form-data' }}
      }).then((response)=>{
        data = response.data;
         this.handleClose();
         history.push({
          pathname: '/report/FUTTRD',
         })
        });
    }
  }
  render() {

	linksDispArr	= [];
	linksArr 		= [];
	declareStr		= '';

    let linkName;
    if (this.props.linkName !== undefined)
      linkName = this.props.linkName;

    if (this.props.screenLinkImage !== undefined){
      screenLinkImage = this.props.screenLinkImage;
    //  console.log("feb2019 screenLinkImage",screenLinkImage);
    }

    if (this.props.fromDate !== undefined){
      fromDate = this.props.fromDate;
    //  console.log("feb2019 fromDate",fromDate);
    }

    if (this.props.toDate !== undefined){
      toDate = this.props.toDate;
    //  console.log("feb2019 toDate",toDate);
    }

  let tbody="";
  let elements1;
//  console.log("data" , data)
  if(data !== undefined && data!=="") {
    fileds = data.commonData;
    if(data.Title && data.Title !== undefined)
    title = data.Title.name;
	buttonsdata	= '';
	if(screenLinkImage === 'FUNDINFO') {
    		if(fileds['EOD Cut-Off Time'] !== 'Suspended')
    		{
			buttonsdata	= <span><button className="btn btn-primary btn-xs mt" id="createaccount" onClick={this.doAccountCreate.bind(this)}>Create Account</button>
    	        			<button className="btn btn-primary btn-xs mt" id="tradefund" onClick={this.doTrade.bind(this)}>Trade in this Fund</button></span>
		}else{
			buttonsdata	= <span><button disabled className="btn btn-primary btn-xs mt" id="createaccount" >Create Account</button>
    	        			<button disabled className="btn btn-primary btn-xs mt" id="tradefund" >Trade in this Fund</button></span>
		}
	}
// console.log('--fileds-->',fileds);

//	for(var i in fileds){
//		console.log('--fileds-i->',i);
//	}
// console.log("ACTIONS",data.ACTIONS)
btn='';
if(data.ACTIONS !== undefined)
if(screenLinkImage === "FUTTRD" && data.ACTIONS.length>0){
  btn = <button className="btn btn-xs btn-primary" onClick={this.requestCancel} >{data.ACTIONS[0].label}</button>
}
elements1 =Object.keys(fileds).map((key) => {
	console.log("keyyy::",key)
	console.log("value::",fileds[key])
	if(key === "Transaction Amount"){
		return (
			<tr>
				<td className="w25"> {key} </td>
						<td className="TxtNrml"> 
						{
							fileds[key] === "Pending" ?
								fileds[key] 
							:
								<Formatter currency={fileds[key]}/>
						}
						</td>
			</tr>
			)
	}else if(key === "Booking Date"){
		return (
			<tr>
				<td className="w25"> {key} </td>
				<td className="TxtNrml"> 
					{
						fileds[key] === "Pending" ?
							fileds[key]
						:
							<Formatter datetime={fileds[key]}/>
					} 
				</td>
			</tr>
			)
	}	 
	else if(key === "Approved/Rejected Date/Time"){
		return (
			<tr>
				<td className="w25"> {key} </td>
				<td className="TxtNrml"> 
					{
						fileds[key] === "N/A" ?
							fileds[key]
						:
							<Formatter datetime={fileds[key]}/>
					} 
				</td>
			</tr>
			)
	}	 
	else {	return (
			("acctNbr"!== key && "issueChild"!== key && "prodId"!== key && "viewAcctPosFlag"!== key )?
			<tr>
				<td className="w25">{key}</td><td className="TxtNrml"> {fileds[key]}
				{/* {
					("Money Fund Account"===key && "Y"  === fileds['viewAcctPosFlag'] ) ?
						<a title="View account position" onClick={(e)=>{this.doAccountPos(fileds['acctNbr'],fileds['issueChild'],fileds['prodId']);}} className="btn btn-primary btn-xs">View account position</a>
						:
						""
				} */}
			</td></tr>
			:
			""
		)
	}
}
)
		if(screenLinkImage === 'FUNDINFO'){
			if(data!=undefined && data.pdfData !== undefined) {
			    if(data.pdfData.fyieldList!==undefined && data.pdfData.fyieldList.length>0)
			    {
				linksArr			= data.pdfData.fyieldList;
			     }
				//console.log(linksArr)
				if(linksArr != null && linksArr.length > 0) {
					linksArr.map((items, index) => {
						//console.log(items.phdescr,items.phurl)
						linksDispArr.push(<Grid style={{textAlign:'left',padding:'5px 0px 5px 15px'}} xs={4}><img src={require('../../images/icon_pdf.png')} width="18" height="18" /><a phurl={items.phurl} phid={items.phid} href="javascript:void(0);" onClick={e => this.doFundCardInfo(items, event)}>{items.phdescr}</a></Grid>);
					});
				}
			}
		}
  }
    return (
      <div>
        <a onClick={this.handleClickOpen.bind(this,"paper",this.props.rowData)}>
          {linkName}
        </a>
        <Dialog
          open={this.state.open}
          onClose={this.handleClose}
          scroll={this.state.scroll}
          aria-labelledby="scroll-dialog-title"
          fullWidth={true}
          maxWidth = {'md'}
        >
          <DialogTitle id="scroll-dialog-title"> {title}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              <table className="table table-striped table-bordered scrollbodyStyle" width="100%">
			      <tbody>
			      	{elements1}
						</tbody>
						</table>
            {btn}
            </DialogContentText>
						{screenLinkImage === 'FUNDINFO' &&
							<Grid container spacing={24}>
								{linksDispArr}
							</Grid>
						}
          </DialogContent>
          <DialogActions>
          	{buttonsdata}
            <button onClick={this.handleClose} className="btn btn-primary btn-xs">
              Close
            </button>

          </DialogActions>
        </Dialog>
       {scrolldialogpopup}
      </div>
    );
  }
}

export default ScrollDialog;
