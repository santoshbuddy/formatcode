import React from "react";
import Table from "@material-ui/core/Table";
import TableRow from "@material-ui/core/TableRow";
import TableCell from "@material-ui/core/TableCell";


class DrillDown extends React.Component {
  state = {

  };



  render() {
    console.log(this.props.rowData);

    return (
      <div>
      <Table>
       <TableRow>
		<TableCell>
			  Data: {JSON.stringify(this.props.rowData)}
		</TableCell>
		<TableCell>
			  Data: {JSON.stringify(this.props.rowData)}
		</TableCell>
		<TableCell>
			  Data: {JSON.stringify(this.props.rowData)}
		</TableCell>
	   </TableRow>
	</Table>
      </div>
    );
  }
}

export default DrillDown;
