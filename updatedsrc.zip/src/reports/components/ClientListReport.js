import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { reportActions } from '../actions/report.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import '../../user/css/App.css';
import 'react-tabs/style/react-tabs.css';
import Loading from '../../common/Loading'
import MUIDataTable from "mui-datatables";
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiThemeProvider } from "@material-ui/core/styles";

let pageName='';
let filterFlag=true;
class ClientListReport extends React.Component {
    constructor(){
        super();
        this.state={
            reportdata:[],
            changeFlag:false,
            reportdata1:[]
        }
        this.doChange = this.doChange.bind(this);
      }
    componentDidMount() {
         console.log("Report Template componentDidMount")
        pageName=this.props.location.pathname;
         this.getFilter()
    }
    componentDidUpdate(){
       console.log("page name",pageName)
      console.log("this.props.location.pathname",this.props.location.pathname)
      if(pageName.length!==0 && pageName!==this.props.location.pathname)
       {
	    filterFlag=true;
        pageName=this.props.location.pathname;
        console.log("Report Template componentDidUpdate",pageName)
          this.getFilter()
       }
       else
       pageName=this.props.location.pathname;
    }
    getFilter(){
         var bodyFormData = new FormData();
         bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));

         this.props.dispatch(reportActions.fetchClientReportData(bodyFormData));
    }
    doChange(bodyFormData){
        this.state.changeFlag=true;
         bodyFormData.append("clientFirm",sessionStorage.getItem('clientFirm'));
         filterFlag=false;

        this.props.dispatch(reportActions.fetchClientReportData(bodyFormData));
   }
    render() {
        let clientlistreport,subBlk;
        var results1=[],screenName;
        this.state.reportdata = this.props.reportdata.reportdata;
        if(this.state.changeFlag === false)
            this.state.reportdata1 = this.props.reportdata;

        // console.log("this.state.reportdata",this.state.clientreportdata)
        if(this.state.reportdata!==undefined)
            results1  = Array.from(this.state.reportdata);

            console.log("results1.toString().trim().length",results1.toString().trim().length)
            if(results1 !== undefined && results1.toString().trim().length!==0 ){
                screenName = results1.find(item => item.type==="Title").name;
                 subBlk = <Filters method={this.doChange} data={this.state.reportdata1} filterFlag={filterFlag}/>
        let item = results1.find(item => item.name==="data")
        const options = {
            filterType: "dropdown",
            selectableRows: false,
            pagination:false
        };
        if(item.name === "data"){
			if(item.data != undefined)
			{
				clientlistreport = item.data.map((val,ind) => {
					return(
						<div>
							<div><span className="pull-left">{val.FIRSTROW}</span><span className="pull-right">{val.LASTROW}</span></div>
							<MuiThemeProvider key={ind} theme={muiTableStyles.getMuiThemeNoToolBar()}>
								<MUIDataTable
									data={val.SUBDATA}
									columns={val.SUBCOLUMNS}
									options={options}
								/>
							</MuiThemeProvider>
						</div>
						)
					})
				}
            }
        }



        return (
            <div>
                <NavBar/>
			    <div className="clearfix"></div>
                <div className="col-md-12 col-sm-12">
                    <div className="clearfix"></div>
                        <div>
                            <h4>{screenName}</h4>
                        </div>
			            <div className="clearfix"></div>
                        <div className="filter_div" id="filter_div" >
                            {subBlk}
                        </div>
			            <div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12">
                        {
                            results1 !== undefined ?
                                clientlistreport
                            :
                                <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
                        }
                        </div>
                    </div>
                </div>
            );
        }
}

function mapStateToProps(state) {
    const { reportdata } = state;
    return { reportdata };
}

const connectedClientListReport = connect(mapStateToProps)(ClientListReport);
export { connectedClientListReport as ClientListReport };