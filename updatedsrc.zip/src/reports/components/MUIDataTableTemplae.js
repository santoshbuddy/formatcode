import React from 'react';
import '../../user/css/App.css'; 
import '../../user/css/index.css';
import '../../user/css/custom.css';
import '../../user/css/layout.css';  
import { connect } from 'react-redux';
import { NavBar } from '../../navbar/components/navbar';
import 'react-tabs/style/react-tabs.css';
import Loading from '../../common/Loading';
import MUIDataTable from "mui-datatables";
import Card from "./Card";
import ScrollDialog from "./ScrollDialog";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";  

class MUIDataTableTemplate extends React.Component {
    getMuiTheme = () =>
    createMuiTheme({
      overrides: {
        MUIDataTableHeadCell: {
          root: {
            background: '#eaeaea !important',
            color: '#0066b2 !important',
            textTransform: 'uppercase',
            whiteSpace: 'nowrap',
            fontWeight:'bold',
            borderRight: '1px solid #b3b3b3',
            borderTop: '1px solid #b3b3b3',
            borderBottom: '1px solid #b3b3b3',
            '&:first-child':{
              borderLeft: '1px solid #b3b3b3'
            },
            '&:last-child':{
              paddingRight: '4px'
            }
          }
        },
        MUIDataTableBodyRow: {
          root: {
            '&:nth-child(odd)': { 
              backgroundColor: '#f7f8f9'
            }
          }
         },  
         MuiTableCell: {
           root: {
            whiteSpace: 'nowrap',
            padding: '7px 5px',
            borderRight: '1px solid #f3ebeb',
            // borderTop: '1px solid #c3c3c3',
            borderBottom: '1px solid #f3ebeb',
            '&:last-child':{
              borderRight:'0px'
            },
            '&:first-child':{
              borderLeft: '1px solid #f3ebeb'
            }
           }
         },
         MuiTableRow: {
           root:{
             height:'auto'
           },
           head: {
             height:'auto',
           }
         }
        }
      });


    constructor() {
        super()
        this.state = { loading:true,tabIndex: 0, enterdata: '',fixed:'' };
    }

    componentDidMount() {
      // if(this.props.mmmfdata === undefined || this.props.mmmfdata === "")
        // this.props.dispatch(userActions.getMMMFData()); 
    }
   
    render() { 
        const { user, users,mmmfdata } = this.props;
        var data,columns;
        if(mmmfdata.mmmfdata !== undefined){
         columns = mmmfdata.mmmfdata.COLUMNS;
         data = mmmfdata.mmmfdata.DATA;

        console.log(data)
        console.log(columns)
    }
        const columns1 = [
            {
              name: "Fund Name",
              options: {
                filter: true,
                sort: true, 
                customBodyRender: (value, tableMeta, updateValue) => {
                  return (
                    <ScrollDialog
                      href="#"
                      onClick={e => this.openPopUp(e, tableMeta)}
                      rowData={tableMeta}
                    />
                  );
                }
              }
            },
            "Nav Type",
            "CCY",
            "Factor",
            "Nav",
            "Daily Yield(%)",
            "Rating S&P",
            "Rating Moody's",
            "Rating Fitch",
            "Rating NAIC",
            "EOD Cut-Off Time",
            "AUM(MM)",
            {
              name: <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>,
              options: { 
                filter: false,
                sort: false,
      
                customBodyRender: (value, tableMeta, updateValue) => {
                  return (
                    <Card
                      href="#"
                      onClick={e => this.openPopUp(e, tableMeta)}
                      displayText={value} 
                    />
                  );
                }
              }
            }
          ];
      const data1 = [
        ["INSTL CASH SERIES EURO GOV LIQ EUR HERITAGE D", "CNAV", "USD", "0.34", "1.00", "0.28", "AAM", "AAAA", "AA", "PROV", "11:55 PM (GMT-5:0)", "5,348",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
        ["INSTITUTIONAL CASH SERIES STERLING LIQUIDITY SELECT DIST", "CNAV", "USD", "0.34", "1.00","0.28", "AAM", "AAAA", "AAA", "PROV", "11:55 PM (GMT-5:0)", "5,348",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
        ["BLACKROCK AM IE ICS STERLING GOVT LIQDTY SEL", "CNAV", "EUR", "0.29","1.00", "0.35", "AAM", "AAAA", "AA", "PROV", "11:55 PM (GMT+0:0)", "5,542",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
        ["FIDELITY INSTITUTIONAL CASH FUND PLC SHS CL D SERIES 1 EURO", "CNAV", "EUR", "0.16","1.00", "0.91", "AAA", "AAA", "AA", "AAA", "11:55 PM (GMT+0:0)", "5,194",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
        ["FIDELITY INSTITUTIONAL CASH FUND PLC SHS CL D SERIES 1 STERLING", "CNAV", "EUR", "0.29","1.00", "0.26", "AAA", "AAA", "AAA", "PROV", "11:55 PM (GMT+0:0)", "5,258",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
        ["GOLDMAN SACHS FUNDS EURO GOVERN LIQ RES FD INST SH", "CNAV", "EUR", "0.157","1.00", "0.35", "AAM", "AAA", "AAA", "PROV", "11:55 PM (GMT+0:0)", "5,384",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
        ["GOLDMAN SACHS AM EURO LIQUID RESERVES INSLT CL", "CNAV", "EUR", "0.182","1.00", "0.23", "AAM", "AAA", "AAA", "PROV", "11:55 PM (GMT+0:0)", "5,595",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
        ["MORGAN STANLEY LIQUIDITY FDS SICAV EURO LIQUIDITY INTL", "CNAV", "GBP", "0.223","1.00", "0.287", "AAA", "AA", "AA", "AAA", "11:55 PM (GMT+0:0)", "5,255",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
        ["BNY MELLON STERLING LIQUIDITY FUND ADVANTAGE SHS", "CNAV", "GBP", "0.35","1.00", "0.28", "AAA", "AAA", "AA", "PROV", "11:55 PM (GMT+0:0)", "5,286",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
        ["WESTERN ASSET LIQUIDITY FDS EURO LIQUIDITY FUND", "CNAV", "USD", "0.24","1.00", "0.31", "AAA", "AAA", "AA", "AAA", "11:55 PM (GMT+0:0)", "5,397",<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"><path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.3-.61-.22l-2.49 1c-.52-.4-1.08-.73-1.69-.98l-.38-2.65C14.46 2.18 14.25 2 14 2h-4c-.25 0-.46.18-.49.42l-.38 2.65c-.61.25-1.17.59-1.69.98l-2.49-1c-.23-.09-.49 0-.61.22l-2 3.46c-.13.22-.07.49.12.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.3.61.22l2.49-1c.52.4 1.08.73 1.69.98l.38 2.65c.03.24.24.42.49.42h4c.25 0 .46-.18.49-.42l.38-2.65c.61-.25 1.17-.59 1.69-.98l2.49 1c.23.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/></svg>],
      ];
          const options = {
            filterType: "dropdown",
            selectableRows: false,
            responsive: "scroll",
            fixedHeader: false,
          };
        return (
            <div>
                <NavBar/>
                <div className="clearfix"></div>
                <div className="col-md-12 col-sm-12">
                    <div className="clearfix"></div>                
                    <div className="col-md-12 col-sm-12">
                    {
                      data1 !== undefined ?
                    <MuiThemeProvider theme={this.getMuiTheme()}>
                        <MUIDataTable
                        title={"MUI Data Table Template"}
                        data={data1}
                        columns={columns1}
                        options={options}
                        />
                    </MuiThemeProvider>
                    :
                    <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
                  }

                    </div>
                </div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    const { users,mmmfdata } = state;
     return {
        users, 
        mmmfdata
    };
}
 
const connectedMUIDataTableTemplate = connect(mapStateToProps)(MUIDataTableTemplate);
export { connectedMUIDataTableTemplate as MUIDataTableTemplate };