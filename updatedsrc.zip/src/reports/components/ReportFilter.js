import React from 'react';
import DatePicker from 'react-datepicker';
import { withStyles } from '@material-ui/core/styles';
import 'react-datepicker/dist/react-datepicker.css';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { MuiThemeProvider } from '@material-ui/core/styles';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
let dateChange=false;
let listChange=false;
const styles = theme => ({
  margin: {
    margin: theme.spacing.unit,
  },
});
var dateFormat = require('dateformat');
let filterNameValueArray=[];

class ReportFilter extends React.Component {
	constructor () {
		super()
		this.state = {
			startDate: new Date(),
			endDate: new Date(),
			onChngeFlag: false,
		};
	}

	componentWillMount(){

	}

	doChange(e){
		var bodyFormData = new FormData();
		if(filterNameValueArray!== undefined && filterNameValueArray.length>0)
		{
			filterNameValueArray.map((item, index) => {
				bodyFormData.append(item.id, item.value)
			});
		}

		this.props.method(bodyFormData);
	}

	handleChange(e)
	{
		var listName	= e.target.name;
		var listValue	= e.target.value;
		listChange		= true;

		if(filterNameValueArray!== undefined && filterNameValueArray.length>0){
			let obj=filterNameValueArray.find(namevalue => namevalue.id === listName);
			if(obj!== undefined){
				obj.value=listValue;
			}
		}

		console.log("after onchange filterNameValueArray::",filterNameValueArray);
		this.setState({ onChngeFlag: true });
	}

    render(){
		const { classes, data } = this.props;
		let filetermarkup;

        if(data !== undefined)
        {
        	filetermarkup = data.map((filter,index) => {
                if(filter.type === "Select")
                {
    				if(filter.type == 'Select' && filter.values !== undefined && listChange === false)
						filterNameValueArray.push({id:filter.name,value:filter.values[0].id})

					var listValue="";
					if(listChange === true)
					{
						if(filterNameValueArray!== undefined && filterNameValueArray.length>0)
						{
							let obj=filterNameValueArray.find(namevalue => namevalue.id === filter.name);
    						if(obj!== undefined) {
    			  				listValue=obj.value;
    		        		}
    					}
                 	}
                 	else
                 	{
                   		listValue	=	filterNameValueArray.find(namevalue => namevalue.id === filter.name)!== undefined && filterNameValueArray.find(namevalue => namevalue.id === filter.name).value
                  	}

					var selectList	= "";
					selectList		= <NativeSelect className={classes.select}
										ref={ filter.name }  name={filter.name}  onChange={(e)=>{this.handleChange(e)}} value={listValue}>
										{filter.values !== undefined && filter.values.map((obj,index) => {
										return <option key={index} value={obj.id}>{obj.name}</option>
										})}
    								</NativeSelect>

                 	return(
						<Grid item  key={filter.id.toString()}>
							<InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder">{ filter.label } :</InputLabel>
							{selectList}
						</Grid>
                   );
                }
                else if(filter.type === "Button")
                {
					return (
						<span>
							<button size="small" style={{height: 30, margin: 12}} className="btn btn-primary btn-xs" title="Go" onClick={(e)=>{this.doChange();}} key={filter.id.toString()}>
								{ filter.name }
							</button>
							{
								((this.props.PageName == "/reportC/COMPART") || (this.props.PageName == "/reportC/INDICAT")) &&
									<span className="displayTxt">Please Click on Go button</span>
							}
						</span>
					);
				}
				else if(filter.type === "label")
				{
					return (
						<Grid item  key={filter.id.toString()}>
							<InputLabel className={classes.labelStyle} htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
							<InputLabel className="TextNrml"> { filter.value }</InputLabel>
						</Grid>
					);
				}
				else if(filter.type === "newline")
				{
					return  							<button size="small" style={{height: 30, margin: 12}} className="btn btn-primary btn-xs" title="Go" onClick={(e)=>{this.doChange();}} key={filter.id.toString()}>
								Go
							</button>

				}
            });

            dateChange=true;
		}

		return(
			<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
				<Grid container spacing={24} style={{marginBottom:'10px'}}>
					{filetermarkup}
					<button size="small" style={{height: 30, margin: 12}} className="btn btn-primary btn-xs" title="Go" onClick={(e)=>{this.doChange();}}>
													Go
								</button>
				</Grid>
			</MuiThemeProvider>
		);
	}
}

export default withStyles(MuiStyles)(ReportFilter);