import { messageUS } from '../../common/javascript/i18N/en_US/alerts'
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts'

export const compareDates =  function (date1,dateformat1,date2,dateformat2)
{
	var d1 = getDateFromFormat(date1,dateformat1);
	var d2 = getDateFromFormat(date2,dateformat2);
	if (d1==0 || d2==0)
	{
		return -1;
	}
	else
	if (d1 > d2)
	{
		return 1;
	}
	return 0;
}

export const getDateFromFormat =  function (val,format)
{
        var MONTH_NAMES = new Array('January','February','March','April','May','June','July','August','September','October','November','December','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
	val = val+"";
	format = format+"";
	var i_val = 0;
	var i_format = 0;
	var c = "";
	var token = "";
	var token2= "";
	var x,y;
	var now   = new Date();
	var year  = now.getYear();
	var month = now.getMonth()+1;
	var date  = now.getDate();
	var hh    = now.getHours();
	var mm    = now.getMinutes();
	var ss    = now.getSeconds();
	var ampm  = "";
	var x;
	while (i_format < format.length) {
		// Get next token from format string
		c = format.charAt(i_format);
		token = "";
		while ((format.charAt(i_format) == c) && (i_format < format.length)) {
			token += format.charAt(i_format);
			i_format++;
			}
		// Extract contents of value based on format token
		if (token=="yyyy" || token=="yy" || token=="y") {
			if (token=="yyyy") { x=4;y=4; }// 4-digit year
			if (token=="yy")   { x=2;y=2; }// 2-digit year
			if (token=="y")    { x=2;y=4; }// 2-or-4-digit year
			year = _getInt(val,i_val,x,y);
			if (year == null) { return 0; }
			i_val += year.length;
			if (year.length == 2) {
				if (year > 70) {
					year = 1900+(year-0);
					}
				else {
					year = 2000+(year-0);
					}
				}
			}
		else if (token=="MMM"){// Month name
			month = 0;
			for (var i=0; i<MONTH_NAMES.length; i++) {
				var month_name = MONTH_NAMES[i];
				if (val.substring(i_val,i_val+month_name.length).toLowerCase() == month_name.toLowerCase()) {
					month = i+1;
					if (month>12) { month -= 12; }
					i_val += month_name.length;
					break;
					}
				}
			if (month == 0) { return 0; }
			if ((month < 1) || (month>12)) { return 0; }
			// TODO: Process Month Name
			}
		else if (token=="MM" || token=="M") {
			x=token.length; y=2;
			month = _getInt(val,i_val,x,y);
			if (month == null) { return 0; }
			if ((month < 1) || (month > 12)) { return 0; }
			i_val += month.length;
			}
		else if (token=="dd" || token=="d") {
			x=token.length; y=2;
			date = _getInt(val,i_val,x,y);
			if (date == null) { return 0; }
			if ((date < 1) || (date>31)) { return 0; }
			i_val += date.length;
			}
		else if (token=="hh" || token=="h") {
			x=token.length; y=2;
			hh = _getInt(val,i_val,x,y);
			if (hh == null) { return 0; }
			if ((hh < 1) || (hh > 12)) { return 0; }
			i_val += hh.length;
			hh--;
			}
		else if (token=="HH" || token=="H") {
			x=token.length; y=2;
			hh = _getInt(val,i_val,x,y);
			if (hh == null) { return 0; }
			if ((hh < 0) || (hh > 23)) { return 0; }
			i_val += hh.length;
			}
		else if (token=="KK" || token=="K") {
			x=token.length; y=2;
			hh = _getInt(val,i_val,x,y);
			if (hh == null) { return 0; }
			if ((hh < 0) || (hh > 11)) { return 0; }
			i_val += hh.length;
			}
		else if (token=="kk" || token=="k") {
			x=token.length; y=2;
			hh = _getInt(val,i_val,x,y);
			if (hh == null) { return 0; }
			if ((hh < 1) || (hh > 24)) { return 0; }
			i_val += hh.length;
			h--;
			}
		else if (token=="mm" || token=="m") {
			x=token.length; y=2;
			mm = _getInt(val,i_val,x,y);
			if (mm == null) { return 0; }
			if ((mm < 0) || (mm > 59)) { return 0; }
			i_val += mm.length;
			}
		else if (token=="ss" || token=="s") {
			x=token.length; y=2;
			ss = _getInt(val,i_val,x,y);
			if (ss == null) { return 0; }
			if ((ss < 0) || (ss > 59)) { return 0; }
			i_val += ss.length;
			}
		else if (token=="a") {
			if (val.substring(i_val,i_val+2).toLowerCase() == "am") {
				ampm = "AM";
				}
			else if (val.substring(i_val,i_val+2).toLowerCase() == "pm") {
				ampm = "PM";
				}
			else {
				return 0;
				}
			}
		else {
			if (val.substring(i_val,i_val+token.length) != token) {
				return 0;
				}
			else {
				i_val += token.length;
				}
			}
		}
	// If there are any trailing characters left in the value, it doesn't match
	if (i_val != val.length) {
		return 0;
		}
	// Is date valid for month?
	if (month == 2) {
		// Check for leap year
		if ( ( (year%4 == 0)&&(year%100 != 0) ) || (year%400 == 0) ) { // leap year
			if (date > 29){ return false; }
			}
		else {
			if (date > 28) { return false; }
			}
		}
	if ((month==4)||(month==6)||(month==9)||(month==11)) {
		if (date > 30) { return false; }
		}
	// Correct hours value
	if (hh<12 && ampm=="PM") {
		hh+=12;
		}
	else if (hh>11 && ampm=="AM") {
		hh-=12;
		}
	var newdate = new Date(year,month-1,date,hh,mm,ss);
	return newdate.getTime();
}

export const _getInt =  function (str,i,minlength,maxlength)
{
	for (var x=maxlength; x>=minlength; x--) {
		var token = str.substring(i,i+x);
		if (token.length < minlength) {
			return null;
			}
		if (_isInteger(token)) {
			return token;
			}
		}
	return null;
	}

export const _isInteger =  function (val)
{
	var digits = "1234567890";
	for (var i=0; i < val.length; i++) {
		if (digits.indexOf(val.charAt(i)) == -1) { return false; }
		}
	return true;
	}

export const doDateVerify =  function (filterNameValueArray)
{
  let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
  var fromDate = filterNameValueArray.find(e=>e.id === 'fromDate');
  var toDate = filterNameValueArray.find(e=>e.id === 'toDate');
  var todaysDate = filterNameValueArray.find(e=>e.id === 'todaysDate');
  var format = filterNameValueArray.find(e=>e.id === 'format').value;
  //var format = filterNameValueArray.find(e=>e.id === 'format');


	if(toDate!= null && fromDate.value) {

		if((compareDates(fromDate.value,format,
			todaysDate.value,format)) == 1)
		{
			alert(message["FRMDTGTODAYS"]);
			 return false;
		}

		// this is commented for to date field to remove restrict
		/*if((compareDates(toDate.value,format,
			todaysDate.value,format)) == 1)
		 {
			alert(message["TOMDTGTODAYS"]);
			return false;
		}*/

	   	if(fromDate.value==""){
			alert(message["PLSENTDT"]);
			return false;
		}

		if(toDate.value==""){
			alert(message["PLSENTDT"]);
			return false;
		}
		if((compareDates(fromDate.value,format,
			toDate.value,format)) == 1)
		{
			alert(message["FRMDTGTD"]);
			return false;
		}
		else
		if((fromDate.value!="") || (toDate.value!=""))
		{
		if((compareDates(fromDate.value,format,
			toDate.value,format)) == -1)
		{
			alert(message["ENTVLDDT"]);
			return false;
		  }
		}
	}
	return true;
    }