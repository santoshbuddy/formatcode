import React from "react";
import PropTypes from "prop-types";
import * as Styled from "./style";
import { withStyles } from '@material-ui/core/styles';
import calendar from '../../../images/calendar.png';

const Calendar = {
  calendarIcon: {
    position: 'absolute',
    right: 0,
    top: 1,
    zIndex: 1,
    borderLeft: '1px solid #ccc',
    padding: '9px',
    '&:hover':{
      background: '#4097BC'
    },
    '&:active': {
      background: '#00395D'
    }
  }
}

class CustomDatePickerInput extends React.Component {
  static propTypes = {
    onClick: PropTypes.func,
    value: PropTypes.string
  }
  render() {
    const {value, onClick} = this.props;
    const {classes} = this.props;

    return (
      <div className="form-group">
        <Styled.CalendarInput type="text" value={value} onClick={onClick} style={{width: '100%'}} />
        <img src={calendar} onClick={onClick} className={classes.calendarIcon}/> 
        {/* <Styled.CalendarInputSpan onClick={onClick}></Styled.CalendarInputSpan> */}
      </div>
    );
  }
}

export default withStyles(Calendar)(CustomDatePickerInput);
