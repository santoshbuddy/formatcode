import { poolConstants } from '../constants/pool.constants';
import { poolService } from '../services/pool.service';

export const poolActions = {
    fetchPoolData,
    fetchPoolTableData,
    submitPoolData
};

function fetchPoolData() {
    return dispatch => {
        dispatch(request());

        poolService.fetchPool()
            .then(
                pooldata => dispatch(success(pooldata)),
                 error => dispatch(failure(error))
            );
    };

    function request() { return { type: poolConstants.GETPOOLDATA_REQUEST } }
    function success(pooldata) { return { type: poolConstants.GETPOOLDATA_SUCCESS, pooldata } }
    function failure(error) { return { type: poolConstants.GETPOOLDATA_FAILURE, error } }
}

function fetchPoolTableData(bodyFormData){
     return dispatch => {
        dispatch(request());
         poolService.fetchPoolTable(bodyFormData)
            .then(
                pooldatatable => dispatch(success(pooldatatable)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: poolConstants.GETPOOLTBLDATA_REQUEST } }
    function success(pooldatatable) { return { type: poolConstants.GETPOOLTBLDATA_SUCCESS, pooldatatable } }
    function failure(error) { return { type: poolConstants.GETPOOLTBLDATA_FAILURE, error } }

}
 function submitPoolData(bodyFormData){
	    console.log("submitPoolData")
	    return dispatch => {
	        dispatch(request());
			console.log('submitPoolData :'+JSON.stringify(bodyFormData));
	        poolService.submitPoolData(bodyFormData)
	            .then(
	                pooldatatable => dispatch(success(pooldatatable)),
	                error => dispatch(failure(error))
	            );
    };

    function request() { return { type: poolConstants.GETPOOLTBLDATA_REQUEST } }
    function success(pooldatatable) { return { type: poolConstants.GETPOOLTBLDATA_SUCCESS, pooldatatable } }
    function failure(error) { return { type: poolConstants.GETPOOLTBLDATA_FAILURE, error } }

}