import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import { Tabs, TabList, Tab, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import '../../user/css/App.css';
import { connect } from 'react-redux';
import SelectProduct from './SelectProduct';
import EnterTrade from './EnterTrade';
import ConfirmTrade from './ConfirmTrade';
import { poolActions } from '../actions/pool.actions';
import FormData from 'form-data';

class TradeEntry extends React.Component {
    constructor() {
        super();
        this.state = { tabIndex: 0, enterdata: '' };
        this.poolSubmit = this.poolSubmit.bind(this);
        this.reviewSubmit = this.reviewSubmit.bind(this);
        this.confirmSubmit = this.confirmSubmit.bind(this);
      }
      componentDidMount(){
        this.props.dispatch(poolActions.fetchTradeData());
      }
      poolSubmit(obj){
        this.state.enterdata = obj;
        this.setState({ tabIndex:1 })

        var arr = [];
        for(var k in obj){
            arr.push({
                "rowNumber" : k
            });
        }
        var results2;

        this.props.pooldata.pooldata.map((item,index) => {
            if(item.name === "data")
                results2 = item.values;
        })
       var bodyFormdata = new FormData();
        results2.map((item,index) => {
             for(var i=0 ;i <arr.length;i++){
                if(arr[i].rowNumber === item.rowNumber){
                    for(var k in item){
                        if(k === "fromPage" || k === "mmmfDealListSize")
                            bodyFormdata.append(k,item[k])
                        else
                            bodyFormdata.append(k+item.rowNumber,item[k])
                     }
                }
             }
        });

        this.props.dispatch(poolActions.fetchTradeReviewData(bodyFormdata));
      }

      reviewSubmit(){
        this.setState({ tabIndex:2 })
      }
      confirmSubmit(obj){
        var arr = [];
        for(var k in obj){
            arr.push({
                "rowNumber" : k
            });
        }
        var results2;

        this.props.pooldata.pooldata.map((item,index) => {
            if(item.name === "data")
                results2 = item.values;
        })
        var bodyFormdata = new FormData();
        results2.map((item,index) => {
             for(var i=0 ;i <arr.length;i++){
                if(arr[i].rowNumber === item.rowNumber){
                    for(var k in item){
                        if(k === "fromPage" || k === "mmmfDealListSize")
                            bodyFormdata.append(k,item[k])
                        else
                            bodyFormdata.append(k+item.rowNumber,item[k])
                     }
                }
             }
        });
        this.props.dispatch(poolActions.fetchTradeConfirmData(bodyFormdata));
      }

    render(){
        const{ pooldata } = this.props.pooldata;
        const{ poolreviewdata } = this.props.poolreviewdata;
        const{ poolconfirmdata } = this.props.poolconfirmdata;

        let results,results1,columns;
        if(pooldata !== undefined)
        pooldata.map((item,index) => {
            if(item.name === "data")
                results = item.values
            if(item.name === "Columns")
                columns = item.values
        })

        if(poolreviewdata !== undefined)
        poolreviewdata.map((item,index) => {
            if(item.name === "data")
                results1 = item.values

        })

        return(
            <div>
                <NavBar /> 
                <div className="clearfix"></div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Trade Entry</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12">
                        <Tabs selectedIndex={this.state.tabIndex} onSelect={tabIndex => this.setState({ tabIndex })}>
                            <TabList>
                            <Tab>1. Select Product</Tab>
                            <Tab>2. Enter Trade </Tab>
                            <Tab>3. Confirm Trade  </Tab>
                            </TabList>
                            <TabPanel>
                                <SelectProduct method1={this.poolSubmit.bind(this)} data={results} columns={columns}/>
                            </TabPanel>
                            <TabPanel>
                                <EnterTrade method={this.reviewSubmit.bind(this)} selectedRows={this.state.enterdata} data={results1}/>
                            </TabPanel>
                            <TabPanel>
                                <EnterTrade flag="confirm" method2={this.confirmSubmit.bind(this)} selectedRows={this.state.enterdata} data={results1}/>
                            </TabPanel>
                        </Tabs>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
function mapStateToProps(state) {
    const { pooldata,poolreviewdata,poolconfirmdata } = state;
    return { pooldata,poolreviewdata,poolconfirmdata };
}

const connectedTradeEntry = connect(mapStateToProps)(TradeEntry);
export { connectedTradeEntry as TradeEntry };