import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import axios from 'axios';
import FormData from 'form-data';
import Loading from '../../common/Loading';
import { alertConstants } from '../../common/constants/alert.constants';
import { createMuiTheme, MuiThemeProvider, withStyles } from "@material-ui/core/styles";
import { MuiStyles } from '../../styles/MuiStyles';
import MUIDataTable from "mui-datatables";
import {doVerify} from './investClntPolicy';
import {isValidAmountLmt} from './investClntPolicy';
import {isValidPerAumLmt} from './investClntPolicy';
import {muiTableStyles} from '../../styles/muidatatableCss';
import Info from "@material-ui/icons/Info";
import CustomToolbarSelect from "../../navbar/components/CustomToolbarSelect";
import {isValidAllAmtLmt} from './investClntPolicy';
import {isValidAllPermAmtLmt} from './investClntPolicy';
import {showErrorMessage} from './investClntPolicy';
import {isVAmtLmt} from './investClntPolicy';
import {isValidAmtLmts} from './investClntPolicy';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import {removeCommas} from '../../common/amountValidations';
import {showProdErrorMsg} from './investClntPolicy';

var data,fileds,title,errMessage,lmtFundMsg,roleType,conditionFlag,disFlag;
let screenLinkImage;
let fromDate;
let toDate;
let data1;
let columns1;
let options;
let filterFlag=true;
let acctLocalNbr;
let policyName;
let policyId;
let selClient;
let statusTxt;
let policyExists;
let linkName;
let cnt=0;
let selRowsIndex;
let companyName;
let rowCnt=0;
let saveBlk="";
let revokeBtn="";
let verifyBlk="";
let msgAmtLmtPerLmt="";
let errMsgBlk="";
let warMsgBlk="";
let errorImg="none";
let warImg="none";
let resetBlk="";
let data2;
let tempCnt=0;
let forwardFlag=true;
let currencyCode="";
let defaultColChecked=[];
let processColChecked=[];
let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
class ActionPopUp extends React.Component {
  constructor(props){
    super(props);
    this.state = {
    open: false,
    scroll: "paper",
    updateFlag: false,
  };
  this.handleClickOpen = this.handleClickOpen.bind(this);
  this.handleSave = this.handleSave.bind(this);
  this.handleRevoke = this.handleRevoke.bind(this);
  this.handleReset = this.handleReset.bind(this);
  this.handlePresentClose = this.handlePresentClose.bind(this);
  this.handleVerify = this.handleVerify.bind(this);
  this.handleEditAmt = this.handleEditAmt.bind(this);
  this.handleEditPer = this.handleEditPer.bind(this);
}

selectedRows(selRows)
{
	console.log("selected rws ", selRows);
	selRowsIndex=selRows;
	selRows.forEach((row,index) => {
		console.log("target record data::", row.dataIndex);
		defaultColChecked[row.dataIndex]=row.dataIndex;
	});
	//alert("defaultColChecked::"+defaultColChecked);
}

handleReset (scroll) {
    // alert("reset block ");
    scroll='paper';
    data=data2;
    console.log("mar 06, 2019 in reset block data::",data);
    this.setState({ open: true, scroll });
    this.setState({ updateFlag: false });
 }
handleRevoke() {
  //alert("in revoke::rowCnt::"+rowCnt)
        var jsonBody = new FormData();
	if(defaultColChecked != undefined && defaultColChecked.length!=0)
	{
	 data1 && data1.map((item,i)=> {
	 if(defaultColChecked!=undefined && defaultColChecked[i] == i)
	 {

			jsonBody.append("prodcheck"+i,"on");
			//jsonBody.append("policyId",data1[i][columns1.findIndex(e => e.name === "Policy Id")]);
			jsonBody.append("processId",data1[i][columns1.findIndex(e => e.name === "Process Id")]);
			jsonBody.append("prodId"+i,data1[i][columns1.findIndex(e => e.name === "Product Id")]);
			jsonBody.append("ruleId"+i,data1[i][columns1.findIndex(e => e.name === "Rule Id")]);
			var amtLmt=document.getElementById("amtLmt"+i).value;
			jsonBody.append("amtLmt"+i,amtLmt);
			var perAumLmt=document.getElementById("perAumLmt"+i).value;
			jsonBody.append("perAumLmt"+i,perAumLmt);
			/*
			console.log("target09 revoke block   Policy Id value ::",columns1.findIndex(e => e.name === "Policy Id"))
			console.log("target09 revoke block   Process Id value ::",columns1.findIndex(e => e.name === "Process Id"))
			console.log("target09 revoke block   Product Id value ::",columns1.findIndex(e => e.name === "Product Id"))
			console.log("target09 revoke block   Rule Id value ::",columns1.findIndex(e => e.name === "Rule Id"))
			*/
		 }
		})

       //alert("rowCnt::"+rowCnt);
	var url;
    	var user = JSON.parse(sessionStorage.getItem('user'));
    	var policyName = document.getElementById("policyName").value;
    	policyId = document.getElementById("policyId").value;
    	jsonBody.append("token",user[0].token);
    	jsonBody.append("actionFlag","REVOKE");
    	jsonBody.append("fromPage","EDIT");
    	//jsonBody.append("btnFlag",linkName);
    	jsonBody.append("revokeFlag","true");
	jsonBody.append("selClient",selClient);
	jsonBody.append("policyName",policyName);
	jsonBody.append("policyId",policyId);
	jsonBody.append("status",statusTxt);
	jsonBody.append("productsSize",rowCnt);
	//alert("processId::"+jsonBody.get("processId"));
        //alert("successfully sent revoked data ...selClient:"+selClient+",companyName:"+companyName+",statusTxt::"+statusTxt+",policyName:"+policyName+",policyExists:"+policyExists);
      if(confirm(message["REVOKCONFM"]))
      {
	this.setState({ open: false });
	this.props.method(jsonBody);
      }
    }else{
      alert(message["PLSELECT"]);
    }
    }
handleSave() {
        var errMsg;
        //alert("clicked save button  defaultColChecked::"+defaultColChecked);
        var jsonBody = new FormData();
	cnt=0;
	var inValidCnt=0
	var prod = "";
	var fld1;
	var fld2;
	//alert("mar11, 2019 updated statusTxt::"+defaultColChecked+",policyExists:"+policyExists);
	//console.log("mar 13, 2019 ... defaultColChecked::",defaultColChecked);
	//alert("defaultColChecked-----------------------"+defaultColChecked);
	//alert("selRowsIndex-----------------------"+selRowsIndex);
	//console.log("apr 04, 2019 data111::",data1);
	//console.log("apr 04, 2019 data111::",columns1);
	if(doVerify() == true)
        {
	if(defaultColChecked != undefined && defaultColChecked.length!=0)
	{
		     data1 && data1.map((item,i)=>
		     {
			 if(defaultColChecked!=undefined && defaultColChecked[i] == i && inValidCnt == 0)
			 {
			 //alert("...begin  i value ... "+i+",defaultColChecked:"+defaultColChecked)

			var amtLmt=document.getElementById("amtLmt"+i).value;
			var perAumLmt=document.getElementById("perAumLmt"+i).value;

			fld1=document.getElementById("amtLmt"+i);
			fld2=document.getElementById("perAumLmt"+i);
			if(isValidAmtLmts(fld1,fld2,i) == false)
			{
			  inValidCnt++;
			}

			var aumAmount;
			var endBalCompareTo;
			var amountLmtObj = document.getElementById("amtLmt"+i);
			var prodName = data1[i][columns1.findIndex(e => e.name === "Product")];
			var amountLmt = document.getElementById("amtLmt"+i).value;
			var aumLmt = document.getElementById("perAumLmt"+i).value;
			var endBal = data1[i][columns1.findIndex(e => e.name === "End Bal")];
			var aum = data1[i][columns1.findIndex(e => e.name === "AUM")];
			//alert("before amountLmt::"+amountLmt);
			amountLmt = removeCommas(amountLmt);
			//alert("after amountLmt::"+amountLmt);
			//alert("amountLmtObj::"+amountLmtObj.value);
			//alert("prodName::"+prodName);
			//alert("amountLmt::"+amountLmt);
			//alert("aumLmt::"+aumLmt);
			//alert("endBal::"+endBal);
			//alert("aum::"+aum);

			if(aumLmt != "" && aumLmt > 0 && aum != "" && aum >0){
				aumAmount = parseFloat((aumLmt*aum*1000000)/100);
				//alert("aumAmount::"+aumAmount);
			}
			if(amountLmt != ""  && amountLmt > 0 && aumAmount != "" && aumAmount > 0 ){
				if(amountLmt <= aumAmount){
				endBalCompareTo = amountLmt;
				//alert("111endBalCompareTo::"+endBalCompareTo);
				} else {
				endBalCompareTo = aumAmount;
				//alert("222endBalCompareTo::"+endBalCompareTo);
				}
			} else if(amountLmt != "" && amountLmt > 0){
				endBalCompareTo = amountLmt;
				//alert("33endBalCompareTo::"+endBalCompareTo);
			} else if(aumAmount != "" && aumAmount > 0){
				endBalCompareTo = aumAmount;
				//alert("442endBalCompareTo::"+endBalCompareTo);
			}

			if(endBalCompareTo != "" && parseFloat(endBalCompareTo) > 0 &&
					(parseFloat(endBal) > parseFloat(endBalCompareTo))){
				prod = prod +" "+prodName+",";
			}
			if(inValidCnt == 0)
			{
			   cnt++;
				//alert("apr05, 2019 amtLmt::"+amtLmt+",perAumLmt:"+perAumLmt);
				//alert("..mar 23, 2019 amtLmt ... "+amtLmt)
				jsonBody.append("prodcheck"+i,"on");
				jsonBody.append("prodName"+i,data1[i][columns1.findIndex(e => e.name === "Product")]);
				jsonBody.append("processId",data1[i][columns1.findIndex(e => e.name === "Process Id")]);
				//jsonBody.append("policyId",data1[i][columns1.findIndex(e => e.name === "Policy Id")]);
				jsonBody.append("prodId"+i,data1[i][columns1.findIndex(e => e.name === "Product Id")]);
				jsonBody.append("ruleId"+i,data1[i][columns1.findIndex(e => e.name === "Rule Id")]);
				if(amtLmt == "" && perAumLmt!="" && perAumLmt.length>0)
				{
				  jsonBody.append("amtLmt"+i,"0");
				  document.getElementById("amtLmt"+i).value="No Limit";
				}else{
				  jsonBody.append("amtLmt"+i,amtLmt);
				}

				if(perAumLmt == "" && amtLmt!="" && amtLmt.length>0)
				{
				   jsonBody.append("perAumLmt"+i,"0");
				   document.getElementById("perAumLmt"+i).value="No Limit";
				}else{
				  jsonBody.append("perAumLmt"+i,perAumLmt);
				}
			  }
		     }
	    });

   //alert("save block cnt::"+cnt+",tempCnt:"+tempCnt+", data1 length::"+data1.length);
    if(inValidCnt == 0)
    {
	if(cnt > 0)
    	{
	if(prod != "" && prod.length>0 && forwardFlag == true)
	{
	 prod = prod.substring(0,prod.length-1);
	 var prodAlert="Warning: "+message["OSBMORE"]+prod;
	 //alert(prodAlert);
	 var prodMsgAlert=message["OSBMORE"]+prod;
	 showProdErrorMsg(prodMsgAlert);
	 forwardFlag=false;
	 return;
	}

       //alert("rowCnt::"+rowCnt);
        var msgAlert=message["SAVECONFRM"];
        if(data1.length == cnt && tempCnt == 1){
          msgAlert=message["SYSOVRLMT"];
        }
        if(confirm(msgAlert))
        {
	var url;
    	var user = JSON.parse(sessionStorage.getItem('user'));
    	var policyName = document.getElementById("policyName").value;
    	policyId = document.getElementById("policyId").value;
    	jsonBody.append("token",user[0].token);
    	jsonBody.append("actionFlag","SAVE");
    	jsonBody.append("fromPage","EDIT");
    	//jsonBody.append("btnFlag",linkName);
    	jsonBody.append("selClient",selClient);
    	jsonBody.append("clientFirm",companyName);
    	jsonBody.append("policyName",policyName);
    	jsonBody.append("policyId",policyId);
    	jsonBody.append("status",statusTxt);
    	console.log("first blk saving companyName:::",companyName);
        //console.log("selected rws selRowsIndex::", selRowsIndex);
	jsonBody.append("productsSize",rowCnt);
        url=alertConstants.URL+"/CLINVPOL.do";
	//alert("save block ...selClient:"+selClient+",companyName:"+companyName+",statusTxt::"+statusTxt+",policyName:"+policyName+",policyExists:"+policyExists);
    axios({
      method: 'post',
      url:url,
      data: jsonBody,
      config: { headers: {'Content-Type': 'multipart/form-data' }}
    }).then((response)=>{
      data = response.data;
        this.setState({ updateFlag: true });
        showErrorMessage("");
        //alert("in action processColChecked::"+processColChecked);
        if(roleType!=undefined && roleType == 'unchecked')
           defaultColChecked=[];
        //alert("submited success");
       });
       }
     }else{
        alert(message["PLSELECT"]);
         errMsg = "<span class='colTxt'>1.Products: </span><span class='fieldtxt fntsz fntclr'>"+message["CHKBOXSAVE"]+"</span>";
         this.showErrorMsg(errMsg);
       }
     }
    }else{
         alert(message["PLSELECT"]);
         errMsg = "<span class='colTxt'>1.Products: </span><span class='fieldtxt fntsz fntclr'>"+message["CHKBOXSAVE"]+"</span>";
         showErrorMessage(errMsg);
       }
    }
  }


handleEditAmt() {
        //alert("edit amount limit for all products");

	if(isValidAllAmtLmt() && rowCnt>0)
	{
	    //alert("success");
	     var amtLmtAll=document.getElementById("amtLmtAll").value;
		for(var i=0;i<rowCnt;i++)
		{
			console.log("save block target i value::", i)
			document.getElementById("amtLmt"+i).value=amtLmtAll;
			tempCnt=1;
	        }
           this.setState({ updateFlag: false });
        }
  }

 handleEditPer() {
         //alert("edit amount limit percentage for all products");
 	if(isValidAllPermAmtLmt() && rowCnt>0)
 	{
 	     //alert("success");
 	     var permLmtAll=document.getElementById("permLmtAll").value;
 		for(var i=0;i<rowCnt;i++)
 		{
 			console.log("save block target i value::", i)
 			document.getElementById("perAumLmt"+i).value=permLmtAll;
 			tempCnt=1;
 		  }
 	this.setState({ updateFlag: false });
 	}
  }
handleVerify() {
        //alert("clicked verify button");
        var jsonBody = new FormData();
	if(rowCnt>0){
	     data1 && data1.map((item,i)=>{
		jsonBody.append("prodcheck"+i,"on");
		//jsonBody.append("policyId",data1[i][columns1.findIndex(e => e.name === "Policy Id")]);
		jsonBody.append("prodId"+i,data1[i][columns1.findIndex(e => e.name === "Product Id")]);
		jsonBody.append("ruleId"+i,data1[i][columns1.findIndex(e => e.name === "Rule Id")]);
		jsonBody.append("processId",data1[i][columns1.findIndex(e => e.name === "Process Id")]);
		var amtLmt=document.getElementById("amtLmt"+i).value;
		var perAumLmt=document.getElementById("perAumLmt"+i).value;
		jsonBody.append("amtLmt"+i,amtLmt);
		jsonBody.append("perAumLmt"+i,perAumLmt);
		//alert("catid INPOLEDT verify block policyId::"+data1[i][13]+"::prodId::"+data1[i][8]+"::ruleId"+data1[i][11]+",amtLmt::"+amtLmt+",perAumLmt::"+perAumLmt);
	    })
	}
	var url;
    	var user = JSON.parse(sessionStorage.getItem('user'));
    	var policyName = document.getElementById("policyName").value;
    	policyId = document.getElementById("policyId").value;
    	jsonBody.append("token",user[0].token);
    	jsonBody.append("actionFlag","");
    	jsonBody.append("verifyFlag","YES");
    	jsonBody.append("fromPage","EDIT");
    	//jsonBody.append("btnFlag",linkName);
	jsonBody.append("selClient",selClient);
    	jsonBody.append("clientFirm",companyName);
    	jsonBody.append("policyName",policyName);
    	jsonBody.append("policyId",policyId);
    	jsonBody.append("status",statusTxt);
    	//console.log("first blk saving companyName:::",companyName);
        //console.log("selected rws selRowsIndex::", selRowsIndex);
	jsonBody.append("productsSize",rowCnt);
        url=alertConstants.URL+"/CLINVPOL.do";
	//alert("verify block ...selClient:"+selClient+",companyName:"+companyName+",statusTxt::"+statusTxt+",policyName:"+policyName+",policyExists:"+policyExists);
    axios({
      method: 'post',
      url:url,
      data: jsonBody,
      config: { headers: {'Content-Type': 'multipart/form-data' }}
    }).then((response)=>{
      data = response.data;
      //alert("verify posting succesful...");
      this.setState({ updateFlag: false });
       });
    };

  handleClickOpen (scroll,rowData,lnkName) {
    linkName=lnkName;
    var jsonBody = new FormData();
    var url;
    var user = JSON.parse(sessionStorage.getItem('user'));
    jsonBody.append("token",user[0].token);

	if(screenLinkImage === "CLINVPOL"){
	        //alert("before submiting in popup block.rowData.rowData[1]::"+rowData.rowData[1]);
	          companyName=rowData.rowData[0];
	          policyName=rowData.rowData[1];
	          policyId=rowData.rowData[6];
	          statusTxt=rowData.rowData[2];
	          selClient=rowData.rowData[4];
		jsonBody.append("fromPage","EDIT");
		//alert("linkName::"+linkName);
		//jsonBody.append("btnFlag",linkName);
		jsonBody.append("selClient",selClient);
		jsonBody.append("clientFirm",companyName);
		jsonBody.append("status",statusTxt);
		jsonBody.append("policyName",policyName);
		jsonBody.append("policyId",policyId);
		url=alertConstants.URL+"/CLINVPOL.do";
	}

    axios({
      method: 'post',
      url:url,
      data: jsonBody,
      config: { headers: {'Content-Type': 'multipart/form-data' }}
    }).then((response)=>{
      data = response.data;
      this.setState({ open: true, scroll });
      });
     data2 = data;
    };
handleClose = () => {
      this.setState({ open: false });
    };

handlePresentClose(){
      //alert("alert..cnt::"+cnt);
      this.setState({ open: false });
      forwardFlag=true;
      if(this.state.updateFlag == true)
        this.props.goback()
    }

 render() {
	 const { classes } = this.props;
     //defaultColChecked=[];
    //alert("action popup block ");
    let dataFlag=true;
    var commonData = [];
    if (this.props.linkName !== undefined)
      linkName = this.props.linkName;

    //console.log("mar2019 statusTxt",statusTxt);
    if (this.props.screenLinkImage !== undefined){
      screenLinkImage = this.props.screenLinkImage;
      console.log("feb2019 screenLinkImage",screenLinkImage);
    }

    let userLocale="";
	var user = JSON.parse(sessionStorage.getItem('user'));
	if(user[0].localeLang !== undefined){
		userLocale=user[0].localeLang;
	}
    if (this.props.fromDate !== undefined){
      fromDate = this.props.fromDate;
    //  console.log("feb2019 fromDate",fromDate);
    }

    if (this.props.toDate !== undefined){
      toDate = this.props.toDate;
    //  console.log("feb2019 toDate",toDate);
    }

   let tbody="";


   if( data !== undefined && data.toString().trim().length!==0){
   data2=data;
   //console.log("ActionPopUp data::",data);

	var mainList=data.find(item =>item.name ==="commonData")// === listName)
	if(mainList!==undefined && mainList.commonData!==undefined)
	 commonData = mainList.commonData;
 	 title=commonData.screenName;
 	 errMessage=commonData.errMessage;
	var mainList=data.find(item =>item.name ==="columns")// === listName)
	columns1 = mainList.COLUMNS;

	mainList=data.find(item =>item.name ==="DATA")// === listName)
	data1 = mainList.DATA;
	//console.log("mar 20, 2019 columns1::",columns1);
	//console.log("mar 20, 2019 data1::",data1);
	//console.log("data1:length::",data1.length);
	if(data1!==undefined && data1.length!==0){
	  rowCnt=data1.length;
	}
     //console.log("ActionPopUp field values::",commonData);
    if(commonData !== undefined && commonData.length !== 0 )
    {
    	if(screenLinkImage!== undefined && screenLinkImage === "CLINVPOL"){
    	  lmtFundMsg=commonData.lmtFundMsg;
 	  conditionFlag=commonData.conditionFlag;
 	  roleType=commonData.roleType;
 	  disFlag=commonData.disFlag;
 	  //alert("mar 21, 2019 disFlag:::"+disFlag+",commonData.curCode:"+commonData.curCode);
 	  policyExists=commonData.policyExists;
	if(rowCnt>0){
	console.log("apr 3 2019 statusTxt::",statusTxt);
	if(statusTxt == "Pending Approval"){
	for(var i=0;i<rowCnt;i++)
	{
	   //alert("mar 12, 2019 .status value.. data1[i][15]::"+data1[i][15]);
	   if(data1!== undefined && data1[i][columns1.findIndex(e => e.name === "Status")] === "checked"){
	     defaultColChecked[i]=i;
	     processColChecked[i]=i;
	     //alert("defaultColChecked----------------"+defaultColChecked);
	   }
	  }
	}
	console.log("mar 13, 2019 ... defaultColChecked::",defaultColChecked);
	}
	if(conditionFlag!== undefined && conditionFlag === "YES"){
    	  revokeBtn=<Button  onClick={this.handleRevoke} color="primary">Revoke</Button>
    	}else{
    	  revokeBtn="";
    	}
	if(errMessage!== undefined && errMessage === "empty"){
    		msgAmtLmtPerLmt=<div className="form-group"><div className="form-group col-md-12 col-sm-12"><Info style={{float:'left'}}/><span  className="pull-left fntsm" style={{marginTop:'5px'}}>{lmtFundMsg}</span></div></div>

    		errMsgBlk=<div className="pull-left col-md-12 errbg" id="errorId" style={{display:'none'}}><div  className="col-md-12 col-sm-12 fntsz"><span><img src={require('../../images/error_icon.gif')} alt="instruction" />&nbsp;</span><span className='colTxt'>Error(s):&nbsp;Please rectify the following to proceed :</span></div>
    		<div  className="col-md-12 col-sm-12" id="errorMsgId"></div></div>

    		warMsgBlk=<div className="pull-left col-md-12 warbg" id="warnId" style={{display:'none'}}><div  className="col-md-12 col-sm-12"><span><img src={require('../../images/amber_alert.gif')} alt="instruction" />&nbsp;</span><span className='colTxt'>Warning(s):</span></div>
    		<div  className="col-md-12 col-sm-12" id="warnMsgId"></div></div>

    		verifyBlk=<Button  onClick={this.handleVerify} color="primary">Verify</Button>
		saveBlk=<Button  onClick={this.handleSave} color="primary">Save</Button>
		//resetBlk=<Button  onClick={this.handleReset.bind(this)} color="primary">Reset</Button>

    		if(disFlag!== undefined && disFlag === "disabled")
    		{
    		        //alert("target block ");
			revokeBtn="";
			saveBlk="";
		}
    	      currencyCode=(commonData.policyName === "No Investment Policy")?"":commonData.curCode;
	   //alert("*** below block in display block of popup....");
	   tbody = <table className="table table-striped table-bordered" width="100%">
	       <tbody>
		     <tr>
		        <td width="20%">
			   <label> Policy Name </label>
		        </td>
		        <td width="25%">
			   <label> Batch edit Amount limit for all products</label>
		        </td>
		        <td width="25%">
			   <label> Batch edit % limit for all products</label>
		        </td>
		     </tr>
			<tr>
			<td width="15%">
			   <input className={classes.inputStyle} type="text" id="policyName" name="policyName" onChange={e => doVerify()}  defaultValue={(commonData.policyName === "No Investment Policy")?"":commonData.policyName} disabled={(disFlag!== undefined && disFlag.length !== 0)?true:false} style={{padding: '5px 7px'}} maxlength="100"/>
			   <input type="hidden" id="policyId" name="policyId" defaultValue={policyId} />
			</td>
			<td width="15%">
			<input className={classes.inputStyle} type="text" id="amtLmtAll" name="amtLmtAll" onChange={e => isVAmtLmt(e)} style={{padding: '5px 7px'}} maxlength="11" /> <a href="#"  onClick={this.handleEditAmt} color="primary">Apply</a>
			</td>
			<td width="15%">
			<input className={classes.inputStyle} type="text" id="permLmtAll" name="permLmtAll" style={{padding: '5px 7px'}} maxlength="3" /> <a href="#"  onClick={this.handleEditPer} color="primary">Apply</a>
			</td>
			</tr>
			<tr>
			<td width="15%" style={{ color: 'red'}}>
			   {commonData.message}
			</td>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
			</tr>
	     </tbody>
	  </table>
	    }else{
	       dataFlag=false;
	       saveBlk="";
	       verifyBlk="";
	       msgAmtLmtPerLmt="";
	       resetBlk="";
	       tbody = <table className="table table-striped table-bordered" width="100%">
		<tbody>
		<tr>
		<td width="15%" style={{ color: 'red'}}>
		   <label> {errMessage} </label>
		</td>
		</tr>
	        </tbody>
	      </table>
	    }
	  }
	 }else{
		dataFlag=false;
		msgAmtLmtPerLmt="";
		tbody = <table className="table table-striped table-bordered" width="100%">
		    <tbody>
		          <tr>
		            <td style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">No Data Found
		            </td>
            </tr>
           </tbody>
           </table>
	}
      options = {
      		filterType: "dropdown",
      		rowsSelected:processColChecked,
      		selectableRows: true,
      		onRowsSelect: (rowsSelected, allRows) => {
             defaultColChecked=[];
      		       this.selectedRows(allRows);
      		      console.log("here" , rowsSelected);
      		},
      		pagination: false,
      		rowsPerPage: 10,
      		responsive: "scroll",
      		fixedHeader: false,
      		filter:false,
      		search:false,
      		print:false,
      		download:false,
      		viewColumns:false,
      		customToolbarSelect: (selectedRows, displayData, setSelectedRows) => (
		  <CustomToolbarSelect selectedRows={selectedRows} displayData={displayData} setSelectedRows={setSelectedRows} />
	       ),
	    };
         }

	if(screenLinkImage === "CLINVPOL"){
	let curFlag=false;
	if(columns1!== undefined && columns1.length !==0){
	  columns1.map((item,index)=>{
	  console.log("apr 03, 2019 ..  item.name::",item.name);
	   if(item.name === "New Amount Limit" || item.name === "Amount Limit"){
	    	//console.log("feb27 2019 firstblock....index:::",index);
	      item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
		if(tableMeta.rowData[15] !== undefined){
			currencyCode=tableMeta.rowData[15];
			curFlag=true;
		}
		if(curFlag === false && tableMeta.rowData[14] !== undefined)
		{
			currencyCode=tableMeta.rowData[14];
		}
		 return (
	          <div><input className={classes.inputStyle} type="text" name={"amtLmt"+tableMeta.rowIndex} id={"amtLmt"+tableMeta.rowIndex} defaultValue={value} onChange={e => isValidAmountLmt(e,tableMeta.rowIndex)} disabled={(disFlag!== undefined && disFlag.length !== 0 && value !== "No Limit")?true:false} style={{padding: '6px 7px'}} maxlength="11"/>
		  {(value === "No Limit")?"":currencyCode}</div>);
	       }
	      }
	    if(item.name === "New % Limit of Fund AUM Limit" || item.name === "% Limit of Fund AUM"){
	      //let j=0;
	      //console.log("feb27 2019 second block....index:::",index);
	      item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
		 return (
	          <div><input className={classes.inputStyle} type="text" name={"perAumLmt"+tableMeta.rowIndex} id={"perAumLmt"+tableMeta.rowIndex} defaultValue={value}  onChange={e => isValidPerAumLmt(e,tableMeta.rowIndex)} disabled={(disFlag!== undefined && disFlag.length !== 0 && value !== "No Limit")?true:false} style={{padding: '6px 7px'}} maxlength="3"/>
		%</div>);
	       }
	    }
	   })
	   //console.log(" mar 12, 2019 defaultColChecked:::",defaultColChecked);
	  }
	}

    return (
      <div>
        <button className="btn btn-primary btn-xs mt" onClick={this.handleClickOpen.bind(this,"paper",this.props.rowData,linkName)}>
          {linkName}
        </button>
        <Dialog
          open={this.state.open}
          onClose={this.handlePresentClose}
          scroll={this.state.scroll}
          aria-labelledby="scroll-dialog-title"
          fullWidth={true}
          maxWidth = {'md'}
        >
          <DialogTitle id="scroll-dialog-title"> {title}</DialogTitle>
          <DialogContent>
            <DialogContentText>
            {errMsgBlk}
            {warMsgBlk}
              {tbody}
		<div className="clearfix"></div>
		{msgAmtLmtPerLmt}
		<div className="clearfix"></div>
	      {
		dataFlag === true ?
		(
		data1 !== undefined ?
		<MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
		  <MUIDataTable
		  data={data1}
		  columns={columns1}
		  options={options}
		  />
		</MuiThemeProvider>
		:
		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
		)
		:
		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div></div>
		}

            </DialogContentText>
          </DialogContent>
          <DialogActions>
            {verifyBlk}
            {saveBlk}
            {resetBlk}
            {revokeBtn}
            <Button  onClick={this.handlePresentClose.bind(this)} color="primary">Close</Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

export default withStyles(MuiStyles)(ActionPopUp);
