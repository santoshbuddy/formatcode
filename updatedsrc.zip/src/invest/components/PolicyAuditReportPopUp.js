import React from "react";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import axios from 'axios';
import FormData from 'form-data';
import Loading from '../../common/Loading';
import { alertConstants } from '../../common/constants/alert.constants';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import {muiTableStyles} from '../../styles/muidatatableCss';

var data,fileds,title;
let screenLinkImage;
let data1;
let columns1;
let options;
let linkName;
let dataFlag=true;
class PolicyAuditReportPopUp extends React.Component {
getMuiTheme = () =>
	        createMuiTheme({
	          overrides: {
	            MUIDataTableHeadCell: {
	              root: {
	                background: '#eaeaea !important',
	                color: '#0066b2 !important',
	                textTransform: 'uppercase',
	                whiteSpace: 'nowrap',
	                fontWeight:'bold',
	                borderRight: '1px solid #b3b3b3',
	                borderTop: '1px solid #b3b3b3',
	                borderBottom: '1px solid #b3b3b3',
	                '&:first-child':{
	                  borderLeft: '1px solid #b3b3b3'
	                },
	                '&:last-child':{
	                  paddingRight: '4px'
	                }
	              }
	            },
	            MUIDataTableBodyRow: {
	              root: {
	                '&:nth-child(odd)': {
	                  backgroundColor: '#f7f8f9'
	                }
	              }
	             },
	             MuiTableCell: {
	               root: {
	                whiteSpace: 'nowrap',
	                padding: '7px 5px',
	                borderRight: '1px solid #f3ebeb',
	                // borderTop: '1px solid #c3c3c3',
	                borderBottom: '1px solid #f3ebeb',
	                '&:last-child':{
	                  borderRight:'0px'
	                },
	                '&:first-child':{
	                  borderLeft: '1px solid #f3ebeb'
	                }
	               }
	             },
	             MuiTableRow: {
	               root:{
	                 height:'auto'
	               },
	               head: {
	                 height:'auto',
	               }
	             }
	            }
	          });

  constructor(props){
    super(props);
    this.state = {
    open: false,
    scroll: "paper",
    updateFlag: false,
  };
  this.handleClickOpen = this.handleClickOpen.bind(this);
}

  handleClickOpen (scroll,rowData) {
  //alert("screenLinkImage:"+screenLinkImage);
    var jsonBody = new FormData();
    var url;
    var user = JSON.parse(sessionStorage.getItem('user'));
    jsonBody.append("token",user[0].token);
		console.log("in policy audit report popup...");
		jsonBody.append("selCompanyId","67199300");//testing
		url=alertConstants.URL+"/PRNTAUDINVPOLICYPopUp.do";

console.log("in policy audit report popup.url info.."+url);

    axios({
      method: 'post',
      url:url,
      data: jsonBody,
      config: { headers: {'Content-Type': 'multipart/form-data' }}
    }).then((response)=>{
      data = response.data;
      this.setState({ open: true, scroll });
      });
    };

    handleClose = () => {
      this.setState({ open: false });
    };


  handleReset(){
     alert("clicked reset button");
  }

  render() {

    console.log(" in render of policy audit report popup block ");

    var commonData = [];
    if (this.props.linkName !== undefined)
      linkName = this.props.linkName;

    if (this.props.screenLinkImage !== undefined){
      screenLinkImage = this.props.screenLinkImage;
      console.log("feb2019 screenLinkImage",screenLinkImage);
    }

    let userLocale="";
	var user = JSON.parse(sessionStorage.getItem('user'));
	if(user[0].localeLang !== undefined){
		userLocale=user[0].localeLang;
	}


    let msg="";

   if( data !== undefined && data.toString().trim().length!==0){
       console.log("policy audit report popup screen ::",data);

	var mainList=data.find(item =>item.name ==="commonData")// === listName)
	if(mainList!==undefined && mainList.commonData!==undefined)
	 commonData = mainList.commonData;
 	 title=commonData.screenName;

 	 console.log("policy audit report popup screen field values:commonData :",commonData);

	var mainList=data.find(item =>item.name ==="columns")// === listName)
	columns1 = mainList.COLUMNS;

console.log("policy audit report popup screen columns1 :",columns1);

	mainList=data.find(item =>item.name ==="DATA")// === listName)
	data1 = mainList.DATA;
console.log("policy audit report popup details ::",data1);

	if(data1!==undefined && data1.length!==0){
	  dataFlag=true;
	}else{
	  dataFlag=false;
	}

	options = {
		filterType: "dropdown",
		selectableRows: false,
		pagination: true,
        	rowsPerPage: 10,
		responsive: "scroll",
		fixedHeader: false
	};
    }



    return (
      <div>
        <button className="btn btn-primary btn-xs mt" onClick={this.handleClickOpen.bind(this,"paper",this.props.rowData)}>
          View Change History
        </button>
        <Dialog
          open={this.state.open}
          onClose={this.handleClose}
          scroll={this.state.scroll}
          aria-labelledby="scroll-dialog-title"
          fullWidth={true}
          maxWidth = {'md'}
        >
          <DialogTitle id="scroll-dialog-title"> {title}</DialogTitle>
          <DialogContent>
            <DialogContentText>
	      {
		dataFlag === true ?
		(
		data1 !== undefined ?
		<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
		  <MUIDataTable
		  title=''
		  data={data1}
		  columns={columns1}
		  options={options}
		  />
		</MuiThemeProvider>
		:
		<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
		)
		:
		<div  className="col-md-12" style={{color: 'red', marginTop:'10%',marginBottom:'10%'}}>No Records Found</div>
		}

            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button  onClick={this.handleClose} color="primary">Close</Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

export default PolicyAuditReportPopUp;
