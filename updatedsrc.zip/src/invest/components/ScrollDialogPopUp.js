import React from "react";
import { connect } from 'react-redux';
import { Route , Redirect } from 'react-router-dom';
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import { tradeActions } from '../../tradeentry/actions/trade.actions';
import axios from 'axios';
import FormData from 'form-data';
import PropTypes from 'prop-types';
import Loading from '../../common/Loading';
import { alertConstants } from '../../common/constants/alert.constants';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import MUIDataTable from "mui-datatables";
import FiltersPopUp from '../../reports/components/FiltersPopUp';
import {addCommaDV} from '../../tradeentry/components/amountValidations';
import {history} from '../../_helpers';
import { resultConstants } from '../../common/constants/result.constants'
import Info from "@material-ui/icons/Info";
import {muiTableStyles} from '../../styles/muidatatableCss';

var data,fileds,title,messageTxt,msgTxt,lmtFundMsg,datatext1,datatext2;
let screenLinkImage;
let fromDate;
let toDate;
let data1;
let columns1;
let options;
let filterFlag=true;
let acctLocalNbr;
let policyName;
let policyId;
let statusTxt;
let companyName;
let selCompanyId;
let editBtn="";
let firstBtn="";
let editLnk="";
let secondBtn="";
let thirdBtn="";
var commonData = [];
var colorData = [];
let verifyBtn="";
let approveBtn="";
let rejectBtn="";
let mcProcessFlag="";
let policyExists="";
let rowCnt=0;
let noDataFlag="";
let msgAmtLmtPerLmt="";
class ScrollDialogPopUp extends React.Component {
	getMuiTheme = () =>
		createMuiTheme({
			overrides: {
				MUIDataTableHeadCell: {
					root: {
						background: '#eaeaea !important',
						color: '#0066b2 !important',
						textTransform: 'uppercase',
						whiteSpace: 'nowrap',
						fontWeight:'bold',
						borderRight: '1px solid #b3b3b3',
						borderTop: '1px solid #b3b3b3',
						borderBottom: '1px solid #b3b3b3',
						'&:first-child':{
							borderLeft: '1px solid #b3b3b3'
						},
						'&:last-child':{
							paddingRight: '4px'
						}
					}
				},
	            MUIDataTableBodyRow: {
					root: {
						'&:nth-child(odd)': {
							backgroundColor: '#f7f8f9'
						}
					}
				},
				MuiTableCell: {
					root: {
						whiteSpace: 'nowrap',
						padding: '7px 5px',
						borderRight: '1px solid #f3ebeb',
						// borderTop: '1px solid #c3c3c3',
						borderBottom: '1px solid #f3ebeb',
						'&:last-child':{
							borderRight:'0px'
						},
						'&:first-child':{
							borderLeft: '1px solid #f3ebeb'
						}
					}
				},
				MuiTableRow: {
					root:{
						height:'auto'
					},
					head: {
						height:'auto',
					}
				}
			}
		});

		constructor(props){
			super(props);
			this.state = {
				open: false,
				openPolicy: false,
				scroll: "paper",
				updateFlag: false,
				approveFlag: false,
			};

			this.handleClickOpen = this.handleClickOpen.bind(this);
			this.doChange = this.doChange.bind(this);
			this.routeChange = this.routeChange.bind(this);
			this.viewChangeHistory = this.viewChangeHistory.bind(this);
			this.editInvestPolicy = this.editInvestPolicy.bind(this);
			this.enterTrade = this.enterTrade.bind(this);
			this.handleVerify = this.handleVerify.bind(this);
			this.handleApprove = this.handleApprove.bind(this);
			this.handleReject = this.handleReject.bind(this);
		}

handleVerify() {
        //alert(" in display block clicked verify button"+policyExists);
        var jsonBody = new FormData();
	if(rowCnt>0){
		  for(var i=0;i<rowCnt;i++)
		  {
		  //console.log("mar 22, 2019 verify block  .. columns1::",columns1);
			jsonBody.append("prodchk"+i,"on");
			jsonBody.append("prodName",data1[i][columns1.findIndex(e => e.name === "Product")]);
			jsonBody.append("amtLmt"+i,data1[i][columns1.findIndex(e => e.name === "Amount Limit of Fund")]);
			//alert("amtLmt value::"+jsonBody.get("amtLmt"+i));
			jsonBody.append("perAumLmt"+i,data1[i][columns1.findIndex(e => e.name === "Current % Limit of Fund AUM")]);
			//alert("perAumLmt value::"+jsonBody.get("perAumLmt"+i));
			jsonBody.append("processId",data1[i][columns1.findIndex(e => e.name === "Process Id")]);
			jsonBody.append("prodId"+i,data1[i][columns1.findIndex(e => e.name === "Product Id")]);
			//jsonBody.append("policyId",data1[i][columns1.findIndex(e => e.name === "Policy Id")]);
			//alert("catid INVPOLDT verify block prodName::"+data1[i][0]+"::amtLmt::"+data1[i][6]+"::perAumLmt"+data1[i][7]+"::processid"+data1[i][5]+",prodid::"+data1[i][8]+",policyId::"+data1[i][9]);
		  }
	}
	var url;
    	var user = JSON.parse(sessionStorage.getItem('user'));
    	jsonBody.append("token",user[0].token);
    	jsonBody.append("actionFlag","");
    	jsonBody.append("verifyFlag","YES");
    	jsonBody.append("fromPage","MCPROCESS");
	jsonBody.append("selClient",selCompanyId);
    	jsonBody.append("clientFirm",companyName);
    	jsonBody.append("policyName",policyName);
    	jsonBody.append("policyId",policyId);
    	jsonBody.append("status",statusTxt);
	jsonBody.append("productsSize",rowCnt);
        url=alertConstants.URL+"/CLINVPOL.do";
	//alert(" sucessful verify block ...selClient:"+selCompanyId+",companyName:"+companyName+",statusTxt::"+statusTxt+",policyName:"+policyName+",policyId::"+policyId);

    axios({
      method: 'post',
      url:url,
      data: jsonBody,
      config: { headers: {'Content-Type': 'multipart/form-data' }}
    }).then((response)=>{
      data = response.data;
      this.setState({ updateFlag: false });
       });
    };

handleApprove() {
        //alert("begin approve button:policyExists:"+policyExists);
        //alert("clicked approve button::rowCnt::"+rowCnt);
        var jsonBody = new FormData();
        //alert("approve .. rowCnt::"+rowCnt);

	if(rowCnt>0){
	        var checkValue="";
		data1 && data1.map((item,i)=>{
			jsonBody.append("prodchk"+i,data1[i][columns1.findIndex(e => e.name === "Enable")]);
			checkValue=data1[i][columns1.findIndex(e => e.name === "Enable")];
			//alert("checkValue::"+checkValue);
			if(checkValue == "checked"){
			    //alert("successfull filled");
				jsonBody.append("prodName",data1[i][columns1.findIndex(e => e.name === "Product")]);
				jsonBody.append("processId",data1[i][columns1.findIndex(e => e.name === "Process Id")]);
				//jsonBody.append("policyId",data1[i][columns1.findIndex(e => e.name === "Policy Id")]);
				jsonBody.append("amtLmt"+i,data1[i][columns1.findIndex(e => e.name === "Amount Limit of Fund")]);
				jsonBody.append("perAumLmt"+i,data1[i][columns1.findIndex(e => e.name === "Current % Limit of Fund AUM")]);
				jsonBody.append("prodId"+i,data1[i][columns1.findIndex(e => e.name === "Product Id")]);
			}
			/*console.log("target09 approve block Enable value ::",columns1.findIndex(e => e.name === "Enable"))
			console.log("target09 approve block   Product value ::",columns1.findIndex(e => e.name === "Product"))
			console.log("target09 approve block   Amount Limit of Fund value ::",columns1.findIndex(e => e.name === "Amount Limit of Fund"))
			console.log("target09 approve block   Current % Limit of Fund AUM value ::",columns1.findIndex(e => e.name === "Current % Limit of Fund AUM"))
			console.log("target09 approve block   Process Id value ::",columns1.findIndex(e => e.name === "Process Id"))
			console.log("target09 approve block   Product Id value ::",columns1.findIndex(e => e.name === "Product Id"))
			console.log("target09 approve block   Policy Id value ::",columns1.findIndex(e => e.name === "Policy Id"))
			*/
		})
	}
	var url;
    	var user = JSON.parse(sessionStorage.getItem('user'));
    	jsonBody.append("token",user[0].token);
    	jsonBody.append("actionFlag","APPROVE");
    	jsonBody.append("fromPage","MCPROCESS");
	jsonBody.append("approveFlag","true");
    	jsonBody.append("policyName",policyName);
    	jsonBody.append("policyId",policyId);
	jsonBody.append("status",statusTxt);
	jsonBody.append("selClient",selCompanyId);
	//jsonBody.append("clientFirm",companyName);
	//console.log("target09 approve block   selCompanyId::",selCompanyId);
	//console.log("target09 approve block   clientFirm::",companyName);
	jsonBody.append("productsSize",rowCnt);
        url=alertConstants.URL+"/CLINVPOL.do";
        //alert("mar 12, 2019 approve block ...selClient:"+selCompanyId+",companyName:"+companyName+",statusTxt::"+statusTxt+",policyExists:"+policyExists);
  if(window.confirm('Are you sure, you want to approve the data?')){
    axios({
      method: 'post',
      url:url,
      data: jsonBody,
      config: { headers: {'Content-Type': 'multipart/form-data' }}
    }).then((response)=>{
      data = response.data;
      this.setState({ approveFlag: true });
        //alert("posting success...");
       });
      }
    };

handleReject() {
        //alert("clicked reject button::statusTxt:"+statusTxt);
        var jsonBody = new FormData();
	//alert("mar 12, 2019 rowCnt::"+rowCnt)
	if(rowCnt>0){
		var checkValue="";
		data1 && data1.map((item,i)=>{
			jsonBody.append("prodchk"+i,data1[i][columns1.findIndex(e => e.name === "Enable")]);
			checkValue=data1[i][columns1.findIndex(e => e.name === "Enable")];
			//alert("checkValue::"+checkValue);
			if(checkValue == "checked"){
			    //alert("successfull filled");
				jsonBody.append("prodName",data1[i][columns1.findIndex(e => e.name === "Product")]);
				jsonBody.append("processId",data1[i][columns1.findIndex(e => e.name === "Process Id")]);
				//jsonBody.append("policyId",data1[i][columns1.findIndex(e => e.name === "Policy Id")]);
				jsonBody.append("amtLmt"+i,data1[i][columns1.findIndex(e => e.name === "Amount Limit of Fund")]);
				jsonBody.append("perAumLmt"+i,data1[i][columns1.findIndex(e => e.name === "Current % Limit of Fund AUM")]);
				jsonBody.append("prodId"+i,data1[i][columns1.findIndex(e => e.name === "Product Id")]);
			}
			/*console.log("target09 approve block Enable value ::",columns1.findIndex(e => e.name === "Enable"))
			console.log("target09 reject block   Product value ::",columns1.findIndex(e => e.name === "Product"))
			console.log("target09 reject block   Amount Limit of Fund value ::",columns1.findIndex(e => e.name === "Amount Limit of Fund"))
			console.log("target09 reject block   Current % Limit of Fund AUM value ::",columns1.findIndex(e => e.name === "Current % Limit of Fund AUM"))
			console.log("target09 reject block   Process Id value ::",columns1.findIndex(e => e.name === "Process Id"))
			console.log("target09 reject block   Product Id value ::",columns1.findIndex(e => e.name === "Product Id"))
			console.log("target09 reject block   Policy Id value ::",columns1.findIndex(e => e.name === "Policy Id"))
			*/
		})
	}
      if(confirm("Are you sure, you want to reject the data?"))
      {
       //alert("rowCnt::"+rowCnt);
	var url;
    	var user = JSON.parse(sessionStorage.getItem('user'));
    	//var policyName = document.getElementById("policyName").value;
    	jsonBody.append("token",user[0].token);
    	jsonBody.append("actionFlag","REJECT");
    	jsonBody.append("fromPage","MCPROCESS");
    	jsonBody.append("rejectFlag","true");
	jsonBody.append("selClient",selCompanyId);
    	jsonBody.append("policyName",policyName);
    	jsonBody.append("policyId",policyId);
	jsonBody.append("status",statusTxt);
	jsonBody.append("productsSize",rowCnt);
        //alert("mar 12, 2019 reject block ...selClient:"+selCompanyId+",companyName:"+companyName+",statusTxt::"+statusTxt);
	this.setState({ openPolicy: false });
	//alert(" reject method .. before submit method")
	this.props.method(jsonBody);
      }
    }

		doChange(filterNameValueArray) {
			var jsonBody = new FormData();
			if(filterNameValueArray !== undefined) {
				for(var i =0; i<filterNameValueArray.length; i++) {
					var temp = filterNameValueArray[i];
					if(temp.id == "eventHistory" && temp.value == "1") {
						//alert("event history block");
					} else {
						jsonBody.append(temp.id, temp.value);
					}

					//alert(temp.id+" ,value:"+temp.value);
				}
			}

			filterFlag=false;
			//alert("in dochange block .acctLocalNbr.."+acctLocalNbr);

			var url;
			var user = JSON.parse(sessionStorage.getItem('user'));

			jsonBody.append("token",user[0].token);
			jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

			console.log('screenLinkImage:'+screenLinkImage);

			jsonBody.append("actionFlag","GO");

			if(screenLinkImage === "MMFRECRE") {
				jsonBody.append("chkStatus","ALL");
				jsonBody.append("subSource","MMFRECRE");
				jsonBody.append("acctNbr",acctLocalNbr);
				jsonBody.append("issueChild","ALL");
				jsonBody.append("eventHistory","ALL");
				jsonBody.append("accountList","ALL");
				jsonBody.append("acctnature","All");
				//jsonBody.append("fromDate",JSON.parse(sessionStorage.getItem('fromDate')));
				//jsonBody.append("toDate",JSON.parse(sessionStorage.getItem('toDate')));
				url	= alertConstants.URL+"/MMMFACCNOPOS.do";
			}

			console.log("scrolldialog .... url info::"+url+",jsonBody:"+jsonBody);

			axios({
				method: 'post',
				url:url,
				data: jsonBody,
				config: { headers: {'Content-Type': 'multipart/form-data' }}
			}).then((response) => {
				data = response.data;
				this.setState({ updateFlag: true });
				//this.setState({ open: true, scroll });
			});
		};

		handleClickOpen (scroll,rowData) {
			//alert("in handle click opent ...");
			var jsonBody = new FormData();
			var url;
			var user = JSON.parse(sessionStorage.getItem('user'));

			jsonBody.append("token",user[0].token);

			console.log('handleClickOpen >screenLinkImage> '+screenLinkImage);

			if(screenLinkImage === "CLINVPOL") {
				//alert(" first  in popup block policy name:"+rowData.rowData[6]);
				policyName=rowData.rowData[1];
				policyId=rowData.rowData[6];
				statusTxt=rowData.rowData[2];
				//alert("before submiting in popup block.... ");
				jsonBody.append("fromPage","MCPROCESS");
				jsonBody.append("selClient",rowData.rowData[4]);
				selCompanyId=rowData.rowData[4];
				jsonBody.append("clientFirm",rowData.rowData[0]);
				companyName=rowData.rowData[0];
				jsonBody.append("status",statusTxt);
				jsonBody.append("policyName",policyName);
				jsonBody.append("policyId",policyId);

				url=alertConstants.URL+"/CLINVPOL.do";

			} else if(screenLinkImage === "NOTIFICATIONS"){
//	        alert("before submiting in popup block.rowData.rowData[1]::"+JSON.stringify(rowData.rowData));

	        	  if(rowData.rowData[0] === "POLICY") {
						policyName=rowData.rowData[2];
						statusTxt='Pending Approval';
						//alert("linkName::"+linkName);
						jsonBody.append("fromPage","MCPROCESS");
						//alert("linkName::"+linkName);
						selCompanyId=rowData.rowData[6];
						jsonBody.append("selClient",rowData.rowData[6]);
						jsonBody.append("clientFirm",rowData.rowData[7]);
						jsonBody.append("status",'Pending Approval');
						jsonBody.append("policyName",rowData.rowData[2]);
						url=alertConstants.URL+"/CLINVPOL.do";

				}else if(rowData.rowData[1] === "POLICY") {
						policyName=rowData.rowData[3];
						statusTxt='Pending Approval';
						//alert("linkName::"+linkName);
						jsonBody.append("fromPage","MCPROCESS");
						//alert("linkName::"+linkName);
						selCompanyId=rowData.rowData[6];
						jsonBody.append("selClient",rowData.rowData[7]);
						jsonBody.append("clientFirm",rowData.rowData[8]);
						jsonBody.append("status",'Pending Approval');
						 jsonBody.append("policyName",rowData.rowData[3]);

						url=alertConstants.URL+"/CLINVPOL.do";

				}else {
				//alert("in handle click opent ...");
					jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
					//alert("MMFRECRE::acctnbr:"+rowData.rowData[9]);
					jsonBody.append("chkStatus","ALL");
					jsonBody.append("subSource","");
					jsonBody.append("actionFlag","GO");
					acctLocalNbr=rowData.rowData[9];
					jsonBody.append("acctNbr",acctLocalNbr);
					jsonBody.append("issueChild","ALL");
					jsonBody.append("accountList","ALL");
					jsonBody.append("acctnature","All");
					jsonBody.append("fromDate",'');
					jsonBody.append("toDate",'');

				url=alertConstants.URL+"/MMMFACCNOPOS.do";
			}
		} else if(screenLinkImage === "MMFRECRE") {
				//alert("in handle click opent ...");
				jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
				//alert("MMFRECRE::acctnbr:"+rowData.rowData[8]);
				jsonBody.append("chkStatus","ALL");
				jsonBody.append("subSource","");
				jsonBody.append("actionFlag","GO");
				acctLocalNbr=rowData.rowData[8];
				jsonBody.append("acctNbr",acctLocalNbr);
				jsonBody.append("issueChild","ALL");
				jsonBody.append("accountList","ALL");
				jsonBody.append("acctnature","All");
				jsonBody.append("fromDate",fromDate);
				jsonBody.append("toDate",toDate);

				url=alertConstants.URL+"/MMMFACCNOPOS.do";
			}else if(screenLinkImage === "HOME") {
				//alert("in handle click opent ...");
				jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
				//alert("MMFRECRE::acctnbr:"+rowData.rowData[9]);
				jsonBody.append("chkStatus","ALL");
				jsonBody.append("subSource","");
				jsonBody.append("actionFlag","GO");
				acctLocalNbr=rowData.rowData[9];
				jsonBody.append("acctNbr",acctLocalNbr);
				jsonBody.append("issueChild","ALL");
				jsonBody.append("accountList","ALL");
				jsonBody.append("acctnature","All");
				jsonBody.append("fromDate",fromDate);
				jsonBody.append("toDate",toDate);

				url=alertConstants.URL+"/MMMFACCNOPOS.do";
			}else if(screenLinkImage === "HOMEINBA") {
				//alert("in handle click opent ...");
				jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
				// alert("MMFRECRE::acctnbr:"+rowData.rowData[6]);

				acctLocalNbr=rowData.rowData[6];



				//alert("MMDAACC::acctnbr:"+rowData.rowData[6]);
						jsonBody.append("chkStatus","ALL");
						jsonBody.append("subSource","MMDAACC");
						jsonBody.append("acctNbr",acctLocalNbr);
						//jsonBody.append("acctNbr","1686536897283335");//acctLocalNbr
						jsonBody.append("issueChild","ALL");
						jsonBody.append("eventHistory","ALL");
						jsonBody.append("accountList","ALL");
						jsonBody.append("acctnature","All");
						//jsonBody.append("fromDate",JSON.parse(sessionStorage.getItem('fromDate')));
				    	//jsonBody.append("toDate",JSON.parse(sessionStorage.getItem('toDate')));
					url=alertConstants.URL+"/MMDAACCNOPOS.do";
			}
			//jsonBody.append("transId",rowData.rowData[9]);
			axios({
				method: 'post',
				url:url,
				data: jsonBody,
				config: { headers: {'Content-Type': 'multipart/form-data' }}
			}).then((response) => {
				data = response.data;
				this.setState({ open: true, scroll });
				this.setState({ openPolicy: false, scroll });
			});
		};

		handleClose = () => {
		   //alert("in close ...");
			this.setState({ open: false });
			if(this.state.approveFlag == true)
        		   this.props.goback()
		};

		handlePolicyClose = () => {
			this.setState({ openPolicy: false });
		};

		enterTrade(paramVal) {
			console.log('In SCrollDialog---->commonData--',commonData);
			this.props.func(commonData, paramVal);
		}

	         editInvestPolicy () {
			//console.log("....clicked editInvestPolicy method");
			this.setState({ open: false });
			let editRowData=[];

			editRowData.push({id:"selClient",value:selCompanyId})
			editRowData.push({id:"companyName",value:companyName})
			editRowData.push({id:"statusTxt",value:statusTxt})
			editRowData.push({id:"policyName",value:policyName})
			editRowData.push({id:"policyId",value:policyId})
			console.log("mar09, 2019 editRowData::",editRowData)
			this.props.editInvest(editRowData);
		  }
		viewChangeHistory (scroll,rowData) {
			//alert("screenLinkImage:"+screenLinkImage);
			var jsonBody = new FormData();
			var url;
			var user = JSON.parse(sessionStorage.getItem('user'));

			console.log("in policy audit report popup..selCompanyId::"+selCompanyId);

			jsonBody.append("token",user[0].token);
			jsonBody.append("selCompanyId",selCompanyId);
			jsonBody.append("popUpFlag","true");

			url=alertConstants.URL+"/PRNTAUDINVPOLICYPopUp.do";
			console.log("in policy audit report popup.url info.."+url);
			axios({
				method: 'post',
				url:url,
				data: jsonBody,
				config: { headers: {'Content-Type': 'multipart/form-data' }}
			}).then((response) => {
				data = response.data;
				this.setState({ openPolicy: true, scroll });
				this.setState({ open: false });
			});
		};

		routeChange(){
			this.setState({ open: false });
			this.props.goInvestRpt()
		}

		render() {
			let linkName;
			let subBlk;
			let dataFlag= true;
			let tbody	= "";
            noDataFlag = "false";
    		//var commonData = [];

    		if (this.props.linkName !== undefined)
      			linkName = this.props.linkName;

			if (this.props.screenLinkImage !== undefined){
				screenLinkImage = this.props.screenLinkImage;
				console.log("feb2019 screenLinkImage",screenLinkImage);
			}

			let userLocale="";
			var user = JSON.parse(sessionStorage.getItem('user'));
			if(user[0].localeLang !== undefined) {
				userLocale=user[0].localeLang;
			}

			if (this.props.fromDate !== undefined) {
				fromDate = this.props.fromDate;
				//  console.log("feb2019 fromDate",fromDate);
			}

			if (this.props.toDate !== undefined) {
				toDate = this.props.toDate;
				//  console.log("feb2019 toDate",toDate);
			}

   			if( data !== undefined && data.toString().trim().length!==0) {
   				console.log("Money Fund Account Position data::",data);

				var mainList=data.find(item =>item.name ==="commonData")// === listName)
				if(mainList!==undefined && mainList.commonData!==undefined)
					commonData = mainList.commonData;

				title=commonData.screenName;
				if(mainList === undefined)
				 {
					 noDataFlag = "true";
					 title="";
				 }

				var colorList=data.find(item =>item.name ==="COLOR")// === listName)
				if(colorList!==undefined && colorList.colorData!==undefined){
					colorData = colorList.colorData;

				datatext1=colorData.DATA1;
				datatext2=colorData.DATA2;
				}else{
				datatext1='';
				datatext2='';
				}


				var mainList=data.find(item =>item.name ==="columns")// === listName)
				columns1 = mainList.COLUMNS;
				mainList=data.find(item =>item.name ==="DATA")// === listName)
				data1 = mainList.DATA;
				// cell prop start
				if(columns1!== undefined && columns1.length !==0){
				//console.log("mar 20,2019 .. columns1::",columns1);
					  columns1 && columns1.map((item,index)=>{
					   if(item.name === "Product" || item.name === "Current Amount Limit" ||  item.name === "New Amount Limit"){
					      //console.log("in side feb27 2019 firstblock....data1[0][12]:::",data1[0][12]);
					      item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
					         //console.log("mar 01, 2019 value:value:"+value);
						 return (
					          (data1[tableMeta.rowIndex][columns1.findIndex(e => e.name === "Modify Amount Limit")]!==undefined && data1[tableMeta.rowIndex][columns1.findIndex(e => e.name === "Modify Amount Limit")]==="true")?(<label className='TxtNrml' style={{ background: 'yellow', textAlign: "left"}}>{value}</label>):(<div>{value}</div>)
						 );
					       }
					      }
					if(item.name === "Product" || item.name === "Current % Limit" ||  item.name === "New % Limit of Fund AUM"){
					      item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
						 return (
						  (data1[tableMeta.rowIndex][columns1.findIndex(e => e.name === "Modify Percentage Limit")]!==undefined && data1[tableMeta.rowIndex][columns1.findIndex(e => e.name === "Modify Percentage Limit")]==="true")?(<label className='TxtNrml' style={{ background: 'yellow', textAlign: "left"}}>{value}</label>):(<div>{value}</div>)
						 );
					       }
					     }
					   })
					   //console.log(" mar 12, 2019 defaultColChecked:::",defaultColChecked);
	  			}
				// cell prop end
				console.log("mar 11, 2019 data1::::",data1);

				if(data1!==undefined && data1.length!==0)
					rowCnt=data1.length;
				options = {
					filterType: "dropdown",
					selectableRows: false,
					pagination: true,
					rowsPerPage: 10,
					responsive: "scroll",
					fixedHeader: false,
					filter:true,
					search:true,
					print:true,
					download:true,
					viewColumns:true,
				};

    			console.log("MMF Relationship Credit Reporting field values::",commonData);
				if(commonData !== undefined && commonData.length !== 0 && noDataFlag === "false")
				{
  					if(screenLinkImage!== undefined && (screenLinkImage === "CLINVPOL" || screenLinkImage === "NOTIFICATIONS")) {
  					  editBtn="";
  					  subBlk="";
  					  firstBtn="";
  					  secondBtn="";
					  thirdBtn="";
  					   mcProcessFlag=commonData.mcProcessFlag;
  					   policyExists=commonData.policyExists;
  					   lmtFundMsg=commonData.lmtFundMsg;
  					   messageTxt=commonData.message;
					    msgTxt = <div style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">{messageTxt==="empty"?"":messageTxt}</div>
   					  //alert("*** below block in display block of popup..policyExists::"+policyExists);
						msgAmtLmtPerLmt="";
						if(screenLinkImage!== undefined && screenLinkImage === "CLINVPOL")
						{
						  msgAmtLmtPerLmt=<div className="form-group"><div className="form-group col-md-12 col-sm-12"><Info style={{float:'left'}}/><span className="pull-left fntsm" style={{marginTop:'5px'}}>{lmtFundMsg}</span></div></div>
						}
						verifyBtn=<Button  onClick={this.handleVerify} color="primary">Verify</Button>
						if(screenLinkImage!== undefined && (screenLinkImage === "CLINVPOL")) {
						editLnk	= <a href="#" className="btn btn-primary btn-xs mt" onClick={e => this.editInvestPolicy()}>Edit Investment Policy</a>
						firstBtn	= <button className="btn btn-primary btn-xs mt pull-right" onClick={e => this.routeChange()}>Investment Policy Report</button>
						}
						if(policyExists!== undefined && policyExists === "true"){
						 secondBtn	= <button className="btn btn-primary btn-xs mt pull-right" onClick={this.viewChangeHistory.bind(this,"paper")}>View Change History</button>
						}else{
						  secondBtn="";
						}

						if(messageTxt === "Approved Successfully"){
						   statusTxt=resultConstants.CHGAPPR;
						}
						//alert("display block ...statusTxt::"+statusTxt);
 						if(mcProcessFlag!== undefined && mcProcessFlag === "true")
						{
							if(messageTxt === "Waiting for Approval"){
								approveBtn=<Button  onClick={this.handleApprove} color="primary">Approve</Button>
								rejectBtn=<Button  onClick={this.handleReject} color="primary">Reject</Button>
							}
						}else{
						 approveBtn="";
						 rejectBtn="";
						}


						tbody = <table className="table table-striped table-bordered" width="100%">
									<tbody>
										<tr>
											<td><label> Policy Name </label></td>
											<td><label> Status </label></td>
										</tr>
										<tr>
											<td><label className="TxtNrml"> {policyName} </label></td>
											<td><label className="TxtNrml"> {statusTxt} </label></td>
										</tr>
									</tbody>
								</table>

  					} else if(screenLinkImage!== undefined && (screenLinkImage === "MMFRECRE" || screenLinkImage === "HOME" || screenLinkImage === "HOMEINBA" || screenLinkImage === "NOTIFICATIONS" )) {
  					verifyBtn="";
 					approveBtn="";
					rejectBtn="";
					messageTxt="";
					msgTxt="";
        				subBlk 		= <FiltersPopUp method={this.doChange} data={data} filterFlag={filterFlag}/>
						editBtn		= <button onClick={e => this.enterTrade('EDITACCOUNT')} className="btn btn-primary btn-xs mt">Edit Account Details</button>
						firstBtn	= <button onClick={e => this.enterTrade('TRADEENTRY')} className="btn btn-primary btn-xs mt pull-right">Enter Trade</button>
						secondBtn	= <button onClick={e => this.enterTrade('CLOSEACCOUNT')} className="btn btn-primary btn-xs mt pull-right">Close this account</button>
						thirdBtn	= <button onClick={e => this.enterTrade('TRADEHISTORY')} className="btn btn-primary btn-xs mt pull-right">Trade History</button>

						tbody = <table className="table table-striped table-bordered" width="100%">
									<tbody>
										<tr>
											<td><label> Client Name: </label><label className="TxtNrml"> {commonData.clientName} </label></td>
											<td><label> Product: </label><label className="TxtNrml"> {commonData.product} </label></td>
											<td><label> Account: </label><label className="TxtNrml"> {commonData.account} </label></td>
										</tr>
										<tr>
											<td><label> Nav : </label><label className="TxtNrml"> {commonData.nav} </label></td>
											<td><label> Balance: </label><label className="TxtNrml"> {commonData.balance === "Pending"?commonData.balance:addCommaDV(commonData.balance,userLocale,"2","2")} </label></td>
											<td><label> Shares: </label><label className="TxtNrml"> {commonData.shares} </label></td>
										</tr>
										<tr>
											<td><label> Currency : </label><label className="TxtNrml"> {commonData.currency} </label></td>
											<td><label> Dividend Payment: </label><label className="TxtNrml"> {commonData.dividendPayment} </label></td>
											<td><label> Daily Factor: </label><label className="TxtNrml"> {commonData.dailyFactor} </label></td>
										</tr>
										<tr>
											<td><label> Rate : </label><label className="TxtNrml"> {commonData.rate} </label></td>
											<td><label> Posted Date: </label><label className="TxtNrml"> {commonData.postedDate} </label></td>
											<td><label> Fund Type: </label><label className="TxtNrml"> {commonData.fundType} </label></td>
										</tr>
									</tbody>
								</table>
  					}
 				} else {
editBtn		= "";
				  	firstBtn	= "";
				  	secondBtn	= "";
				  	thirdBtn	= "";
					dataFlag	= false;

					tbody = <table className="table table-striped table-bordered" width="100%">
								<tbody>
									<tr>
										<td style={{ color: 'red', textAlignVertical: "center",textAlign: "center", }}  className="col-md-12 col-sm-12">No Data Found</td>
									</tr>
								</tbody>
							</table>
				}
  			}

    		return (
				<div>
					<div>
						<a href="#" onClick={this.handleClickOpen.bind(this,"paper",this.props.rowData)}>{ linkName }</a>
						<Dialog
							open={this.state.open}
							onClose={this.handleClose}
							scroll={this.state.scroll}
							aria-labelledby="scroll-dialog-title"
							fullWidth={true}
							maxWidth = {'md'} >

							<DialogTitle id="scroll-dialog-title"> {title}&nbsp;{editLnk}
								{thirdBtn}
								{secondBtn}
								{firstBtn}
								{editBtn}
								{msgTxt}
 							</DialogTitle>

							<div className="col-md-12" style={{paddingLeft:'24px',marginBottom:'10px'}}>{datatext1}<span style={{backgroundColor:'yellow'}}>{datatext2}</span></div>
							<DialogContent>
								<DialogContentText>
									{tbody}
									<div className="clearfix"></div>
									{msgAmtLmtPerLmt}
									<div className="clearfix"></div>
									{subBlk}
									{
										dataFlag === true ?
										(
											data1 !== undefined ?
											<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
												<MUIDataTable
													title=''
													data={data1}
													columns={columns1}
													options={options} />
											</MuiThemeProvider>
											:
											<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
										)
										:
										<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div></div>
									}
								</DialogContentText>
							</DialogContent>
							<DialogActions>
								{verifyBtn}
								{approveBtn}
								{rejectBtn}
								<Button onClick={this.handleClose} color="primary">Close</Button>
							</DialogActions>
						</Dialog>
					</div>

					<div>
						<Dialog
							open={this.state.openPolicy}
							onClose={this.handlePolicyClose}
							scroll={this.state.scroll}
							aria-labelledby="scroll-dialog-title"
							fullWidth={true}
							maxWidth = {'md'} >

							<DialogTitle id="scroll-dialog-title"> {title}</DialogTitle>
							<DialogContent>
								<DialogContentText>
									{
										dataFlag === true ?
										(
											data1 !== undefined ?
											<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
												<MUIDataTable
													title=''
													data={data1}
													columns={columns1}
													options={options} />
											</MuiThemeProvider>
											:
											<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
										)
										:
										<div  className="col-md-12" style={{color: 'red', marginTop:'10%',marginBottom:'10%'}}>No Records Found</div>
									}
								</DialogContentText>
							</DialogContent>
							<DialogActions>
								<Button  onClick={this.handlePolicyClose} color="primary">Close</Button>
							</DialogActions>
						</Dialog>
					</div>
				</div>
    		);
  		}
}

function mapDispatchToProps(dispatch) {
  return { dispatch };
}

//export default ScrollDialogPopUp;
export default connect(null, mapDispatchToProps)(ScrollDialogPopUp);