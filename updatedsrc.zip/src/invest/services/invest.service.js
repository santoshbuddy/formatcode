import { authHeader,fetchHelper } from '../../_helpers';
import { alertConstants } from '../../common/constants/alert.constants';
import FromData from 'form-data';
export const investService = {
    fetchInvest,
    fetchInvestTable
};

function fetchInvest(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));
    let _investData;
     var pathname = window.location.pathname.replace("/invest/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        //bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        _investData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);

    }
    return _investData;
 }
function fetchInvestTable(bodyFormData) {
    var user = JSON.parse(sessionStorage.getItem('user'));

    let _investTableData;

    var pathname = window.location.pathname.replace("/invest/","")

    if(user[0].token !== undefined){
        bodyFormData.append("token",user[0].token)
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("reactJSActionFlag","GO")
        _investTableData = fetchHelper.httpFormPost(alertConstants.URL+'/'+pathname+'.do',bodyFormData);
    }
    return _investTableData;
}