import React from "react";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import DeleteIcon from "@material-ui/icons/Delete";
import EditIcon from "@material-ui/icons/Edit";
import FilterIcon from "@material-ui/icons/FilterList";
import { withStyles } from "@material-ui/core/styles";
import { Link } from 'react-router-dom';
import { fetchSweepNewruleInfo } from './reduxforms/sweepUtil.js';
import NewIcon from "@material-ui/icons/Addbox";
const defaultToolbarSelectStyles = {
  iconButton: {
    marginRight: "24px",
    top: "50%",
    display: "inline-block",
    position: "relative",
    transform: "translateY(-50%)",
  },
  deleteIcon: {
    color: "#000",
  },
};

let companyId='';
let companyName='';
let prosId='';
let ruleid='';

class SweepToolbarSelect extends React.Component {
		constructor () {
		super()
        this.state = {
					selectedRows:[],
          };
        }
  handleClick = () => {
	  let ids=[];
	  let rowData=[];
	  this.props.displayData.map((disdata,index) => {
	  this.props.selectedRows.data.map((row,index) => {
	  if(row.dataIndex === disdata.dataIndex){
		   if(!ids.includes(disdata.data[1])){
	  		rowData.push(disdata.data[4].props.ruleDet);
	  		ids.push(disdata.data[1]);
		}
  		}

	  })
	  })

    console.log("click!", ids); // a user can do something with these selectedRow values
      this.setState({selectedRows:rowData}, () => {
	         this.props.handleDelete(this.state);
      });
  }

 handleEditClick = () => {

	  let ids=[];
		let rowData=[];

	  this.props.displayData.map((disdata,index) => {
	  this.props.selectedRows.data.map((row,index) => {
	  if(row.dataIndex === disdata.dataIndex){
		   if(!ids.includes(disdata.data[1])){
 	  		  companyId=disdata.data[0];
			  ruleid=disdata.data[1];
				prosId=disdata.data[2];
			  this.setState({ruleid});
		}
  		}

	  })
		})


    console.log("handleEditClick click ruleid !"+ ruleid); // a user can do something with these selectedRow values
   }


  render() {

   		 const { classes } = this.props;
		if(this.props.selectedRows){
		let ids=[];
		let rowData=[];
		this.props.displayData.map((disdata,index) => {
		this.props.selectedRows.data.map((row,index) => {
		if(row.dataIndex === disdata.dataIndex){
		   if(!ids.includes(disdata.data[1])){
			  companyId=disdata.data[0];
			  ruleid=disdata.data[1];
			  prosId=disdata.data[2];
		}
		}
		})
		})
	 }

	 let compItem;
		if(this.props.filterData !== undefined){
			this.props.filterData.map((filter,index) => {
					if(filter.name && filter.name === "companyId"){
						if(filter.values !== undefined){
							compItem = filter.values.find(e => e.id===companyId);
							if(compItem)
								companyName = compItem.name;
						}
					}
			})
		}


	 let redirectPath, fromPage;
	 fromPage = this.props.fromPage;
	 if(fromPage && fromPage == "CNEWRULE"){
		redirectPath = '/report/CNEWRULE';
	 } else if(fromPage && fromPage == "MNEWRULE"){
		redirectPath = '/report/MNEWRULE';
	 } else {
		redirectPath = '/report/LNEWRULE';
	 }
	 console.log("this.props.fromPage:::"+this.props.fromPage+"::::"+redirectPath);
     return (
      <div className={"custom-toolbar-select"}>

        {(this.props.selectedRows.data.length === 1)?
	          <Link   to={{ pathname: redirectPath, state: { companyId: companyId, companyName: companyName, fromPage: fromPage} }} >
	         <Tooltip title={"Add"}>
			          <IconButton className={classes.iconButton}>
			         	<NewIcon className={classes.addIcon} />
			          </IconButton>
	        </Tooltip>
        </Link>:""}

        <Tooltip title={"Delete"}>
          <IconButton className={classes.iconButton} onClick={this.handleClick}>
            <DeleteIcon className={classes.deleteIcon} />
          </IconButton>
        </Tooltip>
        {(this.props.selectedRows.data.length === 1)?
          <Link   to={{ pathname: redirectPath, state: { companyId: companyId, companyName: companyName, ruleid:ruleid, fromPage: fromPage} }} >
         <Tooltip title={"Edit"}>
		          <IconButton className={classes.iconButton} onClick={this.handleEditClick}>
		         <EditIcon className={classes.deleteIcon} />
		          </IconButton>
        </Tooltip>
        </Link>:""}
      </div>
    );
  }

}

export default withStyles(defaultToolbarSelectStyles, { name: "CustomToolbarSelect" })(SweepToolbarSelect);