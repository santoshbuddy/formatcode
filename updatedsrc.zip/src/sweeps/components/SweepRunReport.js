import React from 'react';
import { Route } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { sweepsActions } from '../actions/sweeps.actions';
import { connect } from 'react-redux';
import RunReportFilters from './RunReportFilters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import RuleDetails from './RuleDetails';
import MUIDataTable from "mui-datatables";
import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import classnames from 'classnames';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import Grid from '@material-ui/core/Grid';
import PropTypes from 'prop-types';
import FailedTradeToolbarSelect from './FailedTradeToolbarSelect';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import FormData from 'form-data';
import RefreshIcon from "@material-ui/icons/Refresh";
import Loading from '../../common/Loading';
import TableLoader from '../../common/TableLoader';

let formdata ={};
let isFilterLoaded=false;
let reactJSActionFlag='';
Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });
  const styles = theme => ({
  iconButton: {
    marginRight: "24px",
    top: "50%",
    display: "inline-block",
    position: "relative",
    transform: "translateY(-50%)",
  },
  refreshIcon: {
    color: "#000",
  },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
    },
     formControl: {
    		    marginTop: 0,
    		    minWidth: 120,
    		     fontSize: 11,
    		  },
    		  formControlLabel: {
    		    marginTop: 0,
    		     fontSize: 11,
      		},
    	  button: {
    	    margin: theme.spacing.unit,
    	     fontSize: 11,
  	  },
});

  const cols = [
  {
  name: "Rule Name",
       options: {
        filter: true,
        sort: true,
          customBodyRender: (value, tableMeta, updateValue) => {
	       	                 return (
	       	                  <Tooltip title={value} placement="right">
  	        			<a href="#">{value}</a>
	       	            	</Tooltip>
	       	                   );
   	 }
    	}
   },
   {
    name: "Product Name",
          options: {
           filter: true,
           sort: true,
             customBodyRender: (value, tableMeta, updateValue) => {
	          	                 return (
	          	                  <Tooltip title={value} placement="right">
	          	                   <a href="#">{value.substring(0,10)}</a>

	          	            	</Tooltip>
	          	                   );
   	 }
       	}
   },
   {
    name: "Investment Account Number",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Account Number",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "DA Account Number",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Approval",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Rule Mode",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Rule Type",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Excetution Date",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Excetution Time",
          options: {
           filter: true,
           sort: true,

       	}
   },{

    name: "Number of times Sweep Failed",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Last Sweep run report time",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Time Before Cut-Off(mins)",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Status",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Available Balance Source",
          options: {
           filter: true,
           sort: true,

       	}
   },{
    name: "Last Updated Available Balance",
          options: {
           filter: true,
           sort: true,

       	}
   },{

    name: "As Of:",
          options: {
           filter: true,
           sort: true,

       	}
   },
   ];
class SweepRunReport extends React.Component {

 getMuiTheme = () => createMuiTheme({
 		    typography: {
		                                               useNextVariants: true,
		                },
		          overrides: {

		               MuiFormControl: {
		                                    marginNormal: {
		                                        marginTop: '0px',
		                                         marginBottom: '0px',
		                                     }
		            }, MuiIconButton: {
		                                    root: {
		                                        padding: '2px',
		                                     }
		            },
		            MuiTableCell: {
		                root:{
		                  padding: '6px !important',
		                },
		                head: {
		                  fontSize: '0.8rem',
		                  fontWeight: '600',
		                }
		              },
		              MuiTableRow:{
		                  head : {
		                      height: '20px !important',
		                  }
		              },
		              MUIDataTableSelectCell:{
		                  headerCell: {
		                          border: "1px solid #ccc",
		                          align : 'center',
		                          height: '16px !important',
		                          padding: '0px !important',
		                          backgroundColor: "#f4f3f3",
		                  }
		              },
		            MUIDataTableHeadCell: {
		                  root: {
		                          border: "1px solid #ccc",
		                          textAlign : 'center',
		                          color: "blue",
		                          height: '16px !important',
		                          padding: '0px !important',
		                          whiteSpace:'noWrap',
		                       },
		                       fixedHeader :{
		                          backgroundColor: "#f4f3f3",
		                       }
		            },
		            MUIDataTableBodyCell: {
		              root: {
		                  whiteSpace: 'nowrap',
		                  padding:'0px 0px 0px 4px'
		               }
		            },
		            MUIDataTableBodyRow: {
		                        root: {
		                            height: '16px !important',
		                         }
		            },
		          }
		    });


     constructor(){
        super();
        this.state={
            results:[],
            results1:[],
            data:[],
            sweepstunreportdata:[],
            sweepstunreporttabledata:[],
            columns:[],
            screenName:'',
            selected: {},
            selectAll: 0
        }
        this.doChange = this.doChange.bind(this);
        this.handleChildUpdate = this.handleChildUpdate.bind(this);
		this.handleRefresh = this.handleRefresh.bind(this);

    }    
    componentWillMount(){
 	isFilterLoaded=false;
    }
    componentDidMount() {
 	isFilterLoaded=false;
        this.getFilter()
   }
    componentDidUpdate() {
    if(reactJSActionFlag === 'GO'){
    	isFilterLoaded=true;
    }else{
    	isFilterLoaded=false;
    }
     }
   
   getFilter(){
    reactJSActionFlag='';
    this.props.dispatch(sweepsActions.fetchSweepRunReportData());
   }

    handleChildUpdate(formdataObj){
      	 formdata=formdataObj ;
         console.log('handleChildUpdate :'+JSON.stringify( formdata	));
     }
   doChange(fillObj){
        var bodyFormData = new FormData();
        bodyFormData.append("reactJSActionFlag", "GO");
        reactJSActionFlag='GO';
        for (name in fillObj) {
            bodyFormData.append(name, fillObj[name]);
        }
        this.props.dispatch(sweepsActions.fetchSweepRunReportTableData(bodyFormData));

   }
	handleRefresh(){
		 var bodyFormData = new FormData();
        for (name in formdata) {
            bodyFormData.append(name, formdata[name]);
        }
		 this.props.dispatch(sweepsActions.fetchSweepRunReportTableData(bodyFormData));

     }
    render(){

           const { classes } = this.props;
 	   const { sweepstunreportdata,sweepstunreporttabledata } = this.props;
 	 if(sweepstunreportdata.sweepstunreportdata !== undefined){

	           let results1 =[];
	               if(!isFilterLoaded && sweepstunreportdata && sweepstunreportdata){
	            results1=  sweepstunreportdata.sweepstunreportdata;
	               isFilterLoaded=true;
	             if(sweepstunreportdata.sweepstunreportdata !== undefined){
	             sweepstunreportdata.sweepstunreportdata.map((filter,index) => { formdata[filter.name]=filter.fieldValue; });
			}
			 else{
				    return(
					<Loading />
				    )
        		}
				}else {
				results1=  sweepstunreporttabledata.sweepstunreporttabledata;

				}

				let screenName="";
				let msg="";
				let msgType="success";
				let results = [];
		 		if( results1)
		             results1.map((item,index) => {
		                if(item.type === "Title")
		                  screenName = item.name

						 if(item.type === "Message"){
		                  msg = item.name;
		                  msgType =item.label;
					  	}

		                if(item.name === "data")
		                 results = item.values
		            })

	 console.log('data<>--- :'+JSON.stringify(sweepstunreportdata.sweepstunreportdata));
		           let data=[];
					if(results && results.length>0){
					 results.map(row => {
					let cdata=[];
					cdata.push(row.PLANNAME);
					cdata.push(row.DESCR);
					cdata.push(row.ACCOUNT);
					cdata.push(row.SWPACCTNAME);
					cdata.push(row.DDAACCTNAME);
					cdata.push(row.APPROVAL);
					cdata.push(row.RULEMODEDESC);
					cdata.push(row.TRANSTYPEDESC);
					cdata.push(row.EXECDATE);
		 			cdata.push(row.CUTOFF);
					cdata.push(row.FAILCNT);
					cdata.push(row.MODIFIEDDATE);
					cdata.push(row.EXECTIME);
					cdata.push(row.STATUS);
					cdata.push(row.AVAILBALCALL);
					cdata.push(row.DDABAL);
					cdata.push(row.ASOF);
					data.push(cdata);
					})
	{data}
	   console.log('data<>-22-- :'+data);

	}
const options = {
	  viewColumns:false,
      filter: true,
      filterType: 'dropdown',
      responsive: 'stacked',
       responsive: 'scroll',selectableRows:false,
       setRowProps: (row, rowIndex) => {
                     let rem = rowIndex % 2;
                       if(rem === 0){
                     return {
                             style: { backgroundColor: '#fff'}
                         };
                       }else {
                         return {
                             style: { backgroundColor: '#f7f8f9'}
                     };
                       }
      },
	textLabels: {
            body: {
                noMatch: this.props.sweepstunreporttabledata.loading ?
                    <TableLoader /> :
                   <div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center'}}> <b key={'2'}>No Rules are available under Selected Company</b></div>,
            },
        },
    };

        // const columns1 = ["Name", "Company", "City", "State"];

        // const data1 = [
        //  ["Joe James", "Test Corp", "Yonkers", "NY"],
        //  ["John Walsh", "Test Corp", "Hartford", "CT"],
        //  ["Bob Herm", "Test Corp", "Tampa", "FL"],
        //  ["James Houston", "Test Corp", "Dallas", "TX"],
        // ];
        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">Sweep Run Report</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
                            <RunReportFilters handleUpdate={this.handleChildUpdate} method={this.doChange} data={sweepstunreportdata} reactJSActionFlag={reactJSActionFlag}/>
                            </div>
                        </div>

                        <div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                                </div>
                            </div>
                             <MuiThemeProvider theme={this.getMuiTheme()}>
							<MUIDataTable
			    					data={data}
			    					columns={cols} options={options} viewColumns={false}/>
			</MuiThemeProvider>



                        </div>
                    </div>
                </div>
            </div>
        );
        }
	    else
	    {
		return(
		    <Loading />
		)
    }
    }
}

SweepRunReport.propTypes = {
  classes: PropTypes.object.isRequired,
};
function mapStateToProps(state) {
    const { sweepstunreportdata,sweepstunreporttabledata } = state;
     return { sweepstunreportdata,sweepstunreporttabledata };
}

const connectedSweepRunReport = connect(mapStateToProps)((withStyles(styles))(SweepRunReport));
export { connectedSweepRunReport as SweepRunReport };
