import React from 'react';
import { Route } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { sweepsActions } from '../actions/sweeps.actions';
import { connect } from 'react-redux';
import SweepsManualFilters from './SweepsManualFilters';
import { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import FormData from 'form-data';
import MUIDataTable from "mui-datatables";
import RuleDetails from './RuleDetails';
import SweepToolbarSelect from './SweepToolbarSelect';
import RFPSnackbars from '../../messages/RFPSnackbars';
import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import classnames from 'classnames';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import NewIcon from "@material-ui/icons/Addbox";
import Loading from '../../common/Loading';
import TableLoader from '../../common/TableLoader';

let reactJSActionFlag='';

const customStyles = {
  RuleNameRow: {
    '& td': {height: "16px !important"}
  },
  NameCell: {
    fontWeight: 900
  },iconButton: {
    marginRight: "24px",
    top: "50%",
    display: "inline-block",
    position: "relative",
    transform: "translateY(-50%)",
  },
   addIcon: {
      color: "#000",
  }
};

let formdata ={};
let companyName = '';
Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });

  const cols = [
  {
    name: "companyId",
    options: {
	display: false,
	sort: false,
	download: false,
	filter: false,
    }
   }, {
    name: "ruleId",
    options: {
	display: false,
	sort: false,
	download: false,
	filter: false,
    }
   },
   {
     name: "procsId",
     options: {
      	display: false,
	  	sort: false,
	  	download: false,
	  	filter: false,

     }
   },
   {
     name: "ruleChk",
     options: {
      	display: false,
	  	sort: false,
	  	download: false,
	  	filter: false,

     }
   },
   {
     name: "Rule Name",
     options: {
      filter: true,
      sort: true,
       customBodyRender: (value, tableMeta, updateValue) => {
  	 	           return (
  	           <RuleDetails  tdVal={value}  filStatus={formdata['filStatus']}   ruleDet={tableMeta.rowData}/>
              );
     }
  	}
   },
   {
    name: "Rule Type",
    options: {
     filter: true,
     sort: true,
    }
   },
   {
    name: "Approval",
    options: {
     filter: true,
     sort: true,
    }
   },{
    name: "Target Balance",
    options: {
     filter: true,
     sort: true,
    }
   },{
     name: "Status",
     options: {
      filter: true,
      sort: true,
     }
   },
   {
    name: "DDA Type",
    options: {
     filter: true,
     sort: true,
    }
   },
    {
     name: "Modify Date",
     options: {
      	display: false,
	  	sort: true,
	  	download: false,
	  	filter: false,
      }
   },
    {
     name: "Modify By",
     options: {
      	display: false,
	  	sort: true,
	  	download: false,
	  	filter: false,
      }
   }
  ];

class ManualSweep extends React.Component {
getMuiTheme = () => createMuiTheme({
 		    typography: {
		                                               useNextVariants: true,
		                },
		          overrides: {
		               MuiFormControl: {
		                                    marginNormal: {
		                                        marginTop: '0px',
		                                         marginBottom: '0px',
		                                     }
		            }, MuiIconButton: {
		                                    root: {
		                                        padding: '2px',
		                                     }
		            },
		            MuiTableCell: {
		                root:{
		                  padding: '0px !important',
		                },
		                head: {
		                  fontSize: '0.8rem',
		                  fontWeight: '600',
		                }
		              },
		              MuiTableRow:{
		                  head : {
		                      height: '20px !important',
		                      backgroundColor: '#f3f3f3',
		                       border: "1px solid #ccc"
		                  }
		              },
		              MUIDataTableSelectCell:{
		                  head: {
		                          border: "1px solid #ccc",
		                          align : 'center',
		                          height: '16px !important',
		                          padding: '0px !important',
		                          backgroundColor: "#f4f3f3",
		                  },
				  fixedHeader:{
					backgroundColor: "transparent",
		                  }
		              },
		            MUIDataTableHeadCell: {
		                  root: {
		                          border: "1px solid #ccc",
		                          textAlign : 'center',
		                          color: "blue",
		                          height: '16px !important',
		                          padding: '0px !important',
		                          whiteSpace:'noWrap',
		                       },
		                       fixedHeader :{
		                          backgroundColor: "#f4f3f3",
		                       }
		            },
		            MUIDataTableBodyCell: {
		              root: {
		                  whiteSpace: 'nowrap',
		                  padding:'0px 0px 0px 4px'
		               }
		            },
		            MUIDataTableBodyRow: {
		                        root: {
		                            height: '16px !important',
		                         }
		            },
		          }
		    });
    constructor(){
        super();
        this.state={
            results:[],
            results1:[],
            data:[],
            sweepsmanualdata:[],
            sweepsmanualdatatable:[],
             columns:[],
            screenName:'',
            selected: {},
            selectAll: 0,
            selectedRows:[],
            fromPage:'MNEWRULE',
        }
        this.doChange = this.doChange.bind(this);
         this.handleChildUpdate = this.handleChildUpdate.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.addNewTrade = this.addNewTrade.bind(this);

    }
    componentWillMount() {
             this.getFilter()
    }

    getFilter(){
	reactJSActionFlag='';
    this.props.dispatch(sweepsActions.fetchSweepManualData());
   }
	handleChildUpdate(formdataObj){
  	 formdata=formdataObj ;
     }
     addNewTrade(){
        if (window.confirm('Are you sure, you want to add a new rule?')){
           this.props.history.push({pathname:'/report/MNEWRULE',state:{fromPage :this.state.fromPage, companyName: companyName}});
        }
     }

		handleDelete(selectedRows){
			  this.setState({
				selectedRows:selectedRows
			  });
			  if(selectedRows.selectedRows.length>0){
				  let deleteRows=selectedRows.selectedRows;

			var bodyFormdata = new FormData();
			bodyFormdata.append("reactJSActionFlag", "GO");
			reactJSActionFlag='GO';
			for (name in formdata) {

				bodyFormdata.append(name, formdata[name]);

			 }
			bodyFormdata.append('fromPage','MANUALSWEEP') ;
			bodyFormdata.append('actionFlag','DELETE') ;



    		deleteRows.map((deleteRec,index) => {
 					bodyFormdata.append('ruleChk'+index,'Y') ;
 					bodyFormdata.append('ruleId'+index,deleteRec[1]) ;
					bodyFormdata.append('procsId'+index,deleteRec[2]) ;

			  })
		  bodyFormdata.append('rulesSize',''+ deleteRows.length) ;
		//    console.log('handleDelete this.state.selectedRows.length :'+JSON.stringify( deleteRows.length	));
		 this.props.dispatch(sweepsActions.fetchSweepManualTableData(bodyFormdata));
		//  formdata['filStatus']='N' ;
	 }

     }

   doChange(fillObj){
            var bodyFormData = new FormData();
          bodyFormData.append("reactJSActionFlag", "GO");
          reactJSActionFlag='GO';
        for (name in fillObj) {
			console.log(name+'<<<<>>>>>'+fillObj[name]);
            bodyFormData.append(name, fillObj[name]);
         }
      			 this.props.dispatch(sweepsActions.fetchSweepManualTableData(bodyFormData));
   }

    render(){

		const { classes } = this.props;
        const { sweepsmanualdata,sweepsmanualdatatable } = this.props;
         let data=[];
					let screenName="";
					let msg="";
					let msgType="success";
			let results = [];
	   if((sweepsmanualdata && sweepsmanualdata.sweepsmanualdata) !== undefined ||
	   	(sweepsmanualdatatable && sweepsmanualdatatable.sweepsmanualdatatable !== undefined)){
           let results1 =[];
           let compItem;

 	    if(reactJSActionFlag === 'GO'){
			if(sweepsmanualdatatable.sweepsmanualdatatable)
			results1=  sweepsmanualdatatable.sweepsmanualdatatable;

	    }else  if(sweepsmanualdata.sweepsmanualdata !== undefined){

					results1=  sweepsmanualdata.sweepsmanualdata;
					sweepsmanualdata.sweepsmanualdata.map((filter,index) => {
					formdata[filter.name]=filter.fieldValue;
                    if(filter.name && filter.name === "companyId"){
                        if(filter.values !== undefined){
                            compItem = filter.values.find(e => e.id===filter.fieldValue);
                            if(compItem)
                                companyName = compItem.name;
                        }
                    }
                });
		    } else{
			    return(
				<Loading />
			    )
		    }

            //console.log("results1::33333::"+JSON.stringify(results1));

	 		if( results1 && results1.length>0){
	             results1.map((item,index) => {
	                if(item.type === "Title")
	                  screenName = item.name

					 if(item.type === "Message"){
	                  msg = item.name;
	                  msgType =item.label;
				  	}

	                if(item.name === "data")
	                 results = item.values
	            })



				if(results && results.length>0){
				 results.map(row => {
                let cdata=[];
				cdata.push(row.COMPANYID);
				cdata.push(row.RULEID);
				cdata.push(row.PROCESSID);
				cdata.push(row.DISABLE);
				cdata.push(row.RULENAME);
				cdata.push(row.RULETYPE);
				cdata.push(row.APPROVAL);
			        var nf = new Intl.NumberFormat();
 			        cdata.push(nf.format(row.TARGETBAL));
				cdata.push(row.STATUS);
				cdata.push(row.DDATYPE);
	 			cdata.push(row.MODIFIEDDATE);
				cdata.push(row.MODIFIEDBY);
				data.push(cdata);
				})
			}
		}
       let addtradebtn;
	          addtradebtn =
	          <Route render={({ history}) => (

	             <Tooltip title={"Add"}>
	             <IconButton className={classes.iconButton} onClick={this.addNewTrade} >
	  					 <NewIcon className={classes.addIcon} />
	  				  </IconButton>
	  		 	</Tooltip>
        )} />

console.log('formdata[ filStatus ]'+formdata['filStatus']);
 const options = {
	  viewColumns:false,
      filter: true,
      filterType: 'dropdown',
      responsive: 'stacked',
      selectableRows: formdata['filStatus']=== 'Y'?true:false,
      setRowProps: (row, rowIndex) => {
        let rem = rowIndex % 2;
          if(rem === 0){
        return {
                style: { backgroundColor: '#fff'}
            };
          }else {
            return {
                style: { backgroundColor: '#f7f8f9'}
        };
          }
      },
      customToolbarSelect: (selectedRows, displayData, setSelectedRows) =>   <SweepToolbarSelect handleDelete={this.handleDelete} selectedRows={selectedRows} displayData={displayData} setSelectedRows={setSelectedRows} fromPage={this.state.fromPage} filterData={sweepsmanualdata.sweepsmanualdata}/>
		,textLabels: {
            body: {
                 noMatch: this.props.sweepsmanualdatatable.loading ?
                    <TableLoader /> :
                       <div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center'}}> <b key={'2'}>No Rules are available under Selected Company</b></div>,
            },
        },
    };



        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">Manual Sweep</h4>
                    </div>
                     <div className="clearfix"></div>
                     <div  >
 					       {(msg && msg !== "") ?(<div style={{fontSize: 12, color: '#c30000' ,textAlign: 'center'}}> <b>{msg}</b></div>):''}
                    </div>

                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls" style={{backgroundColor:'#FFF'}}>
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
                            <SweepsManualFilters handleUpdate={this.handleChildUpdate} method={this.doChange} data={sweepsmanualdata} formdata={formdata} reactJSActionFlag={reactJSActionFlag}/>
                            </div>
                        </div>

                        <div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                                </div>
                            </div>
                              <MuiThemeProvider theme={this.getMuiTheme()}>
							<MUIDataTable title={formdata['filStatus'] === 'Y'?addtradebtn:''}
							data={data}
							columns={cols} options={options} viewColumns={false}/>
							</MuiThemeProvider>
                         </div>
                    </div>
                </div>
            </div>
        );
        }
	    else
	    {
		return(
		    <Loading />
		)
    	    }
    }
}

function mapStateToProps(state) {
 	const { sweepsmanualdata,sweepsmanualdatatable } = state;
    return { sweepsmanualdata,sweepsmanualdatatable};
}

const connectedManualSweep = connect(mapStateToProps)((withStyles(customStyles))(ManualSweep));
export { connectedManualSweep as ManualSweep };
