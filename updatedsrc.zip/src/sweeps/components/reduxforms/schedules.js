import React from 'react'
import { Field } from 'redux-form'
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

import  Paper from '@material-ui/core/Paper';
import DatePicker from 'react-datepicker'; 
import 'react-datepicker/dist/react-datepicker.css'; 

import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import RadioGroup from '@material-ui/core/RadioGroup';
import Radio from '@material-ui/core/Radio';
import FormLabel from '@material-ui/core/FormLabel';
import { Route } from 'react-router-dom';  
import MaintainRulesSchedulesViewChanges from './MaintainRulesSchedulesViewChanges';
  
  const styles = theme => ({
    root: {
      ...theme.mixins.gutters(),
      paddingTop: theme.spacing.unit * 2,
      paddingBottom: theme.spacing.unit * 2,
      backgroundColor: '#f4f3f3',
      border : '1px solid #ccc'
    },
    paper: {
      padding: theme.spacing.unit * 2,
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    table: {
        minWidth: 1000,
      },
    tableWrapper: {
        overflowX: 'auto',
      },
      row: {
        '&:nth-of-type(odd)': {
          backgroundColor: theme.palette.background.default,
        },
      },
      label: {
        fontSize: '12px',
      },
      insrt:{
        fontSize:'10px',
        color: '#666666',
        fontFamily: 'arial,helvetica,sans-serif',
      },
      radio:{padding:'0px 3px 3px 10px !important', 
      height: 20, size: 6}
  });
  
  const renderTextField = ({
    label,
    input,
    meta: { touched, invalid, error },
    ...custom
  }) => (
    <TextField
      label={label}
      placeholder={label}
      error={touched && invalid}
      helperText={touched && error}
      variant="outlined" 
      inputProps={{
        style: {textAlign: "left", padding : 0, width: 120,
        height: 20, fontSize: 12}
      }}    
      {...input}
      {...custom}
    />
  )

  

  const renderRadioGroup = ({ input, ...rest }) => (
    <RadioGroup
      {...input}
      {...rest}
      value={input.value}
      onChange={(event, value) => input.onChange(value)}
      row
    />
  )

let redirectPath,sfromPage, sactionFlag, saveLable,companyId,ruleId,parentId,fromDate;
class ScheduleBlock extends React.Component {

    constructor(props) {
        super(props); 
     this.state = {
	 value: 0,        
	 ck:'' ,    
	 ViewChangesbtn: false,
        }
        this.doViewChanges = this.doViewChanges.bind(this);
    }
       
   	doViewChanges(){
		this.setState({ViewChangesbtn:true})
	}

	doClose = () =>{
		this.setState({ViewChangesbtn:false})
	}   
    render(){ 
        const {classes } = this.props
        const tblStyle  = {width: "1200px"};
        const grpStyle  = {height: "10px"};
	
        //if(!sfromPage)
        sfromPage = this.props.fromPage;  
        companyId = this.props.companyId;  
        ruleId 	  = this.props.ruleid;
        parentId  = this.props.parentId;
        fromDate  = this.props.fromDate;        
        if(sfromPage && sfromPage == "CNEWRULE"){
              redirectPath = '/report/CMNTRULE';
            if(this.props.saveFlag === "start"){
                saveLable ="Processing...";
            }else {
                saveLable = "Save";	
            }   
         } else if(sfromPage && sfromPage == "MNEWRULE"){
              redirectPath = '/report/MSWEEP';
            if(this.props.saveFlag === "start"){
                saveLable ="Processing...";
            }else {
                saveLable = "Run";	
            } 
         } else {
              redirectPath = '/report/LSWEEP';
            if(this.props.saveFlag === "start"){
                saveLable ="Processing...";
            }else {
                saveLable = "Run";	
            } 
         }
       
        sactionFlag = this.props.actionFlag;
      
  let backtotradebtn; 
  let tradesubmitbtn; 
  tradesubmitbtn =
        <Route render={({ history}) => (
            <button  className="btn btn-primary btn-xs"
                type='submit'               
            >
            {saveLable}
          </button> 
        )} />
  backtotradebtn =
        <Route render={({ history}) => (
            <button  className="btn btn-primary btn-xs"
                type='button'
                onClick={() => { history.push({pathname : redirectPath}) }}
            >Back</button> 
        )} />

      
        const omsTRowStyle  = { height: "14px", width: "60px", padding: "0px", textAlign:"center"};
        const omsTColStyle  = { height: "14px", width: "60px", padding: "2px"};
    return (	
      <Paper  className={classes.root} >
    <Paper  className={classes.root} elevation={1}>
      <div className="panel">
            <div className="panel-heading clearfix">
                    <h4 className="panel-title pull-left col-md-1">Scheduling Details</h4>
             </div>
      </div>
     <div className="clearfix"></div>    
       <div className="form-group"  >      
      <div className="form-group col-md-3 col-sm-3" >     
      <FormLabel className={classes.label} >From Date:</FormLabel>
      </div>
      <div className="form-group col-md-2 col-sm-2" >
      <Field 
              name="fromDate" 
              component={'input'} 
              type = 'date'
              dateformat={'MMM dd, yyyy'}
              />
      
      </div>
      <div className="form-group col-md-2 col-sm-2" >       
      <FormLabel  className={classes.label}>To Date:</FormLabel> 
      </div>
      <div className="form-group col-md-2 col-sm-2" >  
      <Field 
              name="toDate" 
              component={'input'} 
              type = 'date'
              dateformat={'MMM dd, yyyy'}
              />
      </div> 
      <div className="form-group col-md-3 col-sm-3" >    </div>
      
      </div>
      <div className="clearfix"></div>
      <div className="form-group"  >
      <div className="form-group col-md-3 col-sm-3" >
      <FormLabel  className={classes.label}>Time Before Cut-off (mins):</FormLabel>
      </div>
      <div className="form-group col-md-4 col-sm-4" >
      <Field name="execTime" component={renderTextField} label="" /> <span style={{color: 'red', paddingRight: '5px'}}>*</span>     
      </div>
      <div className="form-group col-md-4 col-sm-4" ></div>
      </div>
      <div className="clearfix"></div>
      <div className="form-group" >
          <div className="form-group col-md-12 col-sm-12 ">
          <span className= {classes.insrt} > <img src={require('../../../images/icon_instruction.gif')} alt="instruction" />
         &nbsp; If To Date is not entered, then Schedule will have no end date. </span>
			    </div>
      </div>      
      <div className="clearfix"></div>
      <div className="form-group" >
      <div className="form-group col-md-2 col-sm-2" >
      <FormLabel  className={classes.label}>Schedule Type:</FormLabel>
      </div> 
      <div className="form-group col-md-10 col-sm-10" >
      <Field name="sheduleType" component={renderRadioGroup}>
        <FormControlLabel
                classes={{root: classes.formControlLabelRoot, label: classes.label}}
                value="100"
                control={<Radio color="primary" classes={{root:classes.radio}}/>}
                label="Everyday"
                labelPlacement="end"
                />
            <FormControlLabel
                classes={{root: classes.formControlLabelRoot, label: classes.label}}
                value="101"
                control={<Radio color="primary" classes={{root:classes.radio}}/>}
                label="Weekly"
                labelPlacement="end"
                />
            <FormControlLabel
                classes={{root: classes.formControlLabelRoot, label: classes.label}}
                value="102"
                control={<Radio color="primary" classes={{root:classes.radio}}/>}
                label="Bi-Weekly"
                labelPlacement="end"
                />
            <FormControlLabel
                classes={{root: classes.formControlLabelRoot, label: classes.label}}
                value="103"
                control={<Radio color="primary" classes={{root:classes.radio}}/>}
                label="First Day of the Month"
                labelPlacement="end"
                />
            <FormControlLabel
                classes={{root: classes.formControlLabelRoot, label: classes.label}}
                value="104"
                control={<Radio color="primary" classes={{root:classes.radio}}/>}
                label="Last Day of the Month "
                labelPlacement="end"
                />
            <FormControlLabel
                classes={{root: classes.formControlLabelRoot, label: classes.label}}
                value="105"
                control={<Radio color="primary" classes={{root:classes.radio}}/>}
                label="Specific Day"
                labelPlacement="end"
                />  
             <FormControlLabel
                classes={{root: classes.formControlLabelRoot, label: classes.label}}
                value="106"
                control={<Radio color="primary" classes={{root:classes.radio}}/>}
                label="Specific Date"
                labelPlacement="end"
                />         
        </Field>
      </div> 
      </div>
      <div className="clearfix"></div>
      </Paper>
      <Paper className={classes.root}>
      <div className="panel">
            <div className="panel-heading clearfix">
                    <h4 className="panel-title pull-left col-md-1">Exception Details</h4>
             </div>
      </div>
      <div className="clearfix"></div>
      <div className="form-group" >

      <div className="form-group col-md-2 col-sm-2" >
      <FormLabel  className={classes.label}>Holiday:</FormLabel>   
      </div>        
      <div className="form-group col-md-4 col-sm-4" > 
      <Field name="holiday" component={renderRadioGroup}>
        <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="B"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Before"
            labelPlacement="end"
            />
         <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="A"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="After"
            labelPlacement="end"
            />
         <FormControlLabel
            classes={{root: classes.formControlLabelRoot, label: classes.label}}
            value="S"
            control={<Radio color="primary" classes={{root:classes.radio}}/>}
            label="Skip"
            labelPlacement="end"
            />
        </Field>     
      </div>
      <div className="form-group col-md-6 col-sm-6" ></div> 
      </div> 
      <div className="clearfix"></div>     
      </Paper>
      <div style= {{textAlign: "center", paddingTop: "12px"}}>   
	      {(sactionFlag != undefined && sactionFlag === 'MODIFY') && 	      
		    <a title="View Changes" onClick={(e)=>{this.doViewChanges();}} className="btn btn-primary btn-xs">View Changes 
			{this.state.ViewChangesbtn ?(<MaintainRulesSchedulesViewChanges companyId ={companyId} ruleId ={ruleId} fromDate ={fromDate} open={this.state.ViewChangesbtn} doClose={this.doClose} />):''}
		    </a>	      
	       }
       	       
       		{tradesubmitbtn}
		{backtotradebtn}
      </div>
                <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>
                {this.props.resultMsg}</div>
      </Paper>
        );
    }
}

ScheduleBlock.propTypes = {
    classes: PropTypes.object.isRequired,
  };
  
  export default withStyles(styles)(ScheduleBlock);