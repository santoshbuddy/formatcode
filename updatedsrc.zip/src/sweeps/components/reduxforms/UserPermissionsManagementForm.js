import React from 'react'
import { reduxForm } from 'redux-form'
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import  Paper from '@material-ui/core/Paper'
import asyncValidate from './asyncValidate'
import validate from './validate'
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import { Route } from 'react-router-dom';
import FormData from 'form-data';

import { fetchSweepNewruleInfo } from './sweepUtil.js';
import RulesBlock from './rules';
import ScheduleBlock from './schedules';
import WithLoading  from '../WithLoading';

const RulesBlockWithLoading = WithLoading(RulesBlock);

function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
};

const styles = theme => ({
  root: {
    ...theme.mixins.gutters(),
    paddingTop: theme.spacing.unit * 2,
    paddingBottom: theme.spacing.unit * 2,
  },
  paper: {
    padding: theme.spacing.unit * 2,
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
  table: {
      minWidth: 1000,
    },
  tableWrapper: {
      overflowX: 'auto',
    },
    row: {
      '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.background.default,
      },
    },
});


class UserPermissionsManagement extends React.Component {
  constructor(){
    super();
    this.state={
        sweepsnewrules:[],
        rulesnewdata: [],
        tabIndex: 0,
        loading: false,

    }
}
componentWillMount () {
  console.log("4444444444444444");
   this.getFilter();

}
getFilter(){
  this.setState({ loading: true });
  var bodyFormdata = new FormData();

  console.log(' ruleid#####:'+ this.props.ruleid);
  console.log(' companyId#####:'+ this.props.companyId);
  let editrule = '';
  let companyId = '';

  if(this.props.ruleid){
    bodyFormdata.append("ruleid", this.props.ruleid);
    editrule = this.props.ruleid;
    bodyFormdata.append("actionFlag", "MODIFY");
  }else {
    bodyFormdata.append("ruleid", "");
    bodyFormdata.append("actionFlag", "ADD");
  }
  if(this.props.companyId){
    bodyFormdata.append("companyId", this.props.companyId);
    companyId = this.props.companyId;
  }else {
    bodyFormdata.append("companyId", JSON.parse(sessionStorage.getItem('clientFirm')));
    companyId = JSON.parse(sessionStorage.getItem('clientFirm'));
  }
  bodyFormdata.append("modifyFlag", "MODIFY");
  bodyFormdata.append("filStatus", "Y");
  bodyFormdata.append("rulesSize", "1");
  bodyFormdata.append("reports_length", "10");
  bodyFormdata.append("currency", "USD");
  bodyFormdata.append("eodDate", "Apr 18, 2018");

  fetchSweepNewruleInfo(bodyFormdata)
  .then(response => {
      console.log(' response#####:'+JSON.stringify(response));
      if(response && response.ruleDet){
        this.buildIntialJson(response, companyId);
      }else {
        console.log(' before doDummy:');
        this.doDummy(editrule, companyId);
      }
      this.props.initialize(this.state.rulesnewdata);
      this.setState({ loading: false, sweepsnewrules: response });

  }).catch(error => {
      if(error.status === 401) {
         // this.props.handleLogout('/login', 'error', 'You have been logged out. Please login create poll.');
         console.log('You have been logged out. Please login create poll.');
        } else {
        console.log('Sorry! Something went wrong. Please try again!');
      }
  });
}

buildIntialJson(response, companyId){

  console.log('buildIntialJson:'+companyId);

  var initJson = new Object();

  if(response){
    initJson.accountRule = "S";
    initJson.actionFlag = "SAVE";
    initJson.modifyFlag = "MODIFY";

    initJson.product0 = "1700";
    initJson.issueChild0 = "28029897";
    initJson.currency = "EUR";
    initJson.swpRefActNbr0 = "7012000012";
    initJson.sweepAcctName0 = "Sweep Fund Account";
    initJson.Omnibus = "Omnibus";
    initJson.parentDDAAccount0 = "3528360639360069";
    initJson.dividendAccount0 = "101";
    initJson.dpoold0 = "N";
    initJson.dividendType0 = "100";
    initJson.amtorPer0 = "1";
    initJson.availRules0 = "yuuuu , Test Rule21 , 234234234";
    initJson.maxAmt0 = "";

    initJson.availShares0 = "0.000";
    initJson.nav0 = "1.00";
    initJson.decimalCnt0 = "4";
    initJson.roundType0 = "4";
    initJson.value0 = "";

    initJson.principalAmt0 = "0.00";
    initJson.mtd = "";
    initJson.ppdflag0 = "Y";
    initJson.principalAmt0 = "0.00";
    initJson.principalAmt0 = "0.00";
    initJson.companyId = companyId;
    initJson.selCompanyId = companyId;
    initJson.distinctRule = "409";
    initJson.swpActNbr0 = "1767855731615406";
    initJson.planname = "Not Used";
    initJson.planType = "S";
    initJson.fromDate = "Dec 26, 2018";
    initJson.sheduleType = "100";
    initJson.holiday = "S";
    initJson.balType = "100";
    initJson.addCnt = "1";

  }
  if(response && response.execTime){
    initJson.execTime = response.execTime;
  }else {
    initJson.execTime = "1";
  }
  if(response && response.ruleDet){

    initJson.ruleName = response.ruleDet.RULENAME;
    initJson.ruleid = response.ruleDet.RULEID;
    initJson.ruleId = response.ruleDet.RULEID;
    initJson.ruleMode = response.ruleDet.RULEMODE;
    initJson.targetCcy = response.ruleDet.TARGETCCY;
    if(response.ruleDet.BALTYPE && response.ruleDet.BALTYPE != "")
      initJson.balType = response.ruleDet.BALTYPE;

    initJson.approval = response.ruleDet.APPROVAL;
    initJson.ruleType = response.ruleDet.RULETYPEID;
    if(response.ruleDet.DDATYPE && response.ruleDet.DDATYPE == 'Yes'){
      initJson.ddaType = true;
    }else {
      initJson.ddaType = false;
    }
    initJson.targetBal = response.ruleDet.TARGETBAL;
    initJson.trigccy = response.ruleDet.TRIGCCY;
    initJson.trigAmt = response.ruleDet.TRIGAMT;
    initJson.incrAmt = response.ruleDet.INCRAMT;
    initJson.overideAmt = response.ruleDet.AVAILBALCALL;
  }
  /*if(response &&  response.account){
    initJson.account = response.account;
  }else {*/
    initJson.account = "5331532312640037";
  //}
  if(response &&  response.account){
    initJson.acctGrp = response.account;
  }else {
    initJson.acctGrp = "6390341548748370";
  }
  if(response &&  response.assocRuleProd){
    response.assocRuleProd.map((obj,index) => {
      initJson.swpRefActNbr0 = obj.REFACCTNBR;
      initJson.nav0 = obj.NAV;
      initJson.availShares0 = obj.ENDSHARES;
      initJson.decimalCnt0 = obj.AMTDECIMALS;
      initJson.roundType0 = obj.CCYROUNDTYPE;
      initJson.value0 = obj.VALUE;
      initJson.parentDDAAccount0 = obj.PDDAACCT;
      })
  }
  if(response &&  response.sheduleType){
    initJson.sheduleType = response.sheduleType;
  }
  if(response &&  response.holiday){
    initJson.holiday = response.holiday;
  }

  //console.log('rinitJson:'+JSON.stringify(initJson));

  this.setState({rulesnewdata : initJson});
}

doDummy(editrule, companyId){

this.state.rulesnewdata = {
  actionFlag : 'SAVE',
  modifyFlag : 'MODIFY',
  ruleName : '',
  ruleid : editrule,
  ddaType : true,
  ruleMode : 'R',
  accountRule : 'S',
  account : '1601156058521574',
  acctGrp : '6390341548748370',
  targetCcy : 'GBP',
  balType : '102',
  approval : 'M',
  ruleType : '55',
  product0 : '1700',
  issueChild0 : '28029897',
  currency : 'EUR',
  swpRefActNbr0 : '7012000012',
  sweepAcctName0 : 'Sweep Fund Account',
  Omnibus : 'Omnibus',
  parentDDAAccount0 : '3528360639360069',
  dividendAccount0 : '101',
  dpoold0 : 'N',
  dividendType0 : '100',
  amtorPer0 : '1',
  decimalCnt0 : '4',
  roundType0 : '4',
  value0 : '',
  availRules0 :'yuuuu , Test Rule21 , 234234234',
  maxAmt0 : '',
  availShares0 : '0.000',
  nav0 : '1.00',
  principalAmt0 : '0.00',
  mtd : '',
  ppdflag0 : 'Y',
  companyId :companyId,
  ruleId : editrule,
  distinctRule : '409',
  selCompanyId : companyId,
  swpActNbr0 :'1767855731615406',
  planname : 'Not Used',
  planType : 'S',
  addCnt : 1
  };

}

handleChange = (event, value) => {
  this.setState({tabIndex : value });
};


  render () {
  const { handleSubmit, pristine, reset, submitting, classes } = this.props
  const tblStyle  = {width: "1200px"};

  let backtotradebtn;
  let tradesubmitbtn;
  tradesubmitbtn =
        <Route render={({ history}) => (
            <button  className="btn btn-primary btn-xs"
                type='submit'
            >
                Run
          </button>
        )} />
  backtotradebtn =
        <Route render={({ history}) => (
            <button  className="btn btn-primary btn-xs"
                type='button'
                onClick={() => { history.push('/report/MSWEEP') }}
            >
                Back
          </button>
        )} />

  return (
    <form style={tblStyle} onSubmit={handleSubmit}  >

      <Tabs value={this.state.tabIndex} onChange={this.handleChange}>
            <Tab label="Rules" />
            <Tab label="Schedules" />
      </Tabs>
        {this.state.tabIndex === 0 && <TabContainer>  <RulesBlockWithLoading isLoading={this.state.loading} sweepsnewrules={this.state.sweepsnewrules} />
        </TabContainer>}
        {this.state.tabIndex === 1 && <TabContainer><ScheduleBlock /></TabContainer>}
        <div><div style= {{textAlign: "center", paddingTop: "12px"}}>
        {tradesubmitbtn}
        {backtotradebtn}
             </div>
      </div>
    </form>
  );
};
};

UserPermissionsManagement =  reduxForm({
  form: "UserPermissionsManagement", // a unique identifier for this form
  validate,
  classes: PropTypes.object.isRequired
})(UserPermissionsManagement);

export default UserPermissionsManagement;