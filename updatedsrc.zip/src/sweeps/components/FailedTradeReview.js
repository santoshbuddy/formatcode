import React from 'react';
import { Route } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { sweepsActions } from '../actions/sweeps.actions';
import { connect } from 'react-redux';
import FailedTradeReviewFilters from './FailedTradeReviewFilters';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import FormData from 'form-data';
import MUIDataTable from "mui-datatables";
import RuleDetails from './RuleDetails';

import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import classnames from 'classnames';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import Grid from '@material-ui/core/Grid';
import PropTypes from 'prop-types';
import FailedTradeToolbarSelect from './FailedTradeToolbarSelect';
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import RefreshIcon from "@material-ui/icons/Refresh";
import TableLoader from '../../common/TableLoader';
import Loading from '../../common/Loading';

let isFilterLoaded=false;
let reactJSActionFlag='';
let formdata ={};
const styles = theme => ({
 iconButton: {
    marginRight: "24px",
    top: "50%",
    display: "inline-block",
    position: "relative",
    transform: "translateY(-50%)",
  },
  refreshIcon: {
    color: "#000",
  },
  textField: {
      marginLeft: theme.spacing.unit,
      marginRight: theme.spacing.unit,
      width: 200,
  },
   formControl: {
  		    marginTop: 0,
  		    minWidth: 120,
  		     fontSize: 11,
  		  },
  		  formControlLabel: {
  		    marginTop: 0,
  		     fontSize: 11,
    		},
  	  button: {
  	    margin: theme.spacing.unit,
  	     fontSize: 11,
	  },
});

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
    minRows: 1
  });

  const cols = [
   {
    name: "runId",
    options: {
	display: false,
	sort: false,
	download: false,
	filter: false,
    }
   },
   {
     name: "companyId",
     options: {
      	display: false,
	  	sort: false,
	  	download: false,
	  	filter: false,

     }
   } ,
   {
     name: "Severity",
     options: {
      filter: true,
      sort: true
  	}
   },
   {
    name: "Failed Resson",
    options: {
     filter: true,
     sort: true,
      customBodyRender: (value, tableMeta, updateValue) => {
	                 return (
	                  <Tooltip title={value} placement="right">
	                   <div>{value.substring(0,10)}</div>

	            	</Tooltip>
	                   );
    }
    }
   },
   {
    name: "Time Before Cut Off",
    options: {
     filter: true,
     sort: true,
    }
   },{
    name: "Last Updated Available Balance",
    options: {
     filter: true,
     sort: true,
    }
   },{
    name: "As of",
    options: {
     filter: true,
     sort: true,
    }
   },{
    name: "Available Balance Override Value",
    options: {
     filter: true,
     sort: true,
     customBodyRender: (value, tableMeta, updateValue) => {
	   	 	           return (
	   	           			 <TextField
							          id="Available-Balance-Override-Value"
							            placeholder={value}
							         	style ={{ width: 120}}
							           	 onChange={event => {
								                    updateValue(event.target.value);
							                }}
							          margin="normal"
       							 />
	               );
     }
    }
   },{
    name: "Rule Name",
    options: {
     filter: true,
     sort: true,
    }
   },{
     name: "Sweep Account Number",
     options: {
      filter: true,
      sort: true,
     }
   },
   {
    name: "Investment Account",
    options: {
     filter: true,
     sort: true,
    }
   },
    {
     name: "Company",
     options: {
       filter: true,
     sort: true,
      }
   },
    {
     name: "DDA Account Number",
     options: {
       filter: true,
     sort: true,
      }
   }
   ,
       {
        name: "DDA Account Name",
        options: {
          filter: true,
        sort: true,
         }
   }
   ,
       {
        name: "Product Name",
        options: {
          filter: true,
        sort: true,
         }
   }
   ,
       {
        name: "Value",
        options: {
          filter: true,
        sort: true,
         }
   }
   ,
       {
        name: "Type",
        options: {
          filter: true,
        sort: true,
         }
   }
   ,
       {
        name: "Rule Type",
        options: {
          filter: true,
        sort: true,
         }
   }
   ,
       {
        name: "Created By",
        options: {
          filter: true,
        sort: true,
         }
   },
    {
     name: "Execution Time",
     options: {
       filter: true,
     sort: false,
      }
   },
    {
     name: "Other Accounts Available Balance",
     options: {
       filter: true,
     sort: true,
      }
   },
    {
     name: "Total Amount",
     options: {
       filter: true,
     sort: true,
      }
   }
  ];

class FailedTradeReview extends React.Component {

	getMuiTheme = () => createMuiTheme({
 		    typography: {
		                                               useNextVariants: true,
		                },
		          overrides: {
		               MuiFormControl: {
		                                    marginNormal: {
		                                        marginTop: '0px',
		                                         marginBottom: '0px',
		                                     }
		            }, MuiIconButton: {
		                                    root: {
		                                        padding: '2px',
		                                     }
		            },
		            MuiTableCell: {
		                root:{
		                  padding: '6px !important',
		                },
		                head: {
		                  fontSize: '0.8rem',
		                  fontWeight: '600',
		                }
		              },
		              MuiTableRow:{
		                  head : {
		                      height: '20px !important',
		                      backgroundColor: '#f3f3f3',
		                       border: "1px solid #ccc"
		                  }
		              },
		              MUIDataTableSelectCell:{
		                  head: {
		                          border: "1px solid #ccc",
		                          align : 'center',
		                          height: '16px !important',
		                          padding: '0px !important',
		                          backgroundColor: "#f4f3f3",
 		                  },
				  fixedHeader:{
					backgroundColor: "transparent",
					position:'inherit !important',
		                  }
		              },
		            MUIDataTableHeadCell: {
		                  root: {
		                          border: "1px solid #ccc",
		                          textAlign : 'center',
		                          color: "blue",
		                          height: '16px !important',
		                          padding: '0px !important',
		                          whiteSpace:'noWrap',
		                       },
		                       fixedHeader :{
		                          backgroundColor: "#f4f3f3",
		                       }
		            },
		            MUIDataTableBodyCell: {
		              root: {
		                  whiteSpace: 'nowrap',
		                  padding:'0px 0px 0px 4px'
		               }
		            },
		            MUIDataTableBodyRow: {
		                        root: {
		                            height: '16px !important',
		                         }
		            },
		          }
		    });

    constructor(){
        super();
        this.state={
            results:[],
            results1:[],
            data:[],
            sweepfailedreviewdata:[],
            sweepfailedreviewtabledata:[],
            columns:[],
            screenName:'',
            selected: {},
            selectAll: 0
        }
		this.doChange = this.doChange.bind(this);
		this.handleChildUpdate = this.handleChildUpdate.bind(this);
		this.handleRefresh = this.handleRefresh.bind(this);

    }
    componentWillMount() {
        this.getFilter()
   }
   componentDidUpdate() {
       if(reactJSActionFlag === 'GO'){
       	isFilterLoaded=true;
       }else{
       	isFilterLoaded=false;
       }
     }
   getFilter(){
	reactJSActionFlag='';
		if(this.props.location.state){
		const {backFlag} = this.props.location.state
		this.handleRefresh();
		}else {
		this.props.dispatch(sweepsActions.fetchSweepFailedReviewData());
		}
   }
	handleChildUpdate(formdataObj){
  	 formdata=formdataObj ;
     console.log('handleChildUpdate :'+JSON.stringify( formdata	));
     }

   doChange(fillObj){
        var bodyFormData = new FormData();
        bodyFormData.append("reactJSActionFlag", "GO");
        reactJSActionFlag='GO';
        for (name in fillObj) {
			console.log(name+'<<<<>>>>>'+fillObj[name]);
            bodyFormData.append(name, fillObj[name]);
        }
        this.props.dispatch(sweepsActions.fetchSweepFailedReviewTableData(bodyFormData));

   }


	handleRefresh(){
		 var bodyFormData = new FormData();
        for (name in formdata) {
            bodyFormData.append(name, formdata[name]);
        }
		 this.props.dispatch(sweepsActions.fetchSweepFailedReviewTableData(bodyFormData));

     }



    render(){
		 const { classes } = this.props;

        const { sweepfailedreviewdata,sweepfailedreviewtabledata } = this.props;
        if(sweepfailedreviewdata.sweepfailedreviewdata !== undefined){

	              let results1 =[];

	               if(!isFilterLoaded && sweepfailedreviewdata && sweepfailedreviewdata.sweepfailedreviewdata){
	               results1=  sweepfailedreviewdata.sweepfailedreviewdata;
	               isFilterLoaded=true;
	               if(sweepfailedreviewdata.sweepfailedreviewdata !== undefined){
	                sweepfailedreviewdata.sweepfailedreviewdata.map((filter,index) => { formdata[filter.name]=filter.fieldValue; });
					}
					 else{
							return(
							<Loading />
							)
						}
	   			}else {
	   			results1=  sweepfailedreviewtabledata.sweepfailedreviewtabledata;

			}


			let screenName="";
			let msg="";
			let msgType="success";
			let results = [];
			let subActVec = [];
	 		if( results1)
	             results1.map((item,index) => {
	                if(item.type === "Title")
	                  screenName = item.name



	               	if(item.type === "data" &&   item.name=== 'data')
				   				 results = item.values

							if(item.type === "data" && item.name=== 'subActVec')
							 subActVec = item.values
				 })

           let data=[];
			if(results  && results.length>0){
			results.map((row,index) => {
			let cdata=[];
			cdata.push(row.RUNID);
			cdata.push(row.COMPANYID+'~'+row.GROUPID+'~'+row.EXECDATE+'~'+row.CREATEDDATE+'~'+row.DDAACCTNBR+'~'+row.OVERRIDEBAL);
			cdata.push(row.SEVERITY);
			cdata.push(row.REASON);
			cdata.push(row.EXECTIME);
			cdata.push(row.ACCTBAL);
			cdata.push(row.ASOF);
			cdata.push("");
			cdata.push(row.RULENAME);
			cdata.push(row.SWPACCTNAME);
			cdata.push(row.ACCTNAME);
 			cdata.push(row.COMPANYNAME);
			cdata.push(row.DDAREFACCTNBR);
			cdata.push(row.DDAACCTNAME);
			cdata.push(row.PRODNAME);
			cdata.push(row.VALUE);
			cdata.push(row.TYPEDESC);
			cdata.push(row.TRANSTYPEDESC);
			cdata.push(row.CREATEDBY);
			cdata.push(row.CREATEDDATE);
			cdata.push(subActVec[index]);
			if(row.TRADEAMOUNT !==''){
				var nf = new Intl.NumberFormat();
				cdata.push(nf.format(row.TRADEAMOUNT));
 			}else {
				cdata.push(row.TRADEAMOUNT);
			}
			data.push(cdata);
			})
		}else  {
			data=[];
		}


 //console.log('data <><><>>:'+JSON.stringify(data));

const options = {
	  viewColumns:false,
      filter: true,
      filterType: 'dropdown',
      responsive: 'scroll',
      setRowProps: (row, rowIndex) => {
              let rem = rowIndex % 2;
                if(rem === 0){
              return {
                      style: { backgroundColor: '#fff'}
                  };
                }else {
                  return {
                      style: { backgroundColor: '#f7f8f9'}
              };
                }
      },
	  customToolbarSelect: (selectedRows, displayData, setSelectedRows) =>   <FailedTradeToolbarSelect  selectedRows={selectedRows} displayData={displayData} setSelectedRows={setSelectedRows} phistory={this.props.history}/>
,textLabels: {
            body: {
                 noMatch: this.props.sweepfailedreviewtabledata.loading ?
                    <TableLoader /> :
                   <div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center'}}> <b key={'2'}>No records are available.</b></div>,
            },
        },
    };



        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">Failed Trade Review</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls" style={{backgroundColor:'#FFF'}}>
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
                            <FailedTradeReviewFilters handleUpdate={this.handleChildUpdate}  method={this.doChange} data={sweepfailedreviewdata} reactJSActionFlag={reactJSActionFlag}/>
                            </div>
                        </div>

                        <div className="clearfix"></div>

                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                                </div>
                            </div>
                             <MuiThemeProvider theme={this.getMuiTheme()}>
							<MUIDataTable title={(  <Tooltip title={"Refresh"}><IconButton className="btn btn-primary btn-xs" onClick={this.handleRefresh}>
									 <RefreshIcon className={classes.refreshIcon} />
								  </IconButton>
								 </Tooltip>)}
							data={data}
							columns={cols} options={options} viewColumns={false}/>
							</MuiThemeProvider>
                         </div>
                    </div>
                </div>
            </div>
        );
        }
	    else
	    {
		return(
		    <Loading />
		)
    }
    }
}

FailedTradeReview.propTypes = {
  classes: PropTypes.object.isRequired,
};
function mapStateToProps(state) {
    const { sweepfailedreviewdata,sweepfailedreviewtabledata	 } = state;
    return { sweepfailedreviewdata,sweepfailedreviewtabledata };
}

const connectedFailedTradeReview = connect(mapStateToProps)((withStyles(styles))(FailedTradeReview));
export { connectedFailedTradeReview as FailedTradeReview };