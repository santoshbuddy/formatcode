import React from 'react';
import { NavBar } from '../../navbar/components/navbar';

import 'react-tabs/style/react-tabs.css';
import '../../user/css/App.css';
import { connect } from 'react-redux';
import { sweepsActions } from '../actions/sweeps.actions';
import FormData from 'form-data';
import { fetchSweepNewruleInfo, submitRuleData } from './reduxforms/sweepUtil';

import { createMuiTheme } from "@material-ui/core/styles";
import blue from "@material-ui/core/colors/blue";
import FormLabel from '@material-ui/core/FormLabel';
import SweepSetupForm from './reduxforms/SweepSetupForm';
import WithLoading  from '../../_helpers/WithLoading';
import {addCommas, IsCharsInBag, Comma, removeCommas} from '../../common/amountValidations';

const SweepSetupFormWithLoading = WithLoading(SweepSetupForm);

var dateFormat = require('dateformat');

const theme = createMuiTheme({
    palette: {
      primary: blue
    },
    typography: {
        useNextVariants: true,
      }
  });

let selfromPage, actionFlag;
let selRuleId, selCompId, selCompName,selfromDate;
let rulesnewdata = [];
let saveFlag = "no";
let parsedData;
class SweepSetup extends React.Component {
    constructor() {
        super();
        this.state = {
        sweepsnewrules:[],
        resultMsg: '',
        loading: false};

        this.postRuleData = this.postRuleData.bind(this);
        this.doUpdateProdsMethod = this.doUpdateProdsMethod.bind(this);

      }
 componentDidMount() {
    parsedData = 'null';
    this.getFilter()
 }
 getFilter(){
    this.setState({ loading: true });
    var bodyFormdata = new FormData();

    let companyId
    if(selRuleId){
      bodyFormdata.append("ruleid", selRuleId);
      actionFlag = "MODIFY";
    }else {
      bodyFormdata.append("ruleid", "");
      actionFlag = "ADD";
    }
    if(selCompId){
      bodyFormdata.append("companyId", selCompId);
      companyId = selCompId;
    }else {
      bodyFormdata.append("companyId", JSON.parse(sessionStorage.getItem('clientFirm')));
      companyId = JSON.parse(sessionStorage.getItem('clientFirm'));
    }
    bodyFormdata.append("actionFlag", actionFlag);
    bodyFormdata.append("modifyFlag", "MODIFY");
    bodyFormdata.append("filStatus", "Y");
    bodyFormdata.append("rulesSize", "1");
    bodyFormdata.append("reports_length", "10");
    bodyFormdata.append("currency", "USD");
    bodyFormdata.append("eodDate", "Apr 18, 2018");

   // console.log("companyId:::"+companyId+"::selRuleId::"+selRuleId+"::selfromDate::"+selfromDate);

    fetchSweepNewruleInfo(bodyFormdata)
    .then(response => {
        if(response && response.ruleDet){
          this.buildIntialJson(response, companyId);
        }else {
          console.log(' before doDummy:');
         // this.doDummy(editrule, companyId);
        }
        this.setState({ loading: false, sweepsnewrules: response });

    }).catch(error => {
        if(error.status === 401) {
           // this.props.handleLogout('/login', 'error', 'You have been logged out. Please login create poll.');
           console.log('You have been logged out. Please login.');
          } else {
          console.log('Sorry! Something went wrong. Please try again!');
        }
    });
  }

  buildIntialJson(response, companyId){

    var initJson = new Object();

    if(response){
      initJson.accountRule = "S";
      initJson.actionFlag = "SAVE";
      initJson.modifyFlag = "MODIFY";


      initJson.mtd = "";
      initJson.companyId = companyId;
      initJson.selCompanyId = companyId;
      initJson.distinctRule = "409";
      initJson.planname = "Not Used";
      initJson.planType = "S";
      /*if(response.fromDate && response.fromDate !== ''){
        initJson.fromDate = dateFormat(response.fromDate,"yyyy-mm-dd");
      }else {
        var today = new Date();
        initJson.fromDate = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
      }*/
      selfromDate = initJson.fromDate;
      if(response.toDate && response.toDate !== ''){
        initJson.toDate = dateFormat(response.toDate,"yyyy-mm-dd");
      }

      initJson.sheduleType = "100";
      initJson.holiday = "S";
      initJson.balType = "100";
      initJson.addCnt = "1";

    }
    /*if(response && response.execTime){
      initJson.execTime = response.execTime;
    }else {
      initJson.execTime = "1";
    }*/
    if(response && response.ruleDet){

      initJson.ruleName = response.ruleDet.RULENAME;
      initJson.ruleid = response.ruleDet.RULEID;
      initJson.ruleId = response.ruleDet.RULEID;
      initJson.ruleMode = response.ruleDet.RULEMODE;
      initJson.targetCcy = response.ruleDet.TARGETCCY;
      if(response.ruleDet.BALTYPE && response.ruleDet.BALTYPE != "")
        initJson.balType = response.ruleDet.BALTYPE;

      initJson.approval = response.ruleDet.APPROVAL;
      initJson.ruleType = response.ruleDet.RULETYPEID;
      if(response.ruleDet.DDATYPE && response.ruleDet.DDATYPE == 'Yes'){
        initJson.ddaType = true;
      }else {
        initJson.ddaType = false;
      }
      initJson.targetBal = response.ruleDet.TARGETBAL;
      initJson.trigccy = response.ruleDet.TRIGCCY;
      initJson.trigAmt = response.ruleDet.TRIGAMT;
      initJson.incrAmt = response.ruleDet.INCRAMT;
      initJson.overideAmt = response.ruleDet.AVAILBALCALL;
    }
    /*if(response &&  response.account){
      initJson.account = response.account;
    }else {*/
      initJson.account = "5331532312640037";
    //}
    if(response &&  response.account){
      initJson.acctGrp = response.account;
    }else {
      initJson.acctGrp = "6037959490645794";
    }
    if(response &&  response.data != undefined){
      let parsedData;
        parsedData = JSON.parse(response.data);

      parsedData.map((obj,index) => {
        initJson['product'+index] = obj.product;
        initJson['issueChild'+index] = obj.issueChild;
        initJson.currency = obj.currency;
        initJson['currency'+index] = obj.currency;
        initJson['swpRefActNbr'+index] = obj.swpRefActNbr;
        initJson['sweepAcctName'+index] = obj.sweepAcctName;
        initJson['Omnibus'+index] = obj.Omnibus;
        initJson['parentDDAAccount'+index] = obj.parentDDAAccount;
        initJson['dividendAccount'+index] = obj.dividendAccount;
        if(obj.dpoold && obj.dpoold !== ''){
        initJson['dpoold'+index] = obj.dpoold;
        }else {
            initJson['dpoold'+index] = 'N';
        }
        initJson['dividendType'+index] = obj.dividendType;
        if(obj.amtorPer && obj.amtorPer !== ''){
        initJson['amtorPer'+index] = obj.amtorPer;
        }else {
            initJson['amtorPer'+index] = '1';
        }
        initJson['value'+index] = obj.value;
        initJson['maxAmt'+index] = obj.maxAmt;
        initJson['availShares'+index] = obj.availShares;
        initJson['nav'+index] = obj.nav;
        initJson['principalAmt'+index] = obj.principalAmt;
        initJson['mtd'+index] = obj.mtd;
        })
    }
    if(response &&  response.sheduleType){
      initJson.sheduleType = response.sheduleType;
    }
    if(response &&  response.holiday){
      initJson.holiday = response.holiday;
    }

    rulesnewdata = initJson;
  }

postRuleData(values){
    let checkValid = true;
    let issueChildOne = '', issueChildTwo = '', parentDDAAccountOne = '', parentDDAAccountTwo = '';

    if (!(values.ruleName)) {
        alert('Please enter valid Rule Name');
        checkValid = false;
        return false;
    }

    if(issueChildOne !== '' && issueChildTwo !== '' && parentDDAAccountOne !== '' && parentDDAAccountTwo !== ''){
        if(issueChildOne === issueChildTwo && parentDDAAccountOne == parentDDAAccountTwo){
            let issueChildDesc, parentDDAAccountDesc, tempitem;
            if(this.state.sweepsnewrules && this.state.sweepsnewrules.assocRuleProd){
                this.state.sweepsnewrules.assocRuleProd.map((obj,index) => {
                    if(obj.PRODVEC){
                        tempitem = obj.PRODVEC.find(e => e.PRODID === issueChildOne);
                        if(tempitem)
                            issueChildDesc =   tempitem.PRODNAME;
                    }
                    if(obj.PDDAACCTVEC){
                        tempitem = obj.PDDAACCTVEC.find(e => e.ACCTNBR === parentDDAAccountOne);
                        if(tempitem)
                            parentDDAAccountDesc = tempitem.SETTLEMENTACCTNBR +'-'+tempitem.SETTLEMENTTYPE;
                      }
                })
            }
            alert("Duplicate Record for Product/DDA Account : "+issueChildDesc+" / "+parentDDAAccountDesc);
            checkValid = false;
        }
    }
    if (!values.fromDate) {
            alert('Please enter From Date');
            checkValid = false;
             return false;
    }
    /*if (!values.toDate) {
            alert('Please enter To Date');
            checkValid = false;
    } */
    if (!values.execTime) {
        alert('Please enter Time Before Cut-off');
        checkValid = false;
         return false;
    }else  if(values.execTime){
        if(!(IsCharsInBag(values.execTime,"0123456789")))
        {
            alert('Please enter valid Time Before Cut-off');
            checkValid = false;
             return false;
        }
    }

     Object.keys(values).forEach(function(key){
            var value = values[key];
            if(key.indexOf('issueChild') != -1){
                if(issueChildOne === '')
                    issueChildOne = values[key];
                else if(issueChildTwo === '')
                    issueChildTwo = values[key];
            }
            if(key.indexOf('parentDDAAccount') != -1){
                if(parentDDAAccountOne === '')
                    parentDDAAccountOne = values[key];
                else if(parentDDAAccountTwo === '')
                    parentDDAAccountTwo = values[key];
            }


           if(key.indexOf('value') !== -1){
                if (!value) {
                    alert('Please enter Value');
                    checkValid = false;
                     return false;
                }else if(value){
                    if(!(IsCharsInBag(value,"0123456789.,")))
                    {
                        alert("Please enter valid Value.");
                        checkValid = false;
                         return false;
                    }
                }
           }
    });
    //console.log("::checkValid::"+checkValid);
    if(checkValid) {
            //window.alert(`You submitted:\n\n${JSON.stringify(values, null, 2)}`)
            //console.log('::vvvvvvvvvvv:::' + JSON.stringify(values));
                if (window.confirm('Are you sure, you want to continue?')){
                    var bodyFormdata = new FormData();
                    var rowcnt = 0;
                    Object.keys(values).forEach(function(key){
                        var value = values[key];
                        bodyFormdata.append(key, value);
                    });
                    var ext = true;
                    while(ext){
                        if(bodyFormdata.get("product"+rowcnt) && bodyFormdata.get("product"+rowcnt).length > 0){
                            rowcnt++;
                        }else {
                            ext = false;
                        }
                }
                bodyFormdata.append("addCnt", rowcnt);

                saveFlag = "start";
                this.setState({resultMsg: ""});

                submitRuleData(bodyFormdata).then(response => {
                    if(response){
                        saveFlag = "end";
                        if(selfromPage && selfromPage === 'CNEWRULE'){
                            this.setState({resultMsg: "Saved Successfully"});
                        }else {
                            if(values.actionFlag && values.actionFlag === 'SAVE'){
                                this.setState({resultMsg: "Sweep Trade Created Successfully"});
                            }else {
                                this.setState({resultMsg: "Sweep Trade Modified Successfully"});
                            }
                        }
                    }

                }).catch(error => {
                        if(error.status === 401) {
                            // this.props.handleLogout('/login', 'error', 'You have been logged out. Please login create poll.');
                            console.log('You have been logged out. Please login.');
                        } else {
                            console.log('Sorry! Something went wrong. Please try again!');
                        }
                });

            }
        }
  };

  doUpdateProdsMethod(newParsedData){
    parsedData = newParsedData;
  }

    render(){
          if(this.props.location.state){
		  		   const {companyId,ruleid, fromPage, companyName} = this.props.location.state
                      selRuleId = ruleid;
                      selCompId = companyId;
                      selfromPage = fromPage;
                      selCompName = companyName;
        }

        if((parsedData === undefined || parsedData.length === 0 || parsedData === 'null') && this.state.sweepsnewrules != undefined && this.state.sweepsnewrules.data != undefined){
          parsedData = JSON.parse(this.state.sweepsnewrules.data);
        }

        return(
            <div>
                <NavBar />
                <div className="clearfix"></div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Maintain Rules -  Add New Rule</h4>
                    </div>
                    <div className="col-md-12 col-sm-12">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
                                <div className="form-group"  >
                                    <div className="form-group col-md-2 col-sm-2" >
                                        <FormLabel style={{fontSize: '12px'}}>Companies:</FormLabel>
                                    </div>
                                    <div className="form-group col-md-2 col-sm-2" >
                                        <FormLabel style={{fontSize: '12px'}}>{selCompName}</FormLabel>
                                    </div>
                                    <div className="form-group col-md-8 col-sm-8" ></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12">
                             <SweepSetupFormWithLoading isLoading={this.state.loading}
                             onSubmit={this.postRuleData}
                             ruleid={selRuleId}
                             companyId={selCompId}
                             fromDate={selfromDate}
                             rulesnewdata={rulesnewdata}
                             sweepsnewrules={this.state.sweepsnewrules}
                             parsedData = {parsedData}
                              fromPage={selfromPage}
                              actionFlag={actionFlag}
                              saveFlag ={saveFlag}
                              resultMsg ={this.state.resultMsg}
                              updateProdsMethod={this.doUpdateProdsMethod}
                              />
                              </div>
                    </div>
                </div>

            </div>
        );
    }
}
function mapStateToProps(state) {
    const { sweepsnewrules } = state;
    return { sweepsnewrules };
}

const connectedSweepSetup = connect(mapStateToProps)(SweepSetup);
export { connectedSweepSetup as SweepSetup };

