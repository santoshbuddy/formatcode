import React from 'react';
import { Route } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { sweepsActions } from '../actions/sweeps.actions';
import { connect } from 'react-redux';
 import '../../user/css/App.css';
import FormData from 'form-data';
import MUIDataTable from "mui-datatables";
import Tooltip from "@material-ui/core/Tooltip";
import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import classnames from 'classnames';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import Grid from '@material-ui/core/Grid';
import PropTypes from 'prop-types';
import FailedTradeToolbarSelect from './FailedTradeToolbarSelect';
import RFPSnackbars from '../../messages/RFPSnackbars';
import TableLoader from '../../common/TableLoader';
import { Link } from 'react-router-dom';

import Paper from '@material-ui/core/Paper';

let isFilterLoaded=false;
let formdata ={};
const styles = theme => ({

  textField: {
      marginLeft: theme.spacing.unit,
      marginRight: theme.spacing.unit,
      width: 200,
  },
   formControl: {
  		    marginTop: 0,
  		    minWidth: 120,
  		     fontSize: 11,
  		  },
  		  formControlLabel: {
  		    marginTop: 0,
  		     fontSize: 11,
    		},
  	  button: {
  	    margin: theme.spacing.unit,
  	     fontSize: 11,
	  },
});



  const cols = [
   {
    name: "runId",
    options: {
	display: false,
	sort: false,
	download: false,
	filter: false,
    }
   },
   {
     name: "companyId",
     options: {
      	display: false,
	  	sort: false,
	  	download: false,
	  	filter: false,

     }
   } ,
   {
     name: "Failed Reason",
     options: {
      filter: true,
      sort: true
  	}
   } ,
   {
    name: "Time Before Cut Off",
    options: {
     filter: true,
     sort: false,
    }
   },{
    name: "Last Updated Available Balance",
    options: {
     filter: true,
     sort: false,
    }
   },{
    name: "As of",
    options: {
     filter: true,
     sort: false,
    }
   },{
    name: "Available Balance Override Value",
    options: {
     filter: true,
     sort: false,
    }
   },{
    name: "Rule Name",
    options: {
     filter: true,
     sort: false,
    }
   },{
     name: "Sweep Account Number",
     options: {
      filter: true,
      sort: false,
     }
   },
   {
    name: "Investment Account",
    options: {
     filter: true,
     sort: false,
    }
   },
    {
     name: "Company",
     options: {
       filter: true,
     sort: false,
      }
   },
    {
     name: "DDA Account Number",
     options: {
       filter: true,
     sort: false,
      }
   }
   ,
       {
        name: "DDA Account Name",
        options: {
          filter: true,
        sort: false,
         }
   }
   ,
       {
        name: "Product Name",
        options: {
          filter: true,
        sort: false,
         }
   }
   ,
       {
        name: "Value",
        options: {
          filter: true,
        sort: false,
         }
   }
   ,
       {
        name: "Type",
        options: {
          filter: true,
        sort: false,
         }
   }
   ,
       {
        name: "Rule Type",
        options: {
          filter: true,
        sort: false,
         }
   }
   ,
       {
        name: "Created By",
        options: {
          filter: true,
        sort: false,
         }
   },
    {
     name: "Execution Time",
     options: {
       filter: true,
     sort: false,
      }
   },
    {
     name: "Other Accounts Available Balance",
     options: {
       filter: true,
     sort: false,
      }
   }
  ];

class FailedTradePreview extends React.Component {

	 getMuiTheme = () => createMuiTheme({
		  typography: {
							useNextVariants: true,
	 			 },
	    overrides: {
			 MuiFormControl: {
					  	        marginNormal: {
					   	           marginTop: '0px',
					   	            marginBottom: '0px',
					   	        }
	      }, MuiIconButton: {
					  	        root: {
					   	           padding: '2px',
					   	        }
	      },
	      MUIDataTableBodyCell: {
	        root: {
 	           whiteSpace: 'nowrap',
 	           padding:'0px 56px 0px 24px'
 	        }
	      },
	      MUIDataTableBodyRow: {
		  	        root: {
		   	           height: '20px',
		   	        }
	      },
	    }
  })

    constructor(props){
        super(props);
        this.state={
            results:[],
            results1:[],
            data:[],
            sweepfailedpreviewdata:[],
            sweepfailedpreviewtabledata:[],
            failedVect:[],
            actFlag:'',
            columns:[],
            screenName:'',
            selected: {},
            selectAll: 0,
        }
		this.doChange = this.doChange.bind(this);
		this.handleChildUpdate = this.handleChildUpdate.bind(this);
 		this.handleSubmitClick = this.handleSubmitClick.bind(this);

    }
    componentDidMount() {
        this.getFilter()
   }
   getFilter(){
 	             if(this.props.location.state){
	   		  		   const {submitData,actFlag} = this.props.location.state
	   		  		    console.log('KKKK submitData :'+JSON.stringify( submitData	));
	   		  		    this.setState({failedVect:submitData,actFlag:actFlag});
	   		  		    if(submitData && submitData.length>0){
							 var bodyFormData = new FormData();
	   		  		    		submitData.map((trade,index) => {
						 				bodyFormData.append('seltrd'+index,trade.seltrd) ;
										bodyFormData.append('companyId'+index,trade.companyId) ;
										bodyFormData.append('groupId'+index,trade.groupId) ;
										bodyFormData.append('execDate'+index,trade.execDate) ;
										bodyFormData.append('createdDate'+index,trade.createdDate) ;
										bodyFormData.append('ddaNum'+index,trade.ddaNum) ;
										bodyFormData.append('balover'+index,trade.balover) ;


			 				 })
			  					bodyFormData.append('vecSize',submitData.length) ;
								bodyFormData.append('whereFrom',"RULEPRODFAIL") ;
								bodyFormData.append('actFlag',actFlag) ;

 	                      	this.props.dispatch(sweepsActions.fetchSweepFailedPreviewTableData(bodyFormData));

					  }

					}

   }
	handleChildUpdate(formdataObj){
  	 formdata=formdataObj ;
     console.log('handleChildUpdate :'+JSON.stringify( formdata	));
     }

   doChange(fillObj){
        var bodyFormData = new FormData();
        for (name in fillObj) {
            bodyFormData.append(name, fillObj[name]);
        }
        this.props.dispatch(sweepsActions.fetchSweepFailedPreviewTableData(bodyFormData));

   }
    handleSubmitClick(){
		if(this.state.failedVect && this.state.failedVect.length>0){
			if(confirm("Are you sure, you want to submit the data?")){
		var bodyFormData = new FormData();
		this.state.failedVect.map((trade,index) => {
			bodyFormData.append('seltrd'+index,trade.seltrd) ;
			bodyFormData.append('companyId'+index,trade.companyId) ;
			bodyFormData.append('groupId'+index,trade.groupId) ;
			bodyFormData.append('execDate'+index,trade.execDate) ;
			bodyFormData.append('createdDate'+index,trade.createdDate) ;
			bodyFormData.append('ddaNum'+index,trade.ddaNum) ;
			bodyFormData.append('balover'+index,trade.balover) ;


		})
		bodyFormData.append('vecSize',this.state.failedVect.length) ;
		bodyFormData.append('failedVecSize',this.state.failedVect.length) ;
 		bodyFormData.append('actFlag',this.state.actFlag) ;
 		bodyFormData.append('actionFlag','Submit') ;

		this.props.dispatch(sweepsActions.fetchSweepFailedPreviewTableData(bodyFormData));
		}
		}
	}




    render(){
		 const { classes } = this.props;

        const { sweepfailedpreviewdata,sweepfailedpreviewtabledata} = this.props;
  		let results1=  sweepfailedpreviewtabledata.sweepfailedpreviewtabledata;


			let screenName="";
			let msg="";
			let msgType="success";
			let results = [];
			let subActVec = [];
	 		if( results1)
	             results1.map((item,index) => {
	                if(item.type === "Title")
	                  screenName = item.name

				 if(item.type === "Message"){
	                  msg = item.name;
	                  msgType =item.label;
				  	}

				if(item.type === "data" &&   item.name=== 'data')
				 results = item.values

				if(item.type === "data" && item.name=== 'subActVec')
				 subActVec = item.values
				 })


           let data=[];
			if(results  && results.length>0){
			results.map((row,index) => {
			let cdata=[];
			cdata.push(row.RUNID);
			cdata.push(row.COMPANYID);
			cdata.push(row.REASON.substring(0,10));
			cdata.push(row.EXECTIME);
			cdata.push(row.ACCTBAL);
			cdata.push(row.ASOF);
			cdata.push(row.OVERRIDEBAL);
			cdata.push(row.RULENAME);
			cdata.push(row.SWPACCTNAME);
			cdata.push(row.ACCTNAME);
 			cdata.push(row.COMPANYNAME);
			cdata.push(row.DDAREFACCTNBR);
			cdata.push(row.DDAACCTNAME);
			cdata.push(row.PRODNAME);
			cdata.push(row.VALUE);
			cdata.push(row.TYPEDESC);
			cdata.push(row.TRANSTYPEDESC);
			cdata.push(row.CREATEDBY);
			cdata.push(row.CREATEDDATE);
			cdata.push(subActVec[index]);
			data.push(cdata);
			})
		}


 //console.log('data <><><>>:'+JSON.stringify(data));

const options = {
	  viewColumns:false,
      filter: true,
      filterType: 'dropdown',
      responsive: 'scroll',selectableRows:false,
	  customToolbarSelect: (selectedRows, displayData, setSelectedRows) =>   <FailedTradeToolbarSelect  selectedRows={selectedRows} displayData={displayData} setSelectedRows={setSelectedRows} />
	 ,textLabels: {
            body: {
                 noMatch: this.props.sweepfailedpreviewtabledata.loading ?
                    <TableLoader /> :
                   <div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center'}}> <b key={'2'}>No records are available.</b></div>,
            },
        },
    };
 let backbtn;
        backbtn =
        <Route render={({ history}) => (
          <Tooltip title={"Back"}>
             <Link   to={{ pathname: '/report/CRLPRORE', state: {backFlag:true} }}
			           				className="btn btn-primary btn-xs">
					  					Back
				   </Link>
          </Tooltip>
        )} />


        return(
            <div>
                <NavBar/>
                 <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                   <div className="clearfix"></div>
				                      <div  >
 					      			 {(msg && msg !== "") ?(<div style={{fontSize: 12, color: '#c30000' ,textAlign: 'center'}}> <b>{msg}</b></div>):''}
				                     </div>

                 <div className="panel-body">

                 <Paper>
                   			<MuiThemeProvider theme={this.getMuiTheme()}>
								<MUIDataTable title={"Failure Trade Preview"}
								data={data}
								columns={cols} options={options} viewColumns={false}/>


     					 </MuiThemeProvider>
				</Paper>
				  <div style={{textAlign:'center'}}>
				{(msg !== undefined && msg === "") ?(<Tooltip title={"Submit"}>
					<button  color="primary" className="btn btn-primary btn-xs" onClick={this.handleSubmitClick} >
						Submit
					</button>
				</Tooltip>):''}

				{backbtn}
				</div>
            </div>
            </div>
            </div>
        );
    }
}

FailedTradePreview.propTypes = {
  classes: PropTypes.object.isRequired,
};
function mapStateToProps(state) {
    const { sweepfailedpreviewdata,sweepfailedpreviewtabledata} = state;
        return { sweepfailedpreviewdata,sweepfailedpreviewtabledata };
}

const connectedFailedTradePreview = connect(mapStateToProps)((withStyles(styles))(FailedTradePreview));
export { connectedFailedTradePreview as FailedTradePreview };
