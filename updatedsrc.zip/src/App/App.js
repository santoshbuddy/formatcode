import React from 'react';
import { Router, Route, Link } from 'react-router-dom';
import  { Redirect } from 'react-router-dom'
import { connect } from 'react-redux';
import { Switch } from 'react-router';
import { history } from '../_helpers';
import { alertActions } from '../rootindex/actions';
import { PrivateRoute } from '../rootindex/components';
import { Home } from '../rootindex/pages';
import { HomePage } from '../rootindex/pages';
import { BottomHomePage } from '../rootindex/pages';
import { LoginPage } from '../rootindex/pages';
import { LogOutPage } from '../rootindex/pages';
import NotFound from '../common/NotFound';
import TechError from '../common/TechError';
import { RegisterPage } from '../rootindex/pages';
import { AccountGrp } from '../notionalpool/components/AccountGrp';
import { ReportTemplate } from '../reports/components/ReportTemplate';
import { FundBalanceData } from '../reports/components/FundBalanceData';
import { InvestTemplate } from '../invest/components/InvestTemplate';
import { ReportMultiTemplates } from '../reports/components/ReportMultiTemplate';
import { TradeEntry } from '../tradeentry/components/TradeEntry';
import { TradeConfirmPage } from '../tradeentry/components/TradeConfirmPage';
import { TreasuryTemplate } from '../treasurymgmt/components/TreasuryTemplate';
import { TreasuryEditTemplate } from '../treasurymgmt/components/TreasuryEditTemplate';
import { RequestForQuote } from '../treasurymgmt/components/RequestForQuote';
import { RFQReport } from '../treasurymgmt/components/RFQReport';
import { TreasuryNewTemplate } from '../treasurymgmt/components/TreasuryNewTemplate';
import { InputTemplate } from '../inputprofile/components/InputTemplate';
import { UserProfile } from '../treasurymgmt/components/UserProfile';
import { AccountTemplate } from '../accountclone/components/AccountTemplate';
import { LoanSweep } from '../sweeps/components/LoanSweep';
import { FailedTradeReview } from '../sweeps/components/FailedTradeReview';
import { FailedTradePreview } from '../sweeps/components/FailedTradePreview';
import { ManualSweep } from '../sweeps/components/ManualSweep';
import { SweepRunReport } from '../sweeps/components/SweepRunReport';
import { SweepTodayOnlineReport } from '../sweeps/components/SweepTodayOnlineReport';
import { SweepSetup } from '../sweeps/components/SweepSetup';
import { AdministrationTemplate } from '../administration/components/AdminstrationTemplate';
import { AdministrationIBATemplate } from '../administration/components/AdminstrationIBATemplate';
import { MaintainSweep } from '../sweeps/components/MaintainSweep';
import { Adminmfrevpros } from '../administration/components/Adminmfrevpros';
import {EmailAlertTemplate} from '../administration/components/EmailAlertTemplate';
import UserPermissionsManagement from '../administration/components/userManagement/UserPermissionsManagement';
import UserGroupsManagement from '../administration/components/userManagement/UserGroupsManagement';
import UserRolesManagement from '../administration/components/userManagement/UserRolesManagement';
import { AdminTempCreate } from '../administration/components/AdminTempCreate';
import { AlertMgmtTemplate } from '../administration/components/AlertMgmtTemplate';
import { NewAlertTemplate } from '../administration/components/NewAlertTemplate';
 import  { TemplateUserDetails }  from '../administration/components/TemplateUserDetails';
import  { EditAlertTemplate }  from '../administration/components/EditAlertTemplate';
import  { EditAcctDet }  from '../administration/components/EditAcctDet';
import  { EnterAcctDet }  from '../administration/components/EnterAcctDet';
import  { SavedAccountStatus }  from '../administration/components/SavedAccountStatus';
import  { ReviewProspectus }  from '../administration/components/ReviewProspectus';
import  { SelectIBA }  from '../administration/components/SelectIBA';
import  { ReportCompTemplate }  from '../reports/components/ReportCompTemplate';
import  { ReportCheckboxTemplate }  from '../reports/components/ReportCheckboxTemplate';
 import { UploadTrade } from '../tradeentry/components/UploadTrade';
 import Footer from '../user/pages/Footer';
import  Help  from '../user/pages/Help';
import  Notificationnew  from '../user/pages/Notificationsnew';
import { ClientListReport } from '../reports/components/ClientListReport';
import {MySettings} from '../user/pages/MySettings';
 import  AutoLogout   from '../navbar/components/AutoTimeOut';
 import { alertConstants } from '../common/constants/alert.constants';
 import {IntlProvider} from "react-intl";
import { addLocaleData } from "react-intl";
import locale_en from 'react-intl/locale-data/en';
import locale_de from 'react-intl/locale-data/de';

addLocaleData([...locale_en, ...locale_de ]);
const formats = {
    time: {
      '24hour': {hour12: false,hour:'numeric',minute:'numeric',second:'numeric'}
    }
  }; 
 
class App extends React.Component {
    constructor(props) {
        super(props);
        console.log("cook111", document.cookie);
        if(document.cookie )
        {
          console.log("cookie ", document.cookie.substring(11,document.cookie.length-1));
          //var user = document.cookie.match(new RegExp("jsontoken" + '=([^;]+)'));
          var user = document.cookie.substring(11,document.cookie.length-1);
          user = user.replace(/\\/g,'');
          user = JSON.parse(user);
          console.log("user ", user);
          //console.log("json token", (JSON.parse(user))[0].token);
          //user = user.substring(11,user.length-1);
          console.log("token====== ", user[0].token);
          if (user[0].token)
          {
          console.log("user=new===== ", user);
            sessionStorage.setItem('loginName',  user[0].name);
            sessionStorage.setItem('user', JSON.stringify(user));
            sessionStorage.setItem('userLocaleTxt', user[0].localeLang);

          }
        }

        const { dispatch } = this.props;
        history.listen((location, action) => {
            // clear alert on location change
            dispatch(alertActions.clear());
        });
        this.state = {
            warningTime: 1000 * 60 * (alertConstants.timeOut-1),
            signoutTime: 1000 * 60 * alertConstants.timeOut,
          };
    }


    componentDidMount() {
        this.events = [
          'load',
          'mousemove',
          'mousedown',
          'click',
          'scroll',
          'keypress'
        ];


        for (var i in this.events) {
          window.addEventListener(this.events[i], this.resetTimeout);
        }

        this.setTimeout();

      }

      clearTimeoutFunc = () => {
        if (this.warnTimeout) clearTimeout(this.warnTimeout);

        if (this.logoutTimeout) clearTimeout(this.logoutTimeout);
      };

      setTimeout = () => {

        this.warnTimeout = setTimeout(this.warn, this.state.warningTime);
        this.logoutTimeout = setTimeout(this.logout, this.state.signoutTime);
      };

      resetTimeout = () => {
        this.clearTimeoutFunc();
        this.setTimeout();
      };

      warn = () => {
        if(window.location.href.indexOf("login")===-1){
        //window.alert("You will be logged out automatically in 1 minute")
        console.log('You will be logged out automatically in 1 minute.');
        }
      };

      logout = () => {
        // Send a logout request to the API
        console.log('Sending a logout request to the API...');
        this.destroy();
      };

      destroy = () => {
       //clear the session
       sessionStorage.removeItem('user');
       sessionStorage.removeItem('clientFirm');
       sessionStorage.setItem('navlinkFlag',"false");
       if(window.location.href.indexOf("login")===-1)
       {
        history.push({
          pathname: '/logOut',
        });
       }
        //if(window.location.href.indexOf("login")===-1)
        //window.location.href=window.location.origin+"/"+alertConstants.homePage;
      };
    
    render() {
         const { alert } = this.props;
        return (
          <IntlProvider locale={sessionStorage.getItem('userLocaleTxt')} formats={formats}>
                <div className="container-fluid">
                    <div style={{minHeight:window.innerHeight - 118 +"px"}}>
                        {alert.message &&
                            <div className={`alert ${alert.type}`}>{alert.message}</div>
                        }
                        <Router history={history}>

                            <Switch>
                                <PrivateRoute exact path="/" component={Home} />
                                <Route path="/login" component={(LoginPage)} />
                                <Route path="/logOut" component={(LogOutPage)} />
                                <Route path="/register" component={RegisterPage} />
                                <Route path="/NotFound" component={NotFound} />
                                <Route path="/TechError" component={TechError} />
                                <Route path="/DEALENT" component={TradeEntry} />
                                <Route path="/CONFTRD" component={TradeConfirmPage} />
                                <Route path="/pool/*" component={AccountGrp} />
                                <Route path="/report/MSWEEP" component={ManualSweep} />
                                <Route path="/report/LSWEEP" component={LoanSweep} />
                                <Route path="/report/CRLPRORE" component={FailedTradeReview} />
                                <Route path="/report/CFLTRDPEW" component={FailedTradePreview} />
                                <Route path="/report/MNEWRULE" component={SweepSetup} />
                                <Route path="/report/CMNTRULE" component={MaintainSweep} />
                                <Route path="/report/CNEWRULE" component={SweepSetup} />
                                <Route path="/report/LNEWRULE" component={SweepSetup} />
                                <Route path="/report/CSWRUNRT" component={SweepRunReport} />
                                <Route path="/report/CSWPTORP" component={SweepTodayOnlineReport} />
                                <Route path="/report/CLFBHREPD" component={FundBalanceData} />
                                 <Route path="/client/CLLSTREP" component={ClientListReport} />
                                 <Route path="/userprofile/*" component={UserProfile} />
                                <Route path="/accountclone/*" component={AccountTemplate} />
                                <Route path="/report/*" component={ReportTemplate} />
                                <Route path="/reportC/*" component={ReportCompTemplate} />
                                <Route path="/reportCheck/*" component={ReportCheckboxTemplate} />
                                <Route path="/invest/CLINVPOL" component={InvestTemplate} />
                                <Route path="/invest/MMFRECRE" component={InvestTemplate} />
                                <Route path="/reportM/*" component={ReportMultiTemplates} />
                                <Route path="/admincreate/REVIEWPROSPECT" component={Adminmfrevpros} />
				                <Route path="/administration/EAUACL" component={EmailAlertTemplate} />
                                <Route path="/treasury/*" component={TreasuryTemplate} />
                                <Route path="/report/SLMMFSUB" component={AdministrationTemplate} />
                                {/* <Route path="/treasuryedit/*" render={ ()=> <TreasuryEditTemplate actionFlag="edit" policyId="1029" entiySel="19687983" /> } /> */}
                                <Route path="/treasuryedit/*" component={TreasuryEditTemplate} />
                                <Route path="/requestforquote/*" component={RequestForQuote} />
                                <Route path="/RFQReport/" component={RFQReport} />
                                <Route path="/treasurynew/*" component={TreasuryNewTemplate} />
                                <Route path="/administration/MMFEDITACCT"  component={EditAcctDet} />
                                <Route path="/administration/MMFCREATEACCT"  component={EnterAcctDet} />
                                <Route path="/administration/MMFACCTSUCCESS"  component={SavedAccountStatus} />
                                <Route path="/administration/REVIEWPROS"  component={ReviewProspectus} />
                                <Route path="/administration/SELECTIBA"  component={SelectIBA} />
                                <Route path="/administration/USERPROP" component={UserPermissionsManagement} />
                                <Route path="/administration/ADDREMOV" component={UserGroupsManagement} />
                                <Route path="/administration/MCMAINT" component={UserRolesManagement} />
                                <Route path="/administration/CRALKUP" component={AdministrationTemplate} />
                                <Route path="/administration/LOOKUP" component={AdministrationTemplate} />
                                <Route path="/administrationcreate/NEWMMDAACCT" component={AdministrationIBATemplate} />
                                <Route path="/administration/CLALERT" component={AlertMgmtTemplate} />
                                <Route path="/administrationnew/CLEMAIL" component={NewAlertTemplate} />
                                <Route path="/administrationedit/CLEMAIL" component={EditAlertTemplate} />
                                <Route path="/admincreate/*" component={AdminTempCreate} />
                                <Route path="/administration/EDITEMAILTEMP" component={TemplateUserDetails} />
                                <Route path="/uploadtrade" component={UploadTrade} />
                                <Route path="/MYSETTINGS" component={MySettings} />
                                <Route path="/helpdetail" component={ Help } />
                                <Route path="/notifications" component={ Notificationnew } />

                            </Switch>
                        </Router>
                        </div>
                        <Footer/>
                </div>
                </IntlProvider>
        );
    }
}

function mapStateToProps(state) {
    const { alert } = state;
    return {
        alert
    };
}

const connectedApp = connect(mapStateToProps)(App);
export { connectedApp as App };