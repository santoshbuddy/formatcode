import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import CircularProgress from '@material-ui/core/CircularProgress';
import loader from '../images/loader.gif';

const styles = theme => ({
    progress: {
      margin: theme.spacing.unit * 2,
    },
});
const ColorCircularProgress = withStyles({
    root: {
      color: '#409ec8', 
    },
  })(CircularProgress);
class Loading extends React.Component {
    constructor(props){
        super(props)
    }
    render() {
        const { classes } = this.props;
        return(
            <div style={{position:'absolute',left:'50%',top:'50%',transform: 'translate(-50%, -50%)'}}>
                <img alt="loader" src={loader} />         
                {/* <ColorCircularProgress className={classes.progress} value={75} style={{width:'64px',height:'64px'}}/> */}
            </div>
        )
    }
}

Loading.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(Loading);