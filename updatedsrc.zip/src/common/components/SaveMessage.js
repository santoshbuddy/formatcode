import React from 'react';
import GreenCheck from '../../images/save-image.png';

class SaveMessage extends React.Component {
    constructor(props) {
        super(props);

    }
    clickOverlay(e){
        document.getElementById("overlay").style.display="none";
        document.getElementById("saveMessage").style.display="none";
    }
    render(){        
        return(
            <div>
                <div className="overlay"  id={"overlay"} onClick={this.clickOverlay}></div>
                <div className="saveMessage">
                    <img src={GreenCheck} className="greenCheck"/>
                    <h3 className="greenText">{this.props.text}</h3>
                    {/* <h5>Your paying-in book is on its way.</h5> */}
                </div>
            </div>
        )
    }
}

export default SaveMessage;