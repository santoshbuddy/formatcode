import React from 'react';
import GreenCheck from '../../images/error-image.png';
class ErrorMessage extends React.Component {
    constructor(props) {
        super(props);
        this.clickOverlay = this.clickOverlay.bind(this);

    }
    clickOverlay(e){
        document.getElementById("overlay").style.display="none";
        document.getElementById("ErrorMessage").style.display="none";
        if(this.props.method !== undefined)
        this.props.method();
    }
    render(){        
        return(
            <div>
                <div className="overlay"  id={"overlay"} onClick={this.clickOverlay}></div>
                <div className="ErrorMessage" id={"ErrorMessage"}>
                    <img src={GreenCheck} className="ErrorMark"/>
                    <h3 className="ErrorText">{this.props.text}</h3>
                    {/* <h5>Your paying-in book is on its way.</h5> */}
                </div>
            </div>
        )
    }
}

export default ErrorMessage;