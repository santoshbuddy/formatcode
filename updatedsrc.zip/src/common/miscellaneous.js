import {IsCharsInBag} from '../common/amountValidations';

import { messageUS } from './javascript/i18N/en_US/alerts';
import { messageTr } from './javascript/i18N/tr_TR/alerts';

var user 		= JSON.parse(sessionStorage.getItem('user'));
let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
var temp;
var pos;
//  Replace characters with given string
export function replaceChars(inputString,replaceThis,withThis)
{
    temp = "" + inputString; // temporary holder

    while (temp.indexOf(replaceThis)>-1)
    {
        pos= temp.indexOf(replaceThis);
        temp = "" + (temp.substring(0, pos) + withThis +
        temp.substring((pos + replaceThis.length), temp.length));
    }
    return temp;
}

// To round amounts and rates
export function roundIt(Num, Places)
{
   if (Places > 0)
   {
      if ((Num.toString().length - Num.toString().lastIndexOf('.')) > (Places + 1))
      {
         var Rounder = Math.pow(10, Places);
         return Math.round(Num * Rounder) / Rounder;
      }
      else return Num;
   }
   else return Math.round(Num);
}
export function Xtend(Q, N)
{
	var P
    Q = String(Q)
    if (Q.indexOf(".") == 0)
    	Q = "0" + Q;
    while ((P=Q.indexOf('.'))<0) Q+='.'
    while (Q.length <= P+N) Q+='0'
    return Q
}
export function Comma(number)
{
	var decimal = "";
	if (number.indexOf(".") > 0)
	{
		decimal = number.substring(number.indexOf("."));
		number = number.substring(0,number.indexOf("."));
	}
	number = '' + number;
	if (number.length > 3)
	{
		var mod = number.length % 3;
		var output = (mod > 0 ? (number.substring(0,mod)) : '');
		for (i=0 ; i < Math.floor(number.length / 3); i++)
		{
			if ((mod == 0) && (i == 0))
				output += number.substring(mod+ 3 * i, mod + 3 * i + 3);
			else
				output+= ',' + number.substring(mod + 3 * i, mod + 3 * i + 3);
		}
		return (output+decimal);
	}
	else
		return number+decimal;
}

export function markUpValidation(markUp)
{
	if(markUp.length==0 || isNaN(markUp))
	{
		alert(message["ENTVLDRT"]);
		return false;
	}
	else if(IsCharsInBag(markUp,"-1234567890.")==false)
	{
		alert(message["ENTVLDRT"]);
		return false;
	}
	else if(markUp.indexOf("-") >= 0)
	{
		if(markUp.indexOf("-") != markUp.lastIndexOf("-") &&
		markUp.indexOf("-") != 0 )
		{
			alert(message["ENTVLDRT"]+"\t");
			return false;
		}
	}
	else if(markUp.indexOf(".") != markUp.lastIndexOf(".") )
	{
		alert(message["ENTVLDRT"]+"\t");
		return false;
	}
	return true;
}
export function textCounter(field,maxlimit)
{
	if (field.value.length > maxlimit)
	{
		alert(message["TEXTLIMIT"]+maxlimit+message["CHARACTERS"]);
		field.value = field.value.substring(0, maxlimit);
	}
}

/*export function clearTxt(obj)
{
	return filterNum(obj.value)
	  function filterNum(str) {
		re = /\$|,|@|#|~|`|\%|\*|\^|\&|\(|\)|\+|\=|\[|\-|\_|\]|\[|\}|\{|\;|\:|\'|\"|\<|\>|\?|\||\\|\!|\$|\./g;
		// remove special characters like "$" and "," etc...
		return str.replace(re, "");
	}
}*/

export function validMemo(memo)
{
	flag=true;
	var count = 0;
	for(var k=0;k<memo.value.length;k++)
	{
	 if(IsCharsInBag(memo.value.charAt(k),'~`%<>^&@!'))
	   		count++;
	 }
	 if(count>0)
	{
		alert(message["PAYMTINSTR"]);
		flag=false;
		return false;
	}
	return true;
}
 /*export function doPledge(){
			var pledge;
		if(document.forms[0].pledge !=null){
				for( var i = 0; i < document.forms[0].pledge.length; i++ )
			{
				if( document.forms[0].pledge[i].checked == true )
					pledge = document.forms[0].pledge[i].value;
			}
			if( pledge=="N"){
				document.forms[0].pledgecontract.value="";
				document.forms[0].pledgecontract.disabled=true;
				document.forms[0].pledgeDate.value="";
				document.forms[0].pledgeDate.disabled=true;
				if(document.forms[0].rollover!=null)
				document.forms[0].rollover[0].disabled=false;
				if(document.getElementById("pledgeDateIdShow")!=null)
					document.getElementById("pledgeDateIdShow").style.display="none";
				if(document.getElementById("pledgeDateIdHide")!=null)
					document.getElementById("pledgeDateIdHide").style.display="block";
			}else{
			if(document.forms[0].rollover!=null)
			{
			 	for( var i = 0; i < document.forms[0].rollover.length; i++ ){
					if( document.forms[0].rollover[i].value == "N" ){
						document.forms[0].rollover[i].disabled='yes';
						document.forms[0].rollover[1].checked=true;
						document.forms[0].rollovertype.disabled=false;
					}
				}
				}
 				document.forms[0].pledgecontract.disabled=false;
				document.forms[0].pledgeDate.disabled=false;
				if(document.getElementById("pledgeDateIdShow")!=null)
					document.getElementById("pledgeDateIdShow").style.display="block";
				if(document.getElementById("pledgeDateIdHide")!=null)
					document.getElementById("pledgeDateIdHide").style.display="none";

		  }
		}
}

export function doRollover(){
			var rollover;
			if(document.forms[0].rollover!=null)
			{
			for( var i = 0; i < document.forms[0].rollover.length; i++ )
			{
			if( document.forms[0].rollover[i].checked == true )
				rollover = document.forms[0].rollover[i].value;
			}

			if( rollover=="N")
			{
				if(document.forms[0].rollovertype!=null)
				document.forms[0].rollovertype.disabled=true;
			}
			else
				if(document.forms[0].rollovertype!=null)
				document.forms[0].rollovertype.disabled=false;


		  }
}
export function verifypledge(){
  var verpledge;
  if(document.forms[0].pledge!=null){
	for( var i = 0; i <document.forms[0].pledge.length; i++ ){
		if( document.forms[0].pledge[i].checked == true )
			verpledge = document.forms[0].pledge[i].value;
		}
    }
  if(verpledge=="Y"){
	   if(IsCharsInBag(document.forms[0].pledgecontract.value,"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 "))
		return true;
		else
		{
		alert(message["VALPLDCONTR"]);
		return false;
		}
   }
   else return true;
}*/

export function hidePledgeDate()
{
  if(document.getElementById("pledge") !=null)
  {
      if(document.getElementById("pledge").checked== true)
      {
        if(document.getElementById("pledgeDateIdShow")!=null)
      	  document.getElementById("pledgeDateIdShow").style.display="none";
        if(document.getElementById("pledgeDateIdHide")!=null)
      	  document.getElementById("pledgeDateIdHide").style.display="block";
  }
  else
  {
        if(document.getElementById("pledgeDateIdShow")!=null)
        	document.getElementById("pledgeDateIdShow").style.display="block";
        if(document.getElementById("pledgeDateIdHide")!=null)
        	document.getElementById("pledgeDateIdHide").style.display="none";
	}
  }
}

export function compare2Dates(datecheck,date1,dateformat1,date2,dateformat2)
{
	var valuDateLimit ;
	if(document.forms[0].valuDateLimit != null)
	valuDateLimit 	= document.forms[0].valuDateLimit.value;
	var d1 = getDateFromFormat(date1,dateformat1);
	var d2 = getDateFromFormat(date2,dateformat2);
	if (d1==0 || d2==0)
	{
		return -1;
	}
	else
		if (datecheck == "startDate" && d1 <= d2)
		{
			return 1;
		}
	else
		if (datecheck == "tradeDate" && d1 <= d2)
		{
			return 1;
		}
	else
		if (datecheck == "valueDate" && d1 <= d2)
		{
			return 1;
		}
	else
		if (datecheck == "maturityDate" && d2 >= d1)
		{
			return 1;
		}
	else
		if (datecheck == "startvalDate")
		{
			var noOfDays = (d1-d2)/(1000*60*60*24);

			if(noOfDays > valuDateLimit)
			{
				return 1;
			}
	   }
}
export function setFormAutocomplete(){
	if(document.forms[0] != null){
		var form = document.forms[0];
		form.setAttribute("autocomplete","off");
	}
}
/********************** end of program script ********************************/
