import React from 'react';
import { Link } from 'react-router-dom';
import { NavBar } from '../navbar/components/navbar';
import 'react-datepicker/dist/react-datepicker.css';
import { MuiThemeProvider } from "@material-ui/core/styles";


class TechError extends React.Component {
    constructor(props) {
        super(props);
     }

    render() {

        return (
			<div >
				<NavBar/>
				<div className="col-md-12 col-sm-12" style={{textAlign:'center',paddingTop:'100px',paddingBottom:'10px',fontSize:'18px',fontFamily:'sans-serif',fontWeight:'bold'}}>
                Due to a technical error your request is not processes. Please try again later or contact your helpdesk
				</div>
			</div>
        );
    }
}


 export default TechError;