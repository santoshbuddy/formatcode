export const resultConstants = {
CANTMODASPETRD : 'You can not modify user parameters, as there are waiting for approval trades.',
SAVEUNSUCCF : 'Save Unsuccessful',
SALESPERSONMEMBERCATID : '3',
RATEDECIMALS : '3',
NOCHNGESTOSAVE : 'No changes to save',
CHGAPPR : 'Changes Approved',
APPROVED : 'Approved',
REJECTED : 'Rejected',
MMFPRODID: '1700'
};