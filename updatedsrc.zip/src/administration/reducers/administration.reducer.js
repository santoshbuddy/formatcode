import { administrationConstants } from '../constants/administration.constants';

export function adminmfrevprosdata(state = {}, action) {
    switch (action.type) {
      case administrationConstants.GETADMINMFREVPROSDATA_REQUEST:
        return {
          loading: true
        };
      case administrationConstants.GETADMINMFREVPROSDATA_SUCCESS:
        return {
            adminmfrevprosdata: action.adminmfrevprosdata
        };
      case administrationConstants.GETADMINMFREVPROSDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

export function cnmfaccountdata(state = {}, action) {
    switch (action.type) {
      case administrationConstants.GETCNMFACCOUNTDATA_REQUEST:
        return {
          loading: true
        };
      case administrationConstants.GETCNMFACCOUNTDATA_SUCCESS:
        return {
            cnmfaccountdata: action.cnmfaccountdata
        };
      case administrationConstants.GETCNMFACCOUNTDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

export function assignAlertRecipientsData(state = {}, action) {
    switch (action.type) {
      case administrationConstants.GETREPORTDATA_REQUEST:
        return {
          loading: true
        };
      case administrationConstants.GETREPORTDATA_SUCCESS:
        return {
            assignAlertRecipientsData: action.assignAlertRecipientsData
        };
      case administrationConstants.GETREPORTDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }
export function adminreportdata(state = {}, action) {
    switch (action.type) {
      case administrationConstants.GETREPORTDATA_REQUEST:
        return {
          loading: true
        };
      case administrationConstants.GETREPORTDATA_SUCCESS:
        return {
          adminreportdata: action.adminreportdata
        };
      case administrationConstants.GETREPORTDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

  export function reportdatatable(state = {}, action) {
      switch (action.type) {
      case administrationConstants.GETREPORTTBLDATA_REQUEST:
        return {
          loading: true
        };
      case administrationConstants.GETREPORTTBLDATA_SUCCESS:
        return {
          reportdatatable: action.reportdatatable
        };
      case administrationConstants.GETREPORTTBLDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }
   export function userdata(state = {}, action) {
        switch (action.type) {
        case administrationConstants.GETUSERDATA_REQUEST:
          return {
            loading: true
          };
        case administrationConstants.GETUSERDATA_SUCCESS:
          return {
            userdata: action.userdata
          };
        case administrationConstants.GETUSERDATA_FAILURE:
          return {
            error: action.error
          };

        default:
          return state
      }
  }

  export function userlinkspermdata(state = {}, action) {
          switch (action.type) {
          case administrationConstants.GETUSERLIKSPERMDATA_REQUEST:
            return {
              loading: true
            };
          case administrationConstants.GETUSERLIKSPERMDATA_SUCCESS:
            return {
              userlinkspermdata: action.userlinkspermdata
            };
          case administrationConstants.GETUSERLIKSPERMDATA_FAILURE:
            return {
              error: action.error
            };

          default:
            return state
        }
  }
   export function userapprovalviewchngsdata(state = {}, action) {
              switch (action.type) {
              case administrationConstants.GETUSERAPPRVLVIEWCHGSDATA_REQUEST:
                return {
                  loading: true
                };
              case administrationConstants.GETUSERAPPRVLVIEWCHGSDATA_SUCCESS:
                return {
                  userapprovalviewchngsdata: action.userapprovalviewchngsdata
                };
              case administrationConstants.GETUSERAPPRVLVIEWCHGSDATA_FAILURE:
                return {
                  error: action.error
                };

              default:
                return state
            }
  }
export function userapprovaldata(state = {}, action) {
              switch (action.type) {
              case administrationConstants.GETUSERAPPRVLDATA_REQUEST:
                return {
                  loading: true
                };
              case administrationConstants.GETUSERAPPRVLDATA_SUCCESS:
                return {
                  userapprovaldata: action.userapprovaldata
                };
              case administrationConstants.GETUSERAPPRVLDATA_FAILURE:
                return {
                  error: action.error
                };

              default:
                return state
            }
  }
  export function acctdata(state = {}, action) {
    switch (action.type) {
      case administrationConstants.GETACCTDETDATA_REQUEST:
        return {
          loading: true
        };
      case administrationConstants.GETACCTDETDATA_SUCCESS:
        return {
            cnmfaccountdata: action.cnmfaccountdata
        };
      case administrationConstants.GETACCTDETDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }

export function associateduserdata(state = {}, action) {
  switch (action.type) {
    case administrationConstants.GETASSOCIATEUSERDATA_REQUEST:
      return {
        loading: true
      };
    case administrationConstants.GETASSOCIATEUSERDATA_SUCCESS:
      return {
          associateduserdata: action.associateduserdata
      };
    case administrationConstants.GETASSOCIATEUSERDATA_FAILURE:
      return {
        error: action.error
      };

    default:
      return state
  }
}

export function ibaacctdata(state = {}, action) {
  switch (action.type) {
    case administrationConstants.GETIBAACCOUNTDATA_REQUEST:
      return {
        loading: true
      };
    case administrationConstants.GETIBAACCOUNTDATA_SUCCESS:
      return {
          ibaacctdata: action.ibaacctdata
      };
    case administrationConstants.GETIBAACCOUNTDATA_FAILURE:
      return {
        error: action.error
      };

    default:
      return state
  }
}

export function tempuserdata(state = {}, action) {
  switch (action.type) {
    case administrationConstants.GETTEMPUSERACCDATA_REQUEST:
      return {
        loading: true
      };
    case administrationConstants.GETTEMPUSERACCDATA_SUCCESS:
      return {
          tempuserdata: action.tempuserdata
      };
    case administrationConstants.GETTEMPUSERACCDATA_FAILURE:
      return {
        error: action.error
      };

    default:
      return state
  }
}

export function alerttempdatadet(state = {}, action) {
  switch (action.type) {
    case administrationConstants.GETALERTTEMPDATADET_REQUEST:
      return {
        loading: true
      };
    case administrationConstants.GETALERTTEMPDATADET_SUCCESS:
      return {
        alerttempdatadet: action.alerttempdatadet
      };
    case administrationConstants.GETALERTTEMPDATADET_FAILURE:
      return {
        error: action.error
      };

    default:
      return state
  }
}
    export function userlinksviewchngsdata(state = {}, action) {
            switch (action.type) {
            case administrationConstants.GETUSERVIEWCHGSDATA_REQUEST:
              return {
                loading: true
              };
            case administrationConstants.GETUSERVIEWCHGSDATA_SUCCESS:
              return {
                userlinksviewchngsdata: action.userlinksviewchngsdata
              };
            case administrationConstants.GETUSERVIEWCHGSDATA_FAILURE:
              return {
                error: action.error
              };

            default:
              return state
          }
  }

  export function makercheckerdata(state = {}, action) {
    switch (action.type) {
    case administrationConstants.GETMAKERCHECKERDATA_REQUEST:
      return {
        loading: true
      };
    case administrationConstants.GETMAKERCHECKERDATA_SUCCESS:
      return {
        makercheckerdata: action.makercheckerdata
      };
    case administrationConstants.GETMAKERCHECKERDATA_FAILURE:
      return {
        error: action.error
      };

    default:
      return state
  }
}

export function mmfeditAcctDet(state = {}, action) {
	switch (action.type) {
		case administrationConstants.GETMMFEDITACCT_REQUEST:
		return {
			loading: true
		};
		case administrationConstants.GETMMFEDITACCT_SUCCESS:
		return {
			mmfeditAcctDet: action.mmfeditAcctDet
		};
		case administrationConstants.GETMMFEDITACCT_FAILURE:
		return {
			error: action.error
		};

		default:
		return state
	}
}

export function mmfcreateAcctDet(state = {}, action) {
	switch (action.type) {
		case administrationConstants.GETMMFCREATEACCT_REQUEST:
		return {
			loading: true
		};
		case administrationConstants.GETMMFCREATEACCT_SUCCESS:
		return {
			mmfcreateAcctDet: action.mmfcreateAcctDet
		};
		case administrationConstants.GETMMFCREATEACCT_FAILURE:
		return {
			error: action.error
		};

		default:
		return state
	}
}

export function mmfreviewPropDet(state = {}, action) {
	switch (action.type) {
		case administrationConstants.GETMMFREVIEWACCT_REQUEST:
		return {
			loading: true
		};
		case administrationConstants.GETMMFREVIEWACCT_SUCCESS:
		return {
			mmfreviewPropDet: action.mmfcreateAcctDet
		};
		case administrationConstants.GETMMFREVIEWACCT_FAILURE:
		return {
			error: action.error
		};

		default:
		return state
	}
}

export function viewchangehistory(state = {}, action) {
  switch (action.type) {
  case administrationConstants.GETVIEWCHANGESHISTORY_REQUEST:
    return {
      loading: true
    };
  case administrationConstants.GETVIEWCHANGESHISTORY_SUCCESS:
    return {
      viewchangehistory: action.viewchangehistory
    };
  case administrationConstants.GETVIEWCHANGESHISTORY_FAILURE:
    return {
      error: action.error
    };

  default:
    return state
}
}

export function assignAlertRecipientsTableData(state = {}, action) {
      switch (action.type) {
      case administrationConstants.GETREPORTTBLDATA_REQUEST:
        return {
          loading: true
        };
      case administrationConstants.GETREPORTTBLDATA_SUCCESS:
        return {
          assignAlertRecipientsTableData: action.assignAlertRecipientsTableData
        };
      case administrationConstants.GETREPORTTBLDATA_FAILURE:
        return {
          error: action.error
        };

      default:
        return state
    }
  }