import React from 'react';
import 'react-tabs/style/react-tabs.css';
import { NavBar } from '../../navbar/components/navbar';
import { AdministrationActions } from '../actions/administration.actions';
import { connect } from 'react-redux';
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import { SelectIBA } from './SelectIBA';
import Loading from '../../common/Loading'

let results1 = [];
let tableData= [];

class AdministrationIBATemplate extends React.Component {
	constructor(){
		super();
		this.state={
			screenName:'',
			tabIndex: 0
		}

		this.doChange = this.doChange.bind(this);
	}

	componentDidMount() {
		this.getFilter()
	}

	getFilter() {
		var filtObj = new FormData();
		this.props.dispatch(AdministrationActions.fetchFundAccountsData(filtObj));
	}

	doChange(fillObj){
		var bodyFormData = new FormData();
		for (name in fillObj)
		{
			bodyFormData.append(name, fillObj[name]);
		}

		this.props.dispatch(AdministrationActions.fetchFundAccountsData(bodyFormData));
	}

    render() {
		tableData	= [];
		const { finalData }	= this.props;

		if( finalData !== undefined)
		{
			results1  = finalData;
		}

		if( results1 !== undefined && results1.length > 0)
		{
			results1.map((item, index) => {
				if(item.type === "Title") {
					this.state.screenName = item.name;
				}

				if(item.type === "data") {
					tableData = item.values;
				}
			});

			return(
				<div>
					<NavBar/>
					<div className="panel panel-primary clearfix" style={{clear:'both'}}>
						<div className="panel-heading">
							<h4 className="panel-title">{this.state.screenName}</h4>
						</div>
						<div className="panel-body">
							<div className="col-md-12 col-sm-12">
								<SelectIBA data={results1} />
							</div>
						</div>
					</div>
				</div>
			);
		}
		else
		{
			return(
				<div>
					<NavBar/>
					<Loading/>
				</div>
			)
		}
    }
}

function mapStateToProps(state)
{
	const { adminreportdata } = state;
	let finalData = [];

	if(adminreportdata != undefined ) {
		if(adminreportdata.adminreportdata != undefined ) {
			finalData   = adminreportdata.adminreportdata;
		}
	}

	return { finalData };
}

const connectedAdministrationIBATemplate = connect(mapStateToProps)(AdministrationIBATemplate);
export { connectedAdministrationIBATemplate as AdministrationIBATemplate };