import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { AdministrationActions } from '../actions/administration.actions';
import { withStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import { NavBar } from '../../navbar/components/navbar';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepConnector from '@material-ui/core/StepConnector';
import Grid from '@material-ui/core/Grid';

const styles = theme => ({
    root: {
      width: '100%',
    },
    heading: {
      fontSize: theme.typography.pxToRem(15),
      fontWeight: theme.typography.fontWeightRegular,
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
        margin:'2px',
        display: 'inline',
    },
	connectorActive: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorCompleted: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorDisabled: {
		'& $connectorLine': {
			borderColor: theme.palette.grey[100],
			borderWidth: '2px'
		},
	},
	connectorLine: {
		transition: theme.transitions.create('border-color,border-size'),
	},
	stepIcon: {
		color: "#828384",
		fontSize: '19px',
		"&$active": {
			color: "#00395c",
			fontSize: '37px'
		},
		"&$completed": {
			color: "#00395c",
			fontSize: '19px'
		}
	},
	active: {},
	completed: {},
	typography: {
		useNextVariants: true,
	},
	iconContainer :{
		paddingRight: "0"
	},
	stepStyle:{
		paddingRight: "0",
		paddingLeft: "0"
	}
});

const InvestAcct = [
    {
        label:"	DK ACCT486-108000486"
        },{
            label:"FR ACCT478-108000478"
        },{
            label:"IE ACCT518-108000518"
        },{
            label:"NO ACCT450-108000450"
        },{
            label:"SE ACCT468-108000468"
        },{
            label:"SP ACCT413-108000413"
        },{
            label:"UK ACCT1-108000401"
        },{
            label:"UK ACCT402-108000402"
        },{
            label:"UK ACCT403-108000403"
        },{
            label:"UK ACCT405-108000405"
        },{
            label:"UK ACCT406-108000406"
        },{
            label:"UK ACCT407-108000407"
        },{
            label:"UK ACCT408-108000408"
        },{
            label:"UK ACCT409-108000409"
        },{
            label:"UK ACCT410-108000410"
        },{
            label:"UK ACCT411-108000411"
        },{
            label:"UK ACCT412-108000412"
        },{
            label:"UK ACCT414-108000414"
        },{
            label:"UK ACCT415-108000415"
        },{
            label:"UK ACCT416-108000416"
        },{
            label:"UK ACCT417-108000417"
        },{
            label:"UK ACCT418-108000418"
        },{
            label:"UK ACCT419-108000419"
        },{
            label:"UK ACCT420-108000420"
        },{
            label:"UK ACCT421-108000421"
        },{
            label:"UK ACCT422-108000422"
        },{
            label:"UK ACCT423-108000423"
        },{
            label:"UK ACCT424-108000424"
        },{
            label:"UK ACCT425-108000425"
        },{
            label:"UK ACCT426-108000426"
        },{
            label:"UK ACCT427-108000427"
        },{
            label:"UK ACCT428-108000428"
        },{
            label:"UK ACCT429-108000429"
        },{
            label:"UK ACCT430-108000430"
        },{
            label:"UK ACCT431-108000431"
        },{
            label:"UK ACCT432-108000432"
        },{
            label:"UK ACCT433-108000433"
        },{
            label:"UK ACCT434-108000434"
        },{
            label:"UK ACCT435-108000435"
        },{
            label:"UK ACCT436-108000436"
        },{
            label:"UK ACCT437-108000437"
        },{
            label:"UK ACCT438-108000438"
        },{
            label:"UK ACCT439-108000439"
        },{
            label:"UK ACCT440-108000440"
        },{
            label:"UK ACCT441-108000441"
        },{
            label:"UK ACCT442-108000442"
        },{
            label:"UK ACCT443-108000443"
        },{
            label:"UK ACCT444-108000444"
        },{
            label:"UK ACCT445-108000445"
        },{
            label:"UK ACCT446-108000446"
        },{
            label:"UK ACCT447-108000447"
        },{
            label:"UK ACCT448-108000448"
        },{
            label:"UK ACCT449-108000449"
        },{
            label:"UK ACCT451-108000451"
        },{
            label:"UK ACCT452-108000452"
        },{
            label:"UK ACCT453-108000453"
        },{
            label:"UK ACCT454-108000454"
        },{
            label:"UK ACCT455-108000455"
        },{
            label:"UK ACCT456-108000456"
        },{
            label:"UK ACCT457-108000457"
        },{
            label:"UK ACCT458-108000458"
        },{
            label:"UK ACCT459-108000459"
        },{
            label:"UK ACCT460-108000460"
        },{
            label:"UK ACCT462-108000462"
        },{
            label:"UK ACCT463-108000463"
        },{
            label:"UK ACCT464-108000464"
        },{
            label:"UK ACCT465-108000465"
        },{
            label:"UK ACCT466-108000466"
        },{
            label:"UK ACCT467-108000467"
        },{
            label:"UK ACCT469-108000469"
        },{
            label:"UK ACCT470-108000470"
        },{
            label:"UK ACCT471-108000471"
        },{
            label:"UK ACCT472-108000472"
        },{
            label:"UK ACCT473-108000473"
        },{
            label:"UK ACCT474-108000474"
        },{
            label:"UK ACCT479-108000479"
        },{
            label:"UK ACCT480-108000480"
        },{
            label:"UK ACCT481-108000481"
        },{
            label:"UK ACCT482-108000482"
        },{
            label:"UK ACCT483-108000483"
        },{
            label:"UK ACCT484-108000484"
        },{
            label:"UK ACCT485-108000485"
        },{
            label:"UK ACCT487-108000487"
        },{
            label:"UK ACCT488-108000488"
        },{
            label:"UK ACCT489-108000489"
        },{
            label:"UK ACCT490-108000490"
        },{
            label:"UK ACCT491-108000491"
        },{
            label:"UK ACCT492-108000492"
        },{
            label:"UK ACCT493-108000493"
        },{
            label:"UK ACCT494-108000494"
        },{
            label:"UK ACCT495-108000495"
        },{
            label:"UK ACCT496-108000496"
        },{
            label:"UK ACCT497-108000497"
        },{
            label:"UK ACCT500-108000500"
        },{
            label:"UK ACCT501-108000501"
        },{
            label:"UK ACCT503-108000503"
        },{
            label:"UK ACCT504-108000504"
        },{
            label:"UK ACCT506-108000506"
        },{
            label:"UK ACCT508-108000508"
        },{
            label:"UK ACCT509-108000509"
        },{
            label:"UK ACCT510-108000510"
        },{
            label:"UK ACCT512-108000512"
        },{
            label:"UK ACCT514-108000514"
        },{
            label:"UK ACCT516-108000516"
        }
    ];

    const FundAcct = [
        {
            label:"None"
        }
    ];

    const BranchId = [
        {
            label:"GIP"
        }
    ];

    const TaxPayer = [
        {
            label: "No Code"
        },{
            label: "Corporation"
        },{
            label: "Disregarded Entity"
        },{
            label: "Entity regd under IC"
        },{
            label: "Exempt charitable tr"
        },{
            label: "Financial Institution"
        },{
            label: "Foreign central bank"
        },{
            label: "Foreign government or"
        },{
            label: "Individual (incl two or"
        },{
            label: "International organi"
        },{
            label: "Common trust fund"
        },{
            label: "Org.tax-exempt-501a,IRA"
        },{
            label: "Other"
        },{
            label: "Partnership"
        },{
            label: "Real estate investmen"
        },{
            label: "Registered dealer in"
        },{
            label: "The United States or an"
        },{
            label: "Trust/Estate"
        }
    ];

    const State = [
        {
            label: "	ALABAMA"
        },{
            label: "ALASKA"
        },{
            label: "AMERICAN SAMOA"
        },{
            label: "ARIZONA"
        },{
            label: "ARKANSAS"
        },{
            label: "CALIFORNIA"
        },{
            label: "COLORADO"
        },{
            label: "CONNECTICUT"
        },{
            label: "D.C"
        },{
            label: "DELAWARE"
        },{
            label: "FEDERATED STATES OF MICRONESIA"
        },{
            label: "FLORIDA"
        },{
            label: "GEORGIA"
        },{
            label: "GUAM"
        },{
            label: "HAWAII"
        },{
            label: "IDAHO"
        },{
            label: "ILLINOIS"
        },{
            label: "INDIANA"
        },{
            label: "IOWA"
        },{
            label: "KANSAS"
        },{
            label: "KENTUCKY"
        },{
            label: "LOUISIANA"
        },{
            label: "MAINE"
        },{
            label: "MARSHALL ISLANDS"
        },{
            label: "MARYLAND"
        },{
            label: "MASSACHUSETTS"
        },{
            label: "MICHIGAN"
        },{
            label: "MINNESOTA"
        },{
            label: "MISSISSIPPI"
        },{
            label: "MISSOURI"
        },{
            label: "MONTANA"
        },{
            label: "NEBRASKA"
        },{
            label: "NEVADA"
        },{
            label: "NEW HAMPSHIRE"
        },{
            label: "NEW JERSEY"
        },{
            label: "NEW MEXICO"
        },{
            label: "NEW YORK"
        },{
            label: "NORTH CAROLINA"
        },{
            label: "NORTH DAKOTA"
        },{
            label: "NORTHERN MARIANA ISLANDS"
        },{
            label: "OHIO"
        },{
            label: "OKLAHOMA"
        },{
            label: "OREGON"
        },{
            label: "PALAU"
        },{
            label: "PENNSYLVANIA"
        },{
            label: "PUERTO RICO"
        },{
            label: "RHODE ISLAND"
        },{
            label: "SOUTH CAROLINA"
        },{
            label: "SOUTH DAKOTA"
        },{
            label: "TENNESSEE"
        },{
            label: "TEXAS"
        },{
            label: "UTAH"
        },{
            label: "VERMONT"
        },{
            label: "VIRGIN ISLANDS"
        },{
            label: "VIRGINIA"
        },{
            label: "WASHINGTON"
        },{
            label: "WEST VIRGINIA"
        },{
            label: "WISCONSIN"
        },{
            label: "WYOMING"
        }
    ];

    const Country =
        [
            {
                label: "USA"
            },{
                label: "Albania"
            },{
                label: "Algeria"
            },{
                label: "American Samoa"
            },{
                label: "Andorra"
            },{
                label: "Anguilla"
            },{
                label: "Antarctica"
            },{
                label: "Antigua "
            },{
                label: "Argentina"
            },{
                label: "Armenia"
            },{
                label: "Aruba"
            },{
                label: "Australia"
            },{
                label: "Austria"
            },{
                label: "Azerbaijan"
            },{
                label: "Bahamas"
            },{
                label: "Bahrain"
            },{
                label: "Bangladesh"
            },{
                label: "Barbados"
            },{
                label: "Belarus"
            },{
                label: "Belgium"
            },{
                label: "Belize"
            },{
                label: "Benin"
            },{
                label: "Bermuda"
            },{
                label: "Bhutan"
            },{
                label: "Bolivia"
            },{
                label: "Bosnia "
            },{
                label: "Botswana"
            },{
                label: "Bouvet Island"
            },{
                label: "Brazil"
            },{
                label: "British Indian"
            },{
                label: "Brunei"
            },{
                label: "Bulgaria"
            },{
                label: "Burkina Faso"
            },{
                label: "Burundi"
            },{
                label: "Cambodia"
            },{
                label: "Cameroon"
            },{
                label: "Canada"
            },{
                label: "Cape Verde"
            },{
                label: "Cayman Islands"
            },{
                label: "Central African"
            },{
                label: "Chad"
            },{
                label: "Chile"
            },{
                label: "China"
            },{
                label: "Christmas Island"
            },{
                label: "Cocos (Keeling)"
            },{
                label: "Colombia"
            },{
                label: "Comoros"
            },{
                label: "Congo, Republic"
            },{
                label: "Congo,Democratic"
            },{
                label: "Cook Islands"
            },{
                label: "Costa Rica"
            },{
                label: "Croatia"
            },{
                label: "Cuba"
            },{
                label: "Cyprus"
            },{
                label: "Czech Republic"
            },{
                label: "Denmark"
            },{
                label: "Djibouti"
            },{
                label: "Dominica"
            },{
                label: "Dominican Republic"
            },{
                label: "East Timor"
            },{
                label: "Egypt"
            },{
                label: "El Salvador"
            },{
                label: "Equador"
            },{
                label: "Equatorial Guine"
            },{
                label: "Eritrea"
            },{
                label: "Estonia"
            },{
                label: "Ethiopia"
            },{
                label: "Falkland Islands"
            },{
                label: "Faroe Islands"
            },{
                label: "Fiji"
            },{
                label: "Finland"
            },{
                label: "France"
            },{
                label: "French Guiana"
            },{
                label: "French Polynesia"
            },{
                label: "French Southern"
            },{
                label: "Gabon"
            },{
                label: "Gambia"
            },{
                label: "Georgia"
            },{
                label: "Germany"
            },{
                label: "Ghana"
            },{
                label: "Gibraltar"
            },{
                label: "Great Britain"
            },{
                label: "Greece"
            },{
                label: "Greenland"
            },{
                label: "Grenada"
            },{
                label: "Guadeloupe"
            },{
                label: "Guam"
            },{
                label: "Guatamala"
            },{
                label: "Guernsey, C.I."
            },{
                label: "Guinea"
            },{
                label: "Guinea-Bissau"
            },{
                label: "Guyana"
            },{
                label: "Haiti"
            },{
                label: "Heard "
            },{
                label: "Holy See (Vatica"
            },{
                label: "Honduras"
            },{
                label: "Hong Kong"
            },{
                label: "Hungary"
            },{
                label: "Iceland"
            },{
                label: "India"
            },{
                label: "Indonesia"
            },{
                label: "Iran"
            },{
                label: "Iraq"
            },{
                label: "Ireland"
            },{
                label: "Isle of Man"
            },{
                label: "Israel"
            },{
                label: "Italy"
            },{
                label: "Ivory Coast"
            },{
                label: "Jamaica"
            },{
                label: "Japan"
            },{
                label: "Jersey, C.I."
            },{
                label: "Jordan"
            },{
                label: "Kazakhstan"
            },{
                label: "Kenya"
            },{
                label: "Kingdom of Lesotho"
            },{
                label: "Kiribati"
            },{
                label: "Korea"
            },{
                label: "Kuwait"
            },{
                label: "Kyrgyzstan"
            },{
                label: "Laos"
            },{
                label: "Latvia"
            },{
                label: "Lebanon"
            },{
                label: "Liberia"
            },{
                label: "Libyan Arab Jama"
            },{
                label: "Liechtenstein"
            },{
                label: "Lithuania"
            },{
                label: "Luxemburg"
            },{
                label: "Macau"
            },{
                label: "Macedonia"
            },{
                label: "Madagascar"
            },{
                label: "Malawi"
            },{
                label: "Malaysia"
            },{
                label: "Maldives"
            },{
                label: "Malta"
            },{
                label: "Marshall Islands"
            },{
                label: "Martinique"
            },{
                label: "Mauritania"
            },{
                label: "Mauritius"
            },{
                label: "Mayotte"
            },{
                label: "Mexico"
            },{
                label: "Micronesia"
            },{
                label: "Moldova"
            },{
                label: "Monaco"
            },{
                label: "Mongolia"
            },{
                label: "Montserrat"
            },{
                label: "Morocco"
            },{
                label: "Mozambique"
            },{
                label: "Myanmar"
            },{
                label: "Namibia"
            },{
                label: "Nauru"
            },{
                label: "Nepal"
            },{
                label: "Netherlands"
            },{
                label: "Netherlands Anti"
            },{
                label: "New Caledonia"
            },{
                label: "New Zealand"
            },{
                label: "Nicaragua"
            },{
                label: "Niger"
            },{
                label: "Nigeria"
            },{
                label: "Niue"
            },{
                label: "Norfolk Island"
            },{
                label: "North korea"
            },{
                label: "Northern Mariana"
            },{
                label: "Norway"
            },{
                label: "Oman"
            },{
                label: "Pakistan"
            },{
                label: "Palau"
            },{
                label: "Panama"
            },{
                label: "Papua New Guinea"
            },{
                label: "Paraguay"
            },{
                label: "Peru"
            },{
                label: "Philippines"
            },{
                label: "Pitcairn"
            },{
                label: "Poland"
            },{
                label: "Portugal"
            },{
                label: "Puerto Rico"
            },{
                label: "Qatar"
            },{
                label: "Republic of Angola"
            },{
                label: "Republic of Ecuador"
            },{
                label: "Republic of Haiti"
            },{
                label: "Republic of Mali"
            },{
                label: "Republic of Serbia"
            },{
                label: "Republic of Tajikistan"
            },{
                label: "Reunion"
            },{
                label: "Romania"
            },{
                label: "Russia"
            },{
                label: "Rwanda"
            },{
                label: "S Georgia  Sa"
            },{
                label: "Samoa"
            },{
                label: "San Marino"
            },{
                label: "Sao Tome "
            },{
                label: "Saudi Arabia"
            },{
                label: "Senegal"
            },{
                label: "Seychelles"
            },{
                label: "Sierra Leone"
            },{
                label: "Singapore"
            },{
                label: "Slovakia"
            },{
                label: "Slovenia"
            },{
                label: "Solomon Islands"
            },{
                label: "Somalia"
            },{
                label: "South Africa"
            },{
                label: "Spain"
            },{
                label: "Sri Lanka"
            },{
                label: "St. Helena"
            },{
                label: "St. Kitts - Nevi"
            },{
                label: "St. Lucia"
            },{
                label: "St.Pierre "
            },{
                label: "St.Vincent "
            },{
                label: "Sudan"
            },{
                label: "Suriname"
            },{
                label: "Svalbard  M"
            },{
                label: "Swaziland"
            },{
                label: "Sweden"
            },{
                label: "Switzerland"
            },{
                label: "Syrian Arab Republic"
            },{
                label: "Taiwan"
            },{
                label: "Tanzania"
            },{
                label: "Thailand"
            },{
                label: "Togo"
            },{
                label: "Tokelau"
            },{
                label: "Tonga"
            },{
                label: "Trinidad "
            },{
                label: "Tunisia"
            },{
                label: "Turkey"
            },{
                label: "Turkmenistan"
            },{
                label: "Turks  I"
            },{
                label: "Tuvalu"
            },{
                label: "U.S. minor outly"
            },{
                label: "UAE"
            },{
                label: "UK"
            },{
                label: "Afghanistan"
            },{
                label: "Uganda"
            },{
                label: "Ukraine"
            },{
                label: "Uruguay"
            },{
                label: "Uzbekistan"
            },{
                label: "Vanuatu"
            },{
                label: "Venezuela"
            },{
                label: "Vietnam"
            },{
                label: "Virgin Islands (B)"
            },{
                label: "Virgin Islands (US)"
            },{
                label: "Wallis "
            },{
                label: "Western Sahara"
            },{
                label: "Yemen"
            },{
                label: "Yugoslavia"
            },{
                label: "Zambia"
            },{
                label: "Zimbabwe"
            }
        ];

class EnterAcctDet extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            columns:[],
            activeStep: 2,
            shortname:'',
			longname:'',
			clientidnetifier:'',
			investacct:'',
			fundacct:'',
			branchid:'',
			taxid:'',
			taxstatuscode:'',
			taxcompname:'',
			taxcity:'',
			taxzip:'',
			taxaddress:'',
			taxstate:'',
			taxcountry:'',
			stmtcompany:'',
			stmtcity:'',
			stmtzip:'',
			stmtaddress:'',
			stmtstate:'',
			stmtcountry:'',
			stmteswnum:'',
			stmteswname:'',
			stmtremark:''
        }

		this.handleChange = this.handleChange.bind(this);
    }

    componentWillMount(){
		var bodyFormData = new FormData();

		bodyFormData.append("product", this.props.location.state.product)
        bodyFormData.append("currency", this.props.location.state.currency);
//        bodyFormData.append("fundTypeId", this.props.location.state.fundTypeId);
//        bodyFormData.append("fundFamilyId", this.props.location.state.fundFamilyId);

        this.props.dispatch(AdministrationActions.fetchMmfcreateAcctData(bodyFormData));
	}

    handleChange = name => event => {
        this.setState({
            [name]: event.target.value,
        });
    };

	getSteps() {
	    return ['', '', ''];
  	}

    render(){
//        const { data } = this.props;
		const steps = this.getSteps();
		const { activeStep } = this.state;
        const { classes, cData } = this.props;
		const connector = (
			<StepConnector
				classes={{
					active: classes.connectorActive,
					completed: classes.connectorCompleted,
					disabled: classes.connectorDisabled,
					line: classes.connectorLine,
				}}
			/>
		);

       	var prodId 		= this.props.location.state.product;
       	var CcyVal 		= this.props.location.state.currency;
       	var prodName 	= this.props.location.state.productname;
       	let commonData = [];
		var TaxStatus 	= [];
		var TaxStateTxt = [];
		var TaxCountryTxt = [];
		var StateTxt = [];
		var CountryTxt = [];
		var InvestAccount = [];
		var FundAccount = [];
		var BranchID = [];

		if(cData !== undefined && cData.toString().length > 0)
		{
			if(cData.taxStatus != undefined) {
				TaxStatus 		= cData.taxStatus;
			}

			if(cData.taxStateTxt != undefined) {
				TaxStateTxt 		= cData.taxStateTxt;
			}

			if(cData.taxCountryTxt != undefined) {
				TaxCountryTxt 		= cData.taxCountryTxt;
			}

			if(cData.stateTxt != undefined) {
				StateTxt 		= cData.stateTxt;
			}

			if(cData.countryTxt != undefined) {
				CountryTxt 		= cData.countryTxt;
			}

			if(cData.investAccount != undefined) {
				InvestAccount 		= cData.investAccount;
			}

			if(cData.ddaAcct != undefined) {
				FundAccount 		= cData.ddaAcct;
			}

			if(cData.branchID != undefined) {
				BranchID 		= cData.branchID;
			}

			return  (
				<div className={classes.root}>
					<NavBar/>
					<div className="clearfix"></div>
					<Stepper  className="col-md-6" activeStep={activeStep} connector={connector}>
						{steps && steps.map((label, index) => {
							const props = {};
							const labelProps = {};
							return (
							<Step key={label} {...props} className={classes.stepStyle}>
								<StepLabel classes={{iconContainer:classes.iconContainer}}
									StepIconProps={{
										classes: { root: classes.stepIcon, active:classes.active, completed:classes.completed }
									}}>
								</StepLabel>
							</Step>
							);
						})}
					</Stepper>
					<div className="clearfix"></div>
					<h5 style={{fontWeight:'bold'}}>{prodName}</h5>
					<ExpansionPanel defaultExpanded>
						<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
							<Typography className={classes.heading}><b>Description</b></Typography>
						</ExpansionPanelSummary>

						<ExpansionPanelDetails>

							<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel required>Short Name:</InputLabel>
									<TextField
										id="standard-required"
										className={classes.textField}
										placeholder="Enter Short Name"
										value=""
										onChange={this.handleChange('shortname')}
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel required>Long Name:</InputLabel>
									<TextField
										id="standard-required"
										className={classes.textField}
										placeholder="Enter Long Name"
										onChange={this.handleChange('longname')}
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Client Identifier:</InputLabel>
									<TextField
										id="standard-clientidnetifier"
										className={classes.textField}
										placeholder="Enter Client Identifier"
										onChange={this.handleChange('clientidnetifier')}
										value=""
										margin="normal"
									/>
								</Grid>
							</Grid>
						</ExpansionPanelDetails>
					</ExpansionPanel>

					<ExpansionPanel>
						<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
							<Typography className={classes.heading}><b>Accounts</b></Typography>
						</ExpansionPanelSummary>

						<ExpansionPanelDetails>
							<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel>Investment Account:</InputLabel>
									<TextField
										id="standard-select-currency-native"
										select
										className={classes.textField}
										value={this.state.investacct}
										onChange={this.handleChange('investacct')}
										SelectProps={{
										native: true,
										MenuProps: {
											className: classes.menu,
										},
										}}
										margin="normal" >

										{InvestAccount && InvestAccount.map(option => (
											<option key={option.key} value={option.key}>
												{option.value}
											</option>
										))}
									</TextField>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Funding Account:</InputLabel>
									<TextField
										id="standard-select-currency-native"
										select
										className={classes.textField}
										value={this.state.fundacct}
										onChange={this.handleChange('fundacct')}
										SelectProps={{
											native: true,
											MenuProps: {
												className: classes.menu,
											},
										}}
										margin="normal" >

										{FundAccount && FundAccount.map(option => (
											<option key={option.key} value={option.key}>
												{option.value}
											</option>
										))}
									</TextField>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Branch Id:</InputLabel>
									<TextField
										disabled
										id="standard-select-currency-native"
										select
										className={classes.textField}
										value={this.state.branchid}
										onChange={this.handleChange('branchid')}
										SelectProps={{
											native: true,
											MenuProps: {
												className: classes.menu,
											},
										}}
										margin="normal" >
										{BranchID && BranchID.map(option => (
											<option key={option.value} value={option.value}>
												{option.label}
											</option>
										))}
									</TextField>
								</Grid>
							</Grid>
						</ExpansionPanelDetails>
					</ExpansionPanel>

					<ExpansionPanel>
						<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
							<Typography className={classes.heading}><b>Tax Information</b></Typography>
						</ExpansionPanelSummary>

						<ExpansionPanelDetails>
							<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel>Tax ID:</InputLabel>
									<TextField
										required
										id="standard-required"
										className={classes.textField}
										onChange={this.handleChange('taxid')}
										placeholder="Enter Tax Id"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Tax Payer Status Code:</InputLabel>
									<TextField
										id="standard-select-currency-native"
										select
										className={classes.textField}
										value={this.state.taxpayer}
										onChange={this.handleChange('taxstatuscode')}
										SelectProps={{
											native: true,
											MenuProps: {
												className: classes.menu,
											},
										}}
										margin="normal" >
										{TaxStatus && TaxStatus.map(option => (
											<option key={option.key} value={option.key}>
												{option.value}
											</option>
										))}
									</TextField>
								</Grid>
							</Grid>
						</ExpansionPanelDetails>
					</ExpansionPanel>

					<ExpansionPanel>
						<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
							<Typography className={classes.heading}><b>Parent Entity Address For Tax Reporting</b></Typography>
						</ExpansionPanelSummary>

						<ExpansionPanelDetails>
							<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel required>Company Name:</InputLabel>
									<TextField
										disabled
										id="standard-required"
										className={classes.textField}
										onChange={this.handleChange('taxcompname')}
										placeholder="Enter Company Name"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel required>City:</InputLabel>
									<TextField
										disabled
										id="standard-required"
										className={classes.textField}
										onChange={this.handleChange('taxcity')}
										placeholder="Enter City"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Zip:</InputLabel>
									<TextField
										disabled
										id="standard-taxzip"
										className={classes.textField}
										onChange={this.handleChange('taxzip')}
										placeholder="Enter Zip"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel required>Address:</InputLabel>
									<TextField
										disabled
										id="standard-required"
										className={classes.textField}
										onChange={this.handleChange('taxaddress')}
										placeholder="Enter Address"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>State:</InputLabel>
									<TextField
										disabled
										id="standard-select-currency-native"
										select
										className={classes.textField}
										value={this.state.taxstate}
										onChange={this.handleChange('taxstate')}
										SelectProps={{
											native: true,
											MenuProps: {
												className: classes.menu,
											},
										}}
										margin="normal" >
										{TaxStateTxt && TaxStateTxt.map(option => (
											<option key={option.key} value={option.key}>
												{option.value}
											</option>
										))}
									</TextField>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Country:</InputLabel>
									<TextField
										disabled
										id="standard-select-currency-native"
										select
										className={classes.textField}
										value={this.state.taxcountry}
										onChange={this.handleChange('taxcountry')}
										SelectProps={{
											native: true,
											MenuProps: {
												className: classes.menu,
											},
										}}
										margin="normal" >
										{TaxCountryTxt && TaxCountryTxt.map(option => (
											<option key={option.key} value={option.key}>
												{option.value}
											</option>
										))}
									</TextField>
								</Grid>
							</Grid>
						</ExpansionPanelDetails>
					</ExpansionPanel>

					<ExpansionPanel>
						<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
							<Typography className={classes.heading}><b>Escrow Account Information for Monthly Statements</b></Typography>
						</ExpansionPanelSummary>

						<ExpansionPanelDetails>
							<Grid container spacing={24}>
								<Grid item xs={4}>
									<InputLabel required>Company Name:</InputLabel>
									<TextField
										id="standard-required"
										className={classes.textField}
										onChange={this.handleChange('stmtcompany')}
										placeholder="Enter Company Name"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel required>City:</InputLabel>
									<TextField
										id="standard-required"
										className={classes.textField}
										onChange={this.handleChange('stmtcity')}
										placeholder="Enter City"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Zip</InputLabel>
									<TextField
										id="standard-required"
										className={classes.textField}
										onChange={this.handleChange('stmtzip')}
										placeholder="Enter Zip"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel required>Address:</InputLabel>
									<TextField
										id="standard-required"
										className={classes.textField}
										onChange={this.handleChange('stmtaddress')}
										placeholder="Enter Address"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>State:</InputLabel>
									<TextField
										id="standard-select-currency-native"
										select
										className={classes.textField}
										onChange={this.handleChange('stmtstate')}
										value={this.state.stmtstate}
										SelectProps={{
											native: true,
											MenuProps: {
												className: classes.menu,
											},
										}}
										margin="normal" >
										{StateTxt && StateTxt.map(option => (
											<option key={option.key} value={option.key}>
												{option.value}
											</option>
										))}
									</TextField>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Country:</InputLabel>
									<TextField
										id="standard-select-currency-native"
										select
										className={classes.textField}
										onChange={this.handleChange('stmtcountry')}
										value={this.state.stmtcountry}
										SelectProps={{
											native: true,
											MenuProps: {
												className: classes.menu,
											},
										}}
										margin="normal" >
										{CountryTxt && CountryTxt.map(option => (
											<option key={option.value} value={option.value}>
												{option.label}
											</option>
										))}
									</TextField>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Escrow Number:</InputLabel>
									<TextField
										id="standard-stmteswnum"
										className={classes.textField}
										onChange={this.handleChange('stmteswnum')}
										placeholder="Enter Escrow Number"
										value=""
										margin="normal"
									/>
								</Grid>
								<Grid item xs={4}>
									<InputLabel>Escrow Name:</InputLabel>
									<TextField
										id="standard-stmteswname"
										className={classes.textField}
										placeholder="Enter Escrow Name"
										onChange={this.handleChange('stmteswname')}
										value=""
										margin="normal"
									/>
								</Grid>
							</Grid>
						</ExpansionPanelDetails>
					</ExpansionPanel>

					<ExpansionPanel>
						<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
							<Typography className={classes.heading}><b>Remarks</b></Typography>
						</ExpansionPanelSummary>
						<ExpansionPanelDetails>
							<Typography>
								<InputLabel>Escrow Name:</InputLabel>
								<TextField
									id="standard-multiline-static"
									multiline
									rows="4"
									className={classes.textField}
									placeholder="Enter Escrow Name"
									onChange={this.handleChange('stmtremark')}
									value=""
									margin="normal"
								/>
							</Typography>
						</ExpansionPanelDetails>
					</ExpansionPanel>
					<div style={{textAlign:'right',padding: '2px 15px'}}>
						{/* <button className={btn btn-primary btn-xs}>Create Account</button> */}
					</div>
				</div>

			)
		}
		else
		{
			return(
				<div>

				</div>
			)
		}
    }
}

EnterAcctDet.propTypes = {
    classes: PropTypes.object.isRequired,
};

function mapStateToProps(state) {
    const { mmfcreateAcctDet } = state;
    let cData = [];

    if(mmfcreateAcctDet != undefined)
    {
		 if(mmfcreateAcctDet.mmfcreateAcctDet != undefined ) {
    	    cData   = mmfcreateAcctDet.mmfcreateAcctDet.commonData;
		}
	}

    return { cData };
}

const connectedEnterAcctDet = connect(mapStateToProps)(withStyles(styles)(EnterAcctDet));
export { connectedEnterAcctDet as EnterAcctDet };

//export default (withStyles(styles))(EnterAcctDet);
