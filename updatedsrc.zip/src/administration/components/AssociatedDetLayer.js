import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import { connect } from 'react-redux';
import MUIDataTable from "mui-datatables";
import FromData from 'form-data';
import { AdministrationActions } from '../actions/administration.actions';

const ContCols = [
    {
        name: 'First Name',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Last Name',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Email Id',
        options: {
            filter: true,
            sort: false,
        }
    }
]
class AssociatedDetLayer extends React.Component{
    constructor(props) {
	    super(props);
        this.state = {
            open: false,
            screenName:'',
            tdVal:this.props.tdVal ? this.props.tdVal : '',
            userDet: this.props.assocDet ? this.props.assocDet : null,
            associateduserdata:[],
            associateduserdata1:[],
            results:[]
        }
        this.handleClickOpen = this.handleClickOpen.bind(this);
    };

    handleClickOpen = () => {
        this.setState({ open: true });
        var bodyFormData = new FromData();
        console.log('userDet <><>:'+JSON.stringify( this.props.assocDet	));
        // console.log(this.state.userDet);
        if(this.props.assocDet){
            bodyFormData.append("clientFirm",this.props.assocDet.companyId);
            bodyFormData.append("templateId",this.props.assocDet.selTemplate);
            bodyFormData.append("parentCompanyId",this.props.assocDet.pCompanyId);
            bodyFormData.append("templateTypeId","Null");
            // bodyFormData.append("fromPage",'CLALERTort');
            // console.log(bodyFormData);
            
            this.props.dispatch(AdministrationActions.fetchAssociatedUserDetPopUpData(bodyFormData));
        }
    };

    handleClose = () => {
        this.setState({ open: false });
    };



    render() {
        const options = {
            filter: true,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:false        
        };

        this.state.associateduserdata = this.props.associateduserdata;
        this.state.associateduserdata1 = this.state.associateduserdata.associateduserdata;

        // console.log(this.state.associateduserdata);
        if(this.state.associateduserdata1 !== undefined){
            // console.log(this.state.associateduserdata1.Title);
            this.state.screenName = this.state.associateduserdata1.Title;
            // console.log(this.state.associateduserdata1.rows);
            this.state.results =  this.state.associateduserdata1.rows;
            console.log('result1 <><>:'+JSON.stringify( this.state.results	));
        }
            let data1=[];
            if(this.state.results !== undefined) { 
                this.state.results.map((row,index) => {
                    let cdata1=[];
                    cdata1.push(row.FirstName);
                    cdata1.push(row.LastName);
                    cdata1.push(row.EmailId);
                    data1.push(cdata1);
                });             
            }

        console.log('result1 <><>:'+JSON.stringify( data1	));

        return(
            <div>
                <a hreaf="javascript:void(0);" onClick={this.handleClickOpen}>
                    {/* {this.state.tdVal}    */}
                    {this.props.tdVal}
                </a>
                <Dialog  fullWidth={true}
                    maxWidth={'md'}
                    open={this.state.open}
                    onClose={this.handleClose}
                    aria-labelledby="form-dialog-title"
                    >
                    <DialogTitle id="form-dialog-title">{this.state.screenName}</DialogTitle>
                    <DialogContent>
                        <MUIDataTable
                            data={data1}
                            columns={ContCols} options={options} />
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.handleClose} color="primary">
                        Close
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        )
    }
}
function mapStateToProps(state) {
    const { associateduserdata } = state;
    console.log("associateduserdata------------>",associateduserdata);
    return { associateduserdata };
}

export default connect(mapStateToProps)(AssociatedDetLayer);