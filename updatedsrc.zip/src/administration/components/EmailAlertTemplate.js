import React from 'react';
import { Route, Link } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { AdministrationActions } from '../actions/administration.actions';
import { connect } from 'react-redux';
import Filters from './FiltersEmailAlertTemplate';
import { ReactTableDefaults } from "react-table";
import '../../../node_modules/react-table/react-table.css';
import '../../user/css/App.css';
import MUIDataTable from "mui-datatables";
import {muiTableStyles} from '../../styles/muidatatableCss';
import FormData from 'form-data';
import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import NativeSelect from '@material-ui/core/NativeSelect';
import RFPSnackbars from '../../messages/RFPSnackbars';
import TemplateDetails from './TemplateDetails';
import { AlertAddAlert } from 'material-ui/svg-icons';
import Loading from '../../common/Loading';
import TableLoader from '../../common/TableLoader';
import { MuiStyles } from '../../styles/MuiStyles';

Object.assign(ReactTableDefaults, {
    defaultPageSize: 5,
     minRows: 1
  });
	let selectedTmpsData={};
	var onChangeFlag = false;
	let loadFilter=false;
	let alertTemplate;
	let  loginId;
	let  companyId;
	let  submitData=[];
	let  saveData =[];
	let msg="";
class EmailAlertTemplate extends React.Component {

    getMuiTheme = () => createMuiTheme({
        typography: {
            useNextVariants: true,
},
        overrides: {
             MuiFormControl: {
                                  marginNormal: {
                                      marginTop: '0px',
                                       marginBottom: '0px',
                                   }
          }, MuiIconButton: {
                                  root: {
                                      padding: '2px',
                                   }
          },
          MUIDataTableBodyCell: {
            root: {
                whiteSpace: 'nowrap',
                padding:'0px 56px 0px 24px'
             }
          },
          MUIDataTableBodyRow: {
                      root: {
                          height: '20px',
                       }
          },
        }
})
    constructor(){
        super();
        this.state={
            results:[],
            results1:[],
            submitData:[],
            saveData:[],
            assignAlertRecipientsData:[],
            assignAlertRecipientsTableData:[],
            columns:[],
            screenName:'',
            saveflag:false,
            loading:true
        }
        this.doChange = this.doChange.bind(this);
        this.doFilterChange = this.doFilterChange.bind(this);
        this.onCheckRows = this.onCheckRows.bind(this);
        this.doSubmit = this.doSubmit.bind(this);
    }
    componentDidMount() {
        this.getFilter()
        loadFilter=true;
   }
   componentDidUpdate(){
       msg=''
    console.log("componentDidUpdate===",msg)

    //if(!loadFilter)
        //this.getFilter();
   }
   componentWillMount(){
       this.getFilter();
   }
   getFilter(){
	   onChangeFlag = false;
	   msg='';
	   var bodyFormData = new FormData();
    this.props.dispatch(AdministrationActions.fetchAssignAlertRecipientsData(bodyFormData, ''));
   }
   doChange(fillObj){
         var bodyFormData = new FormData();
          for (name in fillObj) {
            bodyFormData.append(name, fillObj[name]);
        }
        onChangeFlag = true;
        this.props.dispatch(AdministrationActions.fetchassignAlertRecipientsTableData(bodyFormData));
    }

     doFilterChange(fillObj, selFirm){
            onChangeFlag = false;
            msg='';
            this.props.dispatch(AdministrationActions.fetchAssignAlertRecipientsData(fillObj, selFirm));
    }

onCheckRows(submitData){
    saveData=submitData;
    //console.log('submitData  onCheckRows :'+JSON.stringify(saveData));
}
doSubmit() {
      if(saveData != null && saveData.length>0){
        if (window.confirm('Are you sure, you want to save the data?')){
        var bodyFormData = new FormData();
        saveData.map((item,index) => {
           bodyFormData.append('userCompId'+index, item.companyId);
           bodyFormData.append('loginId'+index, item.loginId);
           bodyFormData.append('userChk'+index, item.loginId);
            if(item.alertTemplate===selectedTmpsData[item.dataIndex]){
            bodyFormData.append('alertTemplate'+index, item.alertTemplate);
           }else{
            bodyFormData.append('alertTemplate'+index, selectedTmpsData[item.dataIndex]);
           }
        });
       bodyFormData.append('clientFirm', JSON.parse(sessionStorage.getItem('clientFirm')));
       bodyFormData.append('size', saveData.length);
       bodyFormData.append('actionFlag', "SAVE");
       onChangeFlag = true;
       saveData=[];
       this.props.dispatch(AdministrationActions.fetchassignAlertRecipientsTableData(bodyFormData));
    }
     }else{
       alert("Please check at least one check box to save.")
     }
    }

    render(){
        const { classes } = this.props;
         this.state.assignAlertRecipientsData = this.props.assignAlertRecipientsData;
         this.state.assignAlertRecipientsTableData = this.props.assignAlertRecipientsTableData;
         if(onChangeFlag){
            this.state.results1  = this.state.assignAlertRecipientsTableData.assignAlertRecipientsTableData;
         }
         else{
            this.state.results1  = this.state.assignAlertRecipientsData.assignAlertRecipientsData;
        }
        let filetermarkup;
        let results2 = [];
        let results3 = [];
        let NewAlertTemplateArry = [];
        let msgType="success";

        if( this.state.results1 !== undefined)
        {
            data = this.props.data;
            this.state.loading=false ;
        }

        if( this.state.results1 !== undefined)
             this.state.results1.map((item,index) => {
                if(item.type === "Title")
                 this.state.screenName = item.name

                if(item.name === "data")
                results2 = item.values

                if(item.name === "columns")
                results3 = item.COLUMNS

                if(item.name === "NewAlertTemplate" && item.type === "Select1" )
                NewAlertTemplateArry = item.values


					if(item.type === "SaveMessage"  && this.state.saveflag===false){
						msg = item.name;
						msgType =item.label;
						this.state.saveflag=true;
                    }
            })

			results3 && results3.map((item,index)=> {
				if(item.name === 'ClientName') {
					let obj	= results3.find(namevalue => namevalue.name === 'ClientName');
					obj.label = 'Client Name';
				} else if(item.name === 'CurrentEmailAlertTemplate') {
					let obj	= results3.find(namevalue => namevalue.name === 'CurrentEmailAlertTemplate');
					obj.label = 'Current Email Alert Template';
				} else if(item.name === 'NewAlertTemplate') {
					let obj	= results3.find(namevalue => namevalue.name === 'NewAlertTemplate');
					obj.label = 'New Alert Template';
				}
			});

           results3 &&  results3.map((item,index)=> {
                if(item.options.hyperlink === "true"){
                    item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
                        return (
                            <TemplateDetails tempUserVal={value} tempDet={tableMeta.rowData} fromPage='EAUACL' />
                        );
                    }
                }
                if(item.name === "NewAlertTemplate"){
                    item.options["customBodyRender"] = (value, tableMeta, updateValue) => {
                        let temp =value.NewAlertTemplateArry &&  value.NewAlertTemplateArry.map((obj, index) =>{
                            return <option key={index} value={obj.id}>{obj.name}</option>
                        })
                        return (
                            <NativeSelect className={classes.select} onClick={(e)=>{ value.NewAlertTemplate=e.target.value;
                            selectedTmpsData[tableMeta.rowIndex]=e.target.value;
                            }} style={{fontSize: 'inherit'}} defaultValue={value.NewAlertTemplate} children={temp}/>
                        );
                    }
                }
            });



             let data=[];

            if(results2 && results2.length>0){
                results2.map((row,index) => {
                let cdata=[];
                let NewAlertTemplateArry1=[];
                 cdata.push(row.User);
                cdata.push(row.ClientName);
                cdata.push(row.CurrentEmailAlertTemplate);
                if(row.alterTemplateRows && row.alterTemplateRows.length>0){
                 for(var i=1;i<row.alterTemplateRows.length;i++)
                 NewAlertTemplateArry1.push(NewAlertTemplateArry.find(e => e.id===row.alterTemplateRows[i]));
                cdata.push({NewAlertTemplateArry:NewAlertTemplateArry1, NewAlertTemplate:row.NewAlertTemplate});
				}
                cdata.push(row.LoginId);
                cdata.push(row.CompanyId);
                selectedTmpsData[index]=row.NewAlertTemplate;
                data.push(cdata);
            })
            }



			let rowsFlag = false;

			if(results2 && results2.length>0){
				rowsFlag = true;
			}
            const options = {
                viewColumns:false,
                filter: false,
                filterType: 'dropdown',
                responsive: 'stacked',
				selectableRows:rowsFlag,
				download:rowsFlag,
				search:rowsFlag,
				pagination:rowsFlag,
                customToolbarSelect: (selectedRows, displayData, setSelectedRows) =>{
                    let ids=[];
                    let rowData=[];
                    submitData=[];
                     displayData && displayData.map((disdata,index) => {
                    selectedRows && selectedRows.data.map((row,index) => {
                     if(row.dataIndex === disdata.dataIndex){
                           if(!ids.includes(disdata.data[4])){
                                 ids.push(disdata.data[4]);
                                         let selectObj= {
                                             dataIndex:row.dataIndex,
                                            companyId:disdata.data[5],
                                            loginId:disdata.data[4],
                                            alertTemplate:selectedTmpsData[disdata.dataIndex]
                                  }
                                   submitData.push(selectObj);
                                   this.onCheckRows(submitData);
                                   var totChkCntId = document.getElementById("totChkCntId");
		                           if (totChkCntId != null) {
 			                          totChkCntId.innerHTML = submitData.length;
		                          }
                            }
                           }
                       })
                    })
                },
                setRowProps: (row) => {
                    return {

                    };
                },
                onRowsSelect: (rowsSelected, allRows) => {
                       let newSaveData=[]
                    if(saveData && saveData.length>0){
                         saveData.map((item,index) => {
                            if((allRows.find((row) => row.index === item.dataIndex)))
                            newSaveData.push(item);
                         });
                    }
                    saveData=newSaveData;
                    var totChkCntId = document.getElementById("totChkCntId");
		            if (totChkCntId != null) {
 			             totChkCntId.innerHTML = saveData.length;
		            }
                  },
                   textLabels: {
				              body: {
				                   noMatch: (this.props.assignAlertRecipientsTableData.loading || this.props.assignAlertRecipientsData.loading)?
				                      <TableLoader/> :
				                         <div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No data found</b></div>,
				              },
        },
             };

             if(this.state.loading)
        	return( <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div> );
        else{
         return <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{this.state.screenName}</h4>
                    </div>
                    <div className="panel-body">
                        <div className="col-md-12 col-sm-12 head-cls">
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                    <a className="pull-right" onClick={this.tottgleDisplay}>
                                        <i className="fa fa-caret-down"></i>
                                    </a>
                                </div>
                            </div>
                            <div className="filter_div" id="filter_div" >
                            <Filters method={this.doFilterChange} data={this.state.assignAlertRecipientsData}/>
                            </div>
                        </div>

                        <div className="clearfix"></div>
                        <div className="col-md-12 col-sm-12 head-cls backwhite" style={{width:'80%',marginRight:'15px'}}>
                            <div className="panel">
                                <div className="panel-heading clearfix">
                                    <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                                </div>
                            </div>
  							 <div>
					            <div className="text-center displayTxt" style={{marginTop:'8px'}}>{msg}</div>
                            </div>
                                <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                                <MUIDataTable
                                data={data}
                                columns={results3} options={options}  viewColumns={false}/>
                                </MuiThemeProvider>


                            <h5 className="col-md-8  col-sm-12 clearfix pull-left">
                            No.of user-email alert template associations selected:<span id="totChkCntId">0</span>
                            </h5>
                            <div className="col-md-6">
                                <a title="Save" onClick={(e)=>{this.doSubmit();}} className="btn btn-primary btn-xs">Save</a>
                                 <Route render={({ history}) => (
                                    <button  className="btn btn-primary btn-xs"
                                        type='button'
                                        onClick={() => { history.push('/administration/EAUACL') }}
                                    >
                                        Reset
                                </button>
                                )} />
                            </div>
                        </div>
                        <div style ={{float:'left',width:'18%',marginTop:'5px'}}>
                            <table className="table table-striped table-bordered">
								 <thead>
									 <tr>
										 <th>
											 Related Links
										 </th>
									 </tr>
								 </thead>
								 <tbody>
									 <tr>
										 <td>
											 <Link to="/administration/CLALERT">Email Alert Management</Link>
										 </td>
                                    </tr>
								 </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        }
    }
}
function mapStateToProps(state) {
    const { assignAlertRecipientsData,assignAlertRecipientsTableData } = state;
    return { assignAlertRecipientsData,assignAlertRecipientsTableData };
}

const connectedEmailAlertTemplate = connect(mapStateToProps)(withStyles(MuiStyles)(EmailAlertTemplate));
export { connectedEmailAlertTemplate as EmailAlertTemplate };
