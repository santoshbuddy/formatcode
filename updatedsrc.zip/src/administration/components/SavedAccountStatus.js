import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { alertConstants } from '../../common/constants/alert.constants';
import { AdministrationActions } from '../actions/administration.actions';
import { withStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import { NavBar } from '../../navbar/components/navbar';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepConnector from '@material-ui/core/StepConnector';
import Grid from '@material-ui/core/Grid';
import axios from 'axios';
import { messageUS } from '../../common/javascript/i18N/en_US/alerts';
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts';
import { history } from '../../_helpers';
import Tooltip from '@material-ui/core/Tooltip';
import Info from "@material-ui/icons/Info";
import Loading from '../../common/Loading';
import infoIcon from '../../images/questionmark.png';
var CommonData = [];

const styles = theme => ({
    root: {
      width: '100%',
    },
    heading: {
      fontSize: theme.typography.pxToRem(15),
      fontWeight: theme.typography.fontWeightRegular,
    },
    statustxt: {
    	textAlign: 'center',
    	color: 'rgb(255,0,0)',
  	},
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
        margin:'2px',
        display: 'inline',
    },
	connectorActive: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorCompleted: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorDisabled: {
		'& $connectorLine': {
			borderColor: theme.palette.grey[100],
			borderWidth: '2px'
		},
	},
	connectorLine: {
		transition: theme.transitions.create('border-color,border-size'),
	},
	stepIcon: {
		color: "#828384",
		fontSize: '19px',
		"&$active": {
			color: "#00395c",
			fontSize: '37px'
		},
		"&$completed": {
			color: "#00395c",
			fontSize: '19px'
		}
	},
	active: {},
	completed: {},
	typography: {
		useNextVariants: true,
	},
	iconContainer :{
		paddingRight: "0"
	},
	stepStyle:{
		paddingRight: "0",
		paddingLeft: "0"
	}
});

class SavedAccountStatus extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            columns:[],
            activeStep: 2,
            shortname:'',
			longname:'',
			clientidnetifier:'',
			stmtremark:''
        }

		this.handleChange = this.handleChange.bind(this);
		this.backTommfAccounts = this.backTommfAccounts.bind(this);
    }
 backTommfAccounts()
 		{
 			this.props.history.push({
 				pathname: '/administration/LOOKUP',
 				state: {
 					tabIndex: 1,
 					activeStep: 2,
 					product: this.props.location.state.product,
 					productname: this.props.location.state.productname,
 					currency: this.props.location.state.currency,
 					fundTypeId: this.props.location.state.fundTypeId,
 					fundFamilyId: this.props.location.state.fundFamilyId
 				}
 			});
 		}

	////backTommfAccounts() {
      // history.push("/administrationcreate/LOOKUP");
	//}

    handleChange = name => event => {
        this.setState({
            [name]: event.target.value,
        });
    };

	getSteps() {
	    return ['', '', ''];
  	}

    render(){
		const steps = this.getSteps();
		const { activeStep } = this.state;
        const { classes } = this.props;
		const connector = (
			<StepConnector
				classes={{
					active: classes.connectorActive,
					completed: classes.connectorCompleted,
					disabled: classes.connectorDisabled,
					line: classes.connectorLine,
				}}
			/>
		);

       	var prodName 	= this.props.location.state.productname;
       	var commonData	= this.props.location.state.commonData;
       	let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

		console.log('commonData--SUCCESS--commonData--',commonData);
		let backButton;
		var errorMsg	= '';
    backButton=<button className="btn btn-primary btn-xs mt" id="back" onClick={this.backTommfAccounts.bind(this)}>Back To MMF Accounts</button>
		if(commonData !== undefined && commonData.toString().length > 0)
		{
			if(commonData.msg != null && commonData.msg != undefined && commonData.msg != '')
				errorMsg	= message[commonData.msg];

			if(commonData.message != null && commonData.message != undefined && commonData.message != '')
				errorMsg	= commonData.message;

			return  (
				<div className={classes.root}>
					<NavBar/>
					<div className="clearfix"></div>

					<div className="panel panel-primary">
						<div className="panel-heading">
							<h4 className="panel-title">Create New MMMF Account</h4>
						</div>
						<div className="panel-body">
							<div className="col-md-12 col-sm-12">

								<Stepper  className="col-md-6" activeStep={activeStep} connector={connector}>
									{steps && steps.map((label, index) => {
										const props = {};
										const labelProps = {};
										return (
										<Step key={label} {...props} className={classes.stepStyle}>
											<StepLabel classes={{iconContainer:classes.iconContainer}}
												StepIconProps={{
													classes: { root: classes.stepIcon, active:classes.active, completed:classes.completed }
												}}>
											</StepLabel>
										</Step>
										);
									})}
								</Stepper>
								<div className="clearfix"></div>

								<Grid container spacing={24}>
									<Grid xs={12} className={classes.statustxt}>{errorMsg}</Grid>
								</Grid>

								<h5 style={{fontWeight:'bold'}}>{prodName}</h5>
								<ExpansionPanel defaultExpanded>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Description</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>

										<Grid container spacing={24}>
											<Grid item xs={4}>
												<InputLabel required className={classes.labelStyle}>
												MMMF Account Number:
												</InputLabel>
												<span className={classes.mrgnRgt}>
												<Tooltip title="MMF Account Number Is Used to Show accounts" aria-label="Add">
													<img src={infoIcon} width="18" className={classes.info}/>
													</Tooltip>
													</span>

												<TextField
													ref="refmmfacctnbr"
													className={classes.textField}
													value={commonData.mmmfaccountnumber}
													defaultValue=""
													onChange={this.handleChange('refmmfacctnbr')}
												/>
											</Grid>

											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>
												Currency:</InputLabel>
												<span className={classes.mrgnRgt}>
												<Tooltip title="Short Name is used in Reports, Statements and SWIFT Messages" aria-label="Add">
												<img src={infoIcon} width="18" className={classes.info}/>
												</Tooltip>
												</span>

												<TextField
													ref="refcurrency"
													className={classes.textField}
													value={commonData.currency}
													defaultValue=""
													onChange={this.handleChange('refcurrency')}
												/>
											</Grid>

											<Grid item xs={4}>
												<InputLabel required className={classes.labelStyle}>
												Short Name:</InputLabel>
												<span className={classes.mrgnRgt}>
												<Tooltip title="Short Name is used in Reports, Statements and SWIFT Messages" aria-label="Add">
													<img src={infoIcon} width="18" className={classes.info}/>
													</Tooltip>
													</span>

												<TextField
													ref="refshortname"
													className={classes.textField}
													value={commonData.mmfdesc}
													defaultValue=""
													onChange={this.handleChange('shortname')}
												/>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>
												Long Name:</InputLabel>
												<span className={classes.mrgnRgt}>
												<Tooltip title="Long Name is for Client internal use" aria-label="Add">
													<img src={infoIcon} width="18" className={classes.info}/>
													</Tooltip>
													</span>

												<TextField
													ref="reflongname"
													className={classes.textField}
													value={commonData.mmfdesclong}
													onChange={this.handleChange('longname')}
													defaultValue=""
													margin="normal"
												/>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>
												Client Identifier:</InputLabel>
												<span className={classes.mrgnRgt}>

												<Tooltip title="Client Identifier is for Client internal use" aria-label="Add">
													<img src={infoIcon} width="18" className={classes.info}/>
													</Tooltip>
													</span>

												<TextField
													ref="refclientidnetifier"
													className={classes.textField}
													value={commonData.clientIdentifier}
													onChange={this.handleChange('clientidnetifier')}
													defaultValue=""
													margin="normal"
												/>
											</Grid>
										</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Accounts & Dividend Options</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>
										<Grid container spacing={24}>
											<Grid item xs={4}>
												<InputLabel>Investment Account:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.investmentaccountname }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel>Account Structure:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.acctstrt }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel>Funding Account:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.fundingacct }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel>Settlement Type:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.setltype }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel>Dividend Account:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.dvdnacct }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel>Dividend Type:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.dvdntype }</InputLabel>
											</Grid>

										</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Tax Information (not editable)</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>
										<Grid container spacing={24}>
											<Grid item xs={4}>
												<InputLabel>Tax ID:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.taxId }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel>Taxpayer Type:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.taxtype }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel>Acc Social Code:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.soccode }</InputLabel>
											</Grid>
										</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Primary Legal Address (not editable)</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>
										<Grid container spacing={24}>
											<Grid item xs={4}>
												<InputLabel >Company Name:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.legalComp }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel >City:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.legalCity }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel>Zip:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.legalZip }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel >Address:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.legalAddr1 }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel>State:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.legalState }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel>Country:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.legalCountry }</InputLabel>
											</Grid>
										</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Statement Mailing Address (not editable)</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>
										<Grid container spacing={24}>
											<Grid item xs={4}>
												<InputLabel >Company Name:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.stmtComp }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel >City:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.stmtCity }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel>Zip</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.stmtZip }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel >Address:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.stmtAddr1 }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel>State:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.stmtState }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel>Country:</InputLabel>
												<InputLabel className="TxtNrml">{ commonData.stmtCountry }</InputLabel>
											</Grid>
										</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Remarks (optional)</b></Typography>
									</ExpansionPanelSummary>
									<ExpansionPanelDetails>
										<Typography>
											<InputLabel>Remarks:</InputLabel>
											<TextField
												multiline
												rows="4"
												className={classes.textField}
												onChange={this.handleChange('stmtremark')}
												value={ commonData.remarks1 }
												defaultValue=""
												margin="normal"
											/>
										</Typography>
									</ExpansionPanelDetails>
								</ExpansionPanel>
								<div style={{padding: '2px 15px'}}>
								{backButton}
 								</div>
							</div>
						</div>
					</div>
				</div>
			)
		}
		else
		{
			return(
				<div>
                <Loading/>
				</div>
			)
		}
    }
}

SavedAccountStatus.propTypes = {
    classes: PropTypes.object.isRequired,
};

function mapStateToProps(state) {
    const { mmfcreateAcctDet } = state;

    return { mmfcreateAcctDet };
}

const connectedSavedAccountStatus = connect(mapStateToProps)(withStyles(styles)(SavedAccountStatus));
export { connectedSavedAccountStatus as SavedAccountStatus };