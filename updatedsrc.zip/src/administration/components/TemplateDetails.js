import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import FromData from 'form-data';
import { AdministrationActions } from '../actions/administration.actions';
 
class TemplateDetails extends React.Component{
    constructor(props) {
	    super(props);
        this.state = {
            open: false,
            screenName:'',
            tempUserVal:this.props.tempUserVal ? this.props.tempUserVal : '',
            tempUserDet: this.props.tempDet ? this.props.tempDet : null,
            fromPage:this.props.fromPage?this.props.fromPage:'',
            tempuserdata:[]
        }
    };

    // TemplateDet = () => {
    //     var bodyFormData = new FromData(); 

    //     if(this.state.tempUserDet){
    //         bodyFormData.append("companyId",this.state.tempUserDet[3].companyId);
    //         bodyFormData.append("selTemplate",this.state.tempUserDet[3].selTemplate);
    //         bodyFormData.append("tempclientFirm",this.state.tempUserDet[3].companyId);
            
            
    //     }

    // };

    render() {
        const options = {
            filter: true,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:false        
        };
        // console.log("veczise:::::>",this.props.size.vecsize);
        //  console.log('this.state.tempUserVal>>>'+this.props.tempDet[3] , this.props.tempUserVal);
         var linkStr = '';
         if(this.state.fromPage==='EAUACL'){
           linkStr= <Link to={{ pathname:"/administration/EDITEMAILTEMP",state: { selTemplate:this.props.tempDet[3].NewAlertTemplate, tempclientFirm: this.props.tempDet[3].companyId} }}>{this.props.tempUserVal}</Link>  ;
         }else{
           linkStr=<Link to={{ pathname:"/administration/EDITEMAILTEMP",state: { processId: this.props.tempDet[3].processId, selTemplate:this.props.tempDet[3].selTemplate, tempclientFirm: this.props.tempDet[3].companyId, mcFlag:this.props.mcFlag.roleFlag, vecsize:this.props.size.vecsize} }}>{this.props.tempUserVal}</Link>  ;
         }         
         return(
            <div>
                {
                    linkStr                    
                }
                  
            </div>
        )
    }
} 

export default TemplateDetails;