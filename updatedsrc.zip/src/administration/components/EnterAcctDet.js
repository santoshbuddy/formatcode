import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { connect } from 'react-redux';
import { alertConstants } from '../../common/constants/alert.constants';
import { AdministrationActions } from '../actions/administration.actions';
import { withStyles,MuiThemeProvider } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import TextField from '@material-ui/core/TextField';
import { NavBar } from '../../navbar/components/navbar';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepConnector from '@material-ui/core/StepConnector';
import Grid from '@material-ui/core/Grid';
import axios from 'axios';
import Info from "@material-ui/icons/Info";
import Tooltip from '@material-ui/core/Tooltip';
import Fab from '@material-ui/core/Fab';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles} from '../../styles/MuiStyles';
import Loading from '../../common/Loading';
import infoIcon from '../../images/questionmark.png';

var TaxStatus 	= [];
var TaxStateTxt = [];
var TaxCountryTxt = [];
var StateTxt = [];
var CountryTxt = [];
var InvestAccount = [];
var FundAccount = [];
var RedemDDANumberAccount = [];
var BranchID = [];
var DividendAcct = [];
var DividendType = [];
var AccountStructure = [];
var SettleType = [];
var TaxInformation = [];
var PrimaryLegalAddress = [];
var StatementMailingAddress = [];
var CommonData = [];

const styles = theme => ({
    root: {
      width: '100%',
    },
    heading: {
      fontSize: theme.typography.pxToRem(15),
      fontWeight: theme.typography.fontWeightRegular,
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
        margin:'2px',
        display: 'inline',
    },
	connectorActive: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorCompleted: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorDisabled: {
		'& $connectorLine': {
			borderColor: theme.palette.grey[100],
			borderWidth: '2px'
		},
	},
	connectorLine: {
		transition: theme.transitions.create('border-color,border-size'),
	},
	stepIcon: {
		color: "#828384",
		fontSize: '19px',
		"&$active": {
			color: "#00395c",
			fontSize: '37px'
		},
		"&$completed": {
			color: "#00395c",
			fontSize: '19px'
		}
	},
	active: {},
	completed: {},
	typography: {
		useNextVariants: true,
	},
	iconContainer :{
		paddingRight: "0"
	},
	stepStyle:{
		paddingRight: "0",
		paddingLeft: "0"
	}
});
//doBackConfirm(){
	//  history.push("/administrationcreate/REVIEWPROS");
//
     // this.props.goback(this.state.invAmtValueArray)
   // }
class EnterAcctDet extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            columns:[],
            activeStep: 2,
            mmfAcctNbr:'',
            shortname:'',
			longname:'',
			clientidnetifier:'',
			investacct:'',
			fundacct:'',
			dividentAcct:'',
			dividentType:'',
			stmtremark:''
        }

		this.handleChange = this.handleChange.bind(this);
		this.saveAcctDetails = this.saveAcctDetails.bind(this);
    }
    enterAccountDet()
		{
			this.props.history.push({
				pathname: '/administration/REVIEWPROS',
				state: {
					tabIndex: 1,
					activeStep: 2,
					product: this.props.location.state.product,
					productname: this.props.location.state.productname,
					currency: this.props.location.state.currency,
					fundTypeId: this.props.location.state.fundTypeId,
					fundFamilyId: this.props.location.state.fundFamilyId
				}
			});
		}

    componentWillMount(){
		var bodyFormData = new FormData();

		bodyFormData.append("product", this.props.location.state.product)
        bodyFormData.append("currency", this.props.location.state.currency);
//        bodyFormData.append("fundTypeId", this.props.location.state.fundTypeId);
//        bodyFormData.append("fundFamilyId", this.props.location.state.fundFamilyId);

		if(this.props.location.state.actionFlag != undefined && this.props.location.state.actionFlag == 'FUNDACCTINFO') {
			bodyFormData.append("company", this.props.location.state.company);
			bodyFormData.append("fundTypeId", this.props.location.state.fundTypeId);
			bodyFormData.append("actionFlag", this.props.location.state.actionFlag);
		}

        this.props.dispatch(AdministrationActions.fetchMmfcreateAcctData(bodyFormData));
	}

	saveAcctDetails() {
		var bodyFormData 	= new FormData();
    	var user 			= JSON.parse(sessionStorage.getItem('user'));
    	var rdividentType	= this.state.dividentType;
    	var rfundacct		= this.state.fundacct;
    	var rinvestacct		= this.state.investacct;
    	var rdividentAcct	= this.state.dividentAcct;
        if(this.state.shortname !== ''){
       if(window.confirm('Are you sure, you want to open this account?')){

    	if(rdividentType == '')
    		rdividentType	= CommonData.dividendType;

    	if(rfundacct == '')
    		rfundacct	= CommonData.ddaAcct;

    	if(rinvestacct == '')
    		rinvestacct	= CommonData.investAccount;

    	if(rdividentAcct == '')
    		rdividentAcct	= CommonData.dividendAcct;

	    bodyFormData.append("token",user[0].token);
	    bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
		bodyFormData.append("acctStruType", AccountStructure.name);
		bodyFormData.append("seldvndType", "RECAPITALIZE");	//	Need to do dynamic
		bodyFormData.append("acctGenType", "A");
		bodyFormData.append("selCompName", StatementMailingAddress.CompanyName);
		bodyFormData.append("selClientFirm", JSON.parse(sessionStorage.getItem('clientFirm')));
		bodyFormData.append("prospectusStatus", "Y");
		bodyFormData.append("clientFirm", JSON.parse(sessionStorage.getItem('clientFirm')));
		bodyFormData.append("fundProduct", this.props.location.state.fundFamilyId);
		bodyFormData.append("product", this.props.location.state.product);
		bodyFormData.append("selectedProdName", this.props.location.state.productname);
		bodyFormData.append("currency", this.props.location.state.currency);
		bodyFormData.append("mmfProduct", this.props.location.state.product);
		bodyFormData.append("frmPage", "newMMFAccount");
		bodyFormData.append("fundFamilyId", this.props.location.state.fundFamilyId);
		bodyFormData.append("fundTypeId", this.props.location.state.fundTypeId);
		bodyFormData.append("prodId", this.props.location.state.product);
		bodyFormData.append("ccy", this.props.location.state.currency);
		bodyFormData.append("refFundNbr", CommonData.refFundNbr);
		bodyFormData.append("actionFlag", "SAVE");
		bodyFormData.append("escrow", "N");
		bodyFormData.append("stmtAddressId", CommonData.stmtAddressId);
		bodyFormData.append("mmfAcctNbr", this.state.mmfAcctNbr);
		bodyFormData.append("mmfDesc", this.state.shortname);
		bodyFormData.append("mmfDescLong", this.state.longname);
		bodyFormData.append("clientIdentifier", this.state.clientidnetifier);
		bodyFormData.append("investAccount", rinvestacct);
		bodyFormData.append("acctStruID", CommonData.acctStruID);
		bodyFormData.append("ddaAcct", rfundacct);
		bodyFormData.append("ddaStleID", CommonData.ddaStleID);
		bodyFormData.append("dividendRef", rdividentAcct);
		bodyFormData.append("dividendAcct", rdividentAcct);
		bodyFormData.append("dividendType", rdividentType);
		bodyFormData.append("taxId", TaxInformation.TaxID);
		bodyFormData.append("seltaxPayerType", TaxInformation.TaxpayerType);
		bodyFormData.append("selsocialCode", CommonData.selsocialCode);

        axios({
            method: 'post',
            url:alertConstants.URL+"/ADDACCNT.do",
            data: bodyFormData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
		}).then((response)=>{
			if(response.data.commonData != undefined) {
			console.log("response.data.commonData===>",response.data.commonData)
				var forwardFlag = response.data.commonData.forwardFlag;
				if(forwardFlag === 'true') {
					this.props.history.push({
						pathname: '/administration/MMFACCTSUCCESS',
						state: {
							tabIndex: 1,
							activeStep: 2,
							productname: this.props.location.state.productname,
							commonData: response.data.commonData
						}
					});
				} else {
					alert(response.data.commonData.errMsg);
				}
			}
		});
            }

}

		  else {
		              return alert('Please enter Short Name')
        }
	}


    handleChange = name => event => {
		if(name === 'dividentType')
		{
			var bodyFormData = new FormData();
			bodyFormData.append("product", this.props.location.state.product)
			bodyFormData.append("currency", this.props.location.state.currency);
			bodyFormData.append("dividendType", event.target.value);

			if(this.props.location.state.actionFlag != undefined && this.props.location.state.actionFlag == 'FUNDACCTINFO')
			{
				bodyFormData.append("company", this.props.location.state.company);
				bodyFormData.append("fundTypeId", this.props.location.state.fundTypeId);
				bodyFormData.append("actionFlag", this.props.location.state.actionFlag);
			}

			this.props.dispatch(AdministrationActions.fetchMmfcreateAcctData(bodyFormData));
		}

        this.setState({
            [name]: event.target.value,
        });
    };

	getSteps() {
	    return ['', '', ''];
  	}

    render(){
//        const { data } = this.props;
		const steps = this.getSteps();
		let operVal;
		const { activeStep } = this.state;
        const { classes, cData, accountsDividendOptions, taxInformation, primaryLegalAddress, statementMailingAddress, commonData } = this.props;
		const connector = (
			<StepConnector
				classes={{
					active: classes.connectorActive,
					completed: classes.connectorCompleted,
					disabled: classes.connectorDisabled,
					line: classes.connectorLine,
				}}
			/>
		);

       	var prodId 		= this.props.location.state.product;
       	var CcyVal 		= this.props.location.state.currency;
       	var prodName 	= this.props.location.state.productname;
       	var divtypeFlag = false;
		var fundAcctFlag= false;
		var acctGenerateFlag= false;
		var redimDdaFlag = false;

        let backButton;
        backButton=<button className="btn btn-primary btn-xs mt" id="back" onClick={this.enterAccountDet.bind(this)}>Back</button>
		if(accountsDividendOptions !== undefined && accountsDividendOptions.toString().length > 0)
		{
			console.log('accountsDividendOptions---accountsDividendOptions---',accountsDividendOptions);
			if(accountsDividendOptions.investAccount != undefined) {
				if(accountsDividendOptions.investAccount.values != undefined) {
					InvestAccount 		= accountsDividendOptions.investAccount.values;
				}
			}

			if(accountsDividendOptions.fundingAccount != undefined) {
				if(accountsDividendOptions.fundingAccount.values != undefined) {
					FundAccount 		= accountsDividendOptions.fundingAccount.values;
				}
			}

			if(accountsDividendOptions.redemDDANumber != undefined) {
				if(accountsDividendOptions.redemDDANumber.values != undefined) {
					RedemDDANumberAccount 		= accountsDividendOptions.redemDDANumber.values;
				}
			}

			if(accountsDividendOptions.dividendAccount != undefined) {
				if(accountsDividendOptions.dividendAccount.values != undefined) {
					DividendAcct 		= accountsDividendOptions.dividendAccount.values;
				}
			}

			if(accountsDividendOptions.dividendType != undefined) {
				if(accountsDividendOptions.dividendType.values != undefined) {
					DividendType 		= accountsDividendOptions.dividendType.values;
				}
			}

			if(accountsDividendOptions.accountStructure != undefined) {
				AccountStructure 		= accountsDividendOptions.accountStructure;
			}

			if(accountsDividendOptions.settleType != undefined) {
				SettleType	 		= accountsDividendOptions.settleType;
			}

			if(taxInformation != undefined) {
				TaxInformation	 		= taxInformation;
			}

			if(primaryLegalAddress != undefined) {
				PrimaryLegalAddress	 		= primaryLegalAddress;
			}

			if(statementMailingAddress != undefined) {
				StatementMailingAddress	 		= statementMailingAddress;
			}

			if(commonData != undefined) {
				CommonData	 		= commonData;

				if(CommonData.disabledDivType === "true") {
					divtypeFlag = true;
				}

				if(CommonData.acctGenFlag === "true") {
					acctGenerateFlag = true;
				}

				if(CommonData.redimDdaFlag === "true") {
					redimDdaFlag = true;
				}

				operVal=commonData.operVal;
				//operVal=7;
        			//console.log("may 08, 2019 ::account creation ::operVal:::::::::::::;:",operVal);
				if(CommonData.disabledfundAcct === true) {
					fundAcctFlag = true;
				}
			}

			return  (
				<div className={classes.root}>
					<NavBar/>
					<div className="clearfix"></div>
					<div className="panel panel-primary">
						<div className="panel-heading">
							<h4 className="panel-title">Create New MMMF Account</h4>
						</div>
						<div className="panel-body">
							<div className="col-md-12 col-sm-12">

								<Stepper  className="col-md-6" activeStep={activeStep} connector={connector}>
									{steps && steps.map((label, index) => {
										const props = {};
										const labelProps = {};
										return (
										<Step key={label} {...props} className={classes.stepStyle}>
											<StepLabel classes={{iconContainer:classes.iconContainer}}
												StepIconProps={{
													classes: { root: classes.stepIcon, active:classes.active, completed:classes.completed }
												}}>
											</StepLabel>
										</Step>
										);
									})}
								</Stepper>
								<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
								<div className="clearfix"></div>
								<h5 style={{fontWeight:'bold'}}>{prodName}</h5>
								<ExpansionPanel defaultExpanded>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Description</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>

<Grid container spacing={24}>
	<Grid item xs={4}>
	  {acctGenerateFlag === true ?<InputLabel required className={classes.labelStyle}>MMMF Account Number:</InputLabel>:''}
	  {acctGenerateFlag === true ?<span className={classes.mrgnRgt}><Tooltip title="" aria-label="Add"><img style={{position:'relative'}} src={infoIcon} width="18" className={classes.info}/></Tooltip></span>:''}
	  {acctGenerateFlag === true ?<TextField ref="refmmfAcctNbr" inputProps={{maxLength: 19,}} className={classes.inputStyle} value={this.state.mmfAcctNbr} defaultValue="" onChange={this.handleChange('mmfAcctNbr')}/>:''}
	</Grid>
	<Grid item xs={4}>
		<InputLabel className={classes.labelStyle}></InputLabel>
		<InputLabel className="TextNrml"></InputLabel>
	</Grid>
	<Grid item xs={4}>
		<InputLabel className={classes.labelStyle}></InputLabel>
		<InputLabel className="TextNrml"></InputLabel>
	</Grid>
	<Grid item xs={4}>
	<InputLabel required className={classes.labelStyle}>
		Short Name:
	</InputLabel>
	<span className={classes.mrgnRgt}>
		<Tooltip title="Short Name is used in Reports, Statements and SWIFT Messages" aria-label="Add">
			<img style={{position:'relative'}} src={infoIcon} width="18" className={classes.info}/>
		</Tooltip>
	</span>
	<TextField
		ref="refshortname"
		inputProps={{
			maxLength: 19,
		}}
		className={classes.inputStyle}
		value={this.state.shortname}
		defaultValue=""
		onChange={this.handleChange('shortname')}
	/>
	</Grid>
	<Grid item xs={4}>
	<InputLabel className={classes.labelStyle}>
		Long Name:
	</InputLabel>
	<span className={classes.mrgnRgt}>
		<Tooltip title="Long Name is for Client internal use" aria-label="Add">
			<img style={{position:'relative'}} src={infoIcon} width="18" className={classes.info}/>
		</Tooltip>
	</span>
	<TextField
		ref="reflongname"
		inputProps={{
			maxLength: 19,
		}}
		className={classes.inputStyle}
		value={this.state.longname}
		onChange={this.handleChange('longname')}
		defaultValue=""
		margin="normal"
	/>
	</Grid>
	<Grid item xs={4}>
	<InputLabel className={classes.labelStyle}>
		Client Identifier:
	</InputLabel>
	<span className={classes.mrgnRgt}>
		<Tooltip title="Client Identifier is for Client internal use" aria-label="Add">
			<img style={{position:'relative'}} src={infoIcon} width="18" className={classes.info}/>
		</Tooltip>
	</span>
	<TextField
		ref="refclientidnetifier"
		inputProps={{
			maxLength: 19,
		}}
		className={classes.inputStyle}
		value={this.state.clientidnetifier}
		onChange={this.handleChange('clientidnetifier')}
		defaultValue=""
		margin="normal"
	/>
	</Grid>
</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Accounts & Dividend Options</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>
										<Grid container spacing={24}>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Investment Account:</InputLabel>
												<TextField
													select
													ref="refinvestacct"
													className={classes.textField}
													defaultValue=""
													value={this.state.investacct}
													onChange={this.handleChange('investacct')}
													SelectProps={{
													native: true,
													MenuProps: {
														className: classes.menu,
													},
													}}
													margin="normal" >

													{InvestAccount && InvestAccount.map(option => (
														<option key={option.value} value={option.value}>
															{option.name}
														</option>
													))}
												</TextField>
											</Grid>

											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Account Structure:</InputLabel>
												<InputLabel className="TextNrml">{ AccountStructure.name }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Funding Account:</InputLabel>
												<TextField
													select
													ref="reffundacct"
													className={classes.textField}
													value={this.state.fundacct}
													defaultValue=""
													onChange={this.handleChange('fundacct')}
													SelectProps={{
														native: true,
														MenuProps: {
															className: classes.menu,
														},
													}}
													margin="normal" >

													{FundAccount && FundAccount.map(option => (
														<option key={option.value} value={option.value}>
															{option.name}
														</option>
													))}
												</TextField>
											</Grid>

											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Settlement Type:</InputLabel>
												<InputLabel className="TextNrml">{ SettleType.name }</InputLabel>
											</Grid>
											{redimDdaFlag=== true &&
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Redemption DDA Number:</InputLabel>
												<TextField
													select
													ref="redemddaAcct"
													className={classes.textField}
													value={this.state.fundacct}
													defaultValue=""
													onChange={this.handleChange('fundacct')}
													SelectProps={{
														native: true,
														MenuProps: {
															className: classes.menu,
														},
													}}
													margin="normal" >

													{RedemDDANumberAccount && RedemDDANumberAccount.map(option => (
														<option key={option.value} value={option.value}>
															{option.name}
														</option>
													))}
												</TextField>
											</Grid>
											}

											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Dividend Account:</InputLabel>
												<TextField
													ref="refdividentAcct"
													disabled={fundAcctFlag}
													select
													className={classes.textField}
													value={this.state.dividentAcct}
													defaultValue=""
													onChange={this.handleChange('dividentAcct')}
													SelectProps={{
														native: true,
														MenuProps: {
															className: classes.menu,
														},
													}}

													margin="normal" >
													{DividendAcct && DividendAcct.map(option => (
														<option key={option.value} value={option.value}>
															{option.name}
														</option>
													))}
												</TextField>
											</Grid>

											<Grid item xs={4} >
												<InputLabel className={classes.labelStyle}>Dividend Type:</InputLabel>
												<TextField
													ref="refdividentType"
													disabled={divtypeFlag}
													select
													className={classes.textField}
													value={this.state.dividentType}
													defaultValue=""
													onChange={this.handleChange('dividentType')}
													SelectProps={{
														native: true,
														MenuProps: {
															className: classes.menu,
														},
													}}

													margin="normal" >
													{DividendType && DividendType.map(option => (
														<option key={option.value} value={option.value}>
															{option.name}
														</option>
													))}
												</TextField>
											</Grid>

										</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Tax Information (not editable)</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>
										<Grid container spacing={24}>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Tax ID:</InputLabel>
												<InputLabel className="TextNrml">{ TaxInformation.TaxID }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Taxpayer Type:</InputLabel>
												<InputLabel className="TextNrml">{ TaxInformation.Taxtype }</InputLabel>
											</Grid>

											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Acc Social Code:</InputLabel>
												<InputLabel className="TextNrml">{ TaxInformation.AccSocialCode }</InputLabel>
											</Grid>
										</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Primary Legal Address (not editable)</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>
										<Grid container spacing={24}>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Company Name:</InputLabel>
												<InputLabel className="TextNrml">{ PrimaryLegalAddress.CompanyName }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>City:</InputLabel>
												<InputLabel className="TextNrml">{ PrimaryLegalAddress.City }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Zip:</InputLabel>
												<InputLabel className="TextNrml">{ PrimaryLegalAddress.Zip }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Address:</InputLabel>
												<InputLabel className="TextNrml">{ PrimaryLegalAddress.Address }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>State:</InputLabel>
												<InputLabel className="TextNrml">{ PrimaryLegalAddress.State }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Country:</InputLabel>
												<InputLabel className="TextNrml">{ PrimaryLegalAddress.Country }</InputLabel>
											</Grid>
										</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Statement Mailing Address (not editable)</b></Typography>
									</ExpansionPanelSummary>

									<ExpansionPanelDetails>
										<Grid container spacing={24}>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Company Name:</InputLabel>
												<InputLabel className="TextNrml">{ StatementMailingAddress.CompanyName }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>City:</InputLabel>
												<InputLabel className="TextNrml">{ StatementMailingAddress.City }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Zip:</InputLabel>
												<InputLabel className="TextNrml">{ StatementMailingAddress.Zip }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Address:</InputLabel>
												<InputLabel className="TextNrml">{ StatementMailingAddress.Address }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>State:</InputLabel>
												<InputLabel className="TextNrml">{ StatementMailingAddress.State }</InputLabel>
											</Grid>
											<Grid item xs={4}>
												<InputLabel className={classes.labelStyle}>Country:</InputLabel>
												<InputLabel className="TextNrml">{ StatementMailingAddress.Country }</InputLabel>
											</Grid>
										</Grid>
									</ExpansionPanelDetails>
								</ExpansionPanel>

								<ExpansionPanel>
									<ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
										<Typography className={classes.heading}><b>Remarks (optional)</b></Typography>
									</ExpansionPanelSummary>
									<ExpansionPanelDetails>
										<Typography>
											<InputLabel className={classes.labelStyle}>Remarks:</InputLabel>
											<TextField
												multiline
												className={classes.textField}
												onChange={this.handleChange('stmtremark')}
												value={this.state.value}
												style={{border:'1px solid',height:'75px'}}
												defaultValue=""
												margin="normal"
											/>
										</Typography>
									</ExpansionPanelDetails>
								</ExpansionPanel>
							</MuiThemeProvider>
								<div style={{padding: '2px 15px'}}>
									{(operVal === 1 || operVal === 3 || operVal === 5 || operVal === 7)?<button onClick={e => this.saveAcctDetails()} className="btn btn-primary btn-xs mt pull-right">Create Account</button>:""}
									{backButton}
								</div>
							</div>
						</div>
					</div>
				</div>
			)
		}
		else
		{
			return(
				<div>
                <Loading/>
				</div>
			)
		}
    }
}

EnterAcctDet.propTypes = {
    classes: PropTypes.object.isRequired,
};

function mapStateToProps(state) {
    const { mmfcreateAcctDet } = state;
    let cData = [];
    let accountsDividendOptions = [];
    let taxInformation = [];
    let primaryLegalAddress = [];
    let statementMailingAddress = [];
    let commonData = [];

    if(mmfcreateAcctDet != undefined)
    {
		 if(mmfcreateAcctDet.mmfcreateAcctDet != undefined ) {
    	    accountsDividendOptions   	= mmfcreateAcctDet.mmfcreateAcctDet.accountsDividendOptions;
    	    taxInformation   			= mmfcreateAcctDet.mmfcreateAcctDet.taxInformation;
    	    primaryLegalAddress   		= mmfcreateAcctDet.mmfcreateAcctDet.primaryLegalAddress;
    	    statementMailingAddress   	= mmfcreateAcctDet.mmfcreateAcctDet.statementMailingAddress;
    	    commonData   				= mmfcreateAcctDet.mmfcreateAcctDet.commonData;
		}
	}

    return { cData, accountsDividendOptions, taxInformation, primaryLegalAddress, statementMailingAddress, commonData };
}

const connectedEnterAcctDet = connect(mapStateToProps)(withStyles(MuiStyles)(EnterAcctDet));
export { connectedEnterAcctDet as EnterAcctDet };

//export default (withStyles(styles))(EnterAcctDet);