import React from 'react';
import { Link } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import { AdministrationActions } from '../actions/administration.actions';
import { connect } from 'react-redux';
import Filters from './Filters';
import '../../user/css/App.css';
import axios from 'axios';
import FormData from 'form-data';
import { alertConstants } from '../../common/constants/alert.constants';
import TextField from '@material-ui/core/TextField';
import InputLabel from '@material-ui/core/InputLabel';
import MUIDataTable from "mui-datatables";
import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import NativeSelect from '@material-ui/core/NativeSelect';
import {addCommasAmntLocale} from '../../tradeentry/components/amountValidations';
function arrayRemove(arr, value) {

    return arr.filter(function(ele){
        return ele != value;
    });

}

const Columns = [
    {
        name: 'Alert Frequency',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Time Interval (Hours)',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Alert When Amount is Greater Than',
        options: {
            filter: true,
            sort: false,
        }
    }
]

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
    tableheader: {
        background:'#ccc'
    },
    tabletheadtr: {
        height: '37px'
    },
    tabletheadth: {
        color:'#333',
        fontWeight:'bold',
        fontSize:'12px',
        paddingTop: '4px',
        paddingBottom: '4px'
    },
    tabletbodytr: {
        height: '32px'
    },
    tabletbodytd: {
        fontSize: '12px'
    },
    label: {
        width: '25%',
        fontSize: '12px',
        fontWeight:'bold'
    },
    labelvalue: {
        fontSize: '12px',
        fontWeight: 'normal'
    },
});

let selTemplate;
let templateName;
let ClientName;
let status;
let temp = [],selection=[];
let fromPage;

class EditAlertTemplate extends React.Component {
    getMuiTheme = () => createMuiTheme({
        typography: {
            useNextVariants: true,
        },
        overrides: {
             MuiFormControl: {
                                  marginNormal: {
                                      marginTop: '0px',
                                       marginBottom: '0px',
                                   }
          }, MuiIconButton: {
                                  root: {
                                      padding: '2px',
                                   }
          },
          MUIDataTableBodyCell: {
            root: {
                whiteSpace: 'nowrap',
                padding:'0px 56px 0px 24px'
             }
          },
          MUIDataTableBodyRow: {
                      root: {
                          height: '20px',
                       }
          },
        }
    })
    constructor(props){
        super(props);
        this.state={
            results:[],
            results1:[],
            reportdata:[],
            reportdatatable:[],
            alerttempdatadet:[],
            selection:[],
            selectAll:false,
            selectedValues:[],
            columns:[],
            screenName:'',
            msg:''
        }
        // this.doChange = this.doChange.bind(this);
        this.doSave = this.doSave.bind(this);
        this.doSelectAll = this.doSelectAll.bind(this);
        this.fileTypeChange = this.fileTypeChange.bind(this);
        this.toggleCheck = this.toggleCheck.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.doCancel = this.doCancel.bind(this);

    }

    // doChange(fillObj){
    //     var bodyFormData = new FormData();
    //     for (name in fillObj) {
    //         bodyFormData.append(name, fillObj[name]);
    //     }
    //     this.props.dispatch(AdministrationActions.fetchReportTableData(bodyFormData));
    // }

    componentWillMount(){
        var bodyFormData = new FormData();
        if(this.props.location.state){
            selTemplate=this.props.location.state.selTemplate
            templateName=this.props.location.state.templateName
            ClientName=this.props.location.state.ClientName
            status=this.props.location.state.status;

            bodyFormData.append('template', this.props.location.state.selTemplate);
            bodyFormData.append('templateName', this.props.location.state.templateName);
            bodyFormData.append('companyName', this.props.location.state.ClientName);
            bodyFormData.append('astatus', this.props.location.state.status);
            bodyFormData.append('selcompanyId', "ALL");
            bodyFormData.append('fromPage', "EDIT");
            // console.log('this.props.location.state------------>',this.props.location.state);
        }
        this.props.dispatch(AdministrationActions.fetchAlertTempData(bodyFormData));
    }
    doSelectAll(){
        // console.log('itemp   '+JSON.stringify( temp ));
        const selectAll =this.state.selectAll === true ?false:true;
        if(selectAll){
            this.setState({ selectAll:selectAll,selection:temp})
        }else {
            this.setState({ selectAll:selectAll,selection:[]})
        }

    }
    toggleCheck(e) {
        selection =this.state.selection;
            // console.log("name",e.target.name)

        if(!selection.includes(e.target.name)){
            // console.log('<<IFFF>>>>'+JSON.stringify(selection));
            selection.push(e.target.name);
            // console.log('<<after>>>>'+JSON.stringify(selection));
            this.setState({ selectAll:false,selection:selection})
        }else {
            // console.log('<<Elseee>>>>'+JSON.stringify(selection));
            selection= arrayRemove(selection,(e.target.name));
            // console.log('<<after>>>>'+JSON.stringify(selection));
            this.setState({ selectAll:false,selection:selection})
            this.state.selection.length= this.state.selection.length-1;
        }

        if(this.state.selection.length === temp.length)
            this.setState({ selectAll:true})
      }
    handleChange(obj){
        this.setState({templateName:obj.target.value});
        // console.log(obj.target.value)
    }

    fileTypeChange(e) {

        var temp = e.target.name;
        this.state.selectedValues.push({id:e.target.name,value:e.target.value})


        // console.log("--before--",+e.target.value.toString());
        // e.target.defaultValue = e.target.value;
        // this.setState({ Ck:0});
        // console.log("--after--",+e.target.defaultValue.toString());
        // console.log("--after--",+e.target.value.toString());
    }
    fileAmtChange(e) {
        let userLocale="";
        var user = JSON.parse(sessionStorage.getItem('user'));
        if(user[0].localeLang !== undefined){
            userLocale=user[0].localeLang;
        }
        addCommasAmntLocale(e,userLocale, true,this)
        var temp = e.target.name;
        this.state.selectedValues.push({id:e.target.name,value:e.target.value})

        console.log('this.state.selectedValues <><>:'+JSON.stringify( this.state.selectedValues ));
        // console.log("--before--",+e.target.value.toString());
        // e.target.defaultValue = e.target.value;
        // this.setState({ Ck:0});
        // console.log("--after--",+e.target.defaultValue.toString());
        // console.log("--after--",+e.target.value.toString());
    }
    doCancel(){
        window.scroll(0,0);
        const selectAll =this.state.selectAll === true ?false:true;
        this.setState({ selectAll:false,selection:[]});
        this.componentWillMount();
    }

    doSave(idx)
    {
        var bodyFormData = new FormData();
        var myArray = [];
        if(window.confirm('Are you sure, you want to save the data?')){
            temp && temp.map((value,index)=>{
                if((this.refs['menuChk'+index] !== undefined) && (this.refs['menuChk'+index].props.checked))
                {
                    myArray.push({id:'menuChk'+index, value:this.refs['menuChk'+index].props.value})
                    myArray.push({id:'selEventId'+index, value:this.refs['menuChk'+index].props.value})

                    if(this.refs['amountAlert'+index] !== undefined) {
                        myArray.push({id:'amountAlert'+index, value:this.refs['amountAlert'+index].props.defaultValue})
                    }

                    if(this.refs['alertFrequency'+index] !== undefined) {
                        myArray.push({id:'alertFrequency'+index, value:this.refs['alertFrequency'+index].props.defaultValue})
                    }

                    if(this.refs['timeInterval'+index] !== undefined) {
                        myArray.push({id:'timeInterval'+index, value:this.refs['timeInterval'+index].props.defaultValue})
                    }

                    if(this.refs['fileType'+index] !== undefined) {
                        myArray.push({id:'fileType'+index, value:this.refs['fileType'+index].props.defaultValue})
                    }
                }
            });

            this.state.selectedValues && this.state.selectedValues.map((item, index) => {
                let obj	= myArray.find(namevalue => namevalue.id === item.id);
                if(obj!== undefined)
                {
                    obj.value = item.value;
                }
            });

           myArray && myArray.map((item, index) => {
                bodyFormData.append(item.id, item.value);
            });

            var user = JSON.parse(sessionStorage.getItem('user'));
            bodyFormData.append('size','26');
            bodyFormData.append('selTemplateName',templateName);
            bodyFormData.append('clientFirm',JSON.parse(sessionStorage.getItem('clientFirm')));

            if(user[0].token !== undefined)
            {
                bodyFormData.append('token',user[0].token);
            }

            fromPage = this.props.location.state.fromPage;
            bodyFormData.append('actionFlag', "SAVE");
            bodyFormData.append('fromPage',fromPage);

            if(fromPage === 'EDIT')
            {
                bodyFormData.append('template', selTemplate);
            }

            var data;
            axios({
                method: 'POST',
                url:alertConstants.URL+"/CLEMAIL.do",
                data: bodyFormData,
                config: { headers: {'Content-Type': 'multipart/form-data' }}
            }).then((response)=>{
                data = response.data;
                this.setState({msg:data.message})
            });

            window.scrollTo(0,0);
        }
		// setTimeout(() => {
		//     this.props.history.push('/administration/CLALERT');
		// }, 5000);
		// this.props.dispatch(AdministrationActions.fetchReportData(bodyFormData));
    }

    render() {
        const { classes } = this.props;
        const { alerttempdatadet } = this.props;

        this.state.reportdata = this.props.reportdata;
        this.state.results1 = this.state.reportdata.reportdata;

        var filterdata = alerttempdatadet.alerttempdatadet;
        // console.log('editdatatable <><>:'+JSON.stringify(filterdata));

        if(filterdata !== undefined) {
            this.state.screenName = filterdata.Title.Title;
            this.state.results = filterdata.data;
            // console.log('Data--- <><>:'+JSON.stringify(filterdata));
            // console.log('filterdata <><>:'+JSON.stringify(this.state.results));

        let menuChk=0;
        let rowsdata
        const headerRow =
            <TableRow>
                <TableCell>
                    <Checkbox defaultChecked={false} checked={this.state.selectAll?true:false} onChange={this.doSelectAll} />Select All Alerts</TableCell>
                <TableCell>Alert Frequency</TableCell>
                <TableCell align="right">Time Inverval (Hours)</TableCell>
                <TableCell align="right">Alert When Amount is Greater Than</TableCell>
            </TableRow>;

            const Bodydata =this.state.results && this.state.results.map((row, index) => {
                rowsdata = row.rows && row.rows.map((rowdata, newindex) => {
                    if(rowdata.ischecked === "checked"){
                        this.state.selection.push("menuChk"+menuChk);
                        selection.push("menuChk"+menuChk);
                        rowdata.ischecked = "";
                        // console.log("selection==>",this.state.selection)
                    }
                    temp.push("menuChk"+menuChk);
                    return (
                        <TableRow key={newindex} className={(newindex%2 ? 'even' : 'odd')}>
                            <TableCell style={{width:'500px'}} className={classes.tabletbodytd}>
                            {/* {console.log(rowdata.ischecked)} */}
                                <Checkbox ref={"menuChk"+menuChk} name={"menuChk"+menuChk} defaultChecked={false} checked={(this.state.selection.includes("menuChk"+menuChk))?true:false} id={"check"+menuChk} value={rowdata.selEventId} onChange={this.toggleCheck}/>
                                {rowdata.alertName}
                                {
                                    (rowdata.fileTypeFlag === "true") &&
                                    <NativeSelect className={classes.select} ref={"fileType"+menuChk} defaultValue={rowdata.fileTypeValue} onChange={this.fileTypeChange.bind(this)} name={"fileType"+menuChk} style={{float:'right',marginTop:'7px'}}>
                                        {filterdata.fileType.values && filterdata.fileType.values.map((obj,index) => {
                                            return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                            </TableCell>
                            <TableCell className={classes.tabletbodytd}>
                                {
                                    (rowdata.frequencyType === "frequency") &&
                                    <NativeSelect className={classes.select} ref={"alertFrequency"+menuChk} defaultValue={rowdata.frequencyValue} onChange={this.fileTypeChange.bind(this)} name={"alertFrequency"+menuChk} style={{width:'200px'}} id={rowdata.alertName} >
                                        {filterdata.frequency.values && filterdata.frequency.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "timeZone") &&
                                    <NativeSelect className={classes.select} ref={"timeZone"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}} id={rowdata.alertName}  name={"timeZone"+menuChk} >
                                        {filterdata.timeZone.values && filterdata.timeZone.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "language") &&
                                    <NativeSelect className={classes.select} ref={"language"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}}
                                    id={rowdata.alertName}  name={"language"+menuChk} >
                                        {filterdata.language.values && filterdata.language.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "amtFormat") &&
                                    <NativeSelect className={classes.select} ref={"amtFormat"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}} id={rowdata.alertName}  name={"amtFormat"+menuChk} >
                                        {filterdata.amtFormat.values && filterdata.amtFormat.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "dateFormat") &&
                                    <NativeSelect className={classes.select} ref={"dateFormat"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}} id={rowdata.alertName}  name={"dateFormat"+menuChk} >
                                        {filterdata.dateFormat.values && filterdata.dateFormat.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                                {
                                    (rowdata.frequencyType === "timeFormat") &&
                                    <NativeSelect className={classes.select} ref={"timeFormat"+menuChk} onChange={this.fileTypeChange.bind(this)} style={{width:'200px'}} id={rowdata.alertName}  name={"timeFormat"+menuChk} >
                                        {filterdata.timeFormat.values && filterdata.timeFormat.values.map((obj,index) => {
                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }

                            </TableCell>
                            <TableCell className={classes.tabletbodytd}>
                                {
                                    (rowdata.timeIntervalFlag === "true") &&
                                    <NativeSelect className={classes.select} ref={"timeInterval"+menuChk} defaultValue={rowdata.timeIntervalValue} onChange={this.fileTypeChange.bind(this)} name={"timeInterval"+menuChk}>
                                        {filterdata.intervalHash.values && filterdata.intervalHash.values.map((obj,index) => {
                                            return <option key={index} value={obj.id}>{obj.name}</option>
                                        })}
                                    </NativeSelect>
                                }
                            </TableCell>
                            <TableCell className={classes.tabletbodytd}>
                                {
                                    (rowdata.amountAlertFlag === "true") &&
                                    <TextField className={classes.inputStyle} type="text" onBlur={this.fileAmtChange.bind(this)} ref={"amountAlert"+menuChk} name={"amountAlert"+menuChk} defaultValue={rowdata.amountAlert} />
                                }
                            </TableCell>
                            <span style={{display:"none"}}>{menuChk++}</span>
                        </TableRow>
                    )
                });
                return (
                    <TableBody key={index}>
                        <TableRow key={index} className={classes.tabletheadtr} style={{background:'#ccc'}}>
                            <TableCell colSpan={4} className={classes.tabletheadth}>{row.name}</TableCell>
                        </TableRow>
                        {rowsdata}
                    </TableBody>
                );
            });
        return(
            <div>
                <NavBar/>
                <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                    <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                        <div className="panel-heading">
                            <h4 className="panel-title">{this.state.screenName}</h4>
                        </div>
                        <div className="panel-body">
                        {
                            this.state.msg !== "" &&
                            <div className="text-center displayTxt">{this.state.msg}</div>
                        }
                            <div className="col-md-12 col-sm-12 head-cls">
                                <div className="panel">
                                    <div className="panel-heading clearfix">
                                        <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                        <a className="pull-right" onClick={this.tottgleDisplay}>
                                            <i className="fa fa-caret-down"></i>
                                        </a>
                                    </div>
                                </div>
                                <div className="filter_div" id="filter_div" >
                                <div className="col-md-4 col-sm-4">
                                        <InputLabel className={classes.labelStyle}>Template Name:</InputLabel>
                                        <InputLabel className={classes.labelvalue}>{templateName}</InputLabel>
                                    </div>
                                    <div className="col-md-4 col-sm-4">
                                        <InputLabel className={classes.labelStyle}>Status:</InputLabel>
                                        <InputLabel className={classes.labelvalue}>{status}</InputLabel>
                                    </div>
                                    <div className="clearfix"></div>
                                    <div className="col-md-4 col-sm-4">
                                        <InputLabel className={classes.labelStyle}>Client Name:</InputLabel>
                                        <InputLabel className={classes.labelvalue}>{ClientName}</InputLabel>
                                    </div>
                                    {/* <Filters method={this.doChange} data={this.state.reportdata}/> */}
                                </div>
                            </div>

                            <div className="clearfix"></div>
                            <div className="col-md-12 col-sm-12 head-cls backwhite">
                                {/* <MuiThemeProvider theme={this.getMuiTheme()}>
                                    <MUIDataTable
                                    data={data}
                                    columns={Columns}/>
                                </MuiThemeProvider>  */}
                                <Paper className={classes.root}>
                                    <Table className={classes.table}>
                                        <TableHead className={classes.tableheader}>
                                            {headerRow}
                                        </TableHead>

                                        {Bodydata}

                                    </Table>
                                    {/* <Table className={classes.table}> */}
                                    {/* <Table className={classes.table}>
                                        <TableHead className={classes.tableheader}>
                                            {headerRow}
                                        </TableHead>
                                            {this.state.results && this.state.results.map((row, index) => {
                                                // console.log('rewwww'+row.rows)
                                                const rowsdata =row.rows &&  row.rows.map((rowdata, newindex) => {
                                                    return (
                                                        <TableRow key={newindex} className={classes.tabletheadtr}>
                                                            <TableCell style={{width:'500px'}} className={classes.tabletbodytd}>
                                                            <Checkbox checked={rowdata.ischecked}/>
                                                            {rowdata.alertName}</TableCell>
                                                            <TableCell className={classes.tabletbodytd}>
                                                                {
                                                                    (rowdata.frequencyType === "frequency") &&
                                                                    <NativeSelect style={{width:'200px'}}  ref={rowdata.alertName} id={rowdata.alertName}  name={rowdata.alertName} >
                                                                        {filterdata.frequency.values && filterdata.frequency.values.map((obj,index) => {
                                                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                                                        })}
                                                                    </NativeSelect>
                                                                }
                                                                {
                                                                    (rowdata.frequencyType === "timeZone") &&
                                                                    <NativeSelect style={{width:'200px'}}  ref={rowdata.alertName} id={rowdata.alertName}  name={rowdata.alertName} >
                                                                        {filterdata.timeZone.values && filterdata.timeZone.values.map((obj,index) => {
                                                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                                                        })}
                                                                    </NativeSelect>
                                                                }
                                                                {
                                                                    (rowdata.frequencyType === "language") &&
                                                                    <NativeSelect style={{width:'200px'}}  ref={rowdata.alertName} id={rowdata.alertName}  name={rowdata.alertName} >
                                                                        {filterdata.language.values && filterdata.language.values.map((obj,index) => {
                                                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                                                        })}
                                                                    </NativeSelect>
                                                                }
                                                                {
                                                                    (rowdata.frequencyType === "amtFormat") &&
                                                                    <NativeSelect style={{width:'200px'}}  ref={rowdata.alertName} id={rowdata.alertName}  name={rowdata.alertName} >
                                                                        {filterdata.amtFormat.values && filterdata.amtFormat.values.map((obj,index) => {
                                                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                                                        })}
                                                                    </NativeSelect>
                                                                }
                                                                {
                                                                    (rowdata.frequencyType === "dateFormat") &&
                                                                    <NativeSelect style={{width:'200px'}}  ref={rowdata.alertName} id={rowdata.alertName}  name={rowdata.alertName} >
                                                                        {filterdata.dateFormat.values && filterdata.dateFormat.values.map((obj,index) => {
                                                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                                                        })}
                                                                    </NativeSelect>
                                                                }
                                                                {
                                                                    (rowdata.frequencyType === "timeFormat") &&
                                                                    <NativeSelect style={{width:'200px'}}  ref={rowdata.alertName} id={rowdata.alertName}  name={rowdata.alertName} >
                                                                        {filterdata.timeFormat.values && filterdata.timeFormat.values.map((obj,index) => {
                                                                            if(rowdata.frequencyId.find(e=>e===obj.id))
                                                                                return <option key={index} value={obj.id}>{obj.name}</option>
                                                                        })}
                                                                    </NativeSelect>
                                                                }

                                                            </TableCell>
                                                            <TableCell className={classes.tabletbodytd}>
                                                                {
                                                                    (rowdata.timeIntervalFlag === "true") &&
                                                                    <NativeSelect>
                                                                        {filterdata.intervalHash.values && filterdata.intervalHash.values.map((obj,index) => {
                                                                            return <option key={index} value={obj.id}>{obj.name}</option>
                                                                        })}
                                                                    </NativeSelect>
                                                                }
                                                            </TableCell>
                                                            <TableCell className={classes.tabletbodytd}>
                                                                {
                                                                    (rowdata.amountAlertFlag === "true") &&
                                                                    <TextField  style={{width:'100px'}} type="text" defaultValue={rowdata.amountAlert} className="form-control input-sm"/>
                                                                }
                                                            </TableCell>
                                                        </TableRow>
                                                    )
                                                    }
                                                    );
                                                    return (
                                                        <TableBody key={index}>
                                                            <TableRow key={index} className={classes.tabletheadtr} style={{background:'#ccc'}}>
                                                                <TableCell colSpan={4} className={classes.tabletheadth}>{row.name}</TableCell>
                                                            </TableRow>
                                                            {rowsdata}
                                                        </TableBody>
                                                    );
                                                })}
                                            </Table> */}

                                        {/* {this.state.results.map((row, index) => {
                                            return (
                                            <TableRow key={index}>
                                                <TableCell component="th" scope="row">
                                                    {row.name}
                                                </TableCell>
                                                <TableCell align="right"></TableCell>
                                                <TableCell align="right"></TableCell>
                                                <TableCell align="right"></TableCell>
                                            </TableRow>
                                            );
                                        })} */}
                                </Paper>
                            </div>
                            <div className="col-md-6">
                                <a title="Save" onClick={(e)=>{this.doSave();}} className="btn btn-primary btn-xs">Save</a>
                                <a title="Cancel" onClick={(e)=>{this.doCancel();}} className="btn btn-primary btn-xs">Cancel</a>
                            </div>
                        </div>
                    </div>
                </MuiThemeProvider>
            </div>
        );
    }else {
        return(
            <div></div>
        )
    }
}
}
function mapStateToProps(state) {
    const { reportdata,reportdatatable, alerttempdatadet } = state;
    return { reportdata,reportdatatable, alerttempdatadet };
}

const connectedEditAlertTemplate = connect(mapStateToProps)(withStyles(MuiStyles)(EditAlertTemplate));
export { connectedEditAlertTemplate as EditAlertTemplate };
