import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { AdministrationActions } from '../actions/administration.actions';
import { withStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';

const admCatList = [
    {
       "id":"0",
       "label":"",
       "name":"Create New MMF Account",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"Title"
    },
    {
       "id":"1",
       "label":"Investment Account Name",
       "name":"investAccount",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"Select",
       "values":[
          {
             "id":"6008233958668745",
             "label":"",
             "name":"Roy Inc Europe Inv01-18092851049724",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          },
          {
             "id":"4957520979496224",
             "label":"",
             "name":"Roy Inc Europe Inv02-18092851049725",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          },
          {
             "id":"8367540868598161",
             "label":"",
             "name":"Roy Inc Europe Inv03-18092851049726",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          },
          {
             "id":"9011038634296324",
             "label":"",
             "name":"Roy Inc Europe Inv04-18092851049727",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          }
       ]
    },
    {
       "id":"2",
       "label":"Funding Account",
       "name":"ddaAcct",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"Select",
       "values":[
          {
             "id":"2285955962363332",
             "label":"",
             "name":"UK Sweep DDA t1-201801020501",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          },
          {
             "id":"2323613452212506",
             "label":"",
             "name":"UK Sweep DDA t2-201801020502",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          }
       ]
    },
    {
       "id":"3",
       "label":"Redemption DDA Number",
       "name":"redemddaAcct",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"Select",
       "values":[
          {
             "id":"2285955962363332",
             "label":"",
             "name":"UK Sweep DDA t1-201801020501",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          },
          {
             "id":"2323613452212506",
             "label":"",
             "name":"UK Sweep DDA t2-201801020502",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          }
       ]
    },
    {
       "id":"4",
       "label":"Dividend Account",
       "name":"dividendAcct",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"Select",
       "values":[
          {
             "id":"2285955962363332",
             "label":"",
             "name":"UK Sweep DDA t1-201801020501",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          },
          {
             "id":"2323613452212506",
             "label":"",
             "name":"UK Sweep DDA t2-201801020502",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          }
       ]
    },
    {
       "id":"5",
       "label":"Dividend Type",
       "name":"dividendType",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"Select",
       "values":[
          {
             "id":"100",
             "label":"",
             "name":"RECAPITALIZE",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          },
          {
             "id":"101",
             "label":"",
             "name":"CASH PAYOUT",
             "value":"",
             "flag":"",
             "image":"",
             "parentImage":"",
             "toppanelImage":"",
             "token":"",
             "href":"",
             "onclick":"",
             "checked":"",
             "fieldValue":"",
             "loginId":"",
             "companyId":"",
             "action":"",
             "link":"",
             "type":""
          }
       ]
    },
    {
       "id":"6",
       "label":"",
       "name":"TaxInformation",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"data",
       "values":[
          {
             "Tax ID":"777-77-7777",
             "Taxpayer Type":"4",
             "Acc Social Code":"Accredited Investor"
          }
       ]
    },
    {
       "id":"7",
       "label":"",
       "name":"Legal Address",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"data",
       "values":[
          {
             "Company Name":"Roy Inc. UK",
             "City":"eur",
             "Zip":"",
             "Address":"eur, , ",
             "State":"",
             "Country":"UK"
          }
       ]
    },
    {
       "id":"8",
       "label":"",
       "name":"Mailing Address",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"data",
       "values":[
          {
             "Company Name":"Roy Inc. UK",
             "City":"eur",
             "Zip":"",
             "Address":"eur, , ",
             "State":"",
             "Country":"UK"
          }
       ]
    },
    {
       "id":"9",
       "label":"",
       "name":"Other Address",
       "value":"",
       "flag":"",
       "image":"",
       "parentImage":"",
       "toppanelImage":"",
       "token":"",
       "href":"",
       "onclick":"",
       "checked":"",
       "fieldValue":"",
       "loginId":"",
       "companyId":"",
       "action":"",
       "link":"",
       "type":"data",
       "values":[
          {
             "Company Name":"",
             "City":"",
             "Zip":"",
             "Address":", , ",
             "State":"",
             "Country":""
          }
       ]
    }
 ]


//  {
//     "Title":{
//        "id":0,
//        "type":"Title",
//        "name":"Create New MMF Account"
//     },
//     "accountsDividendOptions":{
//        "investAccount":{
//           "id":1,
//           "label":"Investment Account Name",
//           "name":"investAccount",
//           "type":"Select",
//           "values":[
//              {
//                 "id":"6008233958668745",
//                 "value":"6008233958668745",
//                 "name":"Roy Inc Europe Inv01-18092851049724"
//              },
//              {
//                 "id":"4957520979496224",
//                 "value":"4957520979496224",
//                 "name":"Roy Inc Europe Inv02-18092851049725"
//              },
//              {
//                 "id":"8367540868598161",
//                 "value":"8367540868598161",
//                 "name":"Roy Inc Europe Inv03-18092851049726"
//              },
//              {
//                 "id":"9011038634296324",
//                 "value":"9011038634296324",
//                 "name":"Roy Inc Europe Inv04-18092851049727"
//              }
//           ]
//        },
//        "fundingAccount":{
//           "id":2,
//           "label":"Funding Account",
//           "name":"ddaAcct",
//           "type":"Select",
//           "values":[
//              {
//                 "id":"2285955962363332",
//                 "value":"2285955962363332",
//                 "name":"UK Sweep DDA t1-201801020501"
//              },
//              {
//                 "id":"2323613452212506",
//                 "value":"2323613452212506",
//                 "name":"UK Sweep DDA t2-201801020502"
//              }
//           ]
//        },
//        "redemDDANumber":{
//           "id":3,
//           "label":"Redemption DDA Number",
//           "name":"redemddaAcct",
//           "type":"Select",
//           "values":[
//              {
//                 "id":"2285955962363332",
//                 "value":"2285955962363332",
//                 "name":"UK Sweep DDA t1-201801020501"
//              },
//              {
//                 "id":"2323613452212506",
//                 "value":"2323613452212506",
//                 "name":"UK Sweep DDA t2-201801020502"
//              }
//           ]
//        },
//        "dividendAccount":{
//           "id":4,
//           "label":"Dividend Account",
//           "name":"dividendAcct",
//           "type":"Select",
//           "values":[
//              {
//                 "id":"2285955962363332",
//                 "value":"2285955962363332",
//                 "name":"UK Sweep DDA t1-201801020501"
//              },
//              {
//                 "id":"2323613452212506",
//                 "value":"2323613452212506",
//                 "name":"UK Sweep DDA t2-201801020502"
//              }
//           ]
//        },
//        "dividendType":{
//           "id":5,
//           "label":"Dividend Type",
//           "name":"dividendType",
//           "type":"Select",
//           "values":[
//              {
//                 "id":"101",
//                 "value":"101",
//                 "name":"CASH PAYOUT"
//              },
//              {
//                 "id":"101",
//                 "value":"101",
//                 "name":"CASH PAYOUT"
//              }
//           ]
//        }
//     },
//     "taxInformation":{
//        "id":6,
//        "TaxID":"777-77-7777",
//        "TaxpayerType":"4",
//        "AccSocialCode":"Accredited Investor"
//     },
//     "primaryLegalAddress":{
//        "id":7,
//        "CompanyName":"Roy Inc. UK",
//        "City":"eur",
//        "Zip":"",
//        "Address":"eur, , ",
//        "State":"",
//        "Country":"UK"
//     },
//     "statementMailingAddress":{
//        "id":8,
//        "CompanyName":"Roy Inc. UK",
//        "City":"eur",
//        "Zip":"",
//        "Address":"eur, , ",
//        "State":"",
//        "Country":"UK"
//     },
//     "otherAddress":{
//        "id":9,
//        "CompanyName":"",
//        "City":"",
//        "Zip":"",
//        "Address":", , ",
//        "State":"",
//        "Country":""
//     }
//  }



const styles = theme => ({
    root: {
      width: '100%',
    },
    //  heading: {
    //    fontSize: theme.Typography.pxToRem(15),
    //    fontWeight: theme.Typography.fontWeightRegular,
    //  },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
        margin:'2px',
    }
}); 


class Adminmfacctdet extends React.Component{
    constructor(props) {
        super(props);
        this.state ={
            columns:[],
            name
        }
        this.handleChange = this.handleChange.bind(this);
    }
componentDidMount() { 
        this.getFilters()
      }
     getFilters(){
        alert(" Adminmfacctdet.js ... component did amount........");
        var bodyFormData = new FormData();
        //bodyFormData.append("company","81837075");
        //bodyFormData.append("fundTypeId","101");
        //bodyFormData.append("fundFamilyId","17903322");
        //bodyFormData.append("prodId","47806054");
        //bodyFormData.append("ccy","EUR");
        this.props.dispatch(AdministrationActions.fetchCNMFAccount(bodyFormData));
    } 
    handleChange = name => event => {
        this.setState({
            [name]: event.target.value,
        });
    };
    render(){

        let investAccts=[];

            // let fundAcct=[];

            // let dividAcct=[];
            let TaxInfo=[];

           

            

	 		if( admCatList)
             admCatList.map((item,index) => {
	              

	                if(item.name === "investAccount")
                    investAccts = item.values

                     if(item.name === "TaxInformation")
                     TaxInfo = item.values

                    // if(item.name === "ddaAcct")
                    // fundAcct = item.values

	                // if(item.name === "dividendAcct")
                    // dividAcct = item.values
	            })
           
       console.log(this.props.product)
    //    var prodVal = this.props.product;
        const { classes } = this.props;
        
            // if(prodVal !== undefined){
                return  (
                    <div className={classes.root}>
                        {/* <div>Product:{prodVal}</div> */}
                        <ExpansionPanel defaultExpanded>
                            <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                            <Typography className={classes.heading}><b>Description</b></Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                            
                            <Grid container spacing={16}>
                                    <Grid item xs={4}  key="1" >
                                    <InputLabel>Short Name:</InputLabel>
                                    <TextField  ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="2">
                                    <InputLabel>Long Name:</InputLabel>
                                    <TextField ref="" name="" />
                                    </Grid>

                                    <Grid item xs={4}  key="3">
                                    <InputLabel>Client Identifier:</InputLabel>
                                    <TextField ref="" name="" />
                                    </Grid>
                                </Grid>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel>
                            <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                            <Typography className={classes.heading}><b>Accounts & Dividend Options</b></Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>

                            <Grid container spacing={16}>
                                    <Grid item xs={4}  key="4" >
                                                <InputLabel>Investment  Account Name:</InputLabel>
                                                <NativeSelect ref=""  name="">
                                                {investAccts && investAccts.map((obj,index) => { 
                                return <option key={index} value={obj.id}>{obj.name}</option>
                            })}
                                                </NativeSelect>
                                    </Grid>
                                    <Grid item xs={8}  key="5">
                                                <InputLabel>Account Structure:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>

                                    <Grid item xs={4}  key="6">
                                                <InputLabel>Funding Account:</InputLabel>
                                                <NativeSelect ref=""  name="">
                                                        <option></option>
                                                </NativeSelect>
                                    </Grid>
                                    <Grid item xs={4}  key="7">
                                                <InputLabel>Settle Type:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="8">
                                                <InputLabel>Redemption DDA Number:</InputLabel>
                                                <NativeSelect ref=""  name="">
                                                        <option></option>
                                                </NativeSelect>
                                    </Grid>
                                    <Grid item xs={12}  key="9">
                                                <InputLabel>Dividend Account:</InputLabel>
                                                <NativeSelect ref=""  name="">
                                                        <option></option>
                                                </NativeSelect>
                                    </Grid>
                                    <Grid item xs={12}  key="10">
                                                <InputLabel>Dividend Type:</InputLabel>
                                                <NativeSelect ref=""  name="">
                                                        <option></option>
                                                </NativeSelect>
                                    </Grid>
                                   
                                </Grid>
                           
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel>
                            <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                            <Typography className={classes.heading}><b>Tax information (not editable)</b></Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <Grid container spacing={16}>
                                    <Grid item xs={4}  key="11" >
                                                <InputLabel>Tax ID:1111</InputLabel>
                                <TextField ref="" name="" 
                                 value={TaxInfo && TaxInfo.map((obj,index) => { 
                                    return <label key={index} value={obj.id}>{obj.name}</label>
                                })}    />

                               
                                    </Grid>
                                    <Grid item xs={4}  key="12" >
                                                <InputLabel>Taxpayer Type:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="13" >
                                                <InputLabel>Acc Social Code:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                </Grid>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel>
                            <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                            <Typography className={classes.heading}><b>	Primary Legal Address (not editable)</b></Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                            <Grid container spacing={16}>
                                    <Grid item xs={4}  key="14" >
                                                <InputLabel>Company Name:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="15" >
                                                <InputLabel>City:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="16" >
                                                <InputLabel>Zip:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="17" >
                                                <InputLabel>Address:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="18" >
                                                <InputLabel>state:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="19" >
                                                <InputLabel>Country:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                </Grid>
                            </ExpansionPanelDetails>
                        </ExpansionPanel> 
                        <ExpansionPanel>
                            <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                            <Typography className={classes.heading}><b>Statement Mailing Address (not editable)</b></Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                            <Grid container spacing={16}>
                                    <Grid item xs={4}  key="14" >
                                                <InputLabel>Company Name:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="15" >
                                                <InputLabel>City:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="16" >
                                                <InputLabel>Zip:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="17" >
                                                <InputLabel>Address:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="18" >
                                                <InputLabel>state:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="19" >
                                                <InputLabel>Country:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                </Grid>
                               
                          
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel>
                            <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                            <Typography className={classes.heading}><b>Other Address (not editable)</b></Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                            <Grid container spacing={16}>
                                    <Grid item xs={4}  key="14" >
                                                <InputLabel>Company Name:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="15" >
                                                <InputLabel>City:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="16" >
                                                <InputLabel>Zip:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="17" >
                                                <InputLabel>Address:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="18" >
                                                <InputLabel>state:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                    <Grid item xs={4}  key="19" >
                                                <InputLabel>Country:</InputLabel>
                                                <TextField ref="" name="" />
                                    </Grid>
                                   
                                </Grid>
                          
                                
                         
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel>
                            <ExpansionPanelSummary className="expandicon" expandIcon={<ExpandMoreIcon/>}>
                            <Typography className={classes.heading}><b>Remarks</b></Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                            <Grid container spacing={16}>
                            <Grid item xs={12}  >
                                    <InputLabel> Remarks :</InputLabel>
                                        <TextField type="textarea"   />
                                        </Grid>
                                </Grid>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <Grid item xs={12}>
                                    <InputLabel></InputLabel>
                                        
                            </Grid>
                        <Grid container spacing={16}>
                                <Grid item xs={11}  >
                                    <a href='#'>Back</a>
                                </Grid>
                                <Grid item xs={1}  >
                                    <button className="btn btn-xs btn-primary">Create Account</button>
                                </Grid>
                            </Grid>    
                    </div>
                );
           
    }

}
function mapStateToProps(state) { 
    const { cnmfaccountdata } = state;
    return { cnmfaccountdata };
}
Adminmfacctdet.propTypes = {
    classes: PropTypes.object.isRequired,
  };
const connectedAdminmfacctdet = connect(mapStateToProps)(withStyles(styles)(Adminmfacctdet));
export { connectedAdminmfacctdet as Adminmfacctdet };
