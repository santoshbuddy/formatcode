import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { Route , withRouter} from 'react-router-dom';
import { Link } from 'react-router-dom';

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
});

let id = 0;

function createData(FundFamily, FundName, FundType, Currency, Action) {
  id += 1;
  return { id, FundFamily, FundName, FundType, Currency, Action };
}
class MTable extends React.Component{
    constructor(props) {
        super(props);
        this.state ={
            columns:[]
         }
      }
      doSelect(obj){
        //alert("in select method...");
        this.props.method(obj);
      }      
    render(){        
        const { classes } = this.props; 
        const {data} = this.props;
        console.log('data <><>:'+JSON.stringify( data ));

        console.log("data target::"+this.props.data)

        if(data !== undefined) {
            data.map((item,index) => {
                if(index === 0){
                    var s =  item;                     
                    for(var k in s) {
                        if(k === "Action"){
                            console.log('action')
							this.state.columns.push({
								id: "btn",
								accessor: "",
								Cell: ({ original }) => { 
									return (
										<div>
											<button className="btn btn-primary btn-xs">Select</button>
										</div>
									);
								},
								Header: x => {
									return (
										 ""
									);
								} 
                            })
                        }
                        else {
                        this.state.columns.push({
                            Header: k,
                            accessor: k 
                            });
                        }
                    }
                }
            }); 
           
        }
         let tableDBlk="";
         tableDBlk=<TableRow><TableCell>No Data Found</TableCell></TableRow>;
         if(data !== undefined){
         tableDBlk=data.map(row => {
            return (
              <TableRow key={row.id}>
                <TableCell align="center">{row.FundFamily}</TableCell>
                <TableCell align="right">{row.FundName}</TableCell>
                <TableCell align="center">{row.FundType}</TableCell>
                <TableCell align="right">{row.Currency}</TableCell>
                <TableCell align="center">
		  <Link  className="btn btn-primary btn-xs"  to={{ pathname: '/admincreate/REVIEWPROSPECT', state: {company:"81837075",fundTypeId:"101" ,fundFamilyId:"17903322" ,prodId:"47806054" ,ccy:"EUR"} }} >Select</Link>
                </TableCell>
              </TableRow>
            );
          })
        }
        //console.log('result1 columns<><>:'+JSON.stringify( this.state.columns	));   
        return  (
            <Paper className={classes.root}>
              <Table className={classes.table}>
                <TableHead>
                  <TableRow>
                    <TableCell>Fund Family</TableCell>
                    <TableCell>Fund Name </TableCell>
                    <TableCell>Fund Type </TableCell>
                    <TableCell>Currency</TableCell>
                    <TableCell align="center">Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {tableDBlk}
                </TableBody>
              </Table>
            </Paper>)
    }

}

export default (withStyles(styles))(MTable);