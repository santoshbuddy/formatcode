import React from 'react';
import PropTypes from 'prop-types';
// import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import {muiTableStyles} from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import FormData from 'form-data';
import { createMuiTheme,MuiThemeProvider, withStyles} from '@material-ui/core/styles';

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
    greyout: {
		backgroundColor:"#c3c3c3"
	}
});

class MuiTable extends React.Component{
    constructor(props) {
        super(props);
        this.state ={
            columns:[]
         }
        //  this.doSelect = this.doSelect.bind(this);
      }
      doSelect(obj1, obj2, obj3, obj4, obj5) {
        this.props.method(obj1, obj2, obj3, obj4, obj5);
      }
      shouldComponentUpdate(nextProps, nextState) {
        // console.log(nextProps, nextState);
        // console.log(this.props, this.state);

        return false;
      }
    render(){
        const { classes } = this.props;
        const {data} = this.props;
        // var data = this.props.data;
        //  console.log('NewData <><>:'+JSON.stringify( data ));
        // }

        // console.log(this.props.data)
        // console.log('result1 columns<><>:'+JSON.stringify( this.state.columns	));
		var tx = '';
		var dataArr = [];
		var tClor = '';

		if(data != undefined)
		{
			data.map((row, index) => {
				tClor = '';
				if(row.Suspend==="B") {
					tClor = classes.greyout;
				}

				dataArr.push(
					<TableRow key={index} className={(index%2 ? 'even' : 'odd')}>
						<TableCell component="th" scope="row">{row.FundFamily}</TableCell>
						<TableCell component="th" scope="row">{row.FundName}</TableCell>
						<TableCell align="right">{row.FundType}</TableCell>
						<TableCell align="right">{row.Currency}</TableCell>
						{
							row.Suspend==="B"?
							<TableCell align="right">Suspended</TableCell>
							:
							<TableCell align="right"><button id="select" className="btn btn-primary btn-xs" onClick={(e)=>this.doSelect(row.Product || row.FundName, row.Currency, row.prodId, row.fundFamilyId, row.fundTypeId)}>Select</button></TableCell>
						}

					</TableRow>
				)

			});

			return  (
					<Paper className={classes.root}>
					<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
						<Table className={classes.table}>
							<TableHead className={classes.tableheader}>
								<TableRow className={classes.tabletheadtr}>
									<TableCell>Fund Family</TableCell>
									<TableCell>Fund Name</TableCell>
									<TableCell>Fund Type</TableCell>
									<TableCell align="right">Currency</TableCell>
									<TableCell align="right">Action</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{dataArr}
							</TableBody>
						</Table>
						</MuiThemeProvider>
					</Paper>
			)
		}
		else
		{
			return  (
				<Table className={classes.table}>
					<TableBody>
						<TableRow>
							<TableCell style={{ color: 'red', textAlign: "center", }}>No data found</TableCell>
						</TableRow>
					</TableBody>
				</Table>
			)
		}
    }
}

export default (withStyles(MuiStyles))(MuiTable);