import React from 'react';
import { Route } from 'react-router-dom';
import { MuiThemeProvider } from '@material-ui/core/styles';
import MUIDataTable from "mui-datatables";
import { muiTableStyles } from '../../styles/muidatatableCss';
import AssociatedDetLayer from './AssociatedDetLayer';
import TemplateDetails from './TemplateDetails';
import TableLoader from '../../common/TableLoader';
import { alertConstants } from '../../common/constants/alert.constants';
import axios from 'axios';
import FormData from 'form-data';
import { InputLabel } from '@material-ui/core';

let vecsize;
let createbtndis='';
let AppRejbtn;
var checkFlag=false;
let pendval=[];
let selRowsIndex;
let roleFlag;
const cols = [
    {
        name: "TemplateName",
        options: {
            sort: true,
            download: false,
            filter: false,
            customBodyRender: (value, tableMeta, updateValue) => {
                return (
                    <TemplateDetails mcFlag={roleFlag} tempUserVal={value} size={vecsize} tempDet={tableMeta.rowData}/>
                );
            }
        }
    },{
        name: "TemplateStatus",
        options: {
            sort: true,
            download: false,
            filter: false,
        }
    },{
        name: "ClientName",
        options: {
             sort: true,
            download: false,
            filter: true,
        }
    },{
        name: "NumberofAssociatedUsers",
        options: {
             sort: true,
            download: false,
            filter: false,
            customBodyRender: (value, tableMeta, updateValue) => {
            return (
                <AssociatedDetLayer tdVal={value.NumberofAssociatedUsers} assocDet={value}/>
            );
        }

    },
}];

class ViewAll extends React.Component{
    constructor(props) {
        super(props);
        this.state={
            allRows:[],
            Msg:'',
        }
        this.AppRej = this.AppRej.bind(this);
    };
    AppRej(e){
        var jsonBody = new FormData();
        var url;
        var user = JSON.parse(sessionStorage.getItem('user'));
        jsonBody.append("token",user[0].token);
        jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

        // console.log("==========data===========",this.props.data1.adminreportdata);

        if(this.props.data1.adminreportdata !== undefined)
            this.props.data1.adminreportdata.map((item,index) => {
                if(item.type === "data")
                    pendval = item.values
            })

        var labelId = e.target.id;
        if(roleFlag.roleFlag === 'Checker')

				if(selRowsIndex === undefined || selRowsIndex.length === 0) {
					alert('Please Check atleast one Checkbox.');
				}else {

				if(labelId === "Approve"){
					if(window.confirm('Are you sure, you want to approve the data?')){
					// console.log('this.state.allRows ',this.state.allRows);
						pendval && pendval.map((item,index)=>{
							if(this.state.allRows.find(e => e.index.toString() === index.toString()) !== undefined){
								// console.log("pendval[0]",pendval[index][3])
								// console.log("item.TemplateName >>>>>>>>",item.TemplateName)
								jsonBody.append("chk"+index,'Y');
								jsonBody.append("tempName"+index,item.TemplateName);
								jsonBody.append("templateFor"+index,'');
								jsonBody.append("template"+index,item.selTemplate);
								jsonBody.append("clientFirm"+index,item.tempclientFirm);
								jsonBody.append("pcompanyid"+index,item.pCompanyId);
								jsonBody.append("processId"+index,item.processId);
								jsonBody.append("allFlag"+index,'ALL');
							}
						});
						jsonBody.append("actionFlag",'APPROVE');
						jsonBody.append("tabName",'PENDINGAPR');
						jsonBody.append("MCdatavecSize",pendval.length);
						url=alertConstants.URL+"/CLALERT.do";
						this.props.doRefresh(jsonBody);
/*
						axios({
							method: 'post',
							url:url,
							data: jsonBody,
							config: { headers: {'Content-Type': 'multipart/form-data' }}
						}).then((response)=>{
                            pendval = response.data;
                            if(pendval !== undefined)
                                pendval.map((item)=>{
                                    if(item.name === 'message')
                                    this.setState({Msg:item.value});
                                });
							// this.props.doRefresh()
						});
*/
					}
				}
				else if(labelId === "Reject"){
					if(window.confirm('Are you sure, you want to reject these changes?')){
						pendval && pendval.map((item,index)=>{
							if(this.state.allRows.find(e => e.index.toString() === index.toString()) !== undefined){
								jsonBody.append("processId"+index,item.processId);
								jsonBody.append("chk"+index,'Y');
								}
						});
						jsonBody.append("actionFlag",'REJECT');
						jsonBody.append("tabName",'PENDINGAPR');
						jsonBody.append("MCdatavecSize",pendval.length);
						url=alertConstants.URL+"/CLALERT.do";
						this.props.doRefresh(jsonBody);
/*
						axios({
							method: 'post',
							url:url,
							data: jsonBody,
							config: { headers: {'Content-Type': 'multipart/form-data' }}
						}).then((response)=>{
                            pendval = response.data;
                            if(pendval !== undefined)
                                pendval.map((item)=>{
                                    if(item.name === 'message')
                                        this.setState({Msg:item.value});
                                });
                            // this.props.doRefresh()
						});
*/
					}
				}
			}
    }

    selectedRows(selRows)
    {
        //console.log("selected rws ", selRows);
        selRowsIndex=selRows;
    }

    render() {
        let x= false;
        const { data,TabType } = this.props;
        roleFlag =this.props;
        if(TabType === 1){
            // console.log(TabType)
            x = true
        }
        // console.log(TabType)
        // console.log(roleFlag.roleFlag)
        vecsize =this.props;
            const options = {
                filter: true,
                filterType: 'dropdown',
                responsive: 'scroll',
                selectableRows:x,
                customToolbarSelect: (selectedRows, displayData, setSelectedRows) =>   <div></div>,
                textLabels: {
                    body: {
                        noMatch: data === undefined?<TableLoader />:<div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No data found</b></div>,
                    },
                },
                onRowsSelect: (rowsSelected, allRows) => {
                    this.selectedRows(allRows);
                    this.setState({allRows})
                }
            };
            console.log(x);
            const options1 = {
                filter: true,
                filterType: 'dropdown',
                responsive: 'scroll',
                selectableRows:false,
                customToolbarSelect: (selectedRows, displayData, setSelectedRows) =>   <div></div>,
                textLabels: {
                    body: {
                        noMatch: data === undefined?<TableLoader />:<div key={'1'} style={{fontSize: 12, color: 'red' ,textAlign: 'center',}}> <b key={'2'}>No data found</b></div>,
                    },
                }
            };

        if(TabType === 0){
            createbtndis =
            <div className="col-md-12 col-sm-12 head-cls">
                <div className="panel">
                    <div className="panel-heading clearfix">
                        <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                        <a className="pull-right" onClick={this.tottgleDisplay}>
                            <i className="fa fa-caret-down"></i>
                        </a>
                    </div>
                </div>
                <div className="filter_div" id="filter_div" >
                    <Route render={({ history}) => (
                        <button  className="btn btn-primary btn-xs mt"
                            type='button'
                            onClick={() => { history.push('/administrationnew/CLEMAIL') }}
                        >
                            Create New Template
                        </button>
                    )} />
                    <div style={{clear:'both'}}></div>
                </div>
            </div>;
            AppRejbtn = ''
        }else {
            createbtndis='';
            AppRejbtn =
            <div className="col-md-12 col-sm-12">
                <a href="#" onClick={this.AppRej} id="Approve" title="Approve" class="btn btn-primary btn-xs">Approve</a>
                <a href="#" onClick={this.AppRej} id="Reject" title="Reject" class="btn btn-primary btn-xs">Reject</a>
            </div>;
        }
         return(
            <div>
                {
                    (roleFlag.roleFlag === 'false') &&
                    <div className="col-md-12 col-sm-12 head-cls">
                        <div className="panel">
                            <div className="panel-heading clearfix">
                                <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                                <a className="pull-right" onClick={this.tottgleDisplay}>
                                    <i className="fa fa-caret-down"></i>
                                </a>
                            </div>
                        </div>
                        <div className="filter_div" id="filter_div" >
                            <Route render={({ history}) => (
                                <button  className="btn btn-primary btn-xs mt"
                                    type='button'
                                    onClick={() => { history.push('/administrationnew/CLEMAIL') }}
                                >
                                    Create New Template
                                </button>
                            )} />
                            <div style={{clear:'both'}}></div>
                        </div>
                    </div>
                }
                {createbtndis}
                <div className="clearfix"></div>
                <div className="col-md-12 col-sm-12 head-cls backwhite">
                    <div className="panel">
                        <div className="panel-heading clearfix">
                            <h4 className="panel-title pull-left col-md-1">Search Results</h4>
                        </div>
                    </div>
                    {
                        roleFlag.roleFlag === 'Checker' &&
                        <div>
                        <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                                <MUIDataTable
                                data={data}
                                columns={cols} options={options}  />
                            </MuiThemeProvider>
                            {AppRejbtn}
                        </div>
                    }
                    {
                        roleFlag.roleFlag === 'Maker' &&
                        <div>
                            <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                                <MUIDataTable
                                data={data}
                                columns={cols} options={options1}  />
                            </MuiThemeProvider>
                            {AppRejbtn}
                        </div>
                    }
                    {
                        (roleFlag.roleFlag !== 'Checker' && roleFlag.roleFlag !== 'Maker') &&
                        <div>
                            <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                                <MUIDataTable
                                data={data}
                                columns={cols} options={options1}  />
                            </MuiThemeProvider>
                            {createbtndis}
                        </div>
                    }
                </div>
                {
                    this.state.Msg !== undefined &&
                    <div className="text-center displayTxt">{this.state.Msg}</div>
                }
            </div>
        )
    }
}

export default ViewAll;