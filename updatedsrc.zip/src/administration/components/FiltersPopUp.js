import React from 'react';
import DatePicker from 'react-datepicker';
import { withStyles } from '@material-ui/core/styles';
import 'react-datepicker/dist/react-datepicker.css';
import Button from '@material-ui/core/Button';
import InputLabel from '@material-ui/core/InputLabel';
import NativeSelect from '@material-ui/core/NativeSelect';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
let dateChange=false;
let listChange=false;
const styles = theme => ({
  margin: {
    margin: theme.spacing.unit,
  },
});
var dateFormat = require('dateformat');
let filterNameValueArray=[];
let filterData=[];
let tempFromDateValue;
class FiltersPopUp extends React.Component {
    constructor () {
        super(),
        this.state = {
          newChangeList:false
        },
        this.doChange = this.doChange.bind(this);
        //this.handleChange = this.handleChange.bind(this);
      }
      componentWillMount(){
        // this.doChange();
      }
      componentDidUpdate(){
        //alert("filter. dateChange.."+dateChange);
        //listChange=false;
        if(dateChange === false){
           filterNameValueArray=[];
        }
      }
      handleDateChange(name,value) {
        dateChange=true;
        //console.log("dateChange:",dateChange);
        filterNameValueArray.find(namevalue => namevalue.id === name).value=dateFormat(value,"mmm dd, yyyy");
        filterData.find(namevalue => namevalue.name === name).value=dateFormat(value,"mmm dd, yyyy");
        this.forceUpdate();
      }

handleChange(e)
      {
	      	var listName=e.target.name;
	      	var listValue=e.target.value;
	      	//alert(listValue)
	      	//var subListName;
	      	//alert(e);
	      	listChange=true;
			if(listValue == "ALL"){
				//alert(" all block ...")
			}else{
				//alert(" else block ...")
	    	var tempFromDate=document.getElementById("tempFromDate");

		//alert("0000 tempFromDate ::"+tempFromDate);

		var dateObj=dateFormat(tempFromDate.value,"mmm dd, yyyy");

		//alert("1111 fromDate value::"+dateObj);

		var d = new Date(dateObj);
		var year = d.getFullYear();
		var month =  d.getMonth()+1;

		var dateChange;

		if(listValue == "30"){
		   month=d.getMonth();
		   dateChange=d.getDate()+1;
		}else{
		  dateChange=d.getDate() - listValue;
		}
		d.setDate(dateChange);
		d.setMonth(month);
		d.setFullYear(year);

		const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
		  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
		];
	      	
		var monthName=monthNames[d.getMonth()-1];
		//console.log("listValue:",listValue+"days after subtract:",dateChange+",year::",year+",monthName::",monthName);

		var fromDateEdit=monthName+" "+dateChange+", "+year;

		//console.log("fromDateEdit:",fromDateEdit);

		var objDate = new Date(fromDateEdit);

		var finalObj=dateFormat(objDate,"mmm dd, yyyy");

		//filterData.find(namevalue => namevalue.name === "fromDate").value=dateFormat(objDate,"mmm dd, yyyy");

		//console.log("after change finalObj:",finalObj);

		if(filterNameValueArray!== undefined && filterNameValueArray.length>0){
			let obj=filterNameValueArray.find(namevalue => namevalue.id === listName);
			if(obj!== undefined){
			  obj.value=listValue;
			}
			obj=filterNameValueArray.find(namevalue => namevalue.id === "fromDate");
				if(obj!== undefined){
				  obj.value=finalObj;
			}
		}
		//console.log("feb 25 2019 onchange filterData::",filterData);
		document.getElementById("fromDate").value = finalObj;
		//this.setState({newChangeList:true});
		 //Cannot set property 'newChangeList' of undefined
		//fromDate.forceUpdate();
		//fromDate.forceUpdate is not a function
		}
     }

     doChange(e){
      //alert("filterNameValueArray data:"+filterNameValueArray);
      //console.log("filterNameValueArray---->")
      //alert(filterNameValueArray.length);
      console.log(filterNameValueArray)
      this.props.method(filterNameValueArray);

     }

    render(){

      //console.log("filter filterFlag::"+this.props.filterFlag);
      //console.log("filterData::"+filterData+",filterFlag:"+this.props.filterFlag);
      //console.log("filterFlag:::"+this.props.filterFlag)
      const { classes } = this.props;
        const { data } = this.props;
        let filetermarkup;
		console.log("target ... data:::",data);
		filterData=data;
        /*if(data !== undefined && this.props.filterFlag === true){
          filterData=data;
          if(listChange ===false){
            filterNameValueArray=[];
            }
        }*/
         //console.log("feb_25_2019after filterData::"+filterData);
        if(filterData !== undefined && filterData.length>0){
           filetermarkup = filterData.map((filter,index) => {
            if(filter.type === "Select"){
			                 console.log("feb_25_2019 select block ...");
             return(
                <Grid item  key={filter.id.toString()}>
                  <InputLabel shrink htmlFor="age-native-label-placeholder">
                    { filter.label } :
                  </InputLabel>
			                        <NativeSelect
			                          ref={ filter.name }  name={filter.name} onChange={this.handleChange}>
			                            {filter.values && filter.values.map((obj,index) => {
			                                    return <option key={index} value={obj.id}>{obj.name}</option>
			                                })}
			                          </NativeSelect>
                </Grid>
               );
            }else if(filter.type === "datepicker"){
			if(filter.name === "toDate"){
				tempFromDateValue=filter.value;
			}
            if(filterNameValueArray.find(namevalue => namevalue.id === filter.name))
			filterNameValueArray.find(namevalue => namevalue.id === filter.name).value=filter.value;
	else
              filterNameValueArray.push({id:filter.name,value:filter.value})
                 return (
                  <Grid item  key={filter.id.toString()}>
                       <InputLabel shrink htmlFor="age-native-label-placeholder">
                       { filter.label }:</InputLabel>
                      <DatePicker dateFormat="MMM dd, YYYY" ref={ filter.name } id={filter.name} autoOk={true} name={filter.name} className="form-control"  selected={new Date(filterData.find(namevalue => namevalue.name === filter.name).value)}  onChange={this.handleDateChange.bind(this, filter.name)} />
                   </Grid>
                 );
              }else if(filter.type === "Button"){
                return (
                <button size="small" style={{height: 30, margin: 12}} className="btn btn-primary btn-xs"  title="Go" onClick={(e)=>{this.doChange();}} key={filter.id.toString()}>
                  { filter.name }
                </button>
               );              
              }else if(filter.type === "label"){
               return (
                  <Grid item  key={filter.id.toString()}>
                      <InputLabel shrink htmlFor="age-native-label-placeholder"> { filter.label } :</InputLabel>
                      <InputLabel> { filter.value }</InputLabel>
                  </Grid>
               );
              }else if(filter.type === "newline"){
                return  <div key="newline" className="clearfix"></div>
              }
        });
        dateChange=true;
        //console.log("after filter block called ... filterNameValueArray::",filterNameValueArray);
        //console.log("after filter block called ... filterFlag::",this.props.filterFlag);

       }

        return(
            <Grid container spacing={24} >
                {filetermarkup}
                <input type="hidden" ref="tempFromDate" id="tempFromDate" name="tempFromDate" defaultValue={tempFromDateValue} className="form-control input-sm" />
            </Grid>
        );
    }
}

export default withStyles(styles)(FiltersPopUp);