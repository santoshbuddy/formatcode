import React from 'react';
import { Route } from 'react-router-dom';
import { NavBar } from '../../../navbar/components/navbar';
import { connect } from 'react-redux';
import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../../node_modules/react-table/react-table.css';
import '../../../user/css/App.css';
import FormData from 'form-data';
import MUIDataTable from "mui-datatables";


import { resultConstants } from '../../../common/constants/result.constants';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import  Paper from '@material-ui/core/Paper';
import  Grid from '@material-ui/core/Grid';
import TradeApprovalParams from './TradeApprovalParams';
import UserRoles from './UserRoles';
import EmailAddrMaintenance from './EmailAddrMaintenance';
import { AdministrationActions } from '../../actions/administration.actions';

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  leftdiv :{
    width: '100%',
    padding: "15px",
  },
  tabsRoot: {
    borderBottom: '1px solid #e8e8e8',
  },
  tabsIndicator: {
    backgroundColor: '#1890ff',
  },
  tabRoot: {
    textTransform: 'initial',
    minWidth: 72,
    fontWeight: theme.typography.fontWeightRegular,
    marginRight: theme.spacing.unit * 4,
    // fontFamily: [
    //   '-apple-system',
    //   'BlinkMacSystemFont',
    //   '"Segoe UI"',
    //   'Roboto',
    //   '"Helvetica Neue"',
    //   'Arial',
    //   'sans-serif',
    //   '"Apple Color Emoji"',
    //   '"Segoe UI Emoji"',
    //   '"Segoe UI Symbol"',
    // ].join(','),
    '&:hover': {
      color: '#40a9ff',
      opacity: 1,
    },
    '&$tabSelected': {
      color: '#1890ff',
      fontWeight: theme.typography.fontWeightMedium,
    },
    '&:focus': {
      color: '#40a9ff',
    },
  },
  tabSelected: {},
  typography: {
    padding: theme.spacing.unit * 3,
  },
});

class UserRolesManagement extends React.Component {
  constructor() {
    super();

    this.state = {
    valueFirst: 0,
    makercheckerdata:[],
  }
  this.doSave = this.doSave.bind(this);
  this.doCancel = this.doCancel.bind(this);
  this.doTabChangeMethod = this.doTabChangeMethod.bind(this);
  this.doViewMethod = this.doViewMethod.bind(this);
}

componentDidMount() {
  this.getMakerCheckerParams()
}


getMakerCheckerParams(){
  var bodyFormdata = new FormData();
  var actionName = "MCMAINT";
  this.props.dispatch(AdministrationActions.fetchMakerCheckerParams(bodyFormdata, actionName));
}
doSave(saveData, actionName){
  console.log("doSave::"+actionName);
  this.props.dispatch(AdministrationActions.saveCheckerParamsData(saveData, actionName));
}
doCancel(saveData, actionName){
  console.log("doCancel::"+actionName);
  this.props.dispatch(AdministrationActions.saveCheckerParamsData(saveData, actionName));
}
doViewMethod(viewData, actionName){
  console.log("doViewMethod::"+actionName);
  this.props.dispatch(AdministrationActions.fetchMakerCheckerParams(viewData, actionName));
}

doTabChangeMethod(bodyFormdata, actionName){
  console.log("tabChangeMethod::"+actionName);
  this.props.dispatch(AdministrationActions.fetchMakerCheckerParams(bodyFormdata, actionName));
}

  handleChangeFirst = (event, valueFirst) => {
    this.setState({ valueFirst });
    var actionName;
    var bodyFormdata = new FormData();
    bodyFormdata.append("trdTabName", "VIEWALL");
    if(valueFirst == 0){
      actionName =  "MCMAINT";
      bodyFormdata.append("tabName", "CHKPARAM");
    }else if(valueFirst == 1){
      actionName =  "USRROLESE";
      bodyFormdata.append("tabName", "USRROLESE");
    }else{
      actionName =  "EMLADSMT";
      bodyFormdata.append("tabName", "EMLADSMT");
    }

      this.props.dispatch(AdministrationActions.fetchMakerCheckerParams(bodyFormdata, actionName));
  };

  render() {
    const { classes, makercheckerdata } = this.props;
    const { valueFirst } = this.state;
    let results = [];
    let resultData = [];
    let screenName = '';
    let checkerFlag = '';
    let respMsg = '';


    let userRoles = [];
    let userMcRoles = [];
    let clientFirm='';
    let processId='';

    if(makercheckerdata){
      resultData = makercheckerdata.makercheckerdata;
          if( resultData){
              resultData.map((item,index) => {
	          if(item.type === "Title")
                    screenName = item.name
                  if(item.type === "ClientFirm")
                    clientFirm = item.name

                  if(item.type === "ProcessId")
                    processId = item.name

 		console.log("mar05, 2019  first component processId::",processId+",clientFirm::",clientFirm);

                  if(item.type === "RoleType")
                    checkerFlag = item.name




	          if(item.name === "data" && valueFirst == 0)
                   results = item.datamap
                  else if(item.name === "data" && (valueFirst == 1 || valueFirst == 2))
                  results = item.values

                  if(item.name === "data1")
                  userRoles = item.values

                  if(item.name === "data2")
                  userMcRoles = item.values

                   if(item.type === "Result"){
                   respMsg = item.name

                   }

              })
          }
    }


 return (
 <div>
    	<NavBar/>

    	<div className="clearfix"></div>
	    	<div style={{float:'left',padding:'16px'}}>User Roles Management :</div>
	      <div className={classes.root} style={{float:'left'}}>
	        <Tabs
	          value={valueFirst}
	          onChange={this.handleChangeFirst}
	          classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}
	        >
	          <Tab
	            disableRipple
	            classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
	            label="Trade Approval Process"
	          />
	         {/* <Tab
	            disableRipple
	            classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
	            label="User Roles"
	          /> */}
	          <Tab
		    disableRipple
		    classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
		    label="Email Address Maintenance"
	          />
	        </Tabs>

       </div>

      <div className="clearfix"></div>
    	<div className="clearfix"></div>

      {valueFirst === 0 && <Grid container spacing={8} direction="row"
			  justify="flex-start"
			  alignItems="flex-start" item xs={12}><Grid item xs={6}>
			<TradeApprovalParams savemethod={this.doSave} cancelmethod={this.doCancel} viewmethod={this.doViewMethod} tabChangeMethod={this.doTabChangeMethod} screenName ={screenName} checkerFlag ={checkerFlag} clientFirm={clientFirm} processId={processId} checkersdata={results} respMsg={respMsg}/>
      </Grid><Grid item xs={6}></Grid></Grid>}
      {/*valueFirst === 1 && <Grid container spacing={8} direction="row"
			  justify="flex-start"
			  alignItems="flex-start" item xs={12}><Grid item xs={9}>
			<UserRoles savemethod={this.doSave} cancelmethod={this.doCancel} tabChangeMethod={this.doTabChangeMethod} screenName ={screenName} checkerFlag ={checkerFlag} clientFirm={clientFirm} processId={processId} usersRolesdata={results} usersdata={userRoles} userMcRoles={userMcRoles} respMsg={respMsg}/>
      </Grid> <Grid item xs={3}>
 <Paper className={classes.root}>
<Typography variant="h5" component="h3">
<div className="panel">
            <div className="panel-heading clearfix">
                  <h4 className="panel-title pull-left col-md-1">Roles Definitions</h4>
             </div>
            </div>
</Typography>
<div className={classes.leftdiv}>
<Typography component="p" gutterBottom>
Definition of Role types for organizations that have turned on the Maker / Checker workflow:
</Typography>
<Typography component="p" gutterBottom>
<b>MAKER</b> : Data entered by this user will require approval from a Checker user
</Typography>
<Typography variant="body1" gutterBottom>
<b>CHECKER</b> : User can perform the Maker function (which will require approval from another Checker user), and also approve entries made by other users
</Typography>
<Typography component="p" gutterBottom>
<b>EXEMPT</b> : User's entries will bypass the Maker / Checker workflow. User can perform the Maker function (which will NOT require approval from another Checker user) but will not be able to approve entries made by other users
</Typography>
<Typography component="p" gutterBottom><i>Notes: </i></Typography>
<Typography component="p" gutterBottom>&nbsp;&nbsp;&nbsp;<i>- You are not required to have two approvals for each trade entry. You can customize your organization's Maker / Checker workflow for trade entries to require either 1 or 2 approvals for each entry.   </i></Typography>
<Typography component="p" gutterBottom >&nbsp;&nbsp;&nbsp;<i>- For Maker / Checker workflows set up for 2 Checker approvals, the process is sequential. The Checker 1 user must enter approval before the Checker 2 user can enter approval.</i></Typography>
<Typography component="p" gutterBottom>&nbsp;&nbsp;&nbsp;<i>- The User Role selection applies only to trade workflows. All user profile management changes will automatically require a Checker approval.  </i></Typography>
</div>
</Paper>
</Grid></Grid>*/}
{valueFirst === 1 && <Grid container spacing={8} direction="row"
			  justify="flex-start"
			  alignItems="flex-start" item xs={12}><Grid item xs={6}>
			<EmailAddrMaintenance savemethod={this.doSave} cancelmethod={this.doCancel} tabChangeMethod={this.doTabChangeMethod} screenName ={screenName} checkerFlag ={checkerFlag} clientFirm={clientFirm} processId={processId} useremaildata={results} respMsg={respMsg}/>
      </Grid><Grid item xs={6}></Grid></Grid>}
       </div>

    );
  }
}


function mapStateToProps(state) {
  const { makercheckerdata } = state;
  return { makercheckerdata};
}

export default connect(mapStateToProps)((withStyles(styles))(UserRolesManagement));




