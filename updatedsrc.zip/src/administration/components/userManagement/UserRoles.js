import React from 'react'
import { Field } from 'redux-form'
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

import  Paper from '@material-ui/core/Paper'
import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import Divider from '@material-ui/core/Divider';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import { createMuiTheme,MuiThemeProvider} from '@material-ui/core/styles';
import { muiTableStyles } from '../../../styles/muidatatableCss';
import { MuiStyles } from '../../../styles/MuiStyles';
import NativeSelect from '@material-ui/core/NativeSelect';
import Input from '@material-ui/core/Input';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import { resultConstants } from '../../../common/constants/result.constants'
import UserRolesViewChanges from './UserRolesViewChanges';
import Info from "@material-ui/icons/Info";
import Loading from '../../../common/Loading';


const styles = theme => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
    },
    paper: {
      padding: theme.spacing.unit * 2,
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    tabsRoot: {
        borderBottom: '1px solid #e8e8e8',
      },
      tabsIndicator: {
        backgroundColor: '#1890ff',
      },
      tabRoot: {
        textTransform: 'initial',
        minWidth: 72,
        fontWeight: theme.typography.fontWeightRegular,
        marginRight: theme.spacing.unit * 4,
        // fontFamily: [
        //   '-apple-system',
        //   'BlinkMacSystemFont',
        //   '"Segoe UI"',
        //   'Roboto',
        //   '"Helvetica Neue"',
        //   'Arial',
        //   'sans-serif',
        //   '"Apple Color Emoji"',
        //   '"Segoe UI Emoji"',
        //   '"Segoe UI Symbol"',
        // ].join(','),
        '&:hover': {
          color: '#40a9ff',
          opacity: 1,
        },
        '&$tabSelected': {
          color: '#1890ff',
          fontWeight: theme.typography.fontWeightMedium,
        },
        '&:focus': {
          color: '#40a9ff',
        },
      },
      tabSelected: {},
      typography: {
        padding: theme.spacing.unit * 3,
      },

      label: {
        fontSize: '14px',
        fontWeight : 'bold',
      },
      tablerow:{
        height : '20px',
      },

      margin: {
        marginRight: '0px',
        marginLeft: '0px',
      },
      insrt:{
        fontSize:'12px',
        color: '#666666',
        fontFamily: 'arial,helvetica,sans-serif',
      },
      listboxstyle:{padding:'0px !important',
      height: 18},
      readonly: {
	    		    border: '1px solid #cccccc',
	    		    backgroundColor: '#afb1b0',
 	}

  });

 let rowdata = [];
 let userMcRoles = [];
 var bodyFormdata = new FormData();
 class UserRoles extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
         value: 0,
         ck:'' ,
         ViewChangesbtn: false,
         labelWidth : 8,
         allCheckVal : [],
        }
        this.doViewChanges = this.doViewChanges.bind(this);
    }

     componentWillMount(){
		 bodyFormdata = new FormData();
	 }
    componentDidMount(){
        rowdata =  [];
        if(this.props.usersdata !== undefined){
                this.props.usersdata.map((item,index) =>{
                    rowdata.push(item);
                });
        }
    }
    handleChange = (event, value) => {
        this.setState({ value });
        var actionName;
        var bodyFormdata = new FormData();

        actionName =  "USRROLESE";
        bodyFormdata.append("tabName", "USRROLESE");
        if(value == 0) {
            bodyFormdata.append("viewTab", "VIEWALL");
        }else if(value == 1){
          bodyFormdata.append("viewTab", "PENDAPPR");
        }
        rowdata = [];
        userMcRoles = [];
        this.props.tabChangeMethod(bodyFormdata, actionName);
    };
    rolesOnChange(e,loginid) {

        var mcroleItem = userMcRoles.find(evt => evt.LOGINID===loginid);
        var indx = userMcRoles.findIndex(evt => evt.LOGINID===loginid);
        if(mcroleItem !== undefined){
            mcroleItem.NEWMCROLEID = e.target.value;
            //if(e.target.value !== "null" || e.target.value !== "NONE")
            //    mcroleItem.STATUS ="Y";

            userMcRoles[indx] = mcroleItem;
        }else {
            mcroleItem.NEWMCROLEID = e.target.value;
            mcroleItem.LOGINID = loginid;
            mcroleItem.DISABLED = "false";
            mcroleItem.NATURE = "Assigned Role Type";
          //  mcroleItem.STATUS = "Y";
            userMcRoles[userMcRoles.length+1] = mcroleItem;
        }
    }

    handleAllowChange = (e, index) => {
        var singlerow = rowdata[index];
        singlerow.ALWINVPOLCY = e.target.value;
        rowdata[index] = singlerow;
    }
    doCancel(){
        bodyFormdata.append("actionFlag","");
        rowdata = [];
        userMcRoles = [];
        this.props.cancelmethod(bodyFormdata, "USRROLESE");
    }
    doSave(){
		var bodyFormdata = new FormData();
        bodyFormdata.append("actionFlag","AMCSAVE");
        var curSize = 0;


        rowdata && rowdata.map((item,index) =>{
            var mcroleItem = userMcRoles.find(e => e.LOGINID===item.LOGINID);
            if(mcroleItem != undefined){
            	if(mcroleItem.MCROLEID === undefined || mcroleItem.MCROLEID.length === 0
                    || mcroleItem.MCROLEID === "null" || mcroleItem.STATUS === "N")
                    mcroleItem.MCROLEID = "NONE";


                    if(mcroleItem.NEWMCROLEID === undefined)
                    mcroleItem.NEWMCROLEID =mcroleItem.MCROLEID;

                    if(mcroleItem.MCROLEID === "NONE")
                    mcroleItem.MCROLEID = "20";

                bodyFormdata.append("UserRolltype"+index.toString(), mcroleItem.NEWMCROLEID);

                bodyFormdata.append("assRoleId"+index.toString(), mcroleItem.MCROLEID);
				bodyFormdata.append("status"+index.toString(), mcroleItem.STATUS);
				bodyFormdata.append("nature"+index.toString(), mcroleItem.NATURE);

				if(mcroleItem.PROCESSID.length == 0){
				bodyFormdata.append("procid"+index.toString(), item.PROCESSID);
				}else {
				bodyFormdata.append("procid"+index.toString(), mcroleItem.PROCESSID);
				}
 				bodyFormdata.append("oldInv"+index.toString(), item.OLDINVPOLCY);

				bodyFormdata.append("UserloginId"+index.toString(), mcroleItem.LOGINID);
	                bodyFormdata.append("invnature"+index.toString(), mcroleItem.INVNATURE);
	                if(item.DISABLED == "true"){
	                 bodyFormdata.append("roleDisable"+index.toString(), "true");
				    }else{
						 bodyFormdata.append("roleDisable"+index.toString(), "false");
					}
            }else {
                bodyFormdata.append("UserRolltype"+index.toString(), "NONE");
            }
            bodyFormdata.append("alwInvPol"+index.toString(), item.ALWINVPOLCY);

        });
        bodyFormdata.append("usrSize", rowdata.length);
        rowdata = [];
        userMcRoles = [];
        this.props.savemethod(bodyFormdata, "USRROLESE");

    }
      handleCheck = (event, index) => {
	        var chkVal = document.getElementById("Check" +index).checked;
	        let allCheckVal = this.state.allCheckVal;
 	 	     if(chkVal){
	            	 allCheckVal[index] = 'Y' ;

	        } else{
	                allCheckVal[index] = 'N' ;

	        }
	        this.setState({allCheckVal});
 	    }

      doApprove(){
			var bodyFormdata = new FormData();

			bodyFormdata.append("actionFlag","APPROVE");
			bodyFormdata.append("tabName","USRROLESE");
			bodyFormdata.append("viewTab","PENDAPPR");
			bodyFormdata.append("reactJSActionFlag","GO");

			var curSize = 0;
			var cnt=0;

	        rowdata && rowdata.map((item,index) =>{
				if(this.state.allCheckVal[index] === 'Y'){
				bodyFormdata.append("Check"+index.toString(), "Y");



	            var mcroleItem = userMcRoles.find(e => e.LOGINID===item.LOGINID);


	            if(mcroleItem != undefined){
					       if(mcroleItem.NEWMCROLEID === undefined)
					                    mcroleItem.NEWMCROLEID =mcroleItem.MCROLEID;


					bodyFormdata.append("assRoleId"+index.toString(), mcroleItem.MCROLEID);
					bodyFormdata.append("status"+index.toString(), mcroleItem.STATUS);
					bodyFormdata.append("nature"+index.toString(), mcroleItem.NATURE);

					if(mcroleItem.PROCESSID.length == 0){
					bodyFormdata.append("procid"+index.toString(), item.PROCESSID);
					}else {
					bodyFormdata.append("procid"+index.toString(), mcroleItem.PROCESSID);
					}
	                bodyFormdata.append("UserRolltype"+index.toString(), mcroleItem.MCROLEID);
	                bodyFormdata.append("oldInv"+index.toString(), item.OLDINVPOLCY);

	                bodyFormdata.append("UserloginId"+index.toString(), mcroleItem.LOGINID);
	                bodyFormdata.append("invnature"+index.toString(), mcroleItem.INVNATURE);

	            }else {
	                bodyFormdata.append("UserRolltype"+index.toString(), "NONE");
	            }
	            bodyFormdata.append("alwInvPol"+index.toString(), item.ALWINVPOLCY);
	            cnt++;
			}


	        });
	        if(cnt>0){
				bodyFormdata.append("usrSize", rowdata.length);
				if(confirm("Are you sure, you want to approve the data?")){
					rowdata = [];
					userMcRoles = [];
					this.props.savemethod(bodyFormdata, "USRROLESE");
				}
			}else {
							 alert('Please check atleast one check box .');

			}
	    }


  doReject() {

	  var bodyFormdata = new FormData();

	  			bodyFormdata.append("actionFlag","REJECT");
	  			bodyFormdata.append("tabName","USRROLESE");
	  			bodyFormdata.append("viewTab","PENDAPPR");
	  			bodyFormdata.append("reactJSActionFlag","GO");

	  			var curSize = 0;

				var cnt=0;
	  	        rowdata.map((item,index) =>{
	  				if(this.state.allCheckVal[index] === 'Y'){
	  				bodyFormdata.append("Check"+index.toString(), "Y");

	  	            var mcroleItem = userMcRoles.find(e => e.LOGINID===item.LOGINID);
	  	            if(mcroleItem != undefined){
       if(mcroleItem.NEWMCROLEID === undefined)
                    mcroleItem.NEWMCROLEID =mcroleItem.MCROLEID;

	  					bodyFormdata.append("assRoleId"+index.toString(), mcroleItem.MCROLEID);
	  					bodyFormdata.append("status"+index.toString(), mcroleItem.STATUS);
	  					bodyFormdata.append("nature"+index.toString(), mcroleItem.NATURE);

	  					if(mcroleItem.PROCESSID.length == 0){
	  					bodyFormdata.append("procid"+index.toString(), item.PROCESSID);
	  					}else {
	  					bodyFormdata.append("procid"+index.toString(), mcroleItem.PROCESSID);
	  					}
	  	                bodyFormdata.append("UserRolltype"+index.toString(), mcroleItem.MCROLEID);
	  	                bodyFormdata.append("oldInv"+index.toString(), item.OLDINVPOLCY);

	  	                bodyFormdata.append("UserloginId"+index.toString(), mcroleItem.LOGINID);
	  	                bodyFormdata.append("invnature"+index.toString(), mcroleItem.INVNATURE);

	  	            }else {
	  	                bodyFormdata.append("UserRolltype"+index.toString(), mcroleItem.MCROLEID);
	  	            }
	  	            bodyFormdata.append("alwInvPol"+index.toString(), item.ALWINVPOLCY);
				 cnt++;
				}


	  	        });
	  	         if(cnt>0){
					bodyFormdata.append("usrSize", rowdata.length);
					if(confirm("Are you sure, you want to reject the data?")){
						rowdata = [];
						userMcRoles = [];
						this.props.savemethod(bodyFormdata, "USRROLESE");
					}
				}else {
						 alert('Please check atleast one check box .');

				}
  }


    doViewChanges(){
	this.setState({ViewChangesbtn:true})
    }

    doClose = () =>{
        this.setState({ViewChangesbtn:false})
    }

    render(){
        const {classes, screenName, checkerFlag, clientFirm, processId, respMsg} = this.props
        const { value } = this.state;

        var len = rowdata.length;

        var k;
        if(this.props.usersdata !== undefined && len == 0){
            this.props.usersdata.map((item,index) =>{
                rowdata.push(item);
            });
            if(this.props.userMcRoles !== undefined){
                this.props.userMcRoles.map((item,index) =>{
                    userMcRoles.push(item);
                });
            }
        }
        let noRecordsblock;
       if(this.props.usersdata !== undefined && rowdata.length > 0){
       	noRecordsblock = <TableRow key="0"><TableCell colSpan={3}> <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>No records are pending approval</div></TableCell></TableRow>
       }else if(this.props.usersdata === undefined && this.props.checkersdata === undefined && rowdata.length === 0){
	noRecordsblock = <TableRow key="0"><TableCell colSpan={3}> <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>No records are pending approval</div></TableCell></TableRow>
       }else{
       	noRecordsblock =<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
       }
        let contentblock;
        let rolesSelect;
        //console.log("this.props.usersRolesdata::2222::"+JSON.stringify(this.props.usersRolesdata));
        if(this.props.usersRolesdata !== undefined){
            let rows = [];
            this.props.usersRolesdata.map((item1,index1) =>{
                //console.log("item1::66666::"+JSON.stringify(item1));
                item1["NONE"] = "EXEMPT";
                    for(var k in item1)
                        rows.push(k);

                    rolesSelect = rows && rows.map((b, index) => {
                        return <option key={index} value={b}>{item1[b]}</option>
                    });
            })

        }else{
            rolesSelect = <option key="1" value="">None</option>
        }



        if(this.props.usersdata !== undefined && rowdata.length > 0){

            contentblock =rowdata && rowdata.map((item,index) =>{
            //console.log("item.CURRENCYCODE::1111:"+item.CURRENCYCODE);

                        bodyFormdata.append("UserloginId"+index.toString(), item.LOGINID);
                        bodyFormdata.append("invnature"+index.toString(), item.INVNATURE);

                if(item.MEMCATID !== resultConstants.SALESPERSONMEMBERCATID){
                        let mcroleType = '';
                        let disableflag;
                        let readOnlyFlg = false;
                        let count = false;
                        var mcroleItem;
                        if(userMcRoles !== undefined){
                            mcroleItem = userMcRoles.find(e => e.LOGINID===item.LOGINID);
                            if(mcroleItem !== undefined){
                                count = true;
                                if(mcroleItem.STATUS != "N"){
                                    mcroleType = mcroleItem.MCROLEID;
                                }else {
                                    mcroleType = "NONE";
                                }
                                if(mcroleItem !== undefined){
                                    disableflag = mcroleItem.DISABLED;
                                    bodyFormdata.append("assRoleId"+index.toString(), mcroleItem.MCROLEID);
                                    bodyFormdata.append("status"+index.toString(), mcroleItem.STATUS);
                                    bodyFormdata.append("nature"+index.toString(), mcroleItem.NATURE);
                                    if(mcroleItem.PROCESSID.length == 0){
                                        bodyFormdata.append("procid"+index.toString(), item.PROCESSID);
                                    }else {
                                        bodyFormdata.append("procid"+index.toString(), mcroleItem.PROCESSID);
                                    }
                                }
                            }
                        }
                        if(mcroleType === '')
                                mcroleType = "NONE";

                        bodyFormdata.append("oldInv"+index.toString(), item.OLDINVPOLCY);

                        let roleselect;
                        if((disableflag !== undefined && disableflag === "true") || item.DISABLED == "true"){
                            readOnlyFlg = true;
                            roleselect = <NativeSelect ref={'UserRolltype' + index.toString() }
                            className={classes.select,classes.readonly}
                            name={ 'UserRolltype' + index.toString()  } children={rolesSelect}
                            defaultValue={mcroleType}
                            disabled
                            inputProps={{
                                style: {fontSize: 12}
                              }}
                            onChange={(e)=>this.rolesOnChange(e, item.LOGINID)} />
                        } else {
                            roleselect = <NativeSelect ref={'UserRolltype' + index.toString() }
                            className={classes.select}
                            name={ 'UserRolltype' + index.toString()  } children={rolesSelect}
                            defaultValue={mcroleType}
                            inputProps={{
                                style: {fontSize: 12}
                              }}
                            onChange={(e)=>this.rolesOnChange(e, item.LOGINID)} />
                        }

                        bodyFormdata.append("roleDisable"+index.toString(), readOnlyFlg);
                        if(count === true) {
                            return <TableRow key={index.toString()} className={classes.tablerow}>
                              <TableCell component="td" scope="row">
                                 {((this.state.value === 1)
                                    && (item.CHECKERFLAG === "Y" || mcroleItem.CHECKERFLAG === "Y")) &&

                                    <Checkbox

                                    key={"Check"+index.toString()}
                                     id={"Check"+index.toString()}
                                    onChange={e => this.handleCheck(e,index)}
                                   checked={this.state.allCheckVal[index] === 'Y'? 'checked':''}

                                    />
                                     }

				                   {item.USERDESC}
                                </TableCell>
                                <TableCell >
                                    {roleselect}
                                </TableCell>
                                <TableCell >
                                 {(readOnlyFlg === true) ?
                                <NativeSelect
                                    ref={'alwInvPol' + index.toString() } name={ 'alwInvPol' + index.toString()  }
                                    className={classes.readonly}
                                    onChange={e => this.handleAllowChange(e,index)}
                                    defaultValue={item.ALWINVPOLCY}
                                    disabled
                                    inputProps={{
                                        style: {fontSize: 12}
                                      }}
                                    >
                                        <option value={'Y'}>Yes</option>
                                        <option value={'N'}>No</option>
                                    </NativeSelect> :
                                        <NativeSelect
                                        ref={'alwInvPol' + index.toString() } name={ 'alwInvPol' + index.toString()  }
                                        className={classes.select}
                                        onChange={e => this.handleAllowChange(e,index)}
                                        defaultValue={item.ALWINVPOLCY}
                                        inputProps={{
                                            style: {fontSize: 12}
                                          }}
                                        >
                                            <option value={'Y'}>Yes</option>
                                            <option value={'N'}>No</option>
                                 </NativeSelect> }
                                </TableCell >
                                </TableRow>
                            }else if(count === false) {
                                bodyFormdata.append("procid"+index.toString(), item.PROCESSID);
                                return <TableRow key={index.toString()} className={classes.tablerow}>
                                <TableCell component="td" scope="row">
                                 {(this.state.value == 1 && item.CHECKERFLAG =="Y") &&

                                    <Checkbox
                                    className={classes.listboxstyle}
                                    key={"Check"+index.toString()}
                                     id={"Check"+index.toString()}
                                    onChange={e => this.handleCheck(e,index)}
                                     checked={this.state.allCheckVal[index] === 'Y'? 'checked':''}
                                    />

                                    }


				                   {item.USERDESC}
                                </TableCell>
                                <TableCell >
                                    {roleselect}
                                </TableCell>
                                <TableCell >
                                {(readOnlyFlg === true) ?
                                <NativeSelect
                                    ref={'alwInvPol' + index.toString() } name={ 'alwInvPol' + index.toString()  }
                                    className={classes.select,classes.readonly}
                                    onChange={e => this.handleAllowChange(e,index)}
                                    defaultValue={item.ALWINVPOLCY}
                                    disabled
                                    inputProps={{
                                        style: {fontSize: 12}
                                      }}
                                    >
                                        <option value={'Y'}>Yes</option>
                                        <option value={'N'}>No</option>
                                    </NativeSelect> :
                                        <NativeSelect
                                        ref={'alwInvPol' + index.toString() } name={ 'alwInvPol' + index.toString()  }
                                        className={classes.select}
                                        onChange={e => this.handleAllowChange(e,index)}
                                        defaultValue={item.ALWINVPOLCY}
                                        inputProps={{
                                            style: {fontSize: 12}
                                          }}
                                        >
                                            <option value={'Y'}>Yes</option>
                                            <option value={'N'}>No</option>
                                 </NativeSelect> }
                                </TableCell >
                                </TableRow>
                            }


                        }

                    });
        }

	let approveBtn="";
	let rejectBtn="";
	if(checkerFlag === "Y"){
		approveBtn=<a title="Approve" onClick={(e)=>{this.doApprove();}} className="btn btn-primary btn-xs">Approve</a>
		rejectBtn=<a title="Reject" onClick={(e)=>{this.doReject();}} className="btn btn-primary btn-xs">Reject</a>
	}
    return (
        <div>
    <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
        <Paper className={classes.root}>
            <div className="panel">
            <div className="panel-heading clearfix">
                  <h4 className="panel-title pull-left col-md-1">{screenName}</h4>
             </div>
            </div>
            <div className="clearfix"></div>
    	    <div style={{float:'left',padding:'16px', width: '280px'}}>User Roles for Maker / Checker process
                and Investment Policy Permissions :</div>
            <div className={classes.root} style={{float:'left'}}>
            <Tabs
            value={value}
            onChange={this.handleChange}
            classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}
            >
            <Tab
                disableRipple
                classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
                label="View All"
            />
            <Tab
                disableRipple
                classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
                label="Pending Approval"
            />
            </Tabs>
            </div>
            <div className="clearfix"></div>
            {value === 0 &&
                <div>
                    <div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> <Info className={classes.info} style={{float:'left'}}/><h6 style={{marginTop:'10px',float:'left',marginLeft:'30px'}}>{this.state.value=== 0?" Records in grey are Pending Approval":"You will not be able to approve any records for which you performed the Maker action. These records are greyed out and cannot be selected."}</h6></div>
                    <Divider light />
                <Table>
                     <TableHead>
                            <TableRow className={classes.tablerow}>
                            <TableCell key={'0'} className={classes.label}>User Name</TableCell>
                            <TableCell key={'1'} className={classes.label}>Role</TableCell>
                            <TableCell key={'2'} className={classes.label}>Is Allowed to override Investment Policy</TableCell>
                            </TableRow>
                        </TableHead>
                    <TableBody>
                    {contentblock}
                    </TableBody>
                </Table>
                {respMsg && respMsg.length > 0 &&
                 <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>{resultConstants[respMsg]}</div>
               }
                <div className="col-md-6" style={{marginTop:'5px'}}>
                  <a title="Save" onClick={(e)=>{this.doSave();}} className="btn btn-primary btn-xs">Save</a>
                  <a title="Cancel" onClick={(e)=>{this.doCancel();}} className="btn btn-primary btn-xs">Cancel</a>
                   <button title="View Changes"  className="btn btn-primary btn-xs" onClick={this.doViewChanges}>View Changes</button>
                  {this.state.ViewChangesbtn ?(<UserRolesViewChanges open={this.state.ViewChangesbtn} clientFirm={clientFirm} processId={processId} doClose={this.doClose} />):''}
               </div>
               
               </div>
            }
    {value === 1 && <div>
        <div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> <Info className={classes.info} style={{float:'left'}}/><h6 style={{marginTop:'7px',float:'left',marginLeft:'30px'}}>{this.state.value=== 0?" Records in grey are Pending Approval":"You will not be able to approve any records for which you performed the Maker action. These records are greyed out and cannot be selected."}</h6></div>
       <Divider light />
                <Table>
                     <TableHead>
                            <TableRow className={classes.tablerow}>
                            <TableCell key={'0'} className={classes.label}>User Name</TableCell>
                            <TableCell key={'1'} className={classes.label}>Role</TableCell>
                            <TableCell key={'2'} className={classes.label}>Is Allowed to override Investment Policy</TableCell>
                            </TableRow>
                        </TableHead>
                    <TableBody>
                    {(contentblock != undefined && contentblock.length > 0) ? contentblock :
                    noRecordsblock}
                    </TableBody>
                </Table>
                           <div className="clearfix"></div>

                {(contentblock != undefined && contentblock.length > 0) &&
                <div className="col-md-6" style={{marginTop:'30px'}}>
                   {approveBtn}
		  		  {rejectBtn}
                  <button title="View Changes" className="btn btn-primary btn-xs" onClick={this.doViewChanges}>View Changes</button>
                  {this.state.ViewChangesbtn ?(<UserRolesViewChanges open={this.state.ViewChangesbtn} clientFirm={clientFirm} processId={processId} doClose={this.doClose} />):''}
               </div>}
               {respMsg && respMsg.length > 0 &&
                 <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>{resultConstants[respMsg]}</div>
               }
               </div>
    }
     </Paper>
     </MuiThemeProvider>

    </div>

        );
    }
}

UserRoles.propTypes = {
    classes: PropTypes.object.isRequired,
  };

  export default withStyles(MuiStyles)(UserRoles);