import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';
import FormData from 'form-data';

import  Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import Divider from '@material-ui/core/Divider';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import { createMuiTheme,MuiThemeProvider} from '@material-ui/core/styles';
import { muiTableStyles } from '../../../styles/muidatatableCss';
import { MuiStyles } from '../../../styles/MuiStyles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import UserRolesTradeApprovalProcessViewChanges from './UserRolesTradeApprovalProcessViewChanges';
import { resultConstants } from '../../../common/constants/result.constants';
import {addCommas, IsCharsInBag, Comma, removeCommas} from '../../../common/amountValidations';
import Info from "@material-ui/icons/Info";
import Loading from '../../../common/Loading';
  const styles = theme => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
    },
    paper: {
      padding: theme.spacing.unit * 2,
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    tabsRoot: {
        borderBottom: '1px solid #e8e8e8',
      },
      tabsIndicator: {
        backgroundColor: '#1890ff',
      },
      tabRoot: {
        textTransform: 'initial',
        minWidth: 72,
        fontWeight: theme.typography.fontWeightRegular,
        marginRight: theme.spacing.unit * 4,
        // fontFamily: [
        //   '-apple-system',
        //   'BlinkMacSystemFont',
        //   '"Segoe UI"',
        //   'Roboto',
        //   '"Helvetica Neue"',
        //   'Arial',
        //   'sans-serif',
        //   '"Apple Color Emoji"',
        //   '"Segoe UI Emoji"',
        //   '"Segoe UI Symbol"',
        // ].join(','),
        '&:hover': {
          color: '#40a9ff',
          opacity: 1,
        },
        '&$tabSelected': {
          color: '#1890ff',
          fontWeight: theme.typography.fontWeightMedium,
        },
        '&:focus': {
          color: '#40a9ff',
        },
      },
      tabSelected: {},
      typography: {
        padding: theme.spacing.unit * 3,
      },

      label: {
        fontSize: '14px',
        fontWeight : 'bold',
      },
      tablerow:{
        height : '20px',
      },
      margin: {
        marginRight: '0px',
        marginLeft: '0px',
      },
      insrt:{
        fontSize:'12px',
        color: '#666666',
        fontFamily: 'arial,helvetica,sans-serif',
      },
      checkboxstyle:{padding:'0px !important',
      height: 18}

  });

 var rowdata = [];
 var bodyFormdata = new FormData();
 class TradeApprovalParams extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
         value: 0,
         ck:'',
         ViewChangesbtn: false,
         allCheckVal : [],
         maindisable : [],
        }
        this.doViewChanges = this.doViewChanges.bind(this);
    }
    componentWillMount(){
		 rowdata =  [];
	}
    componentDidMount(){
        rowdata =  [];
        let arrObj;
        var innerArry = [];

        if(this.props.checkersdata !== undefined){
            for(var k in this.props.checkersdata) {
                innerArry = [];
                arrObj =  this.props.checkersdata[k];
                arrObj && arrObj.map((item,index) =>{
                    innerArry.push(item);
                });
                    rowdata.push(innerArry);
            }
        }
    }
    handleChange = (event, value) => {
        this.setState({ value });
        var actionName;
        var bodyFormdata = new FormData();

        actionName =  "MCMAINT";
        bodyFormdata.append("tabName", "CHKPARAM");
        if(value == 0) {
            bodyFormdata.append("trdTabName", "VIEWALL");
        }else if(value == 1){
          bodyFormdata.append("trdTabName", "PENDINGAPR");
        }
        rowdata = [];
        this.props.tabChangeMethod(bodyFormdata, actionName);
    };
    handleAmountChange(e,index,chindex) {
       if((IsCharsInBag(e.target.value," ") == false))
        {
            if(!(IsCharsInBag(e.target.value,"0123456789.,MMmmKKkk")))
        {
          alert("Enter Valid Amount");

          e.target.value="";
    		if ( window.event != null ) {
    			window.event.returnValue = false;
    		} else {
    			return false;
    		}
        }

        else if(e.target.value.length<=0)
        {
           alert("Please Enter Valid Amount");

    		if ( window.event != null ) {
    			window.event.returnValue = false;
    		} else {
    			return false;
    		}
        }
        else
        {
            // Removes commas before adding amount

            var tempDollarAmt = "";
            var amtDollar     =  e.target.value;

            for(var k=0;k<amtDollar.length;k++)
            {
                 var c = amtDollar.charAt(k);
                 if(c != ",")
                 {
                    tempDollarAmt = tempDollarAmt+c;
                 }
            }

            // e.target.value = tempDollarAmt;

            var lastElement =0;

            var length      = parseInt(tempDollarAmt.length);
            var sublength   = parseInt(tempDollarAmt.length-1);
            var minilength  = parseInt(tempDollarAmt.length-2);

            lastElement = tempDollarAmt.substring(sublength,length);
            var secondLastElement = tempDollarAmt.substring(sublength,minilength);
            var restString  = tempDollarAmt.substring(0,sublength);
            var strRest     = tempDollarAmt.substring(0,minilength);

            if((IsCharsInBag(secondLastElement,"MmKk")==true) &&
               (IsCharsInBag(lastElement,"0123456789MmKk,.")==false))
            {
                 alert("Please enter valid amount.");

                e.target.value="";
    			if ( window.event != null ) {
    				window.event.returnValue = false;
    			} else {
    				return false;
    			}
            }
            else if((IsCharsInBag(e.target.value,"MmKk")==true))
            {
                 alert("Please enter valid amount.");
                e.target.value="";
    			if ( window.event != null ) {
    				window.event.returnValue = false;
    			} else {
    				return false;
    			}

            }
            else if((IsCharsInBag(lastElement,"ABCDEFGHIJLNOPQRSTUVWXYZabcdefghijlnopqrstuvwxyz")==true))
            {
                 alert("Please enter valid amount.");
                e.target.value="";
    			if ( window.event != null ) {
    				window.event.returnValue = false;
    			} else {
    				return false;
    			}

            }
            else if((IsCharsInBag(restString,"0123456789MmKk.")==false))
            {
                alert("Please enter valid amount.");
                e.target.value="";
    			if ( window.event != null ) {
    				window.event.returnValue = false;
    			} else {
    				return false;
    			}

            }
            else if(isNaN(strRest))
            {

                alert("Please enter valid amount.");
                e.target.value="";
    			if ( window.event != null ) {
    				window.event.returnValue = false;
    			} else {
    				return false;
    			}

            }
            else
            {
             if(!(IsCharsInBag(e.target.value,"0123456789MmKk.,")))
	        {
	            alert("Please enter valid amount.");
	            e.target.value = '';
	            e.target.focus();
	        }else {
	             var singlerow = rowdata[index];
	            addCommas(e);
	            singlerow[chindex].AMOUNT=e.target.value;
	            rowdata[index] = singlerow;
        	}
    			if((lastElement=='M' || lastElement=='m')&&
    	           (secondLastElement=='M' || secondLastElement=='m' ))
                {
                    var data = parseFloat(tempDollarAmt) * 1000000;
                     e.target.value = data;
                      var singlerow = rowdata[index];
		    addCommas(e);
		    singlerow[chindex].AMOUNT=e.target.value;
	            rowdata[index] = singlerow;

                }
                else
                {
                    if((IsCharsInBag(lastElement,"KkMm")==true))
                    {
                        var data = parseFloat(tempDollarAmt) * 1000;
                        e.target.value = data;
                          var singlerow = rowdata[index];
			    addCommas(e);
			    singlerow[chindex].AMOUNT=e.target.value;
	            rowdata[index] = singlerow;
                    }
                }


            }
        }

    }else{
    	  return true;
}



    }
    handlePendingAllCheck = (event, index, chindex) => {
        var chkVal = document.getElementById("pendingCheckAll" +index).checked;
        var singlerow = rowdata[index];

        if(chkVal){
            this.state.allCheckVal[index] = 'Y';
			singlerow && singlerow.map((item,j) =>{
			item.CHECKED="checked";
			});

        } else{
            this.state.allCheckVal[index] = 'N';
			singlerow && singlerow.map((item,j) =>{
			item.CHECKED="";
			});
        }
        rowdata[index] = singlerow;
        this.setState({ck:1})
    }
    handleAllCheck = (event, index, chindex) => {
        var chkVal = document.getElementById("allchk" +index).checked;
        var singlerow = rowdata[index];


        if(chkVal){
            this.state.allCheckVal[index] = 'Y';
            singlerow && singlerow.map((item,j) =>{
                    item.DISABLED="Y";
             });

        } else{
            this.state.allCheckVal[index] = 'N';
            singlerow && singlerow.map((item,j) =>{
                item.DISABLED="";
            });
        }
        rowdata[index] = singlerow;
          console.log('rowdata >>'+rowdata);
        this.setState({ck:1})
    }

    handleCheck = (event, index, chindex) => {
        var singlerow = rowdata[index];

        if(singlerow[chindex].CHECKED===""){
            singlerow[chindex].CHECKED="checked";
        } else{
            singlerow[chindex].CHECKED="";
        }
        this.state.maindisable[index]  = false;
        singlerow && singlerow.map((item,j) =>{
            if(item.CHECKED === "checked" || item.DISABLED === "Y")
                this.state.maindisable[index]  = false;
        });
        rowdata[index] = singlerow;
        this.setState({ck:1})
    }
    doCancel(){
        bodyFormdata.append("actionFlag","");
        rowdata = [];
        this.props.cancelmethod(bodyFormdata, "CHKPARAM");
    }
    doSave(){
       let invalidFlag=true;
       let amountFlag=false;
      var bodyFormdata = new FormData();
        bodyFormdata.append("actionFlag","SAVE");
        var curSize = 0;
         var checkerParamListSize = 0;

console.log('rowdata :'+JSON.stringify(rowdata));
rowdata && rowdata.map((k,index) =>{
			//if(index == 0){
				if(this.state.allCheckVal[index] === 'Y')
				bodyFormdata.append("allchk"+index.toString(), "Y");
				else
				bodyFormdata.append("allchk"+index.toString(), "N");
		//	}

            k && k.map((item,chindex) =>{
  				 	if(this.state.maindisable[index] ===  false){
					 if ((this.state.allCheckVal[index] === 'Y') || (item.CHECKED === "checked" && (item.DISABLED === 'N' || item.DISABLED === ''))){
						 invalidFlag=false;
					 }
			 		}
                     if(item.CHECKED === "checked"){
                        bodyFormdata.append("eachchk"+index.toString()+chindex.toString(), "Y");
                    	if(item.AMOUNT.length ===0){
                    		amountFlag=true;
                    	}
                    }else
                        bodyFormdata.append("eachchk"+index.toString()+chindex.toString(), "N");

                    bodyFormdata.append("amount"+index.toString()+chindex.toString(), removeCommas(item.AMOUNT));
                    bodyFormdata.append("ccyCode"+index.toString()+chindex.toString(), item.CURRENCYCODE);

			  console.log('bodyFormdata >>'+JSON.stringify(bodyFormdata));
            });
            curSize =k.length;
        });
                    checkerParamListSize =rowdata.length

          if(invalidFlag){
			 alert('Please Check atleat one check box .');
		 }else if(amountFlag){
			 alert('Please Enter Amount.');
		 }else {
			  bodyFormdata.append("ccySize", curSize);
			         bodyFormdata.append("checkerParamListSize", checkerParamListSize);
			         rowdata = [];

      		  this.props.savemethod(bodyFormdata, "CHKPARAM");
		}
    }
 doApprove(){
	let invalidFlag=true;
	let amountFlag=false;
	var bodyFormdata = new FormData();
	bodyFormdata.append("actionFlag","APPROVE");
	var curSize = 0;
	 var checkerParamListSize = 0;

	console.log('rowdata :'+JSON.stringify(rowdata));
	rowdata && rowdata.map((k,index) =>{
			//if(index == 0){
				if(this.state.allCheckVal[index] === 'Y')
				bodyFormdata.append("allchk"+index.toString(), "Y");
				else
				bodyFormdata.append("allchk"+index.toString(), "N");
		//	}

          k &&  k.map((item,chindex) =>{
 				 if((this.state.allCheckVal[index] === 'Y') || (item.CHECKED === "checked" && (item.DISABLED === 'N' || item.DISABLED === ''))){
					 invalidFlag=false;
 				 }
 				 if(this.state.allCheckVal[index] === 'Y' && item.PROCESSID !==  undefined)
 				 bodyFormdata.append("AllProcessId"+index.toString(), item.PROCESSID);

                     if(item.CHECKED === "checked"){
                        bodyFormdata.append("eachchk"+index.toString()+chindex.toString(), "Y");
                        bodyFormdata.append("processId"+index.toString()+chindex.toString(), item.PROCESSID);

                    	if(item.AMOUNT.length ===0){
                    		amountFlag=true;
                    	}
                    }else
                        bodyFormdata.append("eachchk"+index.toString()+chindex.toString(), "N");

                    bodyFormdata.append("amount"+index.toString()+chindex.toString(), removeCommas(item.AMOUNT));
                    bodyFormdata.append("ccyCode"+index.toString()+chindex.toString(), item.CURRENCYCODE);

			  console.log('bodyFormdata >>'+JSON.stringify(bodyFormdata));
            });
            curSize =k.length;
        });
                    checkerParamListSize =rowdata.length

          if(invalidFlag){
			 alert('Please Check atleat one check box .');
		 }else if(amountFlag){
			 alert('Please Enter Amount.');
		 }else {
			 if(confirm("Are you sure, you want to approve the data?")){
			bodyFormdata.append("ccySize", curSize);
			bodyFormdata.append("checkerParamListSize", checkerParamListSize);
			rowdata = [];

			bodyFormdata.append("tabName", "CHKPARAM");
			bodyFormdata.append("trdTabName", "PENDINGAPR");
			bodyFormdata.append("reactJSActionFlag", "GO");

      		 this.props.savemethod(bodyFormdata, "MCMAINT");
		 }
		}
    }

   doReject(){

	let invalidFlag=true;
	let amountFlag=false;
	var bodyFormdata = new FormData();
	bodyFormdata.append("actionFlag","REJECT");
	var curSize = 0;
	 var checkerParamListSize = 0;

	console.log('rowdata :'+JSON.stringify(rowdata));
	rowdata && rowdata.map((k,index) =>{
			//if(index == 0){
				if(this.state.allCheckVal[index] === 'Y')
				bodyFormdata.append("allchk"+index.toString(), "Y");
				else
				bodyFormdata.append("allchk"+index.toString(), "N");
		//	}

           k && k.map((item,chindex) =>{
 				 if((this.state.allCheckVal[index] === 'Y') || (item.CHECKED === "checked" && (item.DISABLED === 'N' || item.DISABLED === ''))){
					 invalidFlag=false;
 				 }
 				 if(this.state.allCheckVal[index] === 'Y' && item.PROCESSID !==  undefined)
 				 bodyFormdata.append("AllProcessId"+index.toString(), item.PROCESSID);

                     if(item.CHECKED === "checked"){
                        bodyFormdata.append("eachchk"+index.toString()+chindex.toString(), "Y");
                         bodyFormdata.append("processId"+index.toString()+chindex.toString(), item.PROCESSID);
                    	if(item.AMOUNT.length ===0){
                    		amountFlag=true;
                    	}
                    }else
                        bodyFormdata.append("eachchk"+index.toString()+chindex.toString(), "N");

                    bodyFormdata.append("amount"+index.toString()+chindex.toString(), removeCommas(item.AMOUNT));
                    bodyFormdata.append("ccyCode"+index.toString()+chindex.toString(), item.CURRENCYCODE);


            });
            curSize =k.length;
        });
                    checkerParamListSize =rowdata.length

          if(invalidFlag){
			 alert('Please Check atleat one check box .');
		 }else if(amountFlag){
			 alert('Please Enter Amount.');
		 }else {
			  if(confirm("Are you sure, you want to reject the data?")){
			  bodyFormdata.append("ccySize", curSize);
			         bodyFormdata.append("checkerParamListSize", checkerParamListSize);
			         rowdata = [];

      		 	bodyFormdata.append("tabName", "CHKPARAM");
				bodyFormdata.append("trdTabName", "PENDINGAPR");
				bodyFormdata.append("reactJSActionFlag", "GO");

      		 this.props.savemethod(bodyFormdata, "MCMAINT");
		 }
		}
    }



    doViewChanges(){
        this.setState({ViewChangesbtn:true})
    }

    doClose = () =>{
           this.setState({ViewChangesbtn:false})
    }
    doOnChange(e){

    }

    render(){

        const {classes, screenName, checkerFlag,loginId, clientFirm, processId, respMsg} = this.props
        const { value } = this.state;


        var innerArry = [];
        let arrObj;
        var k;
        var ind = 0;
        var tempRows = [];

         if(this.props.checkersdata !== undefined && rowdata.length === 0 ){
            for(k in this.props.checkersdata) {
                innerArry = [];
                arrObj =  this.props.checkersdata[k];
                this.state.allCheckVal[ind] = 'N';
                this.state.maindisable[ind]  = false;
                arrObj.map((item,index) =>{
                    innerArry.push(item);
                    if((item.CURRENCYCODE === "ALL" && item.PROCESSID && item.PROCESSID.length > 0 && this.state.value === 0) ){
                        this.state.allCheckVal[ind] = 'Y';
                    }
                    if(item.CHECKED !== undefined && (item.CHECKED === "true" || item.CHECKED === "checked"
                        || item.DISABLED === 'Y' || item.PROCESSID && item.PROCESSID.length > 0)){
                        this.state.maindisable[ind]  = true;
                    }
                    item.CHECKED = "";
                });
                    rowdata.push(innerArry);
                    ind++;
            }

        }
        let noRecordsblock;

       if(this.props.usersdata !== undefined && rowdata.length > 0){
	noRecordsblock = <TableRow key="0"><TableCell colSpan={3}> <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>No records are pending approval</div></TableCell></TableRow>
       }else if(this.props.usersdata === undefined && this.props.checkersdata === undefined && rowdata.length === 0){
	noRecordsblock = <TableRow key="0"><TableCell colSpan={3}> <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>No records are pending approval</div></TableCell></TableRow>
       }else{
	noRecordsblock =<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
       }
        let contentblock;
        var processID = '';
        if(this.props.checkersdata !== undefined && rowdata.length > 0){
        contentblock = rowdata.map((k,index1) =>{
                processID = '';

           let row = k.map((item,chindex) =>{
                tempRows = [];
                if(this.state.value == 0){

                    if(chindex == 0){
                        bodyFormdata.append("oldCheckAll"+index1.toString(), item.OLDCCY);
                        bodyFormdata.append("AllCurrency"+index1.toString(), item.CURRENCYCODE);
                        if(item.CURRENCYCODE === "ALL"){
                            bodyFormdata.append("extraRecord"+index1.toString(), '1');
                        }
                        if(item.CURRENCYCODE === "ALL" && item.PROCESSID && item.PROCESSID.length > 0 ){
                            bodyFormdata.append("AllProcessId"+index1.toString(), item.PROCESSID);
                        }

                            processID = item.PROCESSID;

                            tempRows.push( <TableRow key={index1.toString()} className={classes.tablerow}>
                                    <TableCell colSpan={3} component="td" scope="row">

                                    {(this.state.maindisable[index1] ) ? <Checkbox
                                    className={classes.checkboxstyle ,classes.readonly}
                                    key={"allchk"+index1.toString()}
                                    id={"allchk"+index1.toString()}
                                    onChange={e => this.handleAllCheck(e,index1,chindex)}
                                    disabled
                                    checked={this.state.allCheckVal[index1] === 'Y'? 'checked':''}
                                    />:
                                    <Checkbox
                                    className={classes.checkboxstyle}
                                    key={"allchk"+index1.toString()}
                                    id={"allchk"+index1.toString()}
                                    onChange={e => this.handleAllCheck(e,index1, chindex)}
                                    checked={this.state.allCheckVal[index1] === 'Y'? 'checked':''}
                                    />}
                                     &nbsp;&nbsp;All trades in all currencies with any trade amount </TableCell>
                                </TableRow>);
                    }
                    if(item.CURRENCYCODE != "ALL"){
                        //console.log("item.CURRENCYCODE::2222:"+item.CURRENCYCODE);
                        bodyFormdata.append("oldAmtVal"+index1.toString()+chindex.toString(), item.AMOUNT);

                        tempRows.push( <TableRow key={index1.toString()+chindex.toString()} className={classes.tablerow}>
                            <TableCell component="td" scope="row">

                            {((processID && processID.length > 0) ||
                            (item.PROCESSID && item.PROCESSID.length > 0) || (item.DISABLED === 'Y'))? <Checkbox
                                 key={"eachchk"+index1.toString()+chindex.toString()}
                                 className={classes.checkboxstyle,classes.readonly}
                                 disabled
                                 onChange={e => this.handleCheck(e,index1,chindex)}
                                checked={item.CHECKED}
                            />: <Checkbox
                            key={"eachchk"+index1.toString()+chindex.toString()}
                            className={classes.checkboxstyle}
                            onChange={e => this.handleCheck(e,index1,chindex)}
                           checked={item.CHECKED}
                                 /> }
                            &nbsp;&nbsp;Only trades exceeding </TableCell>
                            <TableCell>
                                    {((processID && processID.length > 0) || (item.PROCESSID && item.PROCESSID.length > 0)  || (item.DISABLED === 'Y'))?
                                    <TextField className={classes.inputStyle,classes.readonly} name={"amount"+index1.toString()+chindex.toString()}
                                     defaultValue={Comma(item.AMOUNT)}
                                    disabled
                                    onBlur={(e)=>this.handleAmountChange(e,index1,chindex,"amount"+index1.toString()+chindex.toString())}
                                    inputProps={{
                                        maxLength: 20,
                                        style: {  width: 120,
                                        height: 20, fontSize: 12}
                                      }}
                                      />:
                                    <TextField className={classes.inputStyle}
                                     name={"amount"+index1.toString()+chindex.toString()}
                                    defaultValue={Comma(item.AMOUNT)}
                                    onBlur={(e)=>this.handleAmountChange(e,index1,chindex,"amount"+index1.toString()+chindex.toString())}
                                    inputProps={{
                                        maxLength: 20,
                                        style: {  width: 120,
                                        fontSize: 12}
                                      }}
                                   />}
                                    </TableCell>
                            <TableCell><TextField className={classes.inputStyle,classes.readonly} name={"ccyCode"+index1.toString()+chindex.toString()}
                                defaultValue={item.CURRENCYCODE}

                                disabled
                                inputProps={{
                                    style: {  width: 120,
                                    fontSize: 12}
                                  }}
                               /></TableCell>
                            </TableRow>);
                        }
                    }else {
                        if(chindex == 0){
                            if(item.CURRENCYCODE === "ALL" && item.PROCESSID && item.PROCESSID.length > 0)
                            {
                                tempRows.push(<TableRow key={(index1+1).toString()} className={classes.tablerow}>
                                <TableCell colSpan={3} component="td" scope="row">
                                    Approval by a <b>Checker {index1+1} </b> is required for :
                                </TableCell>
                                </TableRow> );

                                let checkBB = '';

                            if(item.DISABLED === 'N'){
                                checkBB = <Checkbox
                                className={classes.checkboxstyle}
                                key={"pendingCheckAll"+index1.toString()}
                                id={"pendingCheckAll"+index1.toString()}
                                onChange={e => this.handlePendingAllCheck(e,index1, chindex)}
                                checked={this.state.allCheckVal[index1] === 'Y'? 'checked':''}
                                />
                            }
                                tempRows.push( <TableRow key={index1.toString()} className={classes.tablerow}>
                                <TableCell colSpan={3} component="td" scope="row">
                                 {checkBB}
                                 &nbsp;&nbsp;All trades in all currencies with any trade amount </TableCell>
                                </TableRow>);
                            }else {
                                tempRows.push( <TableRow key={index1.toString()} className={classes.tablerow}>
                                <TableCell colSpan={3} component="td" scope="row">
                                <Checkbox
                                className={classes.checkboxstyle}
                                key={"pendingCheckAll"+index1.toString()}
                                id={"pendingCheckAll"+index1.toString()}
                                onChange={e => this.handlePendingAllCheck(e,index1, chindex)}
                                checked={this.state.allCheckVal[index1] === 'Y'? 'checked':''}
                                />
                                 &nbsp;&nbsp; Approval by a <b>Checker {index1+1} </b> is required for : </TableCell>
                                </TableRow>);
                            }
                        }
                        if(item.CURRENCYCODE != "ALL"){
                            tempRows.push( <TableRow key={index1.toString()+chindex.toString()} className={classes.tablerow}>
                                <TableCell component="td" scope="row">

                                  {   (item.DISABLED === 'N')? <div> <Checkbox
										key={"eachchk"+index1.toString()+chindex.toString()}
										className={classes.checkboxstyle}
										onChange={e => this.handleCheck(e,index1,chindex)}
									   checked={item.CHECKED}
                                 />&nbsp;&nbsp;Only trades exceeding</div>
                                 :<div style={{marginRight:'30px'}}>&nbsp;&nbsp;Only trades exceeding</div>}

                                 </TableCell>
                                <TableCell component="td" scope="row">
                                <TextField className={classes.inputStyle,classes.readonly} name={"amount"+index1.toString()+chindex.toString()}
                                defaultValue={Comma(item.AMOUNT)}

                                disabled
                                variant="filled"
                                inputProps={{
                                    style: {  width: 120,
                                    fontSize: 12}
                                  }}
                                 /></TableCell>
                            <TableCell component="td" scope="row">
                            <TextField className={classes.inputStyle,classes.readonly} name={"ccyCode"+index1.toString()+chindex.toString()}
                                defaultValue={item.CURRENCYCODE}

                                disabled
                                inputProps={{
                                    style: {  width: 120,
                                     fontSize: 12}
                                  }}
                                variant="filled" /></TableCell>
                            </TableRow>);
                        }
                    }
                    return tempRows;

                    });
                    {
                    return <Table key={index1.toString()}>
                             <TableBody>
                             {(this.state.value === 0) &&
                                <TableRow key={index1.toString()} className={classes.tablerow}>
                                    <TableCell colSpan={3} component="td" scope="row">
                                        Approval by a <b>Checker {index1+1} </b> is required for :
                                    </TableCell>
                             </TableRow>  }
                                    {row}
                                </TableBody>
                        </Table>
                    }
            });

        }

	let approveBtn="";
	let rejectBtn="";
	if(checkerFlag === "Y"){
	  approveBtn=<a title="Approve" onClick={(e)=>{this.doApprove();}} className="btn btn-primary btn-xs">Approve</a>
	  rejectBtn=<a title="Reject" onClick={(e)=>{this.doReject();}} className="btn btn-primary btn-xs">Reject</a>
	}
    return (
        <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
        <Paper className={classes.root}>
            <div className="panel">
            <div className="panel-heading clearfix">
                  <h4 className="panel-title pull-left col-md-1">{screenName}</h4>
             </div>
            </div>
            <div className="clearfix"></div>
    	    <div style={{float:'left',padding:'16px'}}>Trade Approval Process :</div>
            <div className={classes.root} style={{float:'left'}}>
            <Tabs
            value={value}
            onChange={this.handleChange}
            classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}
            >
            <Tab
                disableRipple
                classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
                label="View All"
            />
            <Tab
                disableRipple
                classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
                label="Pending Approval"
            />
            </Tabs>
            </div>
            <div className="clearfix"></div>
            {value === 0 &&
                <div>
                   <div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> <Info className={classes.info} style={{float:'left'}}/><h6 style={{marginTop:'10px',float:'left',marginLeft:'30px'}}>{this.state.value=== 0?" Records in grey are Pending Approval":"You will not be able to approve any records for which you performed the Maker action. These records are greyed out and cannot be selected."}</h6></div>
                    <Divider light />
                    {(contentblock != undefined && contentblock.length > 0) ? contentblock :
                    <Table key="0">
                    <TableBody>
                    {noRecordsblock}</TableBody>
                        </Table>}

                <div className="col-md-6" style={{marginTop:'5px'}}>
                  <a title="Save" onClick={(e)=>{this.doSave();}} className="btn btn-primary btn-xs">Save</a>
                  <a title="Cancel" onClick={(e)=>{this.doCancel();}} className="btn btn-primary btn-xs">Cancel</a>
                 <button title ='View Changes' className="btn btn-primary btn-xs" onClick={this.doViewChanges}>View Changes</button>

		{this.state.ViewChangesbtn ?(<UserRolesTradeApprovalProcessViewChanges open={this.state.ViewChangesbtn} clientFirm={clientFirm} processId={processId} doClose={this.doClose} />):''}
               </div>
               {respMsg && respMsg.length > 0 &&
                 <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>{resultConstants[respMsg]}</div>
               }
               </div>
            }
    {value === 1 && <div>
                       <div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> <Info className={classes.info} style={{float:'left'}}/><h6 style={{marginTop:'10px',float:'left',marginLeft:'30px'}}>{this.state.value=== 0?" Records in grey are Pending Approval":"You will not be able to approve any records for which you performed the Maker action. These records are greyed out and cannot be selected."}</h6></div>
                    <Divider light />

                    {(contentblock != undefined && contentblock.length > 0) ? contentblock :
                    <Table key="0">
                    <TableBody>
                    {noRecordsblock}</TableBody>
                        </Table>}
                {(contentblock != undefined && contentblock.length > 0) && <div className="col-md-6">
                   {approveBtn}
		   {rejectBtn}
                  <button style={{marginTop:'5px'}} className="btn btn-primary btn-xs" onClick={this.doViewChanges} title ='View Changes' >View Changes</button>

		        {this.state.ViewChangesbtn ?(<UserRolesTradeApprovalProcessViewChanges open={this.state.ViewChangesbtn} clientFirm={clientFirm} processId={processId} doClose={this.doClose} />):''}

               </div>}
               {respMsg && respMsg.length > 0 &&
                 <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>{resultConstants[respMsg]}</div>
               }
               </div>
    }
       </Paper>
       </MuiThemeProvider>

        );
    }
}

TradeApprovalParams.propTypes = {
    classes: PropTypes.object.isRequired,
  };

  export default withStyles(MuiStyles)(TradeApprovalParams);