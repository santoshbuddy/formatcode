import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { connect } from 'react-redux';
import MUIDataTable from "mui-datatables";
import FromData from 'form-data';
import { AdministrationActions } from '../../actions/administration.actions';
import Paper from '@material-ui/core/Paper';
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import Loading from '../../../common/Loading';
import {muiTableStyles} from '../../../styles/muidatatableCss';

let columns1;
let options;
let data1;
let title;
let loading=true

class UserRolesEmailAddMaintainceViewChanges extends React.Component {
 constructor(props) {
	    super(props);
	    this.state = {
	    open: this.props?this.props.open:false,
   };
}
componentWillMount() {
	var bodyFormData = new FromData();
	bodyFormData.append("clientFirm", JSON.parse(sessionStorage.getItem('clientFirm')));
	bodyFormData.append("processId",this.props.processId);
	bodyFormData.append("fromPage","ViewChanges");
	bodyFormData.append("viewPage","ViewChanges");
	this.props.dispatch(AdministrationActions.fetchUserRolesEmailAddMaintainceViewChangesData(bodyFormData));
}


 handleClose = () => {
    this.setState({ open: false });
     this.props.doClose();
  };

  render(){
        const {clientFirm, processId} = this.props
	console.log("mar05, 2019  3rd popup component processId::",processId+",clientFirm::",clientFirm);

  if(loading)
        return( <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div> );


 return (

      <div>
        <Dialog  fullWidth={true}
          maxWidth={'md'}
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="scroll-dialog-title"> {title}
          </DialogTitle>

          <DialogContent>
           <Paper>
		<MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
		  <MUIDataTable
		  title=''
		  data={data1}
		  columns={columns1}
		  options={options}
		  />
		</MuiThemeProvider>

	 </Paper>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}
function mapStateToProps(state) {
    const { userlinksviewchngsdata } = state;
			let results=[];
			title="";
 			let results1  =  userlinksviewchngsdata.userlinksviewchngsdata;
			//console.log('mapStateToProps : results1'+JSON.stringify( results1));


	        if( results1 !== undefined && results1.toString().trim().length!==0){
	             results1.map((item,index) => {

    		if(item.type === "Title")
                   title = item.name
                 })
		var mainList=results1.find(item =>item.name ==="columns")// === listName)
		columns1 = mainList.COLUMNS;

		mainList=results1.find(item =>item.name ==="DATA")// === listName)
		data1 = mainList.DATA;
		if(data1 !== undefined && data1.toString().trim().length!==0){
		  loading=false
		}
		options = {
			filterType: "dropdown",
			selectableRows: false,
			pagination: false,
			rowsPerPage: 10,
			responsive: "scroll",
			fixedHeader: false,
			filter:false,
			search:false,
			print:false,
			download:false,
			viewColumns:false,
		};
             }


    return { userlinksviewchngsdata ,data1};
}
export default connect(mapStateToProps)(UserRolesEmailAddMaintainceViewChanges)  ;
