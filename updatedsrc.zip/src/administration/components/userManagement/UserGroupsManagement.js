
import React from 'react';
import { Route } from 'react-router-dom';
import { NavBar } from '../../../navbar/components/navbar';
 import ReactTable, { ReactTableDefaults } from "react-table";
import '../../../../node_modules/react-table/react-table.css';
import '../../../user/css/App.css';
import FormData from 'form-data';
import MUIDataTable from "mui-datatables";
 import { connect } from 'react-redux';
import { AdministrationActions } from '../../actions/administration.actions';


import PropTypes from 'prop-types';
import {createMuiTheme, withStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import PriorityIcon from "@material-ui/icons/PriorityHigh";
import IconButton from "@material-ui/core/IconButton";
import GroupDisplay from './GroupDisplay';
import GroupUserLinksPerm from './GroupUserLinksPerm';
import UserNameApproval from './UserNameApproval';

import Button from '@material-ui/core/Button';
import Info from "@material-ui/icons/Info";

let msg='';
const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  button: {
    	    margin: theme.spacing.unit,
    	     fontSize: 11,
	  },
  tabsRoot: {
    borderBottom: '1px solid #e8e8e8',
  },
  tabsIndicator: {
    backgroundColor: '#1890ff',
  },
  tabRoot: {
    textTransform: 'initial',
    minWidth: 72,
    fontWeight: theme.typography.fontWeightRegular,
    marginRight: theme.spacing.unit * 4,
    // fontFamily: [
    //   '-apple-system',
    //   'BlinkMacSystemFont',
    //   '"Segoe UI"',
    //   'Roboto',
    //   '"Helvetica Neue"',
    //   'Arial',
    //   'sans-serif',
    //   '"Apple Color Emoji"',
    //   '"Segoe UI Emoji"',
    //   '"Segoe UI Symbol"',
    // ].join(','),
    '&:hover': {
      color: '#40a9ff',
      opacity: 1,
    },
    '&$tabSelected': {
      color: '#1890ff',
      fontWeight: theme.typography.fontWeightMedium,
    },
    '&:focus': {
      color: '#40a9ff',
    },
  },
  tabSelected: {},
  typography: {
    padding: theme.spacing.unit * 3,
  },
   root: {
      flexGrow: 1,
    },
    paper: {
      padding: theme.spacing.unit * 2,
      textAlign: 'center',
      color: theme.palette.text.secondary,
  },
    priorityIcon: {
  	      color: "#000",
  	},
  	iconButton: {
	    marginRight: "24px",
	    top: "50%",
	    display: "inline-block",
	    position: "relative",
	    transform: "translateY(-50%)",
  },
});
 class UserGroupsManagement extends React.Component {
	   getMuiTheme = () => createMuiTheme({
	 	 		  typography: {
	 	 							useNextVariants: true,
	 	 	 			 },
	 	 	    	overrides: {
	 	 			  MuiButtonBase: {
	 	 					  	        root: {
	 	 					   	           padding: '0px',
	 	 					   	        }
	 	 	      },
	 	 	    }
	 	   })

 constructor() {
    super();

    this.state = {
    value: 0,
    userdata:[],
    userLinksPermDet:null,
    user:null,
    group:null,
    groups:null,
	}
	this.showGroupDetails=this.showGroupDetails.bind(this)
	this.doTabChange=this.doTabChange.bind(this)
	this.doApproveReject=this.doApproveReject.bind(this)
	this.doCreate=this.doCreate.bind(this);
	this.getGroupsData=this.getGroupsData.bind(this);
	this.addmarked =this.addmarked.bind(this);
	this.onClickUser=this.onClickUser.bind(this);
	this.doUserApprove=this.doUserApprove.bind(this);
	this.doUserReject=this.doUserReject.bind(this)

   }
  showGroupDetails(linkDetails){
	  		msg='';
		// console.log(' UserGroupsManagement showGroupDetails :'+JSON.stringify(linkDetails));
		 this.setState({userLinksPermDet:linkDetails,user:null,group:null,groups:null,});
  }
    addmarked(userDet,groupDet){
			msg='';
  		  console.log(' UserGroupsManagement userDet :'+JSON.stringify(userDet));
  		   console.log(' UserGroupsManagement groupDet :'+JSON.stringify(groupDet));


	        var bodyFormdata = new FormData();
				bodyFormdata.append("clientFirm", JSON.parse(sessionStorage.getItem('clientFirm')));
				bodyFormdata.append("hidGroupId", groupDet.LINKGROUPID);
				bodyFormdata.append("loginId",userDet.LOGINID);
				bodyFormdata.append("sourceId1", userDet.LINKGROUPID === "" ?'NOTAGROUP': userDet.LINKGROUPID);
				bodyFormdata.append("actionFlag", 'ADDMARKED');
				bodyFormdata.append("logedUserCompany",this.props.params.selectedCompanyId);

 	    	 	this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));
  }

  onClickUser(user,group,groups){
					msg='';
 	    		  this.setState({userLinksPermDet:null,user:user,group:group,groups:groups,});
	}

   doCreate(){
	   		msg='';
	   			const linkDetails ={ size:this.props.finalData.length,
	   						addFlag:"SHOW",
	   						grpName:"",
	   						NORECFLAG:"",
	   						DESCR:"",
	   						selLnkGrpId:"NEW",
	   						LINKGROUPID:"NEW",
	   						COMPANYID:JSON.parse(sessionStorage.getItem('clientFirm')),
	   						processId:""}
	 		this.setState({userLinksPermDet:linkDetails});
  }

  handleChange = (event, value) => {
	  	msg='';
    this.setState({ value:value,userLinksPermDet:null,user:null,group:null,groups:null, });
    if(value === 0){
		 this.doTabChange("VIEWALL");
	}else if(value === 1){
		 this.doTabChange("PENDINGAPR");
	}
  };

 componentDidMount() {
          this.getGroupsData()
   }

    getGroupsData(){
	var bodyFormdata = new FormData();
    this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));
   }

   doTabChange(tabName){
	   	msg='';
		this.setState({ userLinksPermDet:null, });
	   	var bodyFormdata = new FormData();
			bodyFormdata.append("clientFirm", JSON.parse(sessionStorage.getItem('clientFirm')));
			bodyFormdata.append("selLnkGrpId", "");
			bodyFormdata.append("grpMsg", "");
			bodyFormdata.append("tabName", tabName);
 	    	this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));

    }
     doApproveReject(tabName,savemsg){
			 msg=savemsg;
			this.setState({ userLinksPermDet:null, });
		   	var bodyFormdata = new FormData();
				bodyFormdata.append("clientFirm", JSON.parse(sessionStorage.getItem('clientFirm')));
				bodyFormdata.append("selLnkGrpId", "");
				bodyFormdata.append("grpMsg", "");
				bodyFormdata.append("tabName", tabName);
	 	    	this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));

    }
    doUserApprove(processId,linkGroupId){
		this.setState({ user:null, });
 			var bodyFormdata = new FormData();
				bodyFormdata.append("processId", '');
				bodyFormdata.append("userFlag", "SHOW");
				bodyFormdata.append("userProcessId", processId);
				bodyFormdata.append("selLinkGrpId", linkGroupId);
 				bodyFormdata.append("userActionFlag", 'APPROVE');
 					bodyFormdata.append("tabName", 'PENDINGAPR');
	 	    	this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));
	 }

	doUserReject(processId){
		this.setState({ user:null, });
	 			var bodyFormdata = new FormData();
				bodyFormdata.append("processId", '');
				bodyFormdata.append("userFlag", "SHOW");
				bodyFormdata.append("userProcessId", processId);
				bodyFormdata.append("userActionFlag", 'REJECT');
				bodyFormdata.append("tabName", 'PENDINGAPR');
	 	    	this.props.dispatch(AdministrationActions.fetchUserData(bodyFormdata));
	 }

  render() {
    const { classes ,userdata,finalData,params} = this.props;
    const { value } = this.state;



		//   console.log('finalData :'+JSON.stringify(finalData));

 return (
 <div>
    	<NavBar/>
    	<div className="panel panel-primary clearfix" style={{clear:'both'}}>
		<div className="panel-heading">
			<h4 className="panel-title">User Groups Management</h4>
		</div>
		 <div className="clearfix"></div>
		 	 <div className={classes.root} style={{padding: '6px'}}>
    		<h4>User Groups</h4>

    	   <div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> <Info className={classes.info} style={{float:'left'}}/><h6 style={{marginTop:'7px',float:'left'}}>{this.state.value=== 0?" Records in grey are Pending Approval":"You will not be able to approve any records for which you performed the Maker action. These records are greyed out and cannot be selected."}</h6></div>
    	   <div className="clearfix"></div>
    	   <div className="clearfix"></div>
		 <div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> {this.state.value === 0?(<Info className={classes.info} style={{marginTop:'25px',float:'left'}}/>):""} <h6 style={{marginTop:'32px',float:'left'}}>{this.state.value === 0?" Click on the group name to change entitlements for that group.":""}</h6></div>
		 <div className="clearfix"></div>
		 <div style={{marginRight:'10px',float:'left',paddingLeft:'26px'}}> <h6> {this.state.value === 0?"Drag and drop user names to move the user from one group to another ":""}</h6></div>
		{(msg && msg !== "") ?(<div style={{fontSize: 12, color: '#c30000' ,textAlign: 'center'}}> <b>{msg}</b></div>):''}

      <Grid container spacing={8} direction="row" item xs={12} >
     	<Grid item xs={9}>
    	<Paper>
       	<div className={classes.root} >
        <Tabs style={{ borderBottom: '1px solid transparent'}}
          value={value}
          onChange={this.handleChange}
          classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}
			>
			  <Tab
				disableRipple
				classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
				label="View All"
			  />
			  <Tab
				disableRipple
				classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
				label="Pending Approval"
			  />
        </Tabs>
			{value === 0 &&
				<Grid container spacing={8} direction="row" justify="flex-start" alignItems="flex-start" item xs={12}>
				  <Grid item xs={3}>
					<button   color="primary" className="btn btn-primary btn-xs" onClick={this.doCreate} >
					Create New Group
					</button>
				  <GroupDisplay tabName="VIEWALL"  showGroupDetails={this.showGroupDetails} addmarked={this.addmarked}  linksdata={finalData} params={params}/>
					</Grid>
					<Grid item xs={9}><GroupUserLinksPerm tabName="VIEWALL" doTabChange ={this.doTabChange} params={params} userLinksPermDet={this.state.userLinksPermDet}/>
				 </Grid>
				 </Grid>
			 }
			{value === 1 &&
			<Grid container spacing={8} direction="row" justify="flex-start" alignItems="flex-start" item xs={12}>
							  <Grid item xs={3}>
						 		  <GroupDisplay tabName="PENDINGAPR"  onClickUser={this.onClickUser} showGroupDetails={this.showGroupDetails} addmarked={this.addmarked}  linksdata={finalData} params={params}/>
								</Grid>

								<Grid item xs={9}>
								{((this.state.userLinksPermDet)?
								<GroupUserLinksPerm tabName="PENDINGAPR" doApproveReject ={this.doApproveReject}   params={params} userLinksPermDet={this.state.userLinksPermDet}/>
								:"")}
								{(this.state.user?<UserNameApproval
								doUserApprove={this.doUserApprove} doUserReject={this.doUserReject} tabName={this.state.value === 0?"VIEWALL":"PENDINGAPR"}
								userDetails={this.state.user} 	groupDetails={this.state.group} groups={this.state.groups}/>
								:"")}
								{((this.state.userLinksPermDet === null
									&& this.state.user === null &&
									params && params.userMsg !== undefined && params.userMsg !== '')? <div style={{fontSize: 12, color: '#c30000' ,textAlign: 'center'}}> <b>{params.userMsg}</b></div>:'')}


							</Grid>




				 </Grid>
			}
       </div>
       </Paper>
        </Grid>
        <Grid item xs={3}>

	             <Typography variant="h5" component="h3">
	                What are user groups for?
	             </Typography>
	             <Typography component="p">
	              User Groups can be used to apply the same set of
				  permissions to an entire group of users at once.
					  </Typography>
					  <Typography component="p">
				 For example, you can create a group for all the
				 checkers and give them access to the same
				pages.
				 </Typography>
				  <Typography component="p">
				  If you move a user into a new group, that user's
				  entitlements will automatically be updated with the
				  access rights of the new group.
				  <Route render={({ history}) => (
				  	     		<a   onClick={() => { history.push('/administration/USERPROP') }}>	Manage User Permissions		</a>
	     		)} />

	             </Typography>

        </Grid>
       </Grid>
       </div>
       </div>
        </div>
    );
  }
}


function mapStateToProps(state) {
 	const { userdata } = state;
 	let finalData=[];
		let params= null;
	if(userdata && userdata.userdata){
		const results1=userdata.userdata;
		let results = [];
		let innerList = [];

		if( results1)
			results1.map((item,index) => {
			if(item.name === "grpVec")
			results = item.values

			if(item.name === "innerList")
			innerList = item.values

				if(item.name === "Params" && item.values.length>0)
				params = item.values[0]
		})
		// console.log('results :'+JSON.stringify(results));

		//  console.log('innerList :'+JSON.stringify(innerList));
			if(results !== undefined ){var   row=0;
			results.map((group,pndex) => {
			finalData.push({ isExpand: true,id:pndex, name:  group.DESCR ,lnkGroupDet:group, innerList:innerList[0][pndex]});
		});
	}
 }
    return { userdata,finalData,params};
}

 export default connect(mapStateToProps)((withStyles(styles))(UserGroupsManagement));