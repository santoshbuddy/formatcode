import * as React from 'react';
import Paper from '@material-ui/core/Paper';
import {
  SelectionState,
  IntegratedSelection,
  TreeDataState,
  CustomTreeData,
} from '@devexpress/dx-react-grid';
import {
  Grid,
  Table,
  TableHeaderRow,
  TableTreeColumn,
} from '@devexpress/dx-react-grid-material-ui';
import { connect } from 'react-redux';
import { AdministrationActions } from '../../actions/administration.actions';
import Button from '@material-ui/core/Button';
import { createMuiTheme, withStyles,MuiThemeProvider} from '@material-ui/core/styles';
import { muiTableStyles } from '../../../styles/muidatatableCss';
import RFPSnackbars from '../../../messages/RFPSnackbars';
import Typography from '@material-ui/core/Typography';
import LinearProgress from '@material-ui/core/LinearProgress';
import UserViewChanges from './UserViewChanges';
import Checkbox from '@material-ui/core/Checkbox';

 const styles = theme => ({

  textField: {
      marginLeft: theme.spacing.unit,
      marginRight: theme.spacing.unit,
      width: 200,
  },
   formControl: {
  		    marginTop: 0,
  		    minWidth: 120,
  		     fontSize: 11,
  		  },
  		  formControlLabel: {
  		    marginTop: 0,
  		     fontSize: 11,
    		},
  	  button: {
  	    margin: theme.spacing.unit,
  	     fontSize: 11,
	  },
	  typography: {
	        useNextVariants: false,
    },
    paper: {
	      padding: theme.spacing.unit * 2,
	      textAlign: 'center',
	      color: theme.palette.text.secondary,
  },
	  MuiPaperRounded: {
	     borderRadius: 0,
	},
});


const getChildRows = (row, rootRows) => {
  const childRows = rootRows.filter(r => r.parentId === (row ? row.id : null));
  return childRows.length ? childRows : null;
};

 class UserLinksPerm extends React.PureComponent {

	  getMuiTheme = () => createMuiTheme({
	 		  typography: {
	 							useNextVariants: true,
	 	 			 },
	 	    overrides: {
	 			 MuiFormControl: {
	 					  	        marginNormal: {
	 					   	           marginTop: '0px',
	 					   	            marginBottom: '0px',
	 					   	        }
	 	      }, MuiIconButton: {
	 					  	        root: {
	 					   	           padding: '2px',
	 					   	        }
	 	      }, MuiTableCell: {
	 					  	        root: {
	 					   	           padding: '0px',
	 					   	        }
	 	      }, MuiPrivateSwitchBase: {
	 					  	        root: {
	 					   	           padding: '0px',
	 					   	           minHeight:'100%'
	 					   	        }
	 	      },MuiTableRow:{root: {
				  height:'25px',}
			  },MuiSvgIcon:{root: {
				  height:'0.75em', }
			  },
	 	      MUIDataTableBodyCell: {
	 	        root: {
	  	           whiteSpace: 'nowrap',
	  	           padding:'0px 56px 0px 24px'
	  	        }
	 	      },
	 	      MUIDataTableBodyRow: {
	 		  	        root: {
	 		   	           height: '20px',
	 		   	        }
	 	      },
	 	    }
	   })


  constructor(props) {
    super(props);

    this.state = {
		completed: 0,
    buffer: 10,
	  userLinksPermDet: this.props.userLinksPermDet,
	  selection: [],
	   selectedLinks: [],
      columns: [
        { name: 'name', title: 'Select All' , getCellValue: row =>
        (this.props.params != null && this.props.params.disabled === 'disabled'?
        (<div> <Checkbox
			checked={row.CHKFLAG ==='CHECKED'?true:false} value={row.id}
           disabled={((this.props.params &&  this.props.params.disabled === 'disabled' )
          	?true:false)} />
          <span>{row.name}</span></div>):row.name)	 },
      ],
      tableColumnExtensions: [
        { columnName: 'name', width: 300 },
      ],
      defaultExpandedRowIds: [0],
      data:  [],
       viewChangesbtn:false,
    };


    this.changeSelection = selection => this.setState({ selection });

    this.doViewChanges=this.doViewChanges.bind(this);
    this.doSave=this.doSave.bind(this);
	this.doApprove=this.doApprove.bind(this);
	this.doReject=this.doReject.bind(this);
	this.doDelApprove=this.doDelApprove.bind(this);
	this.doDelReject=this.doDelReject.bind(this);
    this.doCancel=this.doCancel.bind(this);
    this.doDelete=this.doDelete.bind(this);
        this.doClose=this.doClose.bind(this);
     }


  componentWillMount() {
 this.timer = setInterval(this.progress, 500);
	  }

    componentDidMount() {

	  }

	  componentWillUnmount() {
	    clearInterval(this.timer);
	  }

	  progress = () => {
	    const { completed } = this.state;
	    if (completed > 100) {
	      this.setState({ completed: 0, buffer: 10 });
	    } else {
	      const diff = Math.random() * 10;
	      const diff2 = Math.random() * 10;
	      this.setState({ completed: completed + diff, buffer: completed + diff + diff2 });
	    }
  };
doSave(){
			if(confirm("Are you sure, you want to save the data?")){
	       		var bodyFormdata = new FormData();
		  			bodyFormdata.append("userId", this.props.userLinksPermDet.LOGINID);
		  			bodyFormdata.append("userName", this.props.userLinksPermDet.LOGINNAME);
		  			bodyFormdata.append("groupId", this.props.userLinksPermDet.ENCLINKGROUPID);
		  			bodyFormdata.append("processId", "");
		  			bodyFormdata.append("actionFlag", "SAVE");
		  			bodyFormdata.append("showData", "SHOWDATA");
		  			if(this.props.params){
		  			bodyFormdata.append("pendingFlag", this.props.params.pendingFlag);
		  			bodyFormdata.append("processId", this.props.params.processId);
		  			//console.log("this.props.params.processId<>>>>>"+this.props.params.processId);
				}

		  			bodyFormdata.append("permVectCnt", this.props.selectedLinks.length);

		  			this.props.selectedLinks && this.props.selectedLinks.map((link,index)=>{
						 if(this.state.selection.includes(link.id)){
							 bodyFormdata.append("grpPermChk"+index, "CHECKED");
						 }else {
							  bodyFormdata.append("grpPermChk"+index, "");
						 }
						bodyFormdata.append("operVal"+index, link.OPERVAL);
						bodyFormdata.append("linkId"+index, link.ENLINKID);

					});

		   		   this.props.dispatch(AdministrationActions.fetchUserLinksPermData(bodyFormdata));
			   }

}
doApprove(){
			if(confirm("Are you sure, you want to approve the data?")){
	       		var bodyFormdata = new FormData();
		  			bodyFormdata.append("userId", this.props.userLinksPermDet.LOGINID);
		  			bodyFormdata.append("userName", this.props.userLinksPermDet.LOGINNAME);
		  			bodyFormdata.append("groupId", this.props.userLinksPermDet.ENCLINKGROUPID);
 		  			bodyFormdata.append("actionFlag", "APPROVE");
		  			bodyFormdata.append("showData", "SHOWDATA");
		  			bodyFormdata.append("tabName", this.props.userLinksPermDet.tabName);
		  			if(this.props.params){
		  			bodyFormdata.append("pendingFlag", this.props.params.pendingFlag);
		  			bodyFormdata.append("processId", this.props.params.processId);
		  			//console.log("this.props.params.processId<>>>>>"+this.props.params.processId);
					}else {
					 bodyFormdata.append("processId", "");
 					}

		  			bodyFormdata.append("permVectCnt", this.props.selectedLinks.length);

		  			this.props.selectedLinks && this.props.selectedLinks.map((link,index)=>{
						 if(this.state.selection.includes(link.id)){
							 bodyFormdata.append("grpPermChk"+index, "CHECKED");
						 }else {
							  bodyFormdata.append("grpPermChk"+index, "");
						 }
						bodyFormdata.append("operVal"+index, link.OPERVAL);
						bodyFormdata.append("linkId"+index, link.ENLINKID);

					});

		   		   this.props.dispatch(AdministrationActions.fetchUserLinksPermData(bodyFormdata));
}
}
doReject(){
		if(confirm("Are you sure, you want to reject the data?")){
	       		var bodyFormdata = new FormData();
		  			bodyFormdata.append("userId", this.props.userLinksPermDet.LOGINID);
		  			bodyFormdata.append("userName", this.props.userLinksPermDet.LOGINNAME);
		  			bodyFormdata.append("groupId", this.props.userLinksPermDet.ENCLINKGROUPID);
 		  			bodyFormdata.append("actionFlag", "REJECT");
		  			bodyFormdata.append("showData", "SHOWDATA");
		  			bodyFormdata.append("tabName", this.props.userLinksPermDet.tabName);
		  			if(this.props.params){
		  			bodyFormdata.append("pendingFlag", this.props.params.pendingFlag);
		  			bodyFormdata.append("processId", this.props.params.processId);
		  			//console.log("this.props.params.processId<>>>>>"+this.props.params.processId);
					}else {
					 bodyFormdata.append("processId", "");
 					}

		  			bodyFormdata.append("permVectCnt", this.props.selectedLinks.length);

		  			this.props.selectedLinks && this.props.selectedLinks.map((link,index)=>{
						 if(this.state.selection.includes(link.id)){
							 bodyFormdata.append("grpPermChk"+index, "CHECKED");
						 }else {
							  bodyFormdata.append("grpPermChk"+index, "");
						 }
						bodyFormdata.append("operVal"+index, link.OPERVAL);
						bodyFormdata.append("linkId"+index, link.ENLINKID);

					});

		   		   this.props.dispatch(AdministrationActions.fetchUserLinksPermData(bodyFormdata));
	}
}
doDelApprove(){
	if(confirm("Are you sure, you want to approve the data?")){
	       		var bodyFormdata = new FormData();
		  			bodyFormdata.append("userId", this.props.userLinksPermDet.LOGINID);
		  			bodyFormdata.append("userName", this.props.userLinksPermDet.LOGINNAME);
		  			bodyFormdata.append("groupId", this.props.userLinksPermDet.ENCLINKGROUPID);
		  			bodyFormdata.append("actionFlag", "DELAPPROVE");
		  			bodyFormdata.append("showData", "SHOWDATA");
		  			bodyFormdata.append("tabName", this.props.userLinksPermDet.tabName);
		  			if(this.props.params){
		  			bodyFormdata.append("pendingFlag", this.props.params.pendingFlag);
		  			bodyFormdata.append("processId", this.props.params.processId);
		  			//console.log("this.props.params.processId<>>>>>"+this.props.params.processId);
				}else {
					 bodyFormdata.append("processId", "");

				}

		  			bodyFormdata.append("permVectCnt", this.props.selectedLinks.length);

		  			this.props.selectedLinks && this.props.selectedLinks.map((link,index)=>{
						 if(this.state.selection.includes(link.id)){
							 bodyFormdata.append("grpPermChk"+index, "CHECKED");
						 }else {
							  bodyFormdata.append("grpPermChk"+index, "");
						 }
						bodyFormdata.append("operVal"+index, link.OPERVAL);
						bodyFormdata.append("linkId"+index, link.ENLINKID);

					});

		   		   this.props.dispatch(AdministrationActions.fetchUserLinksPermData(bodyFormdata));
}
}
doDelReject(){
	if(confirm("Are you sure, you want to reject the data?")){
	       		var bodyFormdata = new FormData();
		  			bodyFormdata.append("userId", this.props.userLinksPermDet.LOGINID);
		  			bodyFormdata.append("userName", this.props.userLinksPermDet.LOGINNAME);
		  			bodyFormdata.append("groupId", this.props.userLinksPermDet.ENCLINKGROUPID);
		  			bodyFormdata.append("processId", "");
		  			bodyFormdata.append("actionFlag", "DELREJECT");
		  			bodyFormdata.append("showData", "SHOWDATA");
		  			bodyFormdata.append("tabName", this.props.userLinksPermDet.tabName);
		  			if(this.props.params){
		  			bodyFormdata.append("pendingFlag", this.props.params.pendingFlag);
		  			bodyFormdata.append("processId", this.props.params.processId);
		  			//console.log("this.props.params.processId<>>>>>"+this.props.params.processId);
					}else {
					 bodyFormdata.append("processId", "");
 					}

		  			bodyFormdata.append("permVectCnt", this.props.selectedLinks.length);

		  			this.props.selectedLinks && this.props.selectedLinks.map((link,index)=>{
						 if(this.state.selection.includes(link.id)){
							 bodyFormdata.append("grpPermChk"+index, "CHECKED");
						 }else {
							  bodyFormdata.append("grpPermChk"+index, "");
						 }
						bodyFormdata.append("operVal"+index, link.OPERVAL);
						bodyFormdata.append("linkId"+index, link.ENLINKID);

					});

		   		   this.props.dispatch(AdministrationActions.fetchUserLinksPermData(bodyFormdata));
}
}
doCancel(){
				var bodyFormdata = new FormData();
	  			bodyFormdata.append("userId", this.props.userLinksPermDet.LOGINID);
	  			bodyFormdata.append("userName", this.props.userLinksPermDet.LOGINNAME);
	  			bodyFormdata.append("groupId", this.props.userLinksPermDet.ENCLINKGROUPID);
	  			bodyFormdata.append("showData", "SHOWDATA");
	  			if(this.props.params)
	  			bodyFormdata.append("pendingFlag", this.props.params.pendingFlag);
	   		    this.props.dispatch(AdministrationActions.fetchUserLinksPermData(bodyFormdata));
}
doDelete(){
	var pendFlag="";
	if(this.props.params)
	  	pendFlag=this.props.params.processId ;
  		if(pendFlag.length > 0){
 			alert("You Cannot Delete User as User Data is Maker Checker Process");
 		}else{
 		/* document.getElementById('testFRame').src = "/fotrd/ectrading/userDeletPopUp.jsp";
		grey_mask() */
		if(confirm("Once the user profile is deleted, the system will revoke all access rights for the selected user.  Are you sure, you want to delete the user profile?")){
			var bodyFormdata = new FormData();
				  			bodyFormdata.append("userId", this.props.userLinksPermDet.LOGINID);
				  			bodyFormdata.append("userName", this.props.userLinksPermDet.LOGINNAME);
				  			bodyFormdata.append("groupId", this.props.userLinksPermDet.ENCLINKGROUPID);
 				  			bodyFormdata.append("actionFlag", "DELETE");
				  			bodyFormdata.append("showData", "SHOWDATA");
 							bodyFormdata.append("tabName", this.props.userLinksPermDet.tabName);

	   		    		 this.props.dispatch(AdministrationActions.fetchUserLinksPermData(bodyFormdata));
		}
	}
}
doViewChanges(){
 this.setState({ viewChangesbtn:true});
}
doClose(){
this.setState({ viewChangesbtn:false});
}

componentWillReceiveProps() {
   	this.setState({selection:[]});
}
componentDidUpdate(prevProps) {
  // Typical usage (don't forget to compare props):
//  console.log('prevProps userLinksPermDet :'+JSON.stringify(prevProps.userLinksPermDet));
//  console.log('this.userLinksPermDet :'+JSON.stringify(this.props.userLinksPermDet));
  //console.log('this.state.selection :'+JSON.stringify(this.state.selection));

  if (this.props.userLinksPermDet &&  (prevProps.userLinksPermDet == null)  || (prevProps.userLinksPermDet && (this.props.userLinksPermDet.tabName !== prevProps.userLinksPermDet.tabName || this.props.userLinksPermDet.LOGINID !== prevProps.userLinksPermDet.LOGINID))) {

	       		var bodyFormdata = new FormData();
	  			bodyFormdata.append("userId", this.props.userLinksPermDet.LOGINID);
	  			bodyFormdata.append("userName", this.props.userLinksPermDet.LOGINNAME);
	  			bodyFormdata.append("groupId", this.props.userLinksPermDet.ENCLINKGROUPID);
	  			bodyFormdata.append("processId", "");
	  			bodyFormdata.append("actionFlag", "");
	  			bodyFormdata.append("showData", "SHOWDATA");
	  			bodyFormdata.append("tabName", this.props.userLinksPermDet.tabName);

	  			if(this.props.params){
	  			bodyFormdata.append("pendingFlag", this.props.params.pendingFlag);
 	  			bodyFormdata.append("notGrpFlag", this.props.params.notGrpFlag);
				}
	   		    this.props.dispatch(AdministrationActions.fetchUserLinksPermData(bodyFormdata));

  }
}
  render() {

	   const { classes } = this.props;

    const {completed, buffer ,
      data, columns, rows,selection,tableColumnExtensions, defaultExpandedRowIds,msg,msgType,
    } = this.state;
	let {savebtn,cancelbtn,deletbtn,approvebtn,rejectbtn,delapprovebtn,delrejectbtn} =this.props;

	const { userlinkspermdata ,userLinksPermDet,menuLinkData,prpsselection,selectedLinks,expandIds,params} = this.props;
	if(userLinksPermDet && userLinksPermDet.LOGINID){
	//console.log('userlinkspermdata :'+JSON.stringify(userlinkspermdata));
	//console.log('userLinksPermDet UserLinksPerms :'+JSON.stringify(userLinksPermDet));

	//  console.log('params :'+JSON.stringify(params));
	if( params &&  params.tabName === "PENDINGAPR"){
			savebtn =false;
			deletbtn =false;
			cancelbtn= false;

	}


			if(menuLinkData == null || (menuLinkData && menuLinkData.length ==0)){
				return ( 	<LinearProgress variant="buffer" value={completed} valueBuffer={buffer} />);

			}else {
			clearInterval(this.timer);
			return (
				<div>
				 {(this.props.msg && this.props.msg !== "") ?( <div style={{fontSize: 12, color: '#c30000',textAlign: 'center'}}>
								 				 			   					<b>{this.props.msg}</b>
				 </div>):''}
			  <Paper>
 				 <MuiThemeProvider theme={muiTableStyles.getMuiThemeNoToolBar()}>
				<Grid
				  rows={menuLinkData}
				  columns={columns}
				>
				  <SelectionState
							   selection={selection.length===0?prpsselection:selection}
							   onSelectionChange={this.changeSelection}
					 />
				  <TreeDataState
					defaultExpandedRowIds={defaultExpandedRowIds}
				//	expandedRowIds={expandIds}
				  />
				  <CustomTreeData
					getChildRows={getChildRows}
				  />
				  <IntegratedSelection  />
				  <Table
					columnExtensions={tableColumnExtensions}
				  />
				  <TableHeaderRow />
				  {  (this.props.params != null && this.props.params.disabled === 'disabled')?
				 				  <TableTreeColumn
				 					for="name"
 				  				  />: <TableTreeColumn
				 					for="name"
				 					showSelectionControls
				 					showSelectAll
  				  /> }
				</Grid>

				 <div style={{textAlign:'center'}}>
				 		{ savebtn?(<button color="primary" className="btn btn-primary btn-xs" onClick={this.doSave} >
					Save
					</button>) :"" }
						{ approvebtn?(<button color="primary" className="btn btn-primary btn-xs" onClick={this.doApprove} >
										Approve
					</button>) :"" }
						{ rejectbtn?(<button color="primary" className="btn btn-primary btn-xs" onClick={this.doReject} >
										Reject
					</button>) :"" }
						{ delapprovebtn?(<button color="primary" className="btn btn-primary btn-xs" onClick={this.doDelApprove} >
										Approve
					</button>) :"" }
						{ delrejectbtn?(<button color="primary" className="btn btn-primary btn-xs" onClick={this.doDelReject} >
										Reject
					</button>) :"" }

								{cancelbtn?(<button    color="primary" className="btn btn-primary btn-xs" onClick={this.doCancel} >
										Cancel
						</button>):""}
							{deletbtn ?(<button  color="primary" className="btn btn-primary btn-xs" onClick={this.doDelete} >
							Delete
							</button>):""}
										<button  color="primary" className="btn btn-primary btn-xs" onClick={this.doViewChanges} >
										View Changes
						</button>
								{this.state.viewChangesbtn ?(<UserViewChanges open={this.state.viewChangesbtn} doClose={this.doClose} selectedCompanyId={this.props.params?this.props.params.logedUserCompany:''} 	selLoginId={this.props.params?this.props.params.userId:''} />):''}

						</div>
				</MuiThemeProvider>

			  </Paper>
			  </div>
			);
		}

		}else{
		return(<Typography gutterBottom noWrap>
			          {`
			          Select a user to view, change or delete that user's access rights.
			        `}
        </Typography>)

		}
  }
}

function mapStateToProps(state) {
 	const { userlinkspermdata} = state;

 	let menuLinkData=[];
	let selectedLinks=[];
	let prpsselection=[];
		let expandIds=[];

	let params = null;
	let msg="";
	let msgType="success";
	let savebtn;
	let deletbtn;
	let cancelbtn;
	let approvebtn;
	let rejectbtn;
	let delapprovebtn;
	let delrejectbtn;



	if(userlinkspermdata && userlinkspermdata.userlinkspermdata){
		const results1=userlinkspermdata.userlinkspermdata;
		let results = [];
		if( results1)
			results1.map((item,index) => {
			if(item.name === "dispPermList")
			results = item.values

			if(item.name === "Params" && item.values.length>0)
			params = item.values[0]


			if(item.type === "Message"){
			msg = item.name;
			msgType =item.label;
			}
		})


	// console.log('results :'+JSON.stringify(results));
		var   row=0;
	 		results && results.map((link,pndex) => {
				if(link.CHKFLAG==='CHECKED')
				 prpsselection.push(pndex)

				 if(link.LVL !== '3')
				expandIds.push(pndex);

			 selectedLinks.push({id:pndex,LINKID:link.LINKID ,PARENTID:link.PARENTID ,CHKFLAG:link.CHKFLAG,OPERVAL:link.OPERVAL,LVL:link.LVL,ENLINKID:link.ENLINKID,PROCESSID:link.PROCESSID,CREATEDBY:link.CREATEDBY,STATUS:link.STATUS,MCSTATUS:link.MCSTATUS});
	 		 menuLinkData.push({ "id": link.LINKID, "index":pndex  ,"parentId": link.PARENTID==="0000"?null:link.PARENTID, "name":   link.DESCR ,"CHKFLAG":link.CHKFLAG  });
		});
	}

		if(params && params.tabName === "PENDINGAPR"){
					savebtn =false;
					deletbtn =false;
					cancelbtn= false;
					approvebtn=false;
					rejectbtn=false;
					delapprovebtn=false;
					delrejectbtn=false;
					if( params.ApproveBtn !==  undefined	)
					{
						if( params.saveMsg !== 'USERDELWATAPP' )
						{
							approvebtn=true;rejectbtn=true;

						}
						if( params.userdelAppBtn !==  undefined	)
						{
							if( params.saveMsg === 'USERDELWATAPP' )
							{
								delapprovebtn=true;delrejectbtn=true;

							}
						}
					}

		}else{
			approvebtn=false;
			rejectbtn=false;
			delapprovebtn=false;
			delrejectbtn=false;
			if(params && params.tempStatusFlag !== "YES")
			{
				if( params.ApproveBtn ===  undefined	)
				{
					if(params.tabName ===  'VIEWALL' && params.saveMsg !== 'USERDELWATAPP' )
					{

						savebtn =true;
					}
				}
			}else{ if(params && params.tabName === "VIEWALL"){
				if(params.tempStatusFlag === "YES"){
					if(params.createFlag !== undefined){
						savebtn =true;
					}
				}
				}
			}

		  if(params && params.tabName === "VIEWALL"){
			if(params.saveMsg !== "USERDELWATAPP"){
				if(params.pendingFlag === undefined || params.pendingFlag !== 'P'){
				deletbtn = true;
				}
			}
		}
		cancelbtn=true;
	}



    return { savebtn,cancelbtn,deletbtn,approvebtn,rejectbtn,delapprovebtn,delrejectbtn,userlinkspermdata,prpsselection,selectedLinks,expandIds,menuLinkData,params,msg,msgType};
}

 export default connect(mapStateToProps)((withStyles(styles))(UserLinksPerm));