import React from 'react'
import { withStyles } from '@material-ui/core/styles';
import PropTypes from 'prop-types';

import  Paper from '@material-ui/core/Paper'
import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import Divider from '@material-ui/core/Divider';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Typography from '@material-ui/core/Typography';
import Table from '@material-ui/core/Table';
import { createMuiTheme,MuiThemeProvider} from '@material-ui/core/styles';
import { muiTableStyles } from '../../../styles/muidatatableCss';
import { MuiStyles } from '../../../styles/MuiStyles';
import TableBody from '@material-ui/core/TableBody';
import TableHead from '@material-ui/core/TableHead';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import { resultConstants } from '../../../common/constants/result.constants'
import {emailValidation} from '../../../common/commonValidations'
import UserRolesEmailAddMaintainceViewChanges from './UserRolesEmailAddMaintainceViewChanges';
import Info from "@material-ui/icons/Info";
import Loading from '../../../common/Loading';
const styles = theme => ({
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
    },
    paper: {
      padding: theme.spacing.unit * 2,
      textAlign: 'center',
      color: theme.palette.text.secondary,
    },
    tabsRoot: {
        borderBottom: '1px solid #e8e8e8',
      },
      tabsIndicator: {
        backgroundColor: '#1890ff',
      },
      tabRoot: {
        textTransform: 'initial',
        minWidth: 72,
        fontWeight: theme.typography.fontWeightRegular,
        marginRight: theme.spacing.unit * 4,
        // fontFamily: [
        //   '-apple-system',
        //   'BlinkMacSystemFont',
        //   '"Segoe UI"',
        //   'Roboto',
        //   '"Helvetica Neue"',
        //   'Arial',
        //   'sans-serif',
        //   '"Apple Color Emoji"',
        //   '"Segoe UI Emoji"',
        //   '"Segoe UI Symbol"',
        // ].join(','),
        '&:hover': {
          color: '#40a9ff',
          opacity: 1,
        },
        '&$tabSelected': {
          color: '#1890ff',
          fontWeight: theme.typography.fontWeightMedium,
        },
        '&:focus': {
          color: '#40a9ff',
        },
      },
      tabSelected: {},
      typography: {
        padding: theme.spacing.unit * 3,
      },

      label: {
        fontSize: '14px',
        fontWeight : 'bold',
      },
      tablerow:{
        height : '20px',
      },
      chkbox : {
        padding: '0 5px',
      },
      margin: {
        marginRight: '0px',
        marginLeft: '0px',
      },
      insrt:{
        fontSize:'12px',
        color: '#666666',
        fontFamily: 'arial,helvetica,sans-serif',
      },
      readonly: {
	  	    		    border: '1px solid #cccccc',
	  	    		    backgroundColor: '#afb1b0',
 	}

  });

 let rowdata = [];
 var bodyFormdata = new FormData();
 class EmailAddrMaintenance extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
         value: 0,
         ck:'' ,
         ViewChangesbtn: false,
         allCheckVal : [],
        }
        this.doViewChanges = this.doViewChanges.bind(this);
    }
       componentWillMount(){
		   bodyFormdata  = new FormData();
   		}
    componentDidMount(){
        rowdata =  [];
        if(this.props.useremaildata !== undefined){
                this.props.useremaildata.map((item,index) =>{
                    rowdata.push(item);
                });
        }
    }
    handleChange = (event, value) => {
        this.setState({ value });
        var actionName;
        var bodyFormdata = new FormData();

        actionName =  "EMLADSMT";
        bodyFormdata.append("tabName", "EMLADSMT");
        if(value == 0) {
            bodyFormdata.append("viewTab", "VIEWALL");
        }else if(value == 1){
          bodyFormdata.append("viewTab", "PENDAPPR");
        }
        rowdata = [];
        this.props.tabChangeMethod(bodyFormdata, actionName);
    };
    handleEmailChange(e,index) {
        var item = rowdata[index];
        if(item !== undefined){
            item.NEWEMAILID = e.target.value;
            rowdata[index] = item;
        }
    }
    doCancel(){
        bodyFormdata.append("actionFlag","");
        rowdata = [];
        this.props.cancelmethod(bodyFormdata, "EMLADSMT");
    }
    doSave(){
       var validFlag = true;
		var bodyFormdata = new FormData();
		bodyFormdata.append("actionFlag","SAVE");
		bodyFormdata.append("tabName","EMLADSMT");
		bodyFormdata.append("viewTab","VIEWALL");
		bodyFormdata.append("reactJSActionFlag","GO");
		var usrSize = rowdata.length;
        rowdata && rowdata.map((eitem,index) =>{
            if(eitem !== undefined){

				if(eitem.NEWEMAILID !==  undefined && eitem.NEWEMAILID === ''){
					eitem.NEWEMAILID=eitem.EMAILID;
				}
				console.log('eitem.NEWEMAILID ?>>'+eitem.NEWEMAILID);
                if(eitem.NEWEMAILID ===  undefined || eitem.NEWEMAILID.length > 0)
                {
                 if(!emailValidation(eitem.NEWEMAILID)){
                    validFlag = false;
                }else{
						bodyFormdata.append("procid"+index.toString(), eitem.PROCESSID);
						bodyFormdata.append("UserloginId"+index.toString(), eitem.LOGINID);


						bodyFormdata.append("oldEmailId"+index.toString(), eitem.EMAILID);
						bodyFormdata.append("emailDisable"+index.toString(), eitem.DISABLED);

						bodyFormdata.append("emailId"+index.toString(), eitem.NEWEMAILID);
                }
			}
            }
        });
        if(validFlag){
		 if(window.confirm('Are you sure, you want to save the data?')){
            bodyFormdata.append("usrSize", usrSize);
            rowdata = [];
            this.props.savemethod(bodyFormdata, "EMLADSMT");
         }
        }else {
            alert("Please enter valid email.");
        }

    }

     doApprove(){
      var invalidFlag = true;

	       var validFlag = true;
		var bodyFormdata = new FormData();


			bodyFormdata.append("actionFlag","APPROVE");
			bodyFormdata.append("tabName","EMLADSMT");
			bodyFormdata.append("viewTab","PENDAPPR");
			bodyFormdata.append("reactJSActionFlag","GO");
			var usrSize = rowdata.length;
	        rowdata && rowdata.map((eitem,index) =>{
	            if(eitem !== undefined){
	                if(eitem.EMAILID ===  undefined || eitem.EMAILID === ''
	                || !emailValidation(eitem.EMAILID)){
	                    validFlag = false;
	                }else{
								if(this.state.allCheckVal[index] === 'Y'){
									bodyFormdata.append("Check"+index.toString(), "Y");
									 invalidFlag=false;
								 }

							bodyFormdata.append("emailId"+index.toString(), eitem.EMAILID);
							bodyFormdata.append("procid"+index.toString(), eitem.PROCESSID);

							bodyFormdata.append("UserloginId"+index.toString(), eitem.LOGINID);

							bodyFormdata.append("oldEmailId"+index.toString(), eitem.EMAILID);
							bodyFormdata.append("emailDisable"+index.toString(), eitem.DISABLED);

 	                }
	            }
	        });
	        if(invalidFlag){
	        alert('Please Check atleast one check box .');
	        }else{
	        if(validFlag){
	         if(window.confirm('Are you sure, you want to approve the data?')){
	            bodyFormdata.append("usrSize", usrSize);
	            rowdata = [];
	            this.props.savemethod(bodyFormdata, "EMLADSMT");
	            }
	        }else {
	            alert("Please enter valid email.");
	        }
	        }


    }

     doReject(){
	       var validFlag = true;
	       var invalidFlag = true;
			var bodyFormdata = new FormData();
			bodyFormdata.append("actionFlag","REJECT");
			bodyFormdata.append("tabName","EMLADSMT");
			bodyFormdata.append("viewTab","PENDAPPR");
			bodyFormdata.append("reactJSActionFlag","GO");
			var usrSize = rowdata.length;
	        rowdata && rowdata.map((eitem,index) =>{
	            if(eitem !== undefined){
	                if(eitem.EMAILID ===  undefined || eitem.EMAILID === ''
	                || !emailValidation(eitem.EMAILID)){
	                    validFlag = false;
	                }
	                //else{
								if(this.state.allCheckVal[index] === 'Y')
								{
								 bodyFormdata.append("Check"+index.toString(), "Y");
								 invalidFlag=false;
							    }
								else
								bodyFormdata.append("Check"+index.toString(), "N");


	                    		bodyFormdata.append("emailId"+index.toString(), eitem.EMAILID);
	                    		bodyFormdata.append("procid"+index.toString(), eitem.PROCESSID);

	                    			bodyFormdata.append("UserloginId"+index.toString(), eitem.LOGINID);

									bodyFormdata.append("oldEmailId"+index.toString(), eitem.EMAILID);
									bodyFormdata.append("emailDisable"+index.toString(), eitem.DISABLED);

	                //}
	            }
	        });
	        if(invalidFlag){
				        alert('Please Check atleast one check box .');
	        }else if(validFlag){
			if(window.confirm('Are you sure, you want to reject the data?')){
	            bodyFormdata.append("usrSize", usrSize);
	            rowdata = [];
	            this.props.savemethod(bodyFormdata, "EMLADSMT");
	         }
	        }else {
	            alert("Please enter valid email.");
	        }
    }

 handleCheck = (event, index) => {
	        var chkVal = document.getElementById("Check" +index).checked;
	        let allCheckVal = this.state.allCheckVal;
 	 	     if(chkVal){
	            	 allCheckVal[index] = 'Y' ;

	        } else{
	                allCheckVal[index] = 'N' ;

	        }
	        this.setState({allCheckVal});
 	    }
	doViewChanges(){
		this.setState({ViewChangesbtn:true})
	}

	doClose = () =>{
		this.setState({ViewChangesbtn:false})
	}

    render(){
        const {classes, screenName, checkerFlag, clientFirm, processId, respMsg} = this.props
        const { value } = this.state;

	//console.log("mar05, 2019  2nd component processId::",processId+",clientFirm::",clientFirm);
        var len = rowdata.length;

        var k;
        if(this.props.useremaildata !== undefined && len == 0){
            this.props.useremaildata.map((item,index) =>{
                rowdata.push(item);
            });
        }
        let noRecordsblock;
       if(this.props.useremaildata !== undefined && rowdata.length > 0){
	noRecordsblock = <TableRow key="0"><TableCell colSpan={3}> <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>No records are pending approval</div></TableCell></TableRow>
       }else if(this.props.useremaildata === undefined && this.props.checkersdata === undefined && rowdata.length === 0){
	noRecordsblock = <TableRow key="0"><TableCell colSpan={3}> <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>No records are pending approval</div></TableCell></TableRow>
       }else{
	noRecordsblock =<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
       }
        let contentblock;


        if(this.props.useremaildata !== undefined && rowdata.length > 0){

            contentblock = rowdata.map((item,index) =>{

                        bodyFormdata.append("procid"+index.toString(), item.PROCESSID);
                        bodyFormdata.append("UserloginId"+index.toString(), item.LOGINID);

                        if(item.DISABLED === "true"){
                            bodyFormdata.append("emailId"+index.toString(), item.EMAILID);
                        }
                        bodyFormdata.append("oldEmailId"+index.toString(), item.EMAILID);
                        bodyFormdata.append("emailDisable"+index.toString(), item.DISABLED);

                            return <TableRow key={index.toString()} className={classes.tablerow}>
                             <TableCell>
                            {(this.state.value === 1 && item.CHECKERFLAG === "Y") &&

                               <Checkbox
                               key={"Check"+index.toString()}
                                id={"Check"+index.toString()}
                               onChange={e => this.handleCheck(e,index)}
                               checked={this.state.allCheckVal[index] === 'Y'? 'checked':''}
                               />
                                }
 							 {item.USERDESC}
                                </TableCell>
                                <TableCell>
                               {(item.DISABLED === "true")?
                               <TextField className={classes.inputStyle,classes.readonly} name={"emailIdTxt"+index.toString()}
                               defaultValue={item.EMAILID}
                               disabled
                               onChange={(e)=>this.handleEmailChange(e,index)}
                               inputProps={{
                                   style: {textAlign: "left", width: 220,fontSize: 12}
                                 }}
                                 />:
                               <TextField className={classes.inputStyle} name={"emailId"+index.toString()}
                               defaultValue={item.EMAILID}
                               onChange={(e)=>this.handleEmailChange(e,index)}
                               inputProps={{
                                   style: {textAlign: "left",width: 220,fontSize: 12}
                                 }}
                               />}
                               </TableCell>
                               </TableRow>


                    });
        }

       let approveBtn="";
       let rejectBtn="";
       if(checkerFlag === "Y"){
	  approveBtn=<a title="Approve" onClick={(e)=>{this.doApprove();}} className="btn btn-primary btn-xs">Approve</a>
	  rejectBtn=<a title="Reject" onClick={(e)=>{this.doReject();}} className="btn btn-primary btn-xs">Reject</a>
       }
    return (
        <div>
          <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
        <Paper className={classes.root}>
            <div className="panel">
            <div className="panel-heading clearfix">
                  <h4 className="panel-title pull-left col-md-1">{screenName}</h4>
             </div>
            </div>
            <div className="clearfix"></div>
    	    <div style={{float:'left',padding:'16px', width: '280px'}}>Email Address Maintenance  :</div>
            <div className={classes.root} style={{float:'left'}}>
            <Tabs
            value={value}
            onChange={this.handleChange}
            classes={{ root: classes.tabsRoot, indicator: classes.tabsIndicator }}
            >
            <Tab
                disableRipple
                classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
                label="View All"
            />
            <Tab
                disableRipple
                classes={{ root: classes.tabRoot, selected: classes.tabSelected }}
                label="Pending Approval"
            />
            </Tabs>
            </div>
            <div className="clearfix"></div>
            {value === 0 &&
                <div>
         <div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> <Info className={classes.info} style={{float:'left'}}/><h6 style={{marginTop:'10px',float:'left', marginLeft:'30px'}}>{this.state.value=== 0?" Records in grey are Pending Approval":"You will not be able to approve any records for which you performed the Maker action. These records are greyed out and cannot be selected."}</h6></div>
                    <Divider light />
                <Table>
                     <TableHead>
                            <TableRow className={classes.tablerow}>
                            <TableCell key={'0'} className={classes.label}>User Name</TableCell>
                            <TableCell key={'1'} className={classes.label}>Email Address</TableCell>
                            </TableRow>
                        </TableHead>
                    <TableBody>
                    {contentblock}
                    </TableBody>
                </Table>
                {respMsg && respMsg.length > 0 &&
                 <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>{resultConstants[respMsg]}</div>
               }
                <div className="col-md-6" style= {{paddingTop: "5px"}}>
                  <a title="Save" onClick={(e)=>{this.doSave();}} className="btn btn-primary btn-xs">Save</a>
                  <a title="Cancel" onClick={(e)=>{this.doCancel();}} className="btn btn-primary btn-xs">Cancel</a>
                   <button title="View Changes" className="btn btn-primary btn-xs" onClick={this.doViewChanges}>View Changes</button>
                  {this.state.ViewChangesbtn ?(<UserRolesEmailAddMaintainceViewChanges clientFirm={clientFirm} processId={processId}  open={this.state.ViewChangesbtn}  doClose={this.doClose} />):''}
               </div>

               </div>
            }
    {value === 1 && <div>
        <div style={{marginRight:'10px',float:'left',borderTop:'#cccccc 1px solid',width:'100%'}}> <Info className={classes.info} style={{float:'left'}}/><h6 style={{marginTop:'10px',float:'left', marginLeft:'30px'}}>{this.state.value=== 0?" Records in grey are Pending Approval":"You will not be able to approve any records for which you performed the Maker action. These records are greyed out and cannot be selected."}</h6></div>
        <Divider light />
                <Table>
                {(contentblock != undefined && contentblock.length > 0) &&
                     <TableHead>
                            <TableRow className={classes.tablerow}>
                            <TableCell key={'0'} className={classes.label}>User Name</TableCell>
                            <TableCell key={'1'} className={classes.label}>Email Address</TableCell>
                            </TableRow>
                </TableHead>   }
                    <TableBody>
                    {(contentblock != undefined && contentblock.length > 0) ? contentblock :
                    noRecordsblock}
                    </TableBody>
                </Table>
                {(contentblock != undefined && contentblock.length > 0) &&
		<div className="col-md-6" style={{paddingTop:'10px' }}>
		  {approveBtn}
		  {rejectBtn}
		  <button title="View Changes" className="btn btn-primary btn-xs" onClick={this.doViewChanges}>View Changes</button>
                  {this.state.ViewChangesbtn ?(<UserRolesEmailAddMaintainceViewChanges clientFirm={clientFirm} processId={processId} open={this.state.ViewChangesbtn} doClose={this.doClose} />):''}
		</div>}
               {respMsg && respMsg.length > 0 &&
                 <div style= {{textAlign: "center", paddingTop: "4px", color: "red" }}>{resultConstants[respMsg]}</div>
               }
               </div>
    }
     </Paper>
     </MuiThemeProvider>
    </div>
        );
    }
}

EmailAddrMaintenance.propTypes = {
    classes: PropTypes.object.isRequired,
  };

  export default withStyles(MuiStyles)(EmailAddrMaintenance);