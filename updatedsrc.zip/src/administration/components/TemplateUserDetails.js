import React from 'react';
import { Router, Route, Link } from 'react-router-dom';
import { NavBar } from '../../navbar/components/navbar';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import { createMuiTheme,MuiThemeProvider, withStyles } from '@material-ui/core/styles';
import MUIDataTable from "mui-datatables";
import {muiTableStyles} from '../../styles/muidatatableCss';
import FromData from 'form-data';
import { AdministrationActions } from '../actions/administration.actions';
import { connect } from 'react-redux';
import '../../user/css/App.css';
import FormData from 'form-data';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import InputLabel from '@material-ui/core/InputLabel';
import { alertConstants } from '../../common/constants/alert.constants';
import axios from 'axios';

const styles = theme => ({
    root: {
      width: '100%',
      marginTop: theme.spacing.unit * 3,
      overflowX: 'auto',
    },
    table: {
      minWidth: 700,
    },
    label: {
        width: '25%',
        fontSize: '12px',
        fontWeight:'bold'
    },
    labelvalue: {
        fontSize: '12px',
        fontWeight: 'normal'
    },
    tableheader: {
        background:'#ccc'
    },
    tabletheadtr: {
        height: '37px'
    },
    tabletheadth: {
        color:'#333',
        fontWeight:'bold',
        fontSize:'12px',
        paddingTop: '4px',
        paddingBottom: '4px'
    },
    tabletbodytr: {
        height: '32px'
    },
    tabletbodytd: {
        fontSize: '12px'
    }
});

const ContCols = [
    {
        name: 'First Name',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Last Name',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Email Id',
        options: {
            filter: true,
            sort: false,
        }
    }
]

const ContCols2 = [
    {
        name: 'Status',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Email Alert Name',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Nature of Change',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Changes Done At',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Changes Done By',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Approved At',
        options: {
            filter: true,
            sort: false,
        }
    },{
        name: 'Approved By',
        options: {
            filter: true,
            sort: false,
        }
    }
]

let processId;
let selTemplate;
let tempclientFirm;
let id;
let mcFlag;
let vecsize;
let newData;
class TemplateUserDetails extends React.Component {
    constructor(){
        super();
        this.state={
            results:[],
            results1:[],
            results2:[],
            results3:[],
            results4:[],
            reportdata:[],
            reportdatatable:[],
            columns:[],
            screenName:'',
            screenName1:'',
            screenName2:'',
            tempuserdata:[],
            associateduserdata:[],
            associateduserdata1:[],
            associateresults:[],
            associateresults1:[],
            viewchangehistory:[],
            viewchangehistory1:[],
            viewchangehistoryResult:[],
            msg:'',
            open: false
        }
        // this.doChange = this.doChange.bind(this);
        this.doRevoke = this.doRevoke.bind(this);
        this.AppRej = this.AppRej.bind(this);
        this.handleClickOpen = this.handleClickOpen.bind(this);
    }
    componentWillMount() {
        var bodyFormData = new FormData();
        if(this.props.location.state){
            // console.log("mcFLag----compoentWillmount",this.props.location.state.mcFlag)
            vecsize = this.props.location.state.vecsize;
            mcFlag = this.props.location.state.mcFlag
            processId = this.props.location.state.processId;
            selTemplate = this.props.location.state.selTemplate;
            tempclientFirm = this.props.location.state.tempclientFirm;
            // console.log('formdata state <><>:'+JSON.stringify( this.props.location.state	));
            // console.log('formdata ruleid <><>:', JSON.stringify(this.props.location.state.tempclientFirm)	);
            bodyFormData.append("companyId",tempclientFirm);
            // bodyFormData.append("processId",processId);
            bodyFormData.append("selTemplate",selTemplate);
            bodyFormData.append("tempclientFirm",tempclientFirm);
        }
        this.props.dispatch(AdministrationActions.fetchtempUserData(bodyFormData));
    }
    doRevoke(){
        var bodyFormData = new FormData();
        bodyFormData.append("processId",processId);
        bodyFormData.append("actionFlag",'REVOKE');
        this.props.dispatch(AdministrationActions.fetchtempUserData(bodyFormData));
    }
    AppRej(e){
        var bodyFormData = new FormData();
        var url;
        var user = JSON.parse(sessionStorage.getItem('user'));
        bodyFormData.append("token",user[0].token);
        bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));
        bodyFormData.append("size",vecsize);
        var labelId = e.target.id;
        if(labelId === "Approve"){
            bodyFormData.append("template",selTemplate);
            bodyFormData.append("templateName",this.state.results3.TemplateName);
            bodyFormData.append("companyName",this.state.results3.ClientName);
            bodyFormData.append("actionFlag",'APPROVE');
        }else if(labelId === "Reject"){
            bodyFormData.append("template",selTemplate);
            bodyFormData.append("templateName",this.state.results3.TemplateName);
            bodyFormData.append("companyName",this.state.results3.ClientName);
            bodyFormData.append("actionFlag",'REJECT');
        }
        url=alertConstants.URL+"/EDITEMAILTEMP.do";
        axios({
            method: 'POST',
            url:url,
            data: bodyFormData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        }).then((response)=>{
            newData = response.data;
            this.setState({msg:newData.commonData})
            console.log(newData.commonData);
            // this.props.doRefresh()
        });
    }
    handleClickOpen = (e) => {
        id = e.target.id;
        // console.log(id)
        if(id === 'ViewAssociate') {
            var bodyFormData = new FromData();
            // console.log("1111")
            this.setState({ open: true });
            // console.log('templateId <><>:'+JSON.stringify( selTemplate	));
            bodyFormData.append("templateId",selTemplate);
            this.props.dispatch(AdministrationActions.fetchAssociatedUserDetPopUpData(bodyFormData));
        }
        else if(id === 'ViewChanges') {
            var bodyFormData = new FromData();
            this.setState({ open: true });
            bodyFormData.append("selectedTemplate",selTemplate);
            bodyFormData.append("templateName",this.state.results3.TemplateName);
            bodyFormData.append("popUpFlag",'true');
            this.props.dispatch(AdministrationActions.fetchViewChangeHistoryPopUpData(bodyFormData));
        }

    };

    handleClose = () => {
        this.setState({ open: false });
    };

    render(){
        const { classes } = this.props;
        this.state.tempuserdata = this.props.tempuserdata;
        this.state.results  = this.state.tempuserdata.tempuserdata;
        // console.log('this.state.tempuserdata <><>:'+JSON.stringify( this.state.results	));
        if(this.state.results !== undefined) {
            this.state.screenName = this.state.results.Title.Title;
            this.state.results1 = this.state.results.data;
            this.state.results3 = this.state.results.EmailAlertTemplate;
            this.state.results4 = this.state.results.commonData;
            // console.log('this.state.result3 <><>:'+JSON.stringify( this.state.results3	));
        }

        // View Associated Recipients

        const options = {
            filter: true,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:false
        };

        this.state.associateduserdata = this.props.associateduserdata;
        this.state.associateduserdata1 = this.state.associateduserdata.associateduserdata;

        // console.log(this.state.associateduserdata);
        if(this.state.associateduserdata1 !== undefined){
            // console.log(this.state.associateduserdata1.Title);
            this.state.screenName1 = this.state.associateduserdata1.Title;
            // console.log(this.state.associateduserdata1.rows);
            this.state.associateresults =  this.state.associateduserdata1.rows;
            // console.log('result1 <><>:'+JSON.stringify( this.state.associateresults	));
            }
        let data1=[];
        if(this.state.associateresults !== undefined) {
            this.state.associateresults.map((row,index) => {
                let cdata1=[];
                cdata1.push(row.FirstName);
                cdata1.push(row.LastName);
                cdata1.push(row.EmailId);
                data1.push(cdata1);
            });
        }

        // View Change History

        this.state.viewchangehistory = this.props.viewchangehistory;
        this.state.viewchangehistory1 = this.state.viewchangehistory.viewchangehistory;
        // console.log('viewchangehistory <><>:'+JSON.stringify( this.state.viewchangehistory	));
        // viewchangehistoryResult

        if(this.state.viewchangehistory1 !== undefined){
            // console.log(this.state.associateduserdata1.Title);
            this.state.screenName2 = this.state.viewchangehistory1.Title;
            // console.log(this.state.associateduserdata1.rows);
            this.state.viewchangehistoryResult =  this.state.viewchangehistory1.rows;
            // console.log('viewchangehistoryResult <><>:'+JSON.stringify( this.state.viewchangehistoryResult	));
        }

        let data2=[];
        if(this.state.viewchangehistoryResult !== undefined) {
            this.state.viewchangehistoryResult.map((row,index) => {
                let cdata2=[];
                cdata2.push(row.Status);
                cdata2.push(row.TemplateName);
                cdata2.push(row.Nature);
                cdata2.push(row.ModifiedDate);
                cdata2.push(row.ModifiedBy);
                cdata2.push(row.AcceptedDate);
                cdata2.push(row.AcceptedBy);
                data2.push(cdata2);
            });
        }

        return(
            <div>
                <NavBar/>
                <div className="panel panel-primary clearfix" style={{clear:'both'}}>
                    <div className="panel-heading">
                        <h4 className="panel-title">{this.state.screenName}</h4>
                    </div>
                    <div className="panel-body">
                        {
                            this.state.msg !== "" &&
                            <div className="text-center displayTxt">{this.state.msg}</div>
                        }
                        <div className="col-md-12 col-sm-12 head-cls backwhite">
                            <div className="col-md-6 col-sm-6">
                            {
                                this.state.results3.Status === 'Approved' &&
                                <Link className="btn btn-primary btn-xs mt" to={{ pathname:"/administrationedit/CLEMAIL", state: { companyId:processId, selTemplate:selTemplate, tempclientFirm:tempclientFirm, templateName:this.state.results3.TemplateName,status: this.state.results3.Status,ClientName:this.state.results3.ClientName,fromPage:"EDIT"} }}>Edit Template</Link>
                            }
                                {/* <Route render={({ history}) => (
                                    <button  className="btn btn-primary btn-xs mt"
                                        type='button'
                                        onClick={() => { history.push('/administrationedit/CLEMAIL') }}
                                    >
                                        Edit Template
                                    </button>
                                )} /> */}
                            </div>
                            <div className="col-md-6 col-sm-6 text-right">
                                <a className="btn btn-primary btn-xs mt" id="ViewAssociate" href="javascript:void(0);" onClick={this.handleClickOpen}>View Associated Recipients</a>
                                {/* <Route render={({ history}) => (
                                    <button  className="btn btn-primary btn-xs mt"
                                        type='button'
                                        onClick={() => { history.push('/administrationcreate/CLEMAIL') }}
                                    >

                                    </button>
                                )} /> */}

                                <a className="btn btn-primary btn-xs mt" id="ViewChanges" href="javascript:void(0);" onClick={this.handleClickOpen}>View Change History</a>
                                {/* <Route render={({ history}) => (
                                    <button  className="btn btn-primary btn-xs mt"
                                        type='button'
                                        onClick={() => { history.push('/administrationcreate/CLEMAIL') }}
                                    >

                                    </button>
                                )} /> */}
                            </div>
                            <div className="panel-body">
                                <div className="col-md-4 col-sm-4">
                                    <InputLabel className={classes.label}>Template Name:</InputLabel>
                                    <InputLabel className={classes.labelvalue}>{this.state.results3.TemplateName}</InputLabel>
                                </div>
                                <div className="col-md-4 col-sm-4">
                                    <InputLabel className={classes.label}>Status:</InputLabel>
                                    <InputLabel className={classes.labelvalue}>{this.state.results3.Status}</InputLabel>
                                </div>
                                <div className="clearfix"></div>
                                <div className="col-md-4 col-sm-4">
                                    <InputLabel className={classes.label}>Client Name:</InputLabel>
                                    <InputLabel className={classes.labelvalue}>{this.state.results3.ClientName}</InputLabel>
                                </div>
                                <div className="clearfix"></div>
                                {(this.state.results4 != undefined) ?
                                    <div>Changes made by {this.state.results4.username} to the Email Alert Template Management are  <span style={{backgroundColor:'yellow'}}>highlighted in yellow.</span> </div> :""
                                }
                                <Paper className={classes.root}>

                                    {this.state.results1 && this.state.results1.map((row, index) => {
                                        // console.log('rewwww'+row.rows)
                                        const rowsdata = row.rows && row.rows.map((rowdata, newindex) => {
                                            return (
                                                <TableRow key={newindex} className={classes.tabletheadtr}>
                                                    <TableCell className={classes.tabletbodytd}><span className={rowdata.color}>{rowdata.alertName+" "+rowdata.alertValue}</span></TableCell>
                                                </TableRow>
                                            )
                                            }
                                            );
                                        return (
                                            <Table className={classes.table} key={index}>
                                                <TableHead className={classes.tableheader}>
                                                    <TableRow key={index} className={classes.tabletheadtr}>
                                                        <TableCell className={classes.tabletheadth}>{row.name}</TableCell>
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody >
                                                    {rowsdata}
                                                </TableBody>
                                            </Table>
                                        );
                                    })}

                                </Paper>
                            </div>
                            {
                                ( mcFlag === 'Maker' && this.state.results3.Status === 'Waiting for Approval') &&
                                <Link onClick={this.doRevoke} className="btn btn-primary btn-xs mt" to={{ pathname: "/administration/CLALERT"}}>Revoke Changes</Link>
                            }
                            {
                                (mcFlag === 'Checker' && this.state.results3.Status === 'Waiting for Approval') &&
                                <div>
                                    <a href="#" onClick={this.AppRej} title="Approve" id="Approve" className="btn btn-primary btn-xs mt">Approve</a>
                                    <a href="#" onClick={this.AppRej} title="Reject" id="Reject" className="btn btn-primary btn-xs mt">Reject</a>
                                </div>
                            }
                        </div>
                        <Link to='/administration/CLALERT' style={{textDecoration:'underline'}}> Back to list of Email Alerts </Link>
                    </div>
                </div>
                <Dialog  fullWidth={true}
                    maxWidth={'md'}
                    open={this.state.open}
                    onClose={this.handleClose}
                    aria-labelledby="form-dialog-title"
                    >
                    {
                        id === 'ViewAssociate' &&
                        <DialogTitle id="form-dialog-title">
                                    {this.state.screenName1}
                        </DialogTitle>
                    }
                    {
                        id === 'ViewChanges' &&
                        <DialogTitle id="form-dialog-title">
                                    {this.state.screenName2}
                        </DialogTitle>
                    }
                    <DialogContent>
                        <MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
                            {
                                id === 'ViewAssociate' &&
                                <MUIDataTable
                                data={data1}
                                columns={ContCols} options={options}  />
                            }
                            {
                                id === 'ViewChanges' &&
                                <MUIDataTable
                                data={data2}
                                columns={ContCols2} options={options}  />
                            }
                        </MuiThemeProvider>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={this.handleClose} color="primary">
                        Close
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }
}
function mapStateToProps(state) {
    const { tempuserdata,associateduserdata,viewchangehistory } = state;
    return { tempuserdata,associateduserdata,viewchangehistory };
}

const connectedTemplateUserDetails = connect(mapStateToProps)(withStyles(styles)(TemplateUserDetails));
export { connectedTemplateUserDetails as TemplateUserDetails };
