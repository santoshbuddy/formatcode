import React from 'react';
import { Route } from 'react-router-dom';
import { MuiThemeProvider } from '@material-ui/core/styles';
import MUIDataTable from "mui-datatables";
import { muiTableStyles } from '../../styles/muidatatableCss';
import AssociatedDetLayer from './AssociatedDetLayer';
import TemplateDetails from './TemplateDetails';
import TableLoader from '../../common/TableLoader';
import { alertConstants } from '../../common/constants/alert.constants';
import axios from 'axios';
import FormData from 'form-data';


let vecsize;
let createbtndis='';
let AppRejbtn;
var checkFlag=false;
let pendval=[];
let selRowsIndex;
const cols = [
    {
        name: "TemplateName",
        options: {
            sort: true,
            download: false,
            filter: false,
            customBodyRender: (value, tableMeta, updateValue) => {
                return (
                    <TemplateDetails tempUserVal={value} size={vecsize} tempDet={tableMeta.rowData}/>
                );
            }
        }
    },{
        name: "TemplateStatus",
        options: {
            sort: true,
            download: false,
            filter: false,
        }
    },{
        name: "ClientName",
        options: {
             sort: true,
            download: false,
            filter: true,
        }
    },{
        name: "NumberofAssociatedUsers",
        options: {
             sort: true,
            download: false,
            filter: false,
            customBodyRender: (value, tableMeta, updateValue) => {
            return (
                <AssociatedDetLayer tdVal={value.NumberofAssociatedUsers} assocDet={value}/>
            );
        }

    },
}];

class MFViewall extends React.Component{
    constructor(props) {
        super(props);
        this.state={
            allRows:[],
        }
        this.AppRej = this.AppRej.bind(this);
    };
    AppRej(e){
        var jsonBody = new FormData();
        var url;
        var user = JSON.parse(sessionStorage.getItem('user'));
        jsonBody.append("token",user[0].token);
        jsonBody.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')));

        // console.log("==========data===========",this.props.data1.reportdata);

        if(this.props.data1.reportdata !== undefined)
            this.props.data1.reportdata.map((item,index) => {
                if(item.type === "data")
                    pendval = item.values
            })

        var labelId = e.target.id;
        if(labelId === "Approve"){

            // console.log('this.state.allRows ',this.state.allRows);
            pendval && pendval.map((item,index)=>{
                  if(this.state.allRows.find(e => e.index.toString() === index.toString()) !== undefined){
                    // console.log("pendval[0]",pendval[index][3])
                    //  console.log("item.TemplateName >>>>>>>>",item.TemplateName)
                    jsonBody.append("chk"+index,'Y');
                    jsonBody.append("tempName"+index,item.TemplateName);
                    jsonBody.append("templateFor"+index,'');
                    jsonBody.append("template"+index,item.selTemplate);
                    jsonBody.append("clientFirm"+index,item.tempclientFirm);
                    jsonBody.append("pcompanyid"+index,item.pCompanyId);
                    jsonBody.append("processId"+index,item.processId);
                    jsonBody.append("allFlag"+index,'ALL');
                    jsonBody.append("actionFlag"+index,'APPROVE');
                    jsonBody.append("vecSize",pendval.length);

                    url=alertConstants.URL+"/CLALERT.do";
                    axios({
                        method: 'post',
                        url:url,
                        data: jsonBody,
                        config: { headers: {'Content-Type': 'multipart/form-data' }}
                    }).then((response)=>{
                        pendval = response.data;
                    });
                }
            });
        }
        else if(labelId === "Reject"){
            pendval && pendval.map((item,index)=>{
                if(this.state.allRows.find(e => e.index.toString() === index.toString()) !== undefined){
                    jsonBody.append("processId"+index,item.processId);

                    url=alertConstants.URL+"/CLALERT.do";
                    axios({
                        method: 'post',
                        url:url,
                        data: jsonBody,
                        config: { headers: {'Content-Type': 'multipart/form-data' }}
                    }).then((response)=>{
                        pendval = response.data;
                    });
                }
            });
        }
    }

    selectedRows(selRows)
    {
        //console.log("selected rws ", selRows);
        selRowsIndex=selRows;
    }

    render() {
        const { data,TabType } = this.props;
        console.log("checkflag------------>",checkFlag);
        const options = {
            filter: true,
            filterType: 'dropdown',
            responsive: 'scroll',
            selectableRows:TabType === 1?true:false,
            textLabels: {
                body: {
                     noMatch: <TableLoader />,
                },
            },
            onRowsSelect: (rowsSelected, allRows) => {
                this.selectedRows(allRows);
                this.setState({allRows})
            }
        };
        if(TabType == '0'){
            createbtndis =
            <div className="col-md-12 col-sm-12 head-cls">
                <div className="panel">
                    <div className="panel-heading clearfix">
                        <h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
                        <a className="pull-right" onClick={this.tottgleDisplay}>
                            <i className="fa fa-caret-down"></i>
                        </a>
                    </div>
                </div>
                <div className="filter_div" id="filter_div" >
                    <Route render={({ history}) => (
                        <button  className="btn btn-primary btn-xs mt"
                            type='button'
                            onClick={() => { history.push('/administrationnew/CLEMAIL') }}
                        >
                            Create New Template
                        </button>
                    )} />
                    <div style={{clear:'both'}}></div>
                </div>
            </div>;
        }else {
            createbtndis='';
            AppRejbtn =
            <div className="col-md-12 col-sm-12">
                <a href="#" onClick={this.AppRej} id="Approve" title="Approve" class="btn btn-primary btn-xs">Approve</a>
                <a href="#" onClick={this.AppRej} id="Reject" title="Reject" class="btn btn-primary btn-xs">Reject</a>
            </div>;
        }

         return(
            <div>
                <div className="panel-body">
										<div className="col-md-12 col-sm-12 head-cls">
											<div className="panel">
												<div className="panel-heading clearfix">
													<h4 className="panel-title pull-left col-md-2">Filter Criteria: </h4>
													<a className="pull-right" onClick={this.tottgleDisplay}>
														<i className="fa fa-caret-down"></i>
													</a>
												</div>
											</div>
											<div className="filter_div" id="filter_div" >
											<Route render={({ history}) => (
												<button  className="btn btn-primary btn-xs"
													type='button'
													onClick={() => { history.push('/administrationcreate/NEWMMDAACCT') }}
												>
													Create New Account
												</button>
											)} />
											{/* <Link to="/CreateNewAcct" className="btn btn-primary btn-xs">Create New Account</Link>             */}
											<Filters method={this.doChange} data={this.state.reportdata}/>
											</div>
										</div>

										<div className="clearfix"></div>
										<div className="col-md-12 col-sm-12 head-cls backwhite">
											<div className="panel">
												<div className="panel-heading clearfix">
													<h4 className="panel-title pull-left col-md-1">Search Results</h4>
												</div>
											</div>
											{/* <ReactTable showPagination={false} resizable={false} noDataText="No Data Found" data={this.state.results} columns={this.state.columns}  className="table table-striped" /> */}

											<div className="col-md-12 col-sm-12">
												{
												this.state.results !== undefined ?
												<MuiThemeProvider theme={muiTableStyles.getMuiTheme()}>
													<MUIDataTable
													data={results}
													columns={columns}
													options={options}
													/>
												</MuiThemeProvider>
												:
												<div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div>
											}
											</div>
										</div>
					</div>
            </div>
        )
    }
}

export default MFViewall;