import React from 'react';
import NavBarItem from './navbaritem';
import { connect } from 'react-redux';
import { navbarActions } from '../actions/navbar.actions';
import { Link } from 'react-router-dom';
import { history } from '../../_helpers';
import {updateMenubarRefreshElem,updateBottomHomeRefreshElem} from './HIddenRefresh';
import axios from 'axios';
import { withStyles, MuiThemeProvider } from '@material-ui/core/styles';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import { alertConstants } from '../../common/constants/alert.constants';
import NativeSelect from '@material-ui/core/NativeSelect';
import Dialog from "@material-ui/core/Dialog";
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Button from '@material-ui/core/Button';
import Select from '@material-ui/core/Select';
import MenuItem from "@material-ui/core/MenuItem";
import keyboard_arrow_down from "@material-ui/icons/KeyboardArrowDown";
import Formatter from '../../formats/Formatters';

let clientFirm;

class NavBar extends React.Component {
    constructor(){
        super();
        this.state={
            linkData:[],
            logout: false,
				refreshData:{ "notificationCnt":this.props && this.props.notificationCnt !== undefined?this.props.notificationCnt:"0" ,
								"currPendCount": undefined,
								"pendFutureCount":undefined,
								"tdate":'' ,
								"pendTrdOperValue":this.props && this.props.pendTrdOperValue !== undefined?this.props.pendTrdOperValue:"0" ,
								"pendFutureTrdOperValue":this.props && this.props.pendFutureTrdOperValue !== undefined?this.props.pendFutureTrdOperValue:"0" ,
								"oldPendCount":this.props && this.props.oldPendCount !== undefined?this.props.oldPendCount:"0" ,
								"oldPendFutureCount":this.props && this.props.oldPendFutureCount !== undefined?this.props.oldPendFutureCount:"0" ,
								},
         }
         		this.checkNotifications = this.checkNotifications.bind(this);
         		this.logout = this.logout.bind(this);


            }
             componentWillMount() {
				//  this.checkNotifications();

			 }
    componentDidMount() {
         if(sessionStorage.getItem("navlinkFlag") === "false" || sessionStorage.getItem("navlinkFlag") === undefined
         || this.props.navlinks.navlinks===undefined
         ){
            sessionStorage.setItem("navlinkFlag","true")
            this.props.dispatch(navbarActions.fetchNavlinks());
        }

     }

    componentWillUnmount() {
		// clearInterval(this.interval);
		}
		checkNotifications(bodyFormData){
			 this.setState({dataVec:[]})
		  // after 5 seconds stop
			 this.interval = setInterval(() => {
				//clearInterval(timerId);
				 //alert('HI');
				var bodyFormData = new FormData();
				var data;
						var user = JSON.parse(sessionStorage.getItem('user'));

						bodyFormData.append("token",user[0].token)
						bodyFormData.append("clientFirm",JSON.parse(sessionStorage.getItem('clientFirm')))
						bodyFormData.append("ajaxFlag",'true')
						bodyFormData.append("subSource",'HOME')
						axios({
							method: 'POST',
							url:alertConstants.URL+"/HiddenTradeRefreshServlet",
							data: bodyFormData,
							config: { headers: {'Content-Type': 'application/x-www-form-urlencoded' }}
						  }).then((response)=>{
						   // data = response.data;
						 //  console.log('response.data? >>>'+response.data);
						  let xml = new DOMParser().parseFromString(response.data.notifications, 'application/xml');
						  let refreshData={ "notificationCnt":this.props && this.props.notificationCnt !== undefined?this.props.notificationCnt:"0" ,
								"currPendCount":this.props && this.props.oldPendCount !== undefined?this.props.oldPendCount:"0" ,
								"pendFutureCount":this.props && this.props.oldPendFutureCount !== undefined?this.props.oldPendFutureCount:"0" ,
								"tdate":'' ,
								"pendTrdOperValue":this.props && this.props.pendTrdOperValue !== undefined?this.props.pendTrdOperValue:"0" ,
								"pendFutureTrdOperValue":this.props && this.props.pendFutureTrdOperValue !== undefined?this.props.pendFutureTrdOperValue:"0" ,
								"oldPendCount":this.props && this.props.oldPendCount !== undefined?this.props.oldPendCount:"0" ,
								"oldPendFutureCount":this.props && this.props.oldPendFutureCount !== undefined?this.props.oldPendFutureCount:"0" ,
								};
						  updateMenubarRefreshElem(response.data.notifications,refreshData);
// console.log('refreshData.data <><<<>>>'+JSON.stringify(refreshData));
						sessionStorage.setItem('currPendCount', refreshData.currPendCount);
						sessionStorage.setItem('pendFutureCount', refreshData.pendFutureCount);
						sessionStorage.setItem('tdate',refreshData.tdate)
						sessionStorage.setItem('notificationCnt',refreshData.notificationCnt)

						this.setState({refreshData:refreshData});



					});


				}, 5000);
	}

    logout(){
    	this.setState({logout:true})
    }
    handleClose = () => {
        this.setState({ logout: false });
   };
    doLogOut = () => {
    var data;

     var bodyFormData = new FormData();
          var user 			= JSON.parse(sessionStorage.getItem('user'));
           bodyFormData.append("token",user[0].token)
           axios({
	              method: 'post',
	              data: bodyFormData,
            url:alertConstants.URL+"/LOGOUT.do",
            });

   };
    doChange(e){
        clientFirm=e.target.value;
        sessionStorage.setItem('clientFirm', clientFirm);
        //history.push('/');
          window.location.href="/"+alertConstants.homePage;
    }
    render(){
        const { navlinks, classes } = this.props;
        let result = navlinks.navlinks;
        // console.log("result--->"+result);

        let linkmap;
        let filterMap;

        let user = JSON.parse(sessionStorage.getItem('user'));
        if(result !== undefined){
            result=Array.from(result)
            filterMap = result.map((filter,index) => {
            //    console.log("filter.values",filter)
               if(index===0 &&
                sessionStorage.getItem("clientFirm")===null && filter.values !== undefined){
                    sessionStorage.setItem("clientFirm",filter.values[0].id);
                }

                // console.log("filter.fieldValue--->"+filter.fieldValue);
                // console.log("filter.fieldvaluesValue--->"+filter.values[0]);
                if(filter.type === "Select"){
                 return(
                    <div key={index} className={classes.lblSelect}>
                        {/* {console.log("memberCatId==>",user[0].memberCatId)} */}
                       {user[0].memberCatId === "4" &&
                        <label className={classes.headerlabelstyle}>Client:</label>
                    }
                       {
                           user[0].memberCatId !== undefined &&
                           user[0].memberCatId === "4" && filter.values !== undefined &&
                    // <div key={filter.id.toString()}>
                            <Select IconComponent = {keyboard_arrow_down} ref={ filter.name }  name={filter.name} onChange={this.doChange} value={filter.fieldValue === "null" ? filter.values[0]:filter.fieldValue}>
                                {
                                    filter.values && filter.values.map((obj,index) => {
                                        if(sessionStorage.getItem("clientFirm")!==undefined && sessionStorage.getItem("clientFirm").replace(/"/g,"") === obj.id.toString()){
                                            return <MenuItem key={index} value={obj.id} selected={obj.id}>{obj.name}</MenuItem>
                                        }else{
                                            return <MenuItem key={index} value={obj.id}>{obj.name}</MenuItem>
                                        }
                                    })
                                }
                            </Select>
                        //  </div>
                       }
                       {/* <br/> */}
                       {/* {
		           user[0].memberCatId !== undefined &&
                           user[0].memberCatId === "4" &&
				<div style={{textAlign:'right',marginTop:'18px',marginRight:'2px'}}>
					<span style={{color:'#ffffff', fontWeight:'bold'}}>Trades pending approval:</span>

								{
									parseInt(this.props && this.props.oldPendCount)>0 ?
									(parseInt(this.props && this.props.pendTrdOperValue)>0?
									<span>&nbsp;<Link to="/reportCheck/WATFRAPP" style={{color:'#ffffff',textDecoration:'underline'}} >
									Today({(sessionStorage.getItem('currPendCount') !== undefined?sessionStorage.getItem('currPendCount'):this.props.oldPendCount )})</Link>&nbsp; </span>
									:<span style={{color:'#ffffff'}}>&nbsp;Today&nbsp;(0)&nbsp; </span>):<span style={{color:'#ffffff'}}>&nbsp;Today&nbsp;(0)&nbsp; </span>}

							{
							parseInt(this.props && this.props.oldPendFutureCount)>0 ?
							(parseInt(this.props && this.props.pendFutureTrdOperValue)>0?
							<span>&nbsp;<Link to="/reportCheck/FUDEAPRL" style={{color:'#ffffff',textDecoration:'underline'}} >
							Future({(sessionStorage.getItem('pendFutureCount')!== undefined?sessionStorage.getItem('pendFutureCount'):this.props.oldPendFutureCount )})</Link>&nbsp; </span>
							:<span style={{color:'#ffffff'}}>&nbsp;Future&nbsp;(0)&nbsp; </span>):<span style={{color:'#ffffff'}}>&nbsp;Future&nbsp;(0)&nbsp; </span>}



				</div>
			} */}
                   </div>

                   );
                }
            });

            result && result.map((item) => {
                if(item.type === "Links"){
                    this.state.linkData = item.values
                    //console.log("linkdata::"+JSON.stringify(this.state.linkData));
                }
            });

            linkmap = this.state.linkData && this.state.linkData.map((item) => {
                if(item.label === "Home"){
                    return <NavBarItem key={item.id.toString()} classname={"active"} item={item}/>
                }else if(item.subitem !== undefined){
                    return <NavBarItem classname="dropdown" key={item.id.toString()} item={item} />
                }else{
                    return <NavBarItem classname="dropdown" key={item.id.toString()} item={item} />
                }
            });
        }
        return(
            <div>
                <MuiThemeProvider  theme={muiTableStyles.getMuiTheme()}>
                <div id="header" className={classes.headerPanel}>
                    <div className={classes.headerFlex} id="headerFlex">
                        <img src="/src/images/header_logo.png" alt="Liquidity Portal" className={classes.headerLogo} id="headerLogo"/>
                        <span className={classes.headerTitle}>lPortal</span>
                    </div>
                    {/* <div className={classes.headerRightcontent}> */}
                    {/* </div> */}
                    <div className={classes.headerRightcontent}>
                        {filterMap} 
                        <div className={classes.userdet}>
                            <div className={classes.headerusername}>{sessionStorage.getItem("loginName").replace(/"/g,"")}</div>
                            <div className={classes.headerdate}>Last login at {<Formatter datetime={sessionStorage.getItem('tdate')}/>}</div>
                        </div>
                            {/* <span className="glyphicon glyphicon-menu-down headericon"></span> */}
                        {/* <span style={{color:'#ffffff'}}><a style={{textDecoration:'underline',color:'#ffffff'}}>
                        <Link style={{color:'#ffffff'}} to="/helpdetail" >Help</Link></a>&nbsp;&nbsp;</span> */}
                    {/* <span><Link to="/MYSETTINGS" style={{color:'#ffffff',textDecoration:'underline'}} >My Settings</Link>&nbsp;&nbsp;</span> */}
                        <a href='javascript:void(0);' onClick={this.logout} className="btn btn-danger btnPrimary">Logout</a>
                        {/* <div style={{paddingLeft:'60px',marginTop:'6px'}}>
                        <img  src="/src/images/notification_icon.png" width="18px" height='12px' />
                        &nbsp;&nbsp;<a style={{textDecoration:'underline',color:'#ffffff'}}>
                        <Link style={{color:'#ffffff'}} to="/notifications" >Notifications ({sessionStorage.getItem('notificationCnt')})</Link>
                        </a>
                        </div> */}
                    </div>

                </div>

                <div className="clearfix"></div>
                <div id="navbar" className={classes.navBar}>
                <nav className="navbar navbar-default navbar-static-top">
                    <div className="collapse navbar-collapse" id="navbar-collapse-1">

                    <div key="newline" className="clearfix"></div>
                        <ul className="nav navbar-nav">
                            {linkmap}
                        </ul>
                    </div>
                </nav>
            </div>
            </MuiThemeProvider>
	    <Dialog  fullWidth={true}
		maxWidth={'xs'}
		open={this.state.logout}
		onClose={this.handleClose}
		aria-labelledby="form-dialog-title">
			<DialogTitle id="form-dialog-title">
				 Thank's for using our services.
			</DialogTitle>
			<DialogContent>
				<div className={classes.ContentBorderStyle}>
					<div>Click "Ok" to Logoff  </div>
					<div className="clearfix"></div>
				<br/>
					<div>Click "Cancel" to return to Liquidity Portal</div>
				</div>
			</DialogContent>
			<DialogActions>
			 <div className="col-md-12 col-sm-12" style={{textAlign:'center'}}>
				<Link to="/logOut" onClick={this.doLogOut} className="btn btn-primary btn-xs">
					Ok
				</Link>
				<button onClick={this.handleClose}  className="btn btn-primary btn-xs">
					Cancel
				</button>
			</div>
			</DialogActions>
	     </Dialog>
		</div>
        );
    }
}
function mapStateToProps(state) {
    const { navlinks } = state;
     let filterMap;
      let result = navlinks.navlinks;

	        let pendTrdOperValue;
	        let pendFutureTrdOperValue;
	        let oldPendCount;
	        let oldPendFutureCount;
	        let notificationCnt;

	        if(result !== undefined){
	            result=Array.from(result)
	           filterMap = result.map((filter,index) => {
 	                  if(filter.name === "pendTrdOperValue"){
						  pendTrdOperValue = filter.value;
					  }else  if(filter.name === "pendFutureTrdOperValue"){
						  pendFutureTrdOperValue = filter.value;
					  }else  if(filter.name === "oldPendCount"){
						  oldPendCount = filter.value;
					  }else  if(filter.name === "oldPendFutureCount"){
						  oldPendFutureCount = filter.value;
					  }else  if(filter.name === "notificationCnt"){
						  notificationCnt = filter.value;
				 	 }
			  });
		  }

    return { navlinks ,pendTrdOperValue,pendFutureTrdOperValue,oldPendCount,oldPendFutureCount,notificationCnt };
}

const connectedNavBar = connect(mapStateToProps)(withStyles(MuiStyles)(NavBar));
export { connectedNavBar as NavBar };
