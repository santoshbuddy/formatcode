import {error,success,handleMsgClose} from '../../messages/Message';

export function updateMenubarRefreshElem(xmlStr ,refreshData) {
	if(xmlStr !== undefined){
 	 let xml = new DOMParser().parseFromString(xmlStr, 'application/xml');

	 if(xml.getElementsByTagName("TodaysDate")[0]!=null) {
		dispDate(xml,refreshData);
	}
	if(xml.getElementsByTagName("pendTrdCntFlag")[0]!=null) {
		dispMenuPendingTradeCnt(xml,refreshData);
	}
	if(xml.getElementsByTagName("pendFutureTrdCnt")[0]!=null) {
		dispMenuPendingFutureTradeCnt(xml,refreshData);
	}
	if(xml.getElementsByTagName("NOTIFICATIONCOUNT")[0]!=null) {
		dispNotificationCount(xml,refreshData);
	}

	}
}


export function dispNotificationCount(xml,refreshData)
{
	if(xml.getElementsByTagName("NOTIFICATIONCOUNT")[0] != null) {
		var notificationCnt = xml.getElementsByTagName("NOTIFICATIONCOUNT")[0].firstChild.nodeValue;
		 refreshData.notificationCnt = notificationCnt;
	}

}

export function dispDate(xml,refreshData)
{
	if(xml.getElementsByTagName("TodaysDate")[0] != null) {
		var tdate = xml.getElementsByTagName("TodaysDate")[0].firstChild.nodeValue;
 		refreshData.tdate = tdate;
	}

}

export function dispMenuPendingTradeCnt (xml,refreshData) {
    		var currPendCount = parseInt(xml.getElementsByTagName("CURRTRADECOUNT")[0].firstChild.nodeValue);

   		refreshData.currPendCount = currPendCount;

}

export function dispMenuPendingFutureTradeCnt (xml,refreshData) {
 		if(xml.getElementsByTagName("CURRFUTURETRADECOUNT")[0] != null) {
			var currPendCount = parseInt(xml.getElementsByTagName("CURRFUTURETRADECOUNT")[0].firstChild.nodeValue);

 			refreshData.pendFutureCount = currPendCount;
		}

}



