import { tradeConstants } from '../constants/trade.constants';
import { tradeService } from '../services/trade.service';

export const tradeActions = {
    fetchTradeData,
    fetchTradeReviewData,
    fetchTradeConfirmData,
    fetchFixedData,
    fetchFixedTradeReviewData,
    fetchFixedTradeConfirmData,
    fetchTenorpopupData,
    fetchfutureTradeConfirmData,
    fetchFutureFixedTradeConfirmData,
    fetchFixedRolloverTradeReviewData,
    fetchFixedRolloverTradeConfirmData
};

function fetchTradeData(bodyFormdata) {
    return dispatch => {
        dispatch(request());

        tradeService.fetchTradeTable(bodyFormdata)
            .then(
                tradedata => dispatch(success(tradedata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETTRADEDATA_REQUEST } }
    function success(tradedata) { return { type: tradeConstants.GETTRADEDATA_SUCCESS, tradedata } }
    function failure(error) { return { type: tradeConstants.GETTRADEDATA_FAILURE, error } }
}

function fetchTradeReviewData(bodyFormData){ 
    
    return dispatch => {
        dispatch(request());

        tradeService.fetchReviewData(bodyFormData)
            .then(
                tradereviewdata => dispatch(success(tradereviewdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETTRADEREVIEWDATA_REQUEST } }
    function success(tradereviewdata) { return { type: tradeConstants.GETTRADEREVIEWDATA_SUCCESS, tradereviewdata } }
    function failure(error) { return { type: tradeConstants.GETTRADEREVIEWDATA_FAILURE, error } }
 
}

function fetchFixedTradeReviewData(bodyFormData){ 
    
    return dispatch => {
        dispatch(request());

        tradeService.fetchFixedReviewData(bodyFormData)
            .then(
                fixedtradereviewdata => dispatch(success(fixedtradereviewdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETFIXEDTRADEREVIEWDATA_REQUEST } }
    function success(fixedtradereviewdata) { return { type: tradeConstants.GETFIXEDTRADEREVIEWDATA_SUCCESS, fixedtradereviewdata } }
    function failure(error) { return { type: tradeConstants.GETFIXEDTRADEREVIEWDATA_FAILURE, error } }
 
}
function fetchFixedRolloverTradeReviewData(bodyFormData){ 
    
    return dispatch => {
        dispatch(request());

        tradeService.fetchFixedRolloverReviewData(bodyFormData)
            .then(
                rolloverfixedtradereviewdata => dispatch(success(rolloverfixedtradereviewdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETFIXEDROLLTRADEREVIEWDATA_REQUEST } }
    function success(rolloverfixedtradereviewdata) { return { type: tradeConstants.GETFIXEDROLLTRADEREVIEWDATA_SUCCESS, rolloverfixedtradereviewdata } }
    function failure(error) { return { type: tradeConstants.GETFIXEDROLLTRADEREVIEWDATA_FAILURE, error } }
 
}
function fetchFixedRolloverTradeConfirmData(bodyFormData){ 
    
    return dispatch => {
        dispatch(request());

        tradeService.fetchFixedRolloverConfirmData(bodyFormData)
            .then(
                rolloverfixedtradeconfirmdata => dispatch(success(rolloverfixedtradeconfirmdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETFIXEDROLLTRADECONFIRMDATA_REQUEST } }
    function success(rolloverfixedtradeconfirmdata) { return { type: tradeConstants.GETFIXEDROLLTRADECONFIRMDATA_SUCCESS, rolloverfixedtradeconfirmdata } }
    function failure(error) { return { type: tradeConstants.GETFIXEDROLLTRADECONFIRMDATA_FAILURE, error } }
 
}

function fetchTradeConfirmData(bodyFormData){  
    return dispatch => {
        dispatch(request());

        tradeService.fetchConfirmData(bodyFormData)
            .then(
                tradeconfirmdata => dispatch(success(tradeconfirmdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETTRADECONFIRMDATA_REQUEST } }
    function success(tradeconfirmdata) { return { type: tradeConstants.GETTRADECONFIRMDATA_SUCCESS, tradeconfirmdata } }
    function failure(error) { return { type: tradeConstants.GETTRADECONFIRMDATA_FAILURE, error } }
 
}
function fetchfutureTradeConfirmData(bodyFormData){  
    return dispatch => {
        dispatch(request());

        tradeService.fetchfutureConfirmData(bodyFormData)
            .then(
                futuretradeconfirmdata => dispatch(success(futuretradeconfirmdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETFUTURETRADECONFIRMDATA_REQUEST } }
    function success(futuretradeconfirmdata) { return { type: tradeConstants.GETFUTURETRADECONFIRMDATA_SUCCESS, futuretradeconfirmdata } }
    function failure(error) { return { type: tradeConstants.GETFUTURETRADECONFIRMDATA_FAILURE, error } }
 
}
function fetchFixedData() {
    return dispatch => {
        dispatch(request());

        tradeService.fetchFixedTableData()
            .then(
                fixedtradedata => dispatch(success(fixedtradedata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETFIXEDDATA_REQUEST } }
    function success(fixedtradedata) { return { type: tradeConstants.GETFIXEDDATA_SUCCESS, fixedtradedata } }
    function failure(error) { return { type: tradeConstants.GETFIXEDDATA_FAILURE, error } }
}

function fetchFixedTradeConfirmData(bodyFormData){  
    return dispatch => {
        dispatch(request());

        tradeService.fetchFixedConfirmData(bodyFormData)
            .then(
                fixedtradeconfirmdata => dispatch(success(fixedtradeconfirmdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETFIXEDTRADECONFIRMDATA_REQUEST } }
    function success(fixedtradeconfirmdata) { return { type: tradeConstants.GETFIXEDTRADECONFIRMDATA_SUCCESS, fixedtradeconfirmdata } }
    function failure(error) { return { type: tradeConstants.GETFIXEDTRADECONFIRMDATA_FAILURE, error } }
 
}
function fetchFutureFixedTradeConfirmData(bodyFormData){  
    return dispatch => {
        dispatch(request());

        tradeService.fetchFutureFixedConfirmData(bodyFormData)
            .then(
                futurefixedtradeconfirmdata => dispatch(success(futurefixedtradeconfirmdata)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETFUTUREFIXEDTRADECONFIRMDATA_REQUEST } }
    function success(futurefixedtradeconfirmdata) { return { type: tradeConstants.GETFUTUREFIXEDTRADECONFIRMDATA_SUCCESS, futurefixedtradeconfirmdata } }
    function failure(error) { return { type: tradeConstants.GETFUTUREFIXEDTRADECONFIRMDATA_FAILURE, error } }
 
}

function fetchTenorpopupData(bodyFormData){
    return dispatch => {
        dispatch(request());

        tradeService.fetchTenorupData(bodyFormData)
            .then(
                tenorpopupData => dispatch(success(tenorpopupData)),
                error => dispatch(failure(error))
            );
    };

    function request() { return { type: tradeConstants.GETTENORPOPUPDATA_REQUEST } }
    function success(tenorpopupData) { return { type: tradeConstants.GETTENORPOPUPDATA_SUCCESS, tenorpopupData } }
    function failure(error) { return { type: tradeConstants.GETTENORPOPUPDATA_FAILURE, error } }

}