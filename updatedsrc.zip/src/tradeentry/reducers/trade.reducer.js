import { tradeConstants } from '../constants/trade.constants';

export function tradedata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETTRADEDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETTRADEDATA_SUCCESS:
        return {
            tradedata: action.tradedata
        };
      case tradeConstants.GETTRADEDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }

  export function tradereviewdata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETTRADEREVIEWDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETTRADEREVIEWDATA_SUCCESS:
        return {
            tradereviewdata: action.tradereviewdata
        };
      case tradeConstants.GETTRADEREVIEWDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
  

  export function tradeconfirmdata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETTRADECONFIRMDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETTRADECONFIRMDATA_SUCCESS:
        return {
            tradeconfirmdata: action.tradeconfirmdata
        };
      case tradeConstants.GETTRADECONFIRMDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }

  export function fixedtradedata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETFIXEDDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETFIXEDDATA_SUCCESS:
        return {
            fixedtradedata: action.fixedtradedata
        };
      case tradeConstants.GETFIXEDDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }

  export function fixedtradereviewdata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETFIXEDTRADEREVIEWDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETFIXEDTRADEREVIEWDATA_SUCCESS:
        return {
          fixedtradereviewdata: action.fixedtradereviewdata
        };
      case tradeConstants.GETFIXEDTRADEREVIEWDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
  export function rolloverfixedtradereviewdata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETFIXEDROLLTRADEREVIEWDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETFIXEDROLLTRADEREVIEWDATA_SUCCESS:
        return {
          rolloverfixedtradereviewdata: action.rolloverfixedtradereviewdata
        };
      case tradeConstants.GETFIXEDROLLTRADEREVIEWDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
  export function rolloverfixedtradeconfirmdata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETFIXEDROLLTRADECONFIRMDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETFIXEDROLLTRADECONFIRMDATA_SUCCESS:
        return {
          rolloverfixedtradeconfirmdata: action.rolloverfixedtradeconfirmdata
        };
      case tradeConstants.GETFIXEDROLLTRADECONFIRMDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }

  export function fixedtradeconfirmdata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETFIXEDTRADECONFIRMDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETFIXEDTRADECONFIRMDATA_SUCCESS:
        return {
          fixedtradeconfirmdata: action.fixedtradeconfirmdata
        };
      case tradeConstants.GETFIXEDTRADECONFIRMDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
  export function futuretradeconfirmdata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETFUTURETRADECONFIRMDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETFUTURETRADECONFIRMDATA_SUCCESS:
        return {
          futuretradeconfirmdata: action.futuretradeconfirmdata
        };
      case tradeConstants.GETFUTURETRADECONFIRMDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
  export function futurefixedtradeconfirmdata(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETFUTUREFIXEDTRADECONFIRMDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETFUTUREFIXEDTRADECONFIRMDATA_SUCCESS:
        return {
          futurefixedtradeconfirmdata: action.futurefixedtradeconfirmdata
        };
      case tradeConstants.GETFUTUREFIXEDTRADECONFIRMDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }

  export function tenorpopupData(state = {}, action) {
    switch (action.type) {
      case tradeConstants.GETTENORPOPUPDATA_REQUEST:
        return {
          loading: true
        };
      case tradeConstants.GETTENORPOPUPDATA_SUCCESS:
        return {
          tenorpopupData: action.tenorpopupData
        };
      case tradeConstants.GETTENORPOPUPDATA_FAILURE:
        return { 
          error: action.error
        };
      
      default:
        return state
    }
  }
  

 
 