import React from 'react';
 import {IsCharsInBag} from './amountValidations';
 import {addCommasAmntLocale} from './amountValidations';
 import TenorPopup from './TenorPopup';
 import DatePicker from 'react-datepicker';
 import Loading from '../../common/Loading';
 import axios from 'axios';
 import { alertConstants } from '../../common/constants/alert.constants';
 var dateFormat = require('dateformat');
 var data;
 var res;
 var futureDate=new Date()
 var matureDate=new Date();
 let tenorpopbtn=false;
var datelbl='Today';
class EnterTrade extends React.Component {
    constructor(props) {
        super(props);
        this.state={fflag:false,tenor:'1 Day',insrate:'',loading:false,dateshow:'none',clntRateRange:'',startDate: futureDate,tenorpopbtn:false,ck:'',amount:[],clntRateRange:[],rateFrom:[],rateTo:[],amtvalue:'',Interest_Rate:'',idisabled:true,disabled:false,flag:'',adddisp:'none',addnotes:''}
        this.doSubmit = this.doSubmit.bind(this);
        this.doConfirm = this.doConfirm.bind(this);
        this.addNotes = this.addNotes.bind(this);
        this.investChange = this.investChange.bind(this);
        this.futureChange = this.futureChange.bind(this);
        this.handleStartDateChange = this.handleStartDateChange.bind(this);
        this.onlyChange = this.onlyChange.bind(this);
    }
    doSubmit(){
        if(this.props.fixed !== "fixed"){
        var vData;
        var fld;
        var validFlag=true;
        if(this.props.data !== undefined){
            vData = this.props.data;
            for(var i in vData){
                fld=this.refs["tempAmount"+i];
                //alert("tempAmount:::value.:"+fld.value.length)
                if(fld.value.length<=0)
                {
                    alert("Please Enter valid amount");
                    validFlag=false;
                    //fld.focus();
                    break;
                }
                if(!(IsCharsInBag(fld.value,"0123456789.,MMmmKKkk")))
                {
                    alert("Invalid amount -  try again");
                    validFlag=false;
                    //fld.focus();
                    break;
                }
            }
        }

        if(validFlag==true){
            //alert("success");
            this.props.method(this.refs)
        }
    }else{
        if(res.paymentMethod === "NONE")
            alert("Selected DDA account is currently not available for trading, please try again later")
        else{
            if(this.state.amtvalue !== ''){
                this.setState({disabled:true})
                this.setState({flag:"confirm"})
                this.setState({addnotes:this.refs.addNotes.value})
                this.setState({adddisp:'none'});

            }else{
                alert("Please Enter Investment Amount");
            }
        }
    }
    }
    doConfirm(){

        if(this.props.fixed !== "fixed"){
            this.props.method2(this.props.selectedRows,this.state.amount,this.state.Interest_Rate,res,this.state.clntRateRange,this.state.rateFrom,this.state.rateTo,dateFormat(futureDate,"mmm d, yyyy"))
        }else{
            this.props.method2(this.props.selectedRows,this.state.amtvalue,this.state.Interest_Rate,res,this.state.clntRateRange,this.state.rateFrom,this.state.rateTo,dateFormat(futureDate,"mmm d, yyyy"),dateFormat(matureDate,"mmm d, yyyy"),this.state.fflag)
        }
        this.setState({loading:true})
    }
    doTenor(){
         this.setState({tenorpopbtn:true});
    }
    amountChange(e,userLocale){
        var res;
        this.props.data && this.props.data.map((item,index) => {
            if(item.name === "data"){
                res = item.values[0].TradeDetails;
            }
        })

        // console.log(parseFloat(e.target.value.replace(/,/g,"")) +"-->"+ parseFloat(res.maxDollar) +"-->"+  parseFloat(res.minDollar))
        // console.log((parseFloat(e.target.value.replace(/,/g,"")) > parseFloat(res.maxDollar)))
        // console.log((parseFloat(e.target.value.replace(/,/g,"")) < parseFloat(res.minDollar) ))
        //addCommasAmount(e);
        addCommasAmntLocale(e,userLocale);
        if(this.props.fixed === "fixed"){
        if((parseFloat(e.target.value.replace(/,/g,"")) > parseFloat(res.maxDollar)) || (parseFloat(e.target.value.replace(/,/g,"")) < parseFloat(res.minDollar) )){
            alert("Please Enter Amount min max range");
            this.setState({Interest_Rate:""})
            this.setState({insrate:""})
            this.setState({amtvalue:""})
            document.getElementById("amount").value="";
        }
        else{

            this.setState({amtvalue:e.target.value})
            var jsonBody = new FormData();



            var user = JSON.parse(sessionStorage.getItem('user'));
            jsonBody.append("token",user[0].token)
            jsonBody.append("ajaxFlag","YES");
            jsonBody.append("dollarAmount",e.target.value);
            jsonBody.append("clCompanyId",JSON.parse(sessionStorage.getItem('clientFirm')));
            jsonBody.append("product",res.productId);
            jsonBody.append("currencyCode",res.currency);
            jsonBody.append("transType",res.transType);
            jsonBody.append("tenorType",res.tenorType);
            jsonBody.append("selectedDDAAcctNbr",res.selectedDDAAcctNbr);
            jsonBody.append("deskId",res.deskId);
            jsonBody.append("investAccount",res.investAccount);
            jsonBody.append("branchId",res.branchId);
            jsonBody.append("groupId",res.groupId);
            jsonBody.append("exactDuration",res.exactDuration);
            jsonBody.append("newDuration",res.newDuration);

            axios({
                method: 'post',
                url:alertConstants.URL+"/TERMDEALING.do",
                data: jsonBody,
                config: { headers: {'Content-Type': 'multipart/form-data' }}
                }).then((response)=>{
                    this.setState({Interest_Rate:response.data.InterestRate})
                    this.setState({insrate:response.data.InterestAmount})
                });
            }
        }

   }
    addNotes(e){
        var id = e.target.id;
        this.refs["addNotes"+id].style.display ='block';
       this.setState({adddisp:'block'});
    }
    investChange(e){

        var index = e.target.selectedIndex;

        var temp = e.target.value;
        res.investAccount = e.target[index].text;

        data && data.map((item,index) => {
            if(item.name === "Funding Account"){
                var fundrows = item.rows.find(e => e.id===temp)

                data && data.map((filter,index) => {
                    if(filter.label === "Funding Account"){
                        filter.values = fundrows.rows;
                        res.fundingAccount = fundrows.rows[0].name;
                        res.paymentMethod = fundrows.rows[0].name;
                    }
                 })
            }
            if(item.name === "Maturity Account"){
                var fundrows = item.rows.find(e => e.id===temp)
                data && data.map((filter,index) => {
                    if(filter.label === "Maturity Account"){
                        filter.values = fundrows.rows;
                        res.maturityAccount = fundrows.rows[0].name;
                    }
                 })
            }
        })

        this.setState({ck:0})
    }

    onSelect = (selectRow) => {
       res.tenorFlag=selectRow.tenorFlag;
       res.durationFrom=selectRow.durationFrom;
       res.durationTo=selectRow.durationTo;

       res.exactDuration=selectRow.exactDuration;
       res.newDuration=selectRow.exactDuration;

       res.maturityDate=selectRow.MaturityDate;
       res.Interest_Rate=selectRow.Rate
       res.interestRate=selectRow.interestRate
       this.setState({Interest_Rate:selectRow.Rate})
       this.setState({tenorpopbtn:false})
       this.setState({tenor:selectRow.Tenor})

       var jsonBody = new FormData();
        if(this.props.fixed === "fixed"){

        this.props.data && this.props.data.map((item,index) => {
            if(item.name === "data"){
                res = item.values[0].TradeDetails;
            }
        })
        var user = JSON.parse(sessionStorage.getItem('user'));
        jsonBody.append("token",user[0].token)
        jsonBody.append("ajaxFlag","YES");
        jsonBody.append("dollarAmount",this.state.amtvalue);
        jsonBody.append("clCompanyId",JSON.parse(sessionStorage.getItem('clientFirm')));
        jsonBody.append("product",res.productId);
        jsonBody.append("currencyCode",res.currency);
        jsonBody.append("transType",res.transType);
        jsonBody.append("tenorType",res.tenorType);
        jsonBody.append("selectedDDAAcctNbr",res.selectedDDAAcctNbr);
        jsonBody.append("deskId",res.deskId);
        jsonBody.append("investAccount",res.investAccount);
        jsonBody.append("branchId",res.branchId);
        jsonBody.append("groupId",res.groupId);
        jsonBody.append("exactDuration",res.exactDuration);
        jsonBody.append("newDuration",res.newDuration);

        axios({
            method: 'post',
            url:alertConstants.URL+"/TERMDEALING.do",
            data: jsonBody,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
            }).then((response)=>{
                this.setState({Interest_Rate:response.data.InterestRate})
                this.setState({insrate:response.data.InterestAmount})
            });
        }
    }
    doClose = () =>{
       this.setState({tenorpopbtn:false})
    }
    handleStartDateChange(date) {
        futureDate =dateFormat(date,"mmm d, yyyy")
        this.setState({startDate:date});
     }
     onlyChange(e){

            if(e.target.checked){
             this.setState({idisabled:false})
             this.setState({clntRateRange:"Y"})
            }else
             this.setState({idisabled:true})

     }
    futureChange(){
        futureDate.setDate(futureDate.getDate() + 1);
        matureDate.setDate(matureDate.getDate() + 2);
        this.setState({fflag:true})
        datelbl ='Future Date';
        this.setState({dateshow:'block'})
    }
    render(){
        //let userLocale="tr_TR";
         //let userLocale="en_US";
         let userLocale="";
         var user = JSON.parse(sessionStorage.getItem('user'));
	 if(user[0].localeLang !== undefined){
	      userLocale=user[0].localeLang;
 	 }
        //alert(userLocale);

        if(this.state.loading)
         return( <div className="col-md-12" style={{marginTop:'10%',marginBottom:'10%'}}><div className="clearfix"></div><Loading/></div> );
        else{
         var date = dateFormat(new Date(),"mmm d, yyyy");

        let entertrademarkup,tradedate,tradeDetails;
        let buttonMarkup,terormarkup,wam;

        if(this.props.fixed === "fixed"){
            var results1;

            if(this.props.data !== undefined){
                data = this.props.data;
                if(this.state.flag !== "confirm"){

                tradedate =
                <div>
                    <div  className="form-group col-md-2 col-sm-2">
                        <input  name="date"  type="radio" defaultChecked={true}/>
                        <label> Today ({date}) </label>
                    </div>
                    <div  className="form-group col-md-6 col-sm-2">
                        <input className="pull-left" name="date"  type="radio" onChange={this.futureChange} />
                        <label className="pull-left" style={{marginTop:'4px'}}> Future Date</label>
                        <div className="form-group col-md-4 col-sm-4" style={{display:this.state.dateshow}}>
                            <DatePicker dateFormat="MMM dd, YYYY" selected={this.state.startDate} name="futureDate" ref="futureDate" className="form-control"  onChange={this.handleStartDateChange} />
                        </div>
                    </div>
                </div>
                entertrademarkup = data && data.map((filter,index) => {
                    if(filter.type === "select"){


                        return(
                         <div className="form-group col-md-2 col-sm-2" key={filter.id.toString()}>
                              <label> { filter.label } :</label>
                              <select ref={ filter.name }  name={filter.name} className="form-control input-sm" onChange={(e) => this.investChange(e)}>
                                 {
                                      filter.values && filter.values.map((obj,index) => {
                                         return <option key={index} value={obj.id}>{obj.name}</option>
                                     })
                                  }
                              </select>
                          </div>
                          );
                       }
                })
            }else{
                tradedate =
                    <div>
                        <div  className="form-group col-md-2 col-sm-2">
                            <label> {datelbl} ({date}) </label>
                        </div>

                    </div>
                entertrademarkup = data && data.map((filter,index) => {
                    if(filter.type === "select"){
                        var valuelabel;
                        if(this.refs[filter.name] !== undefined)
                         if(filter.name === "investAccount"){
                            valuelabel= filter.values.find(e => e.id===this.refs[filter.name].value).name;
                         }else
                          valuelabel = this.refs[filter.name].value;

                        return(
                         <div className="form-group col-md-4 col-sm-4" key={filter.id.toString()}>
                              <label  className="pull-left"> { filter.label } :</label>
                              <label className="pull-right TxtNrml"> { valuelabel }</label>
                          </div>
                          );
                       }
                })

            }

                data && data.map((item,index) => {
                    if(item.name === "data"){
                        res = item.values[0].TradeDetails;

                    }
                })
                if(this.state.flag !== "confirm"){
                    buttonMarkup =  <button className="btn btn-primary btn-xs mt pull-right" onClick={this.doSubmit.bind(this)}>Review Trade</button>
                    terormarkup = <button className="btn btn-primary btn-xs" onClick={ev => {  this.setState({tenorpopbtn:true})}}>Tenor</button>
                }else{
                    buttonMarkup =  <button className="btn btn-primary btn-xs mt pull-right" onClick={this.doConfirm.bind(this)}>Confirm Trade</button>
                }

                // var insrate;
                if(res !== undefined){
                //  insrate = (((parseInt(this.state.amtvalue) * parseFloat(this.state.Interest_Rate))/100)/parseInt(res.newDuration.toString())).toFixed(4);
                // if(insrate === "NaN")
                //   insrate ="";

                tradeDetails =
                         <div  key="tradedetails">
                         <table className="table table-bordered" width="100%">
                             <tbody>
                             <tr>
                                 <td width="30%" className="paddAll">
                                    <div  className="form-group">
                                        <label className="pull-left">Value Date:</label>
                                        <label className="pull-right TxtNrml">{res.valueDate}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Investment Amount:</label>
                                        <label className="pull-right TxtNrml"><input disabled={this.state.disabled} type="text" ref={"amount"} id={"amount"} name={"amount"} onBlur={(e)=>{this.amountChange(e,userLocale)}}/> {res.currency}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                    <label>Min. {parseFloat(res.minDollar).toFixed(4)} - Max. {parseFloat(res.maxDollar).toFixed(4)} </label>
                                    <div className="clearfix"></div>
                        <div className="col-md-12" style={{display:this.state.dateshow}}>
                            <input type="checkbox" ref={"clntRateRange"} value={this.state.clntRateRange} onClick={this.onlyChange}/>
                            <label>Only Execute if Previous day rate is between:</label>
                            <input type="text" ref={"rateFrom"} name={"rateFrom"} size="4" disabled={this.state.idisabled}/>% and <input type="text" ref={"rateTo"} name={"rateTo"} size="4" disabled={this.state.idisabled}/> %
                        </div>
                                    <div className="clearfix"></div>
                                    {
                                        this.state.flag !== "confirm" &&
                                        <div>
                                            <a onClick={(e)=>this.addNotes(e)}>Add Notes to Trade(Optional)</a>
                                            <textarea ref="addNotes" style={{display:this.state.adddisp}} rows="5" cols="15"/>
                                        </div>
                                    }
                                 </td>
                                 <td width="30%" className="paddAll">
                                    <div  className="form-group">
                                        <label className="pull-left">Maturity Date:</label>
                                        <label className="pull-right TxtNrml">{res.maturityDate}</label>
                                    </div>
                                    {terormarkup}
                                     <TenorPopup open={this.state.tenorpopbtn} doClose={this.doClose}  issueChild={res.productId} 	currency={res.currency} tenorType={res.tenorType} companyid={res.deskId} transDate={res.transDate}
                                     investAccount={res.investAccount}  groupId={res.groupId} branchId={res.branchId} onSelect={this.onSelect} amount={this.state.amtvalue} transType={res.transType} prodCat={res.prodCat}/>
                                 </td>
                                 <td className="paddAll">
                                 {
                                    this.state.addnotes !== "" &&
                                    <div  className="form-group">
                                        <label className="pull-left"> View Notes:</label>
                                        <label className="pull-right TxtNrml">{this.state.addnotes}</label>
                                    </div>
                                 }
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Product:</label>
                                        <label className="pull-right TxtNrml">{res.product}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Amount:({res.currency})</label>
                                        <label className="pull-right TxtNrml">{this.state.amtvalue}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Interest Rate:({this.state.tenor})</label>
                                        <label className="pull-right TxtNrml">{this.state.Interest_Rate}%</label>
                                    </div>
                                    <hr/>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Total Interest:({res.currency})</label>
                                        <label className="pull-right TxtNrml">{this.state.insrate}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                   {
                                    this.state.flag === "confirm" &&

                                        <div  className="form-group">
                                            <label className="pull-left">Total Amount:({res.currency})</label>
                                            <label className="pull-right TxtNrml">{(parseFloat(this.state.insrate.replace(/,/g,""))+parseFloat(this.state.amtvalue.replace(/,/g,""))).toFixed(4)}</label>
                                        </div>
                                   }
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Cut-Off time:</label>
                                        <label className="pull-right TxtNrml">{res.Cut_Off_time}</label>
                                    </div>
                                    <div className="clearfix"></div>
                                    <div  className="form-group">
                                        <label className="pull-left">Trading Hours:</label>
                                        <label className="pull-right TxtNrml">{res.Trading_Hours}</label>
                                    </div>


                                 </td>
                             </tr>
                             </tbody>
                         </table>
                        </div>
                }
            }
                var arr1 =[];
                for(var k in data){
                    arr1.push(data[k])
                }

                var obj = this.props.selectedRows;
                var arr = [];

                for(var k in obj){
                    arr.push({
                        "rowNumber" : k
                    });
                }

                if(this.refs.rateFrom !== undefined){
                    this.state.rateFrom=this.refs.rateFrom.value;

                }
                if(this.refs.rateTo !== undefined){
                    this.state.rateTo=this.refs.rateTo.value;
                }


        }else{

                if(this.props.data !== undefined)
                data = this.props.data;

            var arr1 =[];
                for(var k in data){
                    arr1.push(data[k])
                }

                var obj = this.props.selectedRows;
                var arr = [];

                for(var k in obj){
                    arr.push({
                        "rowNumber" : k
                    });
                }

                if(this.props.flag !== "confirm"){
                    buttonMarkup =  <button className="btn btn-primary btn-xs mt pull-right" onClick={this.doSubmit.bind(this)}>Review Trade</button>
                }else{
                    buttonMarkup =  <button className="btn btn-primary btn-xs mt pull-right" onClick={this.doConfirm.bind(this)}>Confirm Trade</button>
                }

                if(data !== undefined){
                entertrademarkup = arr1 && arr1.map((item,index) => {
                    var obj = item;
                    let selectMarkup,selectMarkup1;

                    if(this.props.flag !== "confirm"){
                        wam =
                        <div>
                            <div>
                        <label>WAM1 (max):</label>
				     	<label className="pull-right TxtNrml">60 days</label>
				</div>
				<div>
				     	<label>WAL2 (max):</label>
				     	<label className="pull-right TxtNrml">120 days</label>
				</div>
				<div>
				     	<label>Maturity (max):</label>
				     	<label className="pull-right TxtNrml">397 days</label>
				</div>
				<div>
				     	<label>Daily liquid assets (min):</label>
				     	<label className="pull-right TxtNrml">10%</label>
				</div>
				<div>
				     	<label>Weekly liquid assets (min):</label>
				     	<label className="pull-right TxtNrml" style={{color:'red'}}>32%</label>
                                </div>
                        </div>
                        tradedate =
                        <div>
                            <div  className="form-group col-md-2 col-sm-2">
                                <input name="date" type="radio" defaultChecked={true}/>
                                <label> Today ({date}) </label>
                            </div>
                            <div  className="form-group col-md-6 ">
                                <input  className="pull-left" name="date" type="radio" onChange={this.futureChange}/>
                                <label className="pull-left" style={{marginTop:'4px'}}> Future Date</label>

                                <div className="form-group col-md-4 col-sm-4" style={{display:this.state.dateshow}}>
                                    <DatePicker dateFormat="MMM dd, YYYY" selected={this.state.startDate} name="futureDate" ref="futureDate" className="form-control"  onChange={this.handleStartDateChange} />
                                </div>
                            </div>
                        </div>

                        selectMarkup =  <div>
                        <div  className="form-group">
                                    <label> Investment:   </label>
                                </div>
                        <div  className="form-group">
                        <select>
                            {
                            obj.transTypes && obj.transTypes.map((obj,index) => {
                                return <option key={index} value={obj.id}>{obj.value}</option>
                            })
                        }
                        </select>
                        <input type="text" ref={"tempAmount"+obj.rowNumber.toString()} name={"tempAmount"+obj.rowNumber.toString()}  onBlur={(e)=>{this.amountChange(e,userLocale)}}/>
                        <label>{obj.CurrencyCode} in Cash </label>

                </div>
                <div className="clearfix"></div>
                        <div className="col-md-4" style={{display:this.state.dateshow}}>
                            <input type="checkbox" ref={"clntRateRange"+obj.rowNumber.toString()} value={this.state.clntRateRange} onClick={this.onlyChange}/>
                            <label>Only Execute if Previous day rate is between:</label>
                            <input type="text" ref={"rateFrom"+obj.rowNumber.toString()} name={"rateFrom"+obj.rowNumber.toString()} size="4" disabled={this.state.idisabled}/>% and <input type="text" ref={"rateTo"+obj.rowNumber.toString()} name={"rateTo"+obj.rowNumber.toString()} size="4" disabled={this.state.idisabled}/> %
                        </div>
                        <div className="clearfix"></div>
                    <div  className="form-group">
                        <a id={obj.rowNumber.toString()} onClick={this.addNotes}> Add notes (Optional)   </a>
                        <textarea ref={"addNotes"+obj.rowNumber.toString()} style={{display:'none'}} rows="5" cols="15"/>
                    </div></div>
                    }else{
                        var temp='';
                        var temp1='',clntRateRange='',rateFrom='',rateTo='';
                        tradedate =
                        <div>
                            <div  className="form-group col-md-2 col-sm-2">
                                <label> {datelbl} ({date}) </label>
                            </div>

                        </div>

                        if(this.props.amount["tempAmount"+obj.rowNumber] !== undefined){
                         temp = this.props.amount["tempAmount"+obj.rowNumber].value;
                        }
                        if(this.props.amount["addNotes"+obj.rowNumber] !== undefined){
                         temp1 = this.props.amount["addNotes"+obj.rowNumber].value;
                        }
                        if(this.props.amount["clntRateRange"+obj.rowNumber] !== undefined){
                            clntRateRange = this.props.amount["clntRateRange"+obj.rowNumber].value;
                        }
                        if(this.props.amount["rateFrom"+obj.rowNumber] !== undefined){
                            rateFrom = this.props.amount["rateFrom"+obj.rowNumber].value;
                        }
                        if(this.props.amount["rateTo"+obj.rowNumber] !== undefined){
                            rateTo = this.props.amount["rateTo"+obj.rowNumber].value;
                        }

                        this.state.amount.push(temp);
                        this.state.clntRateRange.push(clntRateRange);
                        this.state.rateFrom.push(rateFrom);
                        this.state.rateTo.push(rateTo);

                        selectMarkup =  <div><div  className="form-group">
                                <label>Purchase</label>
                            </div>
                            <div className="clearfix"></div>
                            <div  className="form-group">
                                <label className="pull-left"> Cash ({obj.CurrencyCode}):</label>

                                <label className="pull-right TxtNrml">{temp}</label>
                            </div>
                            <div className="clearfix"></div>
                            <div  className="form-group">
                                <label className="pull-left">Shares:</label>
                                <label className="pull-right TxtNrml">{temp}</label>
                            </div>
                        </div>

                    selectMarkup1 =  <td className="paddAll"><div>

                        <div  className="form-group">
                    <label className="pull-left"> View Notes:</label>

                    <label className="pull-right TxtNrml">{temp1}</label>
                    </div>
                    <div className="clearfix"></div>
                        <div  className="form-group">
                    <label>New Balance:</label>
                    </div>
                    <div className="clearfix"></div>
                    <div  className="form-group">
                    <label className="pull-left"> Cash ({obj.CurrencyCode}):</label>

                    <label className="pull-right TxtNrml">{temp}</label>
                    </div>
                    <div className="clearfix"></div>
                    <div  className="form-group">
                    <label className="pull-left">Shares:</label>
                    <label className="pull-right TxtNrml">{temp}</label>
                    </div>
                    </div></td>
                    }
                    return <table key={index} width="100%" className="table table-bordered">
                    <tbody>
                        <tr>

                            <td className="paddAll">
                                <div  className="form-group">
                                    <label> {obj.prodName} </label>
                                </div>
                                <div className="clearfix"></div>
                                <div  className="form-group">
                                    <label className="pull-left"> Yesterday's rate: </label>
                                    <label className="pull-right TxtNrml">{obj["Yesterday's rate"]}</label>
                                </div>
                                <div className="clearfix"></div>
                                <div  className="form-group">
                                    <label> EOD Cut-Off Time: </label>
                                    <label className="pull-right TxtNrml">{obj["EOD Cut-Off Time"]}</label>
                                </div>
                            </td>
                            <td className="paddAll">
                                <div  className="form-group">
                                    <label> Money Fund Account {obj["Money Fund Account"]}  </label>
                                </div>
                                <div  className="form-group">
                                    <label> Funding Account  {obj["Funding Account"]}    </label>
                                </div>
                                <div  className="form-group">
                                    <label>Current Balance(NAV={obj.NAV},  Shadow NAV={obj.Shadow}):    </label>
                                </div>
                                <div  className="form-group">
                                    <label>NAV Type:    </label>
                                    <label className="pull-right TxtNrml">{obj["NAV Type"]}</label>
                                </div>
                                <div  className="form-group">
                                    <label>Cash ({obj.CurrencyCode}):     </label>
                                    <label className="pull-right TxtNrml">{obj.abdbal}</label>
                                </div>
                                <div  className="form-group">
                                    <label>Shares:      </label>
                                    <label className="pull-right TxtNrml">{obj.Shares}</label>
                                </div>

                            {wam}

                            </td>

                            <td className="paddAll">

                            {selectMarkup}

                            </td>


                            {selectMarkup1}


                        </tr>
                    </tbody>
                </table>
                });
            }
        }
        if(this.props.fixed === "fixed"){
            return(
                <div className="col-md-12">
              <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Trade Date </h4>
                    </div>
                    <div className="panel-body">
                       {tradedate}
                    </div>
                </div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Accounts</h4>
                    </div>
                    <div className="panel-body">
                            {entertrademarkup}
                    </div>

                </div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Trade Details </h4>
                    </div>
                    <div className="panel-body">
                            {tradeDetails}
                    </div>
                    </div>
               {buttonMarkup}
            </div>
            )
        }else{
        return(
            <div className="col-md-12">
            <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Trade Date </h4>
                    </div>
                    <div className="panel-body">
                       {tradedate}
                    </div>
                </div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <h4 className="panel-title">Enter Trade</h4>
                    </div>
                    <div className="panel-body">
                            {entertrademarkup}
                    </div>
                </div>
               {buttonMarkup}
            </div>
        );
        }
    }
}
}

export default EnterTrade;