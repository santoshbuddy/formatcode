import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import { MuiThemeProvider } from '@material-ui/core/styles';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { MuiStyles } from '../../styles/MuiStyles';
import Grid from '@material-ui/core/Grid';
import Select from '@material-ui/core/Select';
import MenuItem from "@material-ui/core/MenuItem";
import keyboard_arrow_down from "@material-ui/icons/KeyboardArrowDown";
var selectOptions=[5,10,20,50,100];
class CustomPagination extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectopt: 5,
      inputValue: props.pagiNationProps.page
    }
    // this.handleInputValue = this.handleInputValue.bind(this);
  }
  handleFirstPageButtonClick = event => {
    this.props.pagiNationProps.onPageChange(0);
  };

  handleBackButtonClick = event => {
    this.props.pagiNationProps.onPageChange(this.props.pagiNationProps.page- 1);
  };

  handleNextButtonClick = event => {
    this.props.pagiNationProps.onPageChange(this.props.pagiNationProps.page + 1);
  };

  handleLastPageButtonClick = event => {
    this.props.pagiNationProps.onPageChange( 
      Math.max(0, Math.ceil(this.props.pagiNationProps.count / this.props.pagiNationProps.pageSize) - 1),
    );
  };
  changeInputValue = event => {
    let value = event.target.value;
    if(value > Math.ceil(this.props.pagiNationProps.count / this.props.pagiNationProps.pageSize)) value = Math.ceil(this.props.pagiNationProps.count / this.props.pagiNationProps.pageSize);
    if(value < 0) value = 0;
    console.log(value)
    this.setState({inputValue: value},()=>{
      this.props.pagiNationProps.onPageChange(
         this.state.inputValue-1
      );
    });
  }
  onSelectChange = event => {
    this.props.pagiNationProps.onPageSizeChange(event.target.value);
    this.setState({selectopt:event.target.value})
  }
  render() {
    const { pagiNationProps, classes, theme, type } = this.props;
    // console.log("this.props",this.props)
    return (
      <div className={classes.root}>
        
        <Grid className={classes.paginationDiv}>
        { type === 'senario2' &&
          <Grid className={classes.itemLeft} item xs>
            {/* { type === 'senario1' &&
              <div>
                <span className={classes.selectedTextColor}>{pagiNationProps.page+1} </span>
                <span className={classes.normaltextColor}>of {pagiNationProps.count} selected</span>
              </div>
            } */}
            
              <div>
                {pagiNationProps.count > pagiNationProps.pageSize ?
                  <div>
                    <span className={classes.normaltextColor}>({pagiNationProps.pageSize*(pagiNationProps.page)+1} - {pagiNationProps.pageSize*(pagiNationProps.page+1)> pagiNationProps.count ? pagiNationProps.count:pagiNationProps.pageSize*(pagiNationProps.page+1)}) </span>
                    <span className={classes.normaltextColor}>of {pagiNationProps.count} Listed</span>
                  </div>:
                  <div>
                    <span className={classes.normaltextColor}>{pagiNationProps.count} Listed</span>
                  </div>
                }
              </div>
          </Grid>
            }
            <MuiThemeProvider  theme={muiTableStyles.getMuiTheme()}>
          <Grid className={classes.itemLeft} item xs> 
                  <label className="LabelText" style={{marginTop:'4px'}}> Sort : </label>
                  <Select onChange={this.onSelectChange} value={this.state.selectopt} IconComponent = {keyboard_arrow_down}  className={classes.select} className={"w15"}>
                    {
                      selectOptions && selectOptions.map((item) => {                  
                        return <MenuItem value={item}>{item}</MenuItem>
                      })
                    }
                  </Select>
          </Grid>
          </MuiThemeProvider>
          <Grid className={classes.itemCenter} item xs>
          { type === 'senario1' &&
              <div className={classes.itemsDiv}>
               
         
                <IconButton
                  onClick={this.handleBackButtonClick}
                  aria-label="Previous Page"
                  className={classes.itemAorrow}
                  className={pagiNationProps.page === 0 ?classes.buttonDisable:classes.itemAorrow}
                >
                  {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
                </IconButton>
                <input type="text" className={classes.inputWidth} value={pagiNationProps.page+1} onChange={this.changeInputValue}/>
                <span className={classes.normaltextColor}>  of {Math.ceil(pagiNationProps.count / pagiNationProps.pageSize)}</span>
                <IconButton
                  onClick={this.handleNextButtonClick}
                  aria-label="Next Page"
                  className={(pagiNationProps.page >= Math.ceil(pagiNationProps.count / pagiNationProps.pageSize) - 1)?classes.buttonDisable:classes.itemAorrow}
                >
                  {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
                </IconButton>
              </div>
            }
            { type === 'senario2' &&
              <div>
                {pagiNationProps.count > pagiNationProps.pageSize ?
                  <div className={classes.itemsDiv}>
                    <IconButton
                      onClick={this.handleBackButtonClick}
                      aria-label="Previous Page"
                      className={classes.itemAorrow}
                      className={pagiNationProps.page === 0 ?classes.buttonDisable:classes.itemAorrow}
                    >
                      {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
                    </IconButton>
                    <input type="text" className={classes.inputWidth} value={pagiNationProps.page+1} onChange={this.changeInputValue}/>
                    <span className={classes.normaltextColor}>  of {Math.ceil(pagiNationProps.count / pagiNationProps.pageSize)}</span>
                    <IconButton
                      onClick={this.handleNextButtonClick}
                      aria-label="Next Page"
                      className={(pagiNationProps.page >= Math.ceil(pagiNationProps.count / pagiNationProps.pageSize) - 1)?classes.buttonDisable:classes.itemAorrow}
                    >
                      {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
                    </IconButton>
                  </div>:
                  <div></div>
                }
              </div>
            }
          </Grid>
          <Grid className={classes.itemRight} item xs>
            <button className={classes.buttonOutline} onClick={this.handleFirstPageButtonClick}>
              First Page
            </button>
            <button className={classes.buttonOutline} onClick={this.handleLastPageButtonClick}>
              Last Page
            </button>
          </Grid>
        </Grid>
      </div>
    );
  }
}

CustomPagination.propTypes = {
  classes: PropTypes.object,
  count: PropTypes.number,
  onChangePage: PropTypes.func,
  page: PropTypes.number,
  rowsPerPage: PropTypes.number,
  theme: PropTypes.object,
  pagiNationProps: PropTypes.object
};

const styles = theme => ({
  root: {
    background: '#ffffff',
    width: '100%'
  },
  toolBarDiv: {
    marginTop: '18px',
    textAlign:'right',
    fontSize: '16px',
    padding: '0px !important'
  },
  itemsDiv: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  paginationDiv: {
    textAlign:'center',
    // marginTop: '12px',
    borderTop: '1px solid rgba(0,0,0,0.1)',
    background: 'linear-gradient(#FFFFFF, #F6F7F7)',
    fontSize: '16px',
    padding: '9px 12px',
    color: theme.palette.text.secondary,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  itemCenter:{
    textAlign:'center',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '16px',
    padding: '0px !important'
  },
  itemLeft: {
    textAlign:'left',
    fontSize: '16px',
    padding: '0px !important'
  },
  itemRight: {
    textAlign:'right',
    fontSize: '16px',
    padding: '0px !important'
  },
  selectedTextColor: {
    color: '#0074A6'
  },
  normaltextColor: {
    color: '#666666'
  },
  itemAorrow: {
    padding: '0',
    background:'transparent',
    color: '#0074A6',
    '&:hover': {
      color: "#00395d",
      background: 'transparent'
    },
    '&:active': {
      color: "#666666",
      background: 'transparent'
    },
  },
  buttonDisable: {
    color: '#0074A6',
    opacity: '0.6',
    pointerEvents: 'none',
    padding: '0'
  },
  inputWidth: {
    width: '30px',
    height: '30px',
    fontSize: '16px',
    lineHeight: '12px',
    color: '#555',
    padding: '2px 6px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    textAlign:'right',
    marginRight: '9px'
  },
  buttonFill: {
    color: '#fff',
    backgroundColor: '#0074A6',
    border: '1px solid #0074A6',
    padding: '4px 12px',
    fontSize: '14px',
    borderRadius: '5px',
  },
  buttonOutline: {
    color: '#0074A6',
    fontSize: '14px',
    border: '1px solid #0074A6',
    padding: '4px 12px',
    borderRadius: '5px',
    marginRight: '10px',
    backgroundColor: 'transparent'
  },
  select: {
    width: '175px',
    height: '30px',
    padding: '6px 12px',
    fontSize: '16px',
    lineHeight: '1.42857143',
    color: '#555',
    backgroundColor: '#fff',
    border: '1px solid #ccc',
    borderRadius: '4px',
    margin: '18px 0px 12px 12px',
  }
});
export default withStyles(styles, { withTheme: true })(CustomPagination);
