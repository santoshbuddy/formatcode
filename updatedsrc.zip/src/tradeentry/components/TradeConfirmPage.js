import React from 'react';
import { NavBar } from '../../navbar/components/navbar';
import 'react-tabs/style/react-tabs.css';
import Loading from '../../common/Loading';
import '../../user/css/App.css';
import { connect } from 'react-redux';
import { SelectProduct } from './SelectProduct';
import { tradeActions } from '../actions/trade.actions';
import FormData from 'form-data';
import { Route, Redirect } from 'react-router-dom';
import MMMFEnterTrade from './MMMFEnterTrade';
import MMMFConfirmTrade from './MMMFConfirmTrade';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import StepConnector from '@material-ui/core/StepConnector';
import PropTypes from 'prop-types';
import { MuiThemeProvider, withStyles } from "@material-ui/core/styles";
import { alertConstants } from '../../common/constants/alert.constants';
import Dialog from "@material-ui/core/Dialog";
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import { Link } from 'react-router-dom';
import { muiTableStyles } from '../../styles/muidatatableCss';
import { replaceChars } from './amountValidations';
import Formatter from '../../formats/Formatters';

import axios from 'axios';
import { Typography } from '@material-ui/core';
var dateFormat = require('dateformat');

var frompage = '',
	cnfflag = '',
	errorDescription = '',
	TradeType = '',
	tabItem = '',
	cData = '',
	targetPage = '',
	paramVal = '',
	invtype = '',
	backFlag = 'empty';

const styles = theme => ({
	root: {
		width: "90%"
	},
	button: {
		marginRight: theme.spacing.unit
	},
	instructions: {
		marginBottom: theme.spacing.unit
	},
	connectorActive: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorCompleted: {
		'& $connectorLine': {
			borderColor: "#00395c",
			borderWidth: '2px'
		},
	},
	connectorDisabled: {
		'& $connectorLine': {
			borderColor: theme.palette.grey[100],
			borderWidth: '2px'
		},
	},
	connectorLine: {
		transition: theme.transitions.create('border-color,border-size'),
	},
	stepIcon: {
		color: "#828384",
		fontSize: '19px',
		zIndex: '0',
		"&$active": {
			color: "#00395c",
			fontSize: '37px',
			marginTop: '-10px',
			zIndex: '1'
		},
		"&$completed": {
			color: "#00395c",
			fontSize: '19px'
		}
	},
	active: {},
	completed: {},
	typography: {
		useNextVariants: true,
	},
	iconContainer: {
		paddingRight: "0",
		zIndex: '2'
	},
	stepStyle: {
		paddingRight: "0",
		paddingLeft: "0"
	},
	alternativeLabel: {
		top: '9px',
		left: 'calc(-50% + 9px)',
		right: 'calc(50% + 9px)',
		zIndex: '1',
		fontFamily: 'MyFirstFont',
		src: 'url(../user/css/fonts/ExpertSans-Regular.ttf)',
	},
});

class TradeConfirmPage extends React.Component {
	constructor() {
		super();
		this.state = {
			tableData: [],
		};
	}

	componentDidMount() {
		var transId = '';
		var user = JSON.parse(sessionStorage.getItem('user'));
		var bodyFormdata = new FormData();
		var url1 = alertConstants.URL + "/INVCONF.do";

		if (user[0].token !== undefined) {
			bodyFormdata.append("token", user[0].token);
			bodyFormdata.append("clientFirm", JSON.parse(sessionStorage.getItem('clientFirm')));
		}

		if (this.props.location.state !== undefined) {
			transId = this.props.location.state.transId;
		}

		bodyFormdata.append('transId', transId)

		axios({
			method: 'post',
			url: url1,
			data: bodyFormdata,
			config: { headers: { 'Content-Type': 'multipart/form-data' } }
		}).then((response) => {
			this.setState({ tableData: response.data });
		});
		//this.props.dispatch(tradeActions.fetchTradeReviewData(bodyFormdata));
	}

	render() {
		const { classes } = this.props;
		let fileds = [], ttitle = '';
		let elements;
		var buttonstr = '';
		console.log('tableData--tableData--', this.state.tableData)
		if (this.state.tableData !== '') {
			if (this.state.tableData.Title !== undefined) {
				console.log('this.state.tableData.Title--', this.state.tableData.Title)
				Object.keys(this.state.tableData.Title).map((key) => {
					if (key === 'name') {
						ttitle = this.state.tableData.Title[key];
					}
				});
			}

			if (this.state.tableData.commonData !== undefined) {
				elements = Object.keys(this.state.tableData.commonData).map((key) => {
					console.log("keyyy:::", key)
					console.log("valuee:::", this.state.tableData.commonData[key])
					if (key !== undefined && key.length > 0 && key === "Transaction Amount") {
						return (<tr>
							<td className="w30">{key}:</td>
							<td className="TxtNrml"> {<Formatter currency={this.state.tableData.commonData[key]} />}</td>
						</tr>);
					}
					else if (key !== undefined && key.length > 0 && key === "Booking Date") {
						return (<tr>
							<td className="w30">{key}:</td>
							<td className="TxtNrml"> {<Formatter datetime={this.state.tableData.commonData[key]} />}</td>
						</tr>);
					}
					else if (key !== undefined && key.length > 0 && key === "Approved/Rejected Date/Time") {
						return (
							<tr>
								<td className="w30">{key}:</td>
								{
									this.state.tableData.commonData[key] === "N/A" ?
										<td className="TxtNrml"> {this.state.tableData.commonData[key]}</td>
										:
										<td className="TxtNrml"> {<Formatter datetime={this.state.tableData.commonData[key]} />}</td>
								}
									</tr>
						);
					}
					else if (key !== undefined && key.length > 0 && key !== 'Add/View Notes') {
						return (
							("acctNbr" !== key && "issueChild" !== key && "prodId" !== key && "viewAcctPosFlag" !== key) ?
								<tr>
									<td className="w30">{key}:</td>
									<td className="TxtNrml"> {this.state.tableData.commonData[key]}</td>
								</tr> : ""
						)
					} else {
						return (
							<tr>
								<td className="w30">{key}:</td>
								<td className="TxtNrml"> {replaceChars(this.state.tableData.commonData[key], "<BR>", "")}</td>
							</tr>
						)
					}
				});

				buttonstr = <Link to={{ pathname: '/DEALENT', state: { flag: 'newtrade' } }} className="btn btn-primary btn-xs">Place Another Trade</Link>
			}
		}
		return (
			<div>
				<NavBar />
				<div className="mainContent">
					<Typography variant="h5" component="h3" className="screenTitle">{ttitle}</Typography>
					<div className="col-md-8 col-sm-8" style={{ paddingLeft: '0px' }}>
						<table className="table table-striped table-bordered scrollbodyStyle" width="100%">
							<tbody>{elements}
 							<tr>
							<td colspan='2' ><div className="TxtclrNrml" >Your instruction has been submitted. This will be processed by the Corporate Investment Services Managers.  You may be contacted in the case of any problems. You will be able to view the status of your trade on the "Trade Status" screen.
							</div></td>
							</tr>
							</tbody>
						</table>
						<div className="clearfix"></div>
						<div className="pull-right">
							{buttonstr}
 						 </div>
 						 <div className="clearfix"></div>
						<div className="clearfix"></div>
					</div>
 				</div>
			</div>
		);
	}
}

TradeConfirmPage.propTypes = {
	classes: PropTypes.object,
};


function mapStateToProps(state) {
	const { tradedata } = state;
	state = "";
	return { tradedata };
}

const connectedTradeConfirmPage = connect(mapStateToProps)(withStyles(styles)(TradeConfirmPage));
export { connectedTradeConfirmPage as TradeConfirmPage };