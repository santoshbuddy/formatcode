import React from 'react';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import { connect } from 'react-redux';
import MUIDataTable from "mui-datatables";
import FromData from 'form-data';
import Paper from '@material-ui/core/Paper';
import { tradeActions } from '../actions/trade.actions';

const cols = [
	{
	 name: "Tenor",
	 options: {
		filter: true,
		sort: false,
	 }
	},
	{
	 name: "Maturity Date",
	 options: {
		filter: true,
		sort: false,
	 }
	},{
		name: "Rate",
		options: {
		 filter: true,
		 sort: false,
		}
	},{
		name: "Minimum-Maximum",
		options: {
		 filter: true,
		 sort: false,
		}
	}     
 ];

class TenorPopup extends React.Component {
 constructor(props) {
	    super(props);
	    this.state = {
		open: this.props?this.props.open:false,
		screenName:'',
	 };
}
 componentWillMount() {
	   console.log('componentDidMount this.props.transType :: '+this.props.transType);
		 console.log('componentDidMount this.props.transType :: '+this.props.prodCat);

  			 var bodyFormData = new FromData();
 			bodyFormData.append("issueChild",this.props.issueChild);
			bodyFormData.append("company",this.props.companyid);
			bodyFormData.append("currencyCode",this.props.currency);
			bodyFormData.append("transType",this.props.transType);
			bodyFormData.append("tenorType",this.props.tenorType);
			bodyFormData.append("invstAcct",this.props.investAccount);
			bodyFormData.append("branchId",this.props.branchId);
			bodyFormData.append("dollarAmount",this.props.amount);
			bodyFormData.append("product",this.props.prodCat);
			bodyFormData.append("groupId",this.props.groupId);
			bodyFormData.append("transDate",this.props.transDate);
			

 			this.props.dispatch(tradeActions.fetchTenorpopupData(bodyFormData));

	 }
	 componentWillReceiveProps(nextProps){
		//  console.log("this.props-->",this.props.transDate)
		 if(this.props.transDate !== nextProps.transDate){
			//  console.log("this.props-->",this.props.transDate)
			//  console.log("nextProps--->",nextProps.transDate)
			var bodyFormData = new FromData();
			bodyFormData.append("issueChild",this.props.issueChild);
		 bodyFormData.append("company",this.props.companyid);
		 bodyFormData.append("currencyCode",this.props.currency);
		 bodyFormData.append("transType",this.props.transType);
		 bodyFormData.append("tenorType",this.props.tenorType);
		 bodyFormData.append("invstAcct",this.props.investAccount);
		 bodyFormData.append("branchId",this.props.branchId);
		 bodyFormData.append("dollarAmount",this.props.amount);
		 bodyFormData.append("product",this.props.prodCat);
		 bodyFormData.append("groupId",this.props.groupId);
		 bodyFormData.append("transDate",nextProps.transDate);
		 

			this.props.dispatch(tradeActions.fetchTenorpopupData(bodyFormData));
		 }
	 }
 
  
  handleClose = () => {
    //this.setState({ open: false });
      this.props.doClose();
  };

  render(){
     //console.log("target ...futureFlag ::",this.props.futureFlag);
		const options = {
			filter: true,
			filterType: 'dropdown',
			responsive: 'scroll',
			selectableRows:false,
			pagination: false,
			rowsPerPage: 100,
			onRowClick: (rowData, rowState) => {
				// console.log(rowData,rowState);
				// console.log(TenorreportData)
				// console.log(TenorreportData[rowState.rowIndex])
				this.props.onSelect(TenorreportData[rowState.rowIndex])
				this.handleClose
			}
    };
		
		let {changesVec,tenorpopupData} = this.props;
		
		var TenorreportData = tenorpopupData.tenorpopupData;
		// if(TenorreportData !== undefined)
		// 	console.log('tenorpopupData  onCheckRows :'+JSON.stringify(TenorreportData));

			let data=[];             
			if(TenorreportData && TenorreportData.length>0){
			 	//console.log("TenorreportData length--->",TenorreportData.length)
			 	
			 	let tenorReportDataLen=TenorreportData.length;
			 	if(this.props.futureFlag === "block"){
			 	  tenorReportDataLen=TenorreportData.length-1;
			 	}
			 	
				TenorreportData.map((row,index) => {
				        if(this.props.futureFlag === "block"){
				        if(index <tenorReportDataLen){
				        //console.log("index:::",index)
					let cdata=[];
 					cdata.push(row.Tenor);
					cdata.push(row.MaturityDate);
					cdata.push(row.Rate);
					cdata.push(row.MinimumMaximum);   
					data.push(cdata);
					//console.log("data-future date***->",data)
					}
				      }else{
					//console.log("index:::",index)
					let cdata=[];
					cdata.push(row.Tenor);
					cdata.push(row.MaturityDate);
					cdata.push(row.Rate);
					cdata.push(row.MinimumMaximum);   
					data.push(cdata);
					//console.log("data-normal date-->",data)
				   }
			})
			}
    return (
      <div>
        <Dialog  fullWidth={true}
          maxWidth={'md'}
          open={this.props.open}
          onClose={this.handleClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="form-dialog-title">Tenor</DialogTitle>
          <DialogContent>
           <Paper>

			<MUIDataTable
			data={data}
			columns={cols} options={options} />
 			 </Paper>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} id="popupclose" color="primary">
              Close
            </Button>

          </DialogActions>
        </Dialog>
      </div>
    );
	 
  }
}
function mapStateToProps(state) {
		const { tenorpopupData } = state;
    return { tenorpopupData };
}

 export default connect(mapStateToProps)(TenorPopup)  ;



