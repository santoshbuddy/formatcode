import { messageUS } from '../../common/javascript/i18N/en_US/alerts'
import { messageTr } from '../../common/javascript/i18N/tr_TR/alerts'

export const IsCharsInBag =  function (s,bag) {
	var i;
	var c;

	for(i=0;i<s.length;i++)
	{
		c = s.charAt(i);
		if(bag.indexOf(c) == -1)
		return false;
	}
	return true;
  }
export const addCommasAmount =  function (e) {
        //var userLocale="tr_TR";
        var userLocale="en_US";

	var dec=GetCommaDelimiter(userLocale);

       // Removes commas before adding amount
	var fld=e.target;
        var tempDollarAmt = "";
        var amtDollar     =  fld.value;
        for(var k=0;k<amtDollar.length;k++)
        {
		 var c = amtDollar.charAt(k);
		 if(c !=dec) {
			tempDollarAmt = tempDollarAmt+c;
		 }
        }

        // fld.value = tempDollarAmt;

        var lastElement =0;

        var length      = parseInt(tempDollarAmt.length);
        var sublength   = parseInt(tempDollarAmt.length-1);
        var minilength  = parseInt(tempDollarAmt.length-2);

        lastElement = tempDollarAmt.substring(sublength,length);
        var secondLastElement = tempDollarAmt.substring(sublength,minilength);
        var restString  = tempDollarAmt.substring(0,sublength);
        var strRest     = tempDollarAmt.substring(0,minilength-1);

        if((IsCharsInBag(fld.value,"0123456789MmKk.")==true)){

			if((lastElement=='M' || lastElement=='m')&&
	           (secondLastElement=='M' || secondLastElement=='m' ))
            {
                var data = parseFloat(replaceChars(tempDollarAmt,GetDecimalDelimiter(userLocale),'.')) * 1000000;
                e.target.value = data;

            }
            else
            {
                if((IsCharsInBag(lastElement,"KkMm")==true))
                {
                    var data = parseFloat(replaceChars(tempDollarAmt,GetDecimalDelimiter(userLocale),'.')) * 1000;
                    e.target.value = data;
                }
            }
            }
	       //This Method is in  miscellaneous.js file
	       if(addComma(e,userLocale)==false)
	              return false;
        }

export const addCommasAmntLocale =  function (e,userLocale,redeemflag,obj) {
        //var userLocale="tr_TR";
        //var userLocale="en_US";
	let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
	var dec=GetCommaDelimiter(userLocale);

       // Removes commas before adding amount
	var fld=e.target;
        var tempDollarAmt = "";
        var amtDollar     =  fld.value;
        for(var k=0;k<amtDollar.length;k++)
        {
		 var c = amtDollar.charAt(k);
		 if(c !=dec) {
			tempDollarAmt = tempDollarAmt+c;
		 }
        }

        // fld.value = tempDollarAmt;

        var lastElement =0;

        var length      = parseInt(tempDollarAmt.length);
        var sublength   = parseInt(tempDollarAmt.length-1);
        var minilength  = parseInt(tempDollarAmt.length-2);

        lastElement = tempDollarAmt.substring(sublength,length);
        var secondLastElement = tempDollarAmt.substring(sublength,minilength);
        var restString  = tempDollarAmt.substring(0,sublength);
        var strRest     = tempDollarAmt.substring(0,minilength-1);

	if((IsCharsInBag(secondLastElement,"MmKk")==true) &&(IsCharsInBag(lastElement,"0123456789MmKk,.")==false))
	{
	   obj.setState({alertText:message["PLSEVAM"]});
	    e.target.value="";
	    e.target.focus();
	    return false;
	}
	else if((IsCharsInBag(lastElement,"ABCDEFGHIJLNOPQRSTUVWXYZabcdefghijlnopqrstuvwxyz")==true))
	{
	    obj.setState({alertText:message["PLSEVAM"]});
	    e.target.value="";
	    e.target.focus();
	    return false;
	}
	else if((IsCharsInBag(restString,"0123456789MmKk.,")==false))
	{
        // if(redeemflag)
        //     return true;
        // else{
	        obj.setState({alertText:message["PLSEVAM"]});
	        e.target.value="";
	        e.target.focus();
            return false;
        // }
	}
	else if(isNaN(replaceChars(strRest,GetDecimalDelimiter(userLocale),'.')))
	{
		obj.setState({alertText:message["PLSEVAM"]});
		e.target.value="";
		e.target.focus();
		return false;
	}
	else
        {
        if((IsCharsInBag(fld.value,"0123456789MmKk.")==true)){

			if((lastElement=='M' || lastElement=='m')&&
	           (secondLastElement=='M' || secondLastElement=='m' ))
            {
                var data = parseFloat(replaceChars(tempDollarAmt,GetDecimalDelimiter(userLocale),'.')) * 1000000;
                e.target.value = data;

            }
            else
            {
                if((IsCharsInBag(lastElement,"KkMm")==true))
                {
                    var data = parseFloat(replaceChars(tempDollarAmt,GetDecimalDelimiter(userLocale),'.')) * 1000;
                    e.target.value = data;
                }
            }
            }
	       //This Method is in  miscellaneous.js file
	       if(addComma(e,userLocale)==false)
	              return false;
        }
     }

export const replaceChars =  function (inputString, fromString, toString) {
	// Goes through the inputString and replaces every occurrence of fromString with toString
	var temp = inputString;
	if (fromString == "")
	{
		return inputString;
	}
	if (toString.indexOf(fromString) == -1)
	{ // If the string being replaced is not a part of the replacement string (normal situation)
		while (temp.indexOf(fromString) != -1)
		{
			var toTheLeft = temp.substring(0, temp.indexOf(fromString));
			var toTheRight = temp.substring(temp.indexOf(fromString)+fromString.length, temp.length);
			temp = toTheLeft + toString + toTheRight;
		}
	}
	else
	{ // String being replaced is part of replacement string (like "+" being replaced with "++") - prevent an infinite loop
		var midStrings = new Array("~", "`", "_", "^", "#");
		var midStringLen = 1;
		var midString = "";
		// Find a string that doesn't exist in the inputString to be used
		// as an "inbetween" string
		while (midString == "")
		{
			for (var i=0; i < midStrings.length; i++)
			{
				var tempMidString = "";
				for (var j=0; j < midStringLen; j++)
				{
					tempMidString += midStrings[i];
				}
				if (fromString.indexOf(tempMidString) == -1)
				{
					midString = tempMidString;
					i = midStrings.length + 1;
				}
			}
		} // Keep on going until we build an "inbetween" string that doesn't exist
		// Now go through and do two replaces - first, replace the "fromString" with the "inbetween" string
		while (temp.indexOf(fromString) != -1)
		{
			var toTheLeft = temp.substring(0, temp.indexOf(fromString));
			var toTheRight = temp.substring(temp.indexOf(fromString)+fromString.length, temp.length);
			temp = toTheLeft + midString + toTheRight;
		}
		// Next, replace the "inbetween" string with the "toString"
		while (temp.indexOf(midString) != -1)
		{
			var toTheLeft = temp.substring(0, temp.indexOf(midString));
			var toTheRight = temp.substring(temp.indexOf(midString)+midString.length, temp.length);
			temp = toTheLeft + toString + toTheRight;
		}
	} // Ends the check to see if the string being replaced is part of the replacement string or not
	return temp; // Send the updated string back to the user
} // Ends the "replaceSubstring" function

export const ccyRoundIt =  function (Num,Places,RoundType,userLocale) {

	var decDelimiter=GetDecimalDelimiter(userLocale);
	var commaDelimiter=GetCommaDelimiter(userLocale);
	var rndNumber	="";

	var Number="";
	for(var k=0;k<Num.length;k++)
	{
		var c = Num.charAt(k);
		if(c != commaDelimiter)
		{
			Number = Number+c;
		}
	}

	if (Places > 0)
	{
		if ((Num.toString().length - Num.toString().lastIndexOf(decDelimiter)) > (parseInt(Places) + 1))
		{
			var Rounder = Math.pow(10, Places);
			if(RoundType==0){
				rndNumber = Math.ceil(replaceChars(Number,decDelimiter,'.') * Rounder) / Rounder;
			}else if(RoundType==1){
				rndNumber = Math.floor(replaceChars(Number,decDelimiter,'.') * Rounder) / Rounder;
			}
			else if(RoundType==4){
				rndNumber = Math.round(replaceChars(Number,decDelimiter,'.') * Rounder) / Rounder;
			}else{
				rndNumber = Math.round(replaceChars(Number,decDelimiter,'.') * Rounder) / Rounder;
			}
		}
		else rndNumber =Num;
	}
	else {
		if(RoundType=="0"){
			rndNumber = Math.ceil(replaceChars(Number,decDelimiter,'.'));
		}else if(RoundType=="1"){
			rndNumber = Math.floor(replaceChars(Number,decDelimiter,'.'));
		}
		else if(RoundType=="4"){
			rndNumber = Math.round(replaceChars(Number,decDelimiter,'.'));
		}else{
			rndNumber = Math.round(replaceChars(Number,decDelimiter,'.'));
		}
	}

	if((rndNumber.toString()).indexOf(".")==-1){
		rndNumber=rndNumber+".";
		for(var i=0;i<Places;i++){
			rndNumber	=	rndNumber +"0";
		}
	}else if((rndNumber.toString()).indexOf(".")!=-1){
		var dotIndex	=(rndNumber.toString()).indexOf(".")+1;
		var length		=(rndNumber.toString()).length;

		if((length-dotIndex)!=Places){
			for(var i=0;i<(Places-(length-dotIndex));i++){
				rndNumber	=	rndNumber +"0";
			}
		}
	}

	return rndNumber ;
}
export const addComma =  function (e,userLocale) {

var fld=e.target;
    var amtlen=fld.value.length;

    var temp="";
    var amtcont = fld.value;
    var deci=GetDecimalDelimiter(userLocale);

    var dot = parseInt(amtcont.indexOf(deci))+1;
    var dot1 = parseInt(amtcont.indexOf(deci));
    var comma1;
    var comma="";
    var dollamt;
    var actamount;
    var dec=GetCommaDelimiter(userLocale);
	var roundType ="2";
	var deciCnt ="2";


    actamount = fld.value;

    if(!IsCharsInBag(e.target.value,"0123456789.,"))
        {
           alert("Please enter a valid amount.");
            e.target.value="";
            e.target.focus();
            //e.focus();
            return false;
        }
        else if(dot1 != -1 && isBlank(amtcont.substring(dot,amtlen)))
        {
           alert("Please enter a valid amount.");
            e.target.value="";
            e.target.focus();
            //e.focus();
            return false;
        }
	else if(dot1 != -1 && !IsCharsInBag(amtcont.substring(dot,amtlen),"0123456789"))
	{
	   alert("Please enter a valid amount.");
	    e.target.value="";
	    e.target.focus();
	    //e.focus();
	    return false;
	}
    for(var i=0;i<amtlen;i++)
    {
    	var c = amtcont.charAt(i);
        if(c != dec)
        {
            temp = temp+c;
        }
    }
    amtcont = temp;
    dollamt = temp;
    var amtlen=temp.length;
    var dot = parseInt(amtcont.indexOf(deci));

    if(dot==-1)
    {
		while(amtlen>3)
		{
			comma1 = dec+amtcont.substring(amtlen-3,amtlen);
			comma = comma1+comma;
			amtlen = ((amtcont.substring(0,amtlen-3)).length);
		}
		e.target.value = amtcont.substring(0,amtlen)+comma;
		e.target.value = ccyRoundIt(fld.value,deciCnt,roundType,userLocale);
 		e.target.value = FormatNumber(fld.value,deciCnt,userLocale);
		if(parseInt(fld.value) == 0)
			e.target.value="0.00";
	}
	else
	{
		var dotcont = amtcont.substring(dot,amtlen);
		amtlen = amtlen - ((amtcont.substring(dot,amtlen)).length);
		while(amtlen>3)
		{
			comma1 = dec+amtcont.substring(amtlen-3,amtlen);
			comma = comma1+comma;
			amtlen = ((amtcont.substring(0,amtlen-3)).length);
		}

		var resultAmt = amtcont.substring(0,amtlen)+comma+dotcont;

 		e.target.value = ccyRoundIt(resultAmt,deciCnt,roundType,userLocale);
 		e.target.value = FormatNumber(fld.value,deciCnt,userLocale);
 	}
}
export const isBlank =  function (s) {

	for(var i=0;i<s.length;i++)
	{
       var c = s.charAt(i);
       if (( c != ' ' ) && (c!='\n') && (c!='\t')) return false;
	}
   return true;
}

export const removeCommas =  function (fldValue) {

	return FormatClean(fldValue);
}

/**
 * i18N formatting for numbers
 */

 export const GetDecimalDelimiter =  function (countryCode) {

  switch (countryCode)
  {
    case "tr_TR":
           return ',';
    case "en_US":
           return '.';
    case "pl_PL":
           return ',';
    default:
           return '.';
  }
}

 export const GetCommaDelimiter =  function (countryCode) {

  switch (countryCode)
  {
    case "tr_TR":
           return '.';
    case "en_US":
           return ',';
    case "pl_PL":
           return ' ';
    default:
           return ',';
  }

}
 export const FormatClean =  function (nnum) {
 	 var num =nnum+'';
     var sVal='';
     var nVal = num.length;
     var sChar='';
     var nChar;

  try
   {
       for(var c=0;c<nVal;c++)
      {
         sChar = num.charAt(c);
         nChar = sChar.charCodeAt(0);
         if ((nChar >=48) && (nChar <=57))  { sVal += num.charAt(c);   }
      }
   }
   catch (exception) { console.log("Format Clean",exception); }
    return sVal;
}

 export const FormatNumber =  function (num,decimalPlaces,userLocale) {

  var countryCode;
  countryCode = userLocale;
  var minus='';
  var comma='';
  var dec='';
  var preDecimal='';
  var postDecimal='';

  try
  {

    decimalPlaces = parseInt(decimalPlaces);
    comma = GetCommaDelimiter(countryCode);
    dec = GetDecimalDelimiter(countryCode);

		if (decimalPlaces < 1) { dec = ''; }
		// console.log("num",num)
    // if (IsCharsInBag(num,"-") == true && num.indexOf("-") == 0) { minus='-'; }

    preDecimal = FormatClean(num);

    // preDecimal doesn't contain a number at all.
    // Return formatted zero representation.

    if (preDecimal.length < 1)
    {
       return minus + FormatEmptyNumber(dec,decimalPlaces);
    }

    // preDecimal is 0 or a series of 0's.
    // Return formatted zero representation.

    if (parseFloat(preDecimal) < 1)
    {
       return minus + FormatEmptyNumber(dec,decimalPlaces);
    }

    // predecimal has no numbers to the left.
    // Return formatted zero representation.

    if (preDecimal.length == decimalPlaces)
    {
      return minus + '0' + dec + preDecimal;
    }

    // predecimal has fewer characters than the
    // specified number of decimal places.
    // Return formatted leading zero representation.

    if (preDecimal.length < decimalPlaces)
    {
       if (decimalPlaces == 2)
       {
        return minus + FormatEmptyNumber(dec,decimalPlaces - 1) + preDecimal;
       }
       return minus + FormatEmptyNumber(dec,decimalPlaces - 2) + preDecimal;
    }

    // predecimal contains enough characters to
    // qualify to need decimal points rendered.
    // Parse out the pre and post decimal values
    // for future formatting.

    if (preDecimal.length > decimalPlaces)
    {
      postDecimal = dec + preDecimal.substring(preDecimal.length - decimalPlaces,
                                               preDecimal.length);
      preDecimal = preDecimal.substring(0,preDecimal.length - decimalPlaces);
    }

    // Place comma oriented delimiter every 3 characters
    // against the numeric represenation of the "left" side
    // of the decimal representation.  When finished, return
    // both the left side comma formatted value together with
    // the right side decimal formatted value.

    var regex  = new RegExp('(-?[0-9]+)([0-9]{3})');

    while(regex.test(preDecimal))
    {
       preDecimal = preDecimal.replace(regex, '$1' + comma + '$2');
    }

  }
  catch (exception) { console.log("Format Number",exception); }
  return minus + preDecimal + postDecimal;
}
export const FormatEmptyNumber =  function (decimalDelimiter,decimalPlaces) {
    var preDecimal = '0';
    var postDecimal = '';

    for(var i=0;i<decimalPlaces;i++)
    {
      if (i==0) { postDecimal += decimalDelimiter; }
      postDecimal += '0';
    }
   return preDecimal + postDecimal;
}

export const rateDecimalChange =  function (e,userLocale,rateDecimal,roundType) {
        console.log("mmf .... target ... from rate:",e.target.value)
	var validFlag=true;
	var fldValue=e.target.value;
	if(fldValue.length>0){
		if(fldValue.indexOf(".") != fldValue.lastIndexOf(".")){
		validFlag=false;
		}
		if(IsCharsInBag(fldValue,"1234567890.-") == false)
		{
		validFlag=false;
		}
		if((parseFloat(fldValue) <= parseFloat(0.0)) && (fldValue.indexOf("0.0") != -1 ))
		{
		validFlag=false;
		}

	  if(validFlag)
	     e.target.value = ccyRoundIt(fldValue,rateDecimal,roundType,userLocale);
	  }
        }

export const doValidRates =  function (rateFrom,rateTo,obj) {
 //console.log("target .***.. userLocale::",sessionStorage.getItem('userLocaleTxt'));
let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;
          //alert("dovalidrates...");

	//console.log("target block ....rateFrom::",rateFrom+",rateTo::",rateTo);

	   if(rateFrom.length<=0){
		obj.setState({alertText:message["PEFRMCRR"]});
		// alert (message["PEFRMCRR"]);
		return false;
	   }

	   if(rateFrom.length>0){

	   if(rateFrom.indexOf(".") != rateFrom.lastIndexOf(".")){
		obj.setState({alertText:message["ENTVLFCT"]+"\t"});
		// alert(message["ENTVLFCT"]+"\t");
		return false;
	   }
	  if(IsCharsInBag(rateFrom,"1234567890.-") == false)
	  {
		obj.setState({alertText:message["ENTVLFCT"]});
		// alert(message["ENTVLFCT"]);
		return false;
	  }
	  if((parseFloat(rateFrom) <= parseFloat(0.0)) && (rateFrom.indexOf("0.0") != -1 ))
	  {
		obj.setState({alertText:message["ENFCRTGT"]});
		// alert(message["ENFCRTGT"]);
		return false;
	  }
	  if(rateFrom > 999.999)
	  {
		obj.setState({alertText:message["FCRSBNPT"]});
		// alert (message["FCRSBNPT"]);
		return false;
	  }
	  if(rateFrom == +999.999)
	  {
		obj.setState({alertText:message["PEFCRBNP"]});
		//  alert (message["PEFCRBNP"]);
		 return false;
	  }

	  }


	 if(rateTo.length<=0){
		obj.setState({alertText:message["PENTOCRR"]});
   	//    alert (message["PENTOCRR"]);
	   return false;
	 }

	 if(rateTo.length>0){
	   if(rateTo.indexOf(".") != rateTo.lastIndexOf(".")){
		obj.setState({alertText:message["ENTVLTCR"]+"\t"});
		// alert(message["ENTVLTCR"]+"\t");
		return false;
	   }
	  if(IsCharsInBag(rateTo,"1234567890.-") == false)
	  {
		obj.setState({alertText:message["ENTVLTCR"]});
		// alert(message["ENTVLTCR"]);
		return false;
	  }
	if((parseFloat(rateTo) <= parseFloat(0.0)) && (rateTo.indexOf("0.0") != -1 ))
	{
		obj.setState({alertText:message["ENTTCGTT"]});
	// alert(message["ENTTCGTT"]);
	document.getElementById("rateTo").value="";
	return false;
	}
	  if(rateTo > 999.999)
	  {
		obj.setState({alertText:message["TCRSBNPT"]});
		// alert (message["TCRSBNPT"]);
		return false;
	  }
	  if(rateTo == +999.999)
	  {
		obj.setState({alertText:message["PETCRBNP"]});
		//  alert (message["PETCRBNP"]);
		 return false;
	  }
	  if(parseFloat(rateTo) < parseFloat(rateFrom))
	  {
		obj.setState({alertText:message["FRCRTGTO"]});
		// alert (message["FRCRTGTO"]);
		return false;
	  }

	}
	return true;
}


export const isValidBusinessDate =  function (mdate,holidayStr,weekEndStr,obj) {
  	let message 	= (sessionStorage.getItem('userLocaleTxt')==="tr_TR")?messageTr:messageUS;

	var holidayArr			= new Array();
	var weekEndArr			= new Array();
	var flag				= true;
	var maturityDate		= new Date(mdate)
	var maturityyear		= maturityDate.getYear();
	var maturitymonth		= maturityDate.getMonth();
	var maturityday			= maturityDate.getDate();

	//console.log("target feb072019 maturityDate::",maturityDate+",maturityyear:",maturityyear+",maturitymonth:",maturitymonth+",maturityday:",maturityday);
	if(holidayStr!='' && holidayStr.length>0){
		for(var i=0;holidayStr.length>0,holidayStr.indexOf("~")!= -1 ;i++){
			if(holidayStr.substr(0,holidayStr.indexOf("~")).length >0){
				holidayArr[i]=holidayStr.substr(0,holidayStr.indexOf("~"));
				holidayStr	=holidayStr.substr(holidayStr.indexOf("~")+1,holidayStr.length);
			}
		}
	}
	//console.log("target feb072019 weekEndStr::",weekEndStr)
	if(weekEndStr!='' && weekEndStr.length>0){
		for(var i=0;weekEndStr.length>0,weekEndStr.indexOf("~")!= -1 ;i++){
			if(weekEndStr.substr(0,weekEndStr.indexOf("~")).length >0){
				weekEndArr[i]=weekEndStr.substr(0,weekEndStr.indexOf("~"));
				weekEndStr	=weekEndStr.substr(weekEndStr.indexOf("~")+1,weekEndStr.length);
			}
		}
	}
	var holDate	;
	var toDay;
	var holidayyear,holidaymonth,holidayday;
	//console.log("target feb072019 holidayArr::",holidayArr)

	if(holidayArr!='' && holidayArr.length>0){
		for(var i=0;i<holidayArr.length;i++){
			holDate	= new Date(holidayArr[i]);
			holidayyear			=	holDate.getYear();
			holidaymonth		=	holDate.getMonth();
			holidayday			=	holDate.getDate();

			if((holidayyear == maturityyear) && (holidaymonth == maturitymonth) && (holidayday == maturityday)){
			   flag=false;
			   //alert("111flag::"+flag);
			}
		}
	}
	if(weekEndArr!='' && weekEndArr.length>0){
	  for(var i=0;i<weekEndArr.length;i++){
		toDay	=maturityDate.getDay()+1;

		//console.log("target feb072019 toDay::",toDay+",weekendarr:",weekEndArr[i])

		if(toDay	==	weekEndArr[i]){
		  flag=false;
		  //alert("2222111flag::"+flag);
		}
	  }
	}
	//alert("::last flag::"+flag);
	if(!flag){
		obj.setState({alertText:message["SELECT_BUSDAY"]});
            // alert(message["SELECT_BUSDAY"])
	}
 	return flag;

}
export const addCommaDV =  function (dispAmt, userLocale, deciCnt, roundType)
{
	console.log(dispAmt+' ...'+userLocale+' ...'+deciCnt+' ...'+roundType);
    if(dispAmt!="" && dispAmt!="0.00" && dispAmt != undefined && dispAmt.length>0 && IsCharsInBag(dispAmt,"0123456789MmKk., ")==true)
   {
    	var amtlen=dispAmt.length;
      if(amtlen<=3 || parseFloat(dispAmt) < 1)
    {
        var n = parseFloat(dispAmt).toFixed(deciCnt==0?2:deciCnt);
       return n;

    }
    var temp="";
    var returnStr="";
    var amtcont = dispAmt;
    var deci=GetDecimalDelimiter(userLocale);
    var comma1;
    var comma="";
    var dollamt;
    var actamount;
    var dec=GetCommaDelimiter(userLocale);
    actamount = dispAmt;
    for(var i=0;i<amtlen;i++)
    {
    	var c = amtcont.charAt(i);
        if(c != dec)
        {
            temp = temp+c;
        }
    }
    amtcont = temp;
    dollamt = temp;
    var amtlen=temp.length;
    var dot=-1;
    if(amtcont.indexOf(".")>0){
    	dot = parseInt(amtcont.indexOf(deci));
    }

    if(dot==-1)
    {
		while(amtlen>3)
		{
			comma1 = dec+amtcont.substring(amtlen-3,amtlen);
			comma = comma1+comma;
			amtlen = ((amtcont.substring(0,amtlen-3)).length);
		}
		returnStr = amtcont.substring(0,amtlen)+comma;
		returnStr = ccyRoundIt(returnStr,deciCnt,roundType,userLocale);
 		returnStr = FormatNumber(returnStr,deciCnt,userLocale);
		if(parseInt(dispAmt) == 0)
			returnStr="0.00";
	}
	else
	{
		var dotcont = amtcont.substring(dot,amtlen);
		amtlen = amtlen - ((amtcont.substring(dot,amtlen)).length);
		while(amtlen>3)
		{
			comma1 = dec+amtcont.substring(amtlen-3,amtlen);
			comma = comma1+comma;
			amtlen = ((amtcont.substring(0,amtlen-3)).length);
		}
		returnStr = amtcont.substring(0,amtlen)+comma+dotcont;
 		returnStr = ccyRoundIt(returnStr,deciCnt,roundType,userLocale);
 		returnStr = FormatNumber(returnStr,deciCnt,userLocale);
 	}
 	return returnStr;
   }else{
      return dispAmt;
     }
}

export const addCommasAmt =  function (e,userLocale,redeemflag) {
        //var userLocale="tr_TR";
        //var userLocale="en_US";
        var str;
	var dec=GetCommaDelimiter(userLocale);

       // Removes commas before adding amount
	var amtDollar=e.target.value;
        var tempDollarAmt = "";
        //var amtDollar     =  fld.value;
        //console.log("amtDollar::"+amtDollar);
        str=amtDollar;
        for(var k=0;k<amtDollar.length;k++)
        {
		 var c = amtDollar.charAt(k);
		 if(c !=dec) {
			tempDollarAmt = tempDollarAmt+c;
		 }
        }

        // fld.value = tempDollarAmt;

        var lastElement =0;

        var length      = parseInt(tempDollarAmt.length);
        var sublength   = parseInt(tempDollarAmt.length-1);
        var minilength  = parseInt(tempDollarAmt.length-2);

        lastElement = tempDollarAmt.substring(sublength,length);
        var secondLastElement = tempDollarAmt.substring(sublength,minilength);
        var restString  = tempDollarAmt.substring(0,sublength);
        var strRest     = tempDollarAmt.substring(0,minilength-1);

	if((IsCharsInBag(secondLastElement,"MmKk")==true) &&(IsCharsInBag(lastElement,"0123456789MmKk,.")==false))
	{
	   alert("Please enter a valid amount.");
	    e.target.value="";
	    return false;
	}
	else if((IsCharsInBag(lastElement,"ABCDEFGHIJLNOPQRSTUVWXYZabcdefghijlnopqrstuvwxyz")==true))
	{
	    alert("Please enter a valid amount.");
	    e.target.value="";
	    return false;
	}
	else if((IsCharsInBag(restString,"0123456789MmKk.,")==false))
	{
        if(redeemflag)
            return true;
        else{
	        alert("Please enter a valid amount.");
	        e.target.value="";
            return false;
        }
	}
	else if(isNaN(replaceChars(strRest,GetDecimalDelimiter(userLocale),'.')))
	{
		alert("Please enter a valid amount.");
		e.target.value="";
		return false;
	}
	else
        {
		if((lastElement=='M' || lastElement=='m') && (secondLastElement=='M' || secondLastElement=='m' ))
	        {
	                var data = parseFloat(replaceChars(tempDollarAmt,GetDecimalDelimiter(userLocale),'.')) * 1000000;
	                e.target.value = data;
	            }
	            else
	            {
	                if((IsCharsInBag(lastElement,"KkMm")==true))
	                {
	                    var data = parseFloat(replaceChars(tempDollarAmt,GetDecimalDelimiter(userLocale),'.')) * 1000;
	                    e.target.value = data;
	                }
	            }
     var dispAmt=e.target.value;
      var amtlen=dispAmt.length;
         if(amtlen<=3){
            return dispAmt;
         }
         var temp="";
         var returnStr=str;
         var amtcont = dispAmt;
         var deci=GetDecimalDelimiter(userLocale);

         var comma1;
         var comma="";
         var dollamt;
         var actamount;
         var dec=GetCommaDelimiter(userLocale);
     	var roundType ="2";
     	var deciCnt ="2";

         actamount = dispAmt;
         for(var i=0;i<amtlen;i++)
         {
         	var c = amtcont.charAt(i);
             if(c != dec)
             {
                 temp = temp+c;
             }
         }
         amtcont = temp;
         dollamt = temp;
         var amtlen=temp.length;
         var dot=-1;
         if(amtcont.indexOf(".")>0){
         	dot = parseInt(amtcont.indexOf(deci));
         }

         if(dot==-1)
         {
     		while(amtlen>3)
     		{
     			comma1 = dec+amtcont.substring(amtlen-3,amtlen);
     			comma = comma1+comma;
     			amtlen = ((amtcont.substring(0,amtlen-3)).length);
     		}
     		returnStr = amtcont.substring(0,amtlen)+comma;
     		//alert("if blk ... returnStr:::"+returnStr+",deciCnt:"+deciCnt);
     		returnStr = ccyRoundIt(returnStr,deciCnt,roundType,userLocale);
      		returnStr = FormatNumber(returnStr,deciCnt,userLocale);

     	}
     	else
     	{
     		var dotcont = amtcont.substring(dot,amtlen);
     		amtlen = amtlen - ((amtcont.substring(dot,amtlen)).length);
     		while(amtlen>3)
     		{
     			comma1 = dec+amtcont.substring(amtlen-3,amtlen);
     			comma = comma1+comma;
     			amtlen = ((amtcont.substring(0,amtlen-3)).length);
     		}
     		returnStr = amtcont.substring(0,amtlen)+comma+dotcont;
      		//alert("else blk ... returnStr:::"+returnStr+",deciCnt:"+deciCnt);
      		returnStr = ccyRoundIt(returnStr,deciCnt,roundType,userLocale);
      		returnStr = FormatNumber(returnStr,deciCnt,userLocale);
      	}
       }

       //alert("result returnStr=="+returnStr);
       e.target.value=returnStr;
       return true;
     }